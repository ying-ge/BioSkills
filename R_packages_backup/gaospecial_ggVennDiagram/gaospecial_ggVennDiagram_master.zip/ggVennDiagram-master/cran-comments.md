regular update
