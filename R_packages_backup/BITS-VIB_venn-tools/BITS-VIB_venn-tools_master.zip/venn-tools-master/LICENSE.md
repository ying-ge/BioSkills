![BITS icon](http://www.vib.be/VIBMediaLibrary/Logos/Service_facilities/BITS_website.jpg)

This work is owned by **<a href="https://www.bits.vib.be" target="_blank">BITS</a>**, the bioinformatics facility of the **<a href="http://www.vib.be" target="_blank">VIB</a>**

This work is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License

You are free to:
Share — to copy, distribute and transmit the work Remix — to adapt the work

Under the following conditions:
Attribution — You must attribute the work referring to the original author and licensor (**VIB**)
(but not in any way that suggests that they endorse you or your use of the work) 

Share Alike — If you alter, transform, or build upon this work, you may distribute the resulting work
only under the same or similar license to this one.

------------
![Creative Commons License](http://i.creativecommons.org/l/by-sa/3.0/88x31.png?raw=true)

This work is licensed under a [Creative Commons Attribution-ShareAlike 3.0 Unported License](http://creativecommons.org/licenses/by-sa/3.0/).
