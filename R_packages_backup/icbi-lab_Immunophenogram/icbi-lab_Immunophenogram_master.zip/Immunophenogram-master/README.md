# Immunophenogram

Ready to use script to calculate the immunophenoscore and the corresponding immunophenogram. Download the folder and replace the EXPR.txt with your own tab-separated expression file.
