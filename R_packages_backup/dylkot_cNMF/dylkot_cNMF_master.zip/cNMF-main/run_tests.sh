#!/usr/bin/env bash
# Simple script to run pytest with specific options

echo "Running pytest..."
pytest -vs tests
