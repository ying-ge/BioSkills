---
name: Feature idea
about: Suggest an idea for this project
---

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**How could we do it?**
A description of actual ways of implementing a feature.
