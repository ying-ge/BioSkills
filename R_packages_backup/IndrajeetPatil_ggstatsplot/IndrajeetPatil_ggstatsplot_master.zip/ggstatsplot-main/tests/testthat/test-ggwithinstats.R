# graphical pairwise comparisons are tested in `test-pairwise-ggsignif.R`

skip_if_not_installed("afex")
skip_if_not_installed("WRS2")
skip_if_not_installed("rstantools")

test_that("default plots", {
  set.seed(123)
  expect_doppelganger(
    title = "default plots - two groups",
    fig = ggwithinstats(
      data = data_bugs_2,
      x = condition,
      y = desire,
      subject.id = subject,
      pairwise.display = "none",
      point.path.args = list(color = "red"),
      centrality.path.args = list(color = "blue", size = 2, alpha = 0.8),
      centrality.point.args = list(size = 3, color = "darkgreen", alpha = 0.5),
      title = "bugs dataset"
    )
  )

  set.seed(123)
  expect_doppelganger(
    title = "default plots - more than two groups",
    fig = ggwithinstats(
      data = WRS2::WineTasting,
      x = Wine,
      y = Taste,
      subject.id = Taster,
      pairwise.display = "none",
      title = "wine tasting data"
    )
  )
})

# sample size labels with centrality.plotting = FALSE (#695) ----------

test_that("sample size labels visible when centrality.plotting is FALSE", {
  set.seed(123)
  expect_doppelganger(
    title = "n labels visible without centrality - within",
    fig = ggwithinstats(
      data = data_bugs_2,
      x = condition,
      y = desire,
      subject.id = subject,
      centrality.plotting = FALSE,
      pairwise.display = "none",
      results.subtitle = FALSE
    )
  )
})

# aesthetic modifications work ------------------------------------------

test_that("aesthetic modifications work", {
  set.seed(123)
  expect_doppelganger(
    title = "ggplot2 commands work",
    fig = ggwithinstats(
      data = WRS2::WineTasting,
      x = Wine,
      y = Taste,
      subject.id = Taster,
      results.subtitle = FALSE,
      pairwise.display = "none",
      ggplot.component = ggplot2::labs(y = "Taste rating")
    )
  )

  set.seed(123)
  expect_doppelganger(
    title = "centrality path can be turned off",
    fig = ggwithinstats(
      iris_long,
      condition,
      value,
      subject.id = id,
      centrality.point.args = list(size = 5, alpha = 0.5, color = "darkred"),
      centrality.path = FALSE,
      results.subtitle = FALSE,
      pairwise.display = "none"
    )
  )
})

test_that("grouped plots work", {
  expect_snapshot_error(grouped_ggwithinstats(
    bugs_long,
    x = condition,
    y = desire
  ))

  set.seed(123)
  snapshot_variant <- if (getRversion() >= "4.7.0") "r-4.7" else NULL
  expect_doppelganger(
    title = "grouped plots - default",
    variant = snapshot_variant,
    fig = grouped_ggwithinstats(
      data = dplyr::filter(bugs_long, condition %in% c("HDHF", "HDLF")),
      x = condition,
      y = desire,
      subject.id = subject,
      grouping.var = gender,
      type = "np"
    )
  )
})

# subject.id pairing ------------------------------------------

test_that("subject.id pairs unsorted rows and drops incomplete subjects", {
  # subject 10 has a missing `HDHF` rating
  set.seed(123)
  df_shuffled <- data_bugs_2[sample(nrow(data_bugs_2)), ]

  subtitle_statistic <- function(data) {
    p <- ggwithinstats(data, condition, desire, subject.id = subject)
    extract_stats(p)$subtitle_data$statistic
  }
  expect_identical(
    subtitle_statistic(df_shuffled),
    subtitle_statistic(data_bugs_2)
  )

  set.seed(123)
  expect_doppelganger(
    title = "subject.id unsorted - two groups",
    fig = ggwithinstats(
      data = df_shuffled,
      x = condition,
      y = desire,
      subject.id = subject
    )
  )

  # subjects 2 and 10 have missing ratings
  set.seed(123)
  df_three <- dplyr::filter(
    bugs_long,
    subject <= 20L,
    condition %in% c("HDHF", "HDLF", "LDHF")
  )
  df_three <- df_three[sample(nrow(df_three)), ]

  set.seed(123)
  expect_doppelganger(
    title = "subject.id unsorted - three groups",
    fig = ggwithinstats(
      data = df_three,
      x = condition,
      y = desire,
      subject.id = subject,
      pairwise.display = "all"
    )
  )
})

test_that("subject.id must be unique within each condition", {
  df_duplicated <- data.frame(
    condition = c("A", "A", "B", "A", "B"),
    score = c(1, 2, 3, 4, 5),
    id = c(1, 1, 1, 2, 2)
  )

  expect_snapshot_error(ggwithinstats(
    df_duplicated,
    condition,
    score,
    subject.id = id
  ))
})

test_that("type stays the fourth argument and subject.id follows it", {
  arg_names <- names(formals(ggwithinstats))

  expect_identical(
    arg_names[seq_len(6L)],
    c("data", "x", "y", "type", "subject.id", "pairwise.display")
  )
})

test_that("subject.id drops partially observed subjects from the plotting data", {
  df_missing <- data.frame(
    condition = c("A", "B", "A", "B", "A", "B"),
    score = c(1, 2, 3, NA, 4, 5),
    id = c(1, 1, 2, 2, 3, 3)
  )

  point_data <- build_within_plot(df_missing, subject.id = id)$data[[1L]]

  expect_shape(point_data, nrow = 4L)
  expect_setequal(point_data$group, c(1, 2))
})

test_that("incomplete anonymous pairs are excluded from the plotting data", {
  df_missing <- data.frame(
    condition = c("A", "A", "A", "B", "B", "B"),
    score = c(1, 3, 4, 2, NA, 5)
  )

  built_plot <- build_within_plot(df_missing)

  expect_shape(built_plot$data[[1L]], nrow = 4L)
  expect_setequal(built_plot$plot$data$.rowid, c(1, 3))

  # unequal number of rows across conditions
  df_unbalanced <- data.frame(
    condition = c("A", "A", "A", "B", "B"),
    score = c(1, 3, 4, 2, 5)
  )

  built_plot <- build_within_plot(df_unbalanced)

  expect_setequal(built_plot$plot$data$.rowid, c(1, 2))
})

test_that("rows with a missing condition do not drop complete subjects", {
  df_missing_x <- data.frame(
    condition = c("A", "B", NA, "A", "B"),
    score = c(1, 2, 9, 3, 4),
    id = c(1, 1, 1, 2, 2)
  )

  point_data <- build_within_plot(df_missing_x, subject.id = id)$data[[1L]]
  expect_setequal(point_data$group, c(1, 2))

  point_data <- build_within_plot(df_missing_x)$data[[1L]]
  expect_shape(point_data, nrow = 4L)
})

test_that("missing subject.id values are excluded from paired grouping", {
  df_missing_id <- data.frame(
    condition = c("A", "B", "A", "B", "A", "B"),
    score = c(1, 2, 3, 4, 5, 6),
    id = c(1, 1, NA, NA, 2, 2)
  )

  point_data <- build_within_plot(df_missing_id, subject.id = id)$data[[1L]]

  expect_shape(point_data, nrow = 4L)
  expect_setequal(point_data$group, c(1, 2))
})

test_that("empty condition levels are dropped after filtering missing subject.id values", {
  df_missing_id_levels <- data.frame(
    condition = factor(
      c("A", "B", "C", "A", "B", "C"),
      levels = c("A", "B", "C")
    ),
    score = c(1, 2, 3, 4, 5, 6),
    id = c(1, 1, NA, 2, 2, NA)
  )

  built_plot <- build_within_plot(
    df_missing_id_levels,
    subject.id = id,
    centrality.plotting = FALSE
  )

  path_layers <- purrr::keep(
    built_plot$plot$layers,
    \(layer) inherits(layer$geom, "GeomPath")
  )
  expect_length(path_layers, 1L)
})

test_that("subject.id column stays available to user-supplied layers", {
  for (subject_id in list(quote(subject), "subject")) {
    p <- ggwithinstats(
      data = data_bugs_2,
      x = condition,
      y = desire,
      subject.id = !!subject_id,
      results.subtitle = FALSE,
      ggplot.component = ggplot2::geom_text(ggplot2::aes(label = subject))
    )

    expect_identical(p$data$subject, p$data$.rowid)
    expect_no_error(ggplot2::ggplot_build(p))
  }
})

# user caption is kept when no Bayes Factor caption is shown ----------

test_that("user caption is retained without a Bayes Factor caption", {
  p <- ggwithinstats(
    data = data_bugs_2,
    x = condition,
    y = desire,
    subject.id = subject,
    bf.message = FALSE,
    pairwise.display = "none",
    caption = "my caption"
  )

  expect_identical(ggplot2::get_labs(p)$caption, "my caption")
})
