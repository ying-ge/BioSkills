# data for paired tests
set.seed(123)
survey_data <- dplyr::tibble(
  `1st survey` = c("Approve", "Approve", "Disapprove", "Disapprove"),
  `2nd survey` = c("Approve", "Disapprove", "Approve", "Disapprove"),
  Counts = c(794L, 150L, 86L, 570L)
)

survey_data_NA <- dplyr::tibble(
  `1st survey` = c("Approve", "Approve", "Disapprove", "Disapprove"),
  `2nd survey` = c("Approve", "Disapprove", "Approve", "Disapprove"),
  Counts = c(794L, 150L, NA_integer_, 570L)
)


# checking default outputs -----------------------------------------

test_that("checking default outputs", {
  set.seed(123)
  expect_doppelganger(
    title = "checking one-way table - without NA",
    fig = ggbarstats(mtcars, cyl, ratio = c(0.2, 0.2, 0.6))
  )

  set.seed(123)
  expect_doppelganger(
    title = "checking one-way table - with NA",
    fig = ggbarstats(ggplot2::msleep, vore)
  )

  set.seed(123)
  expect_doppelganger(
    title = "checking unpaired two-way table - without NA",
    fig = ggbarstats(mtcars, am, vs, ratio = c(0.4, 0.6))
  )

  set.seed(123)
  expect_doppelganger(
    title = "checking unpaired two-way table - with NA",
    fig = ggbarstats(ggplot2::msleep, conservation, vore)
  )

  set.seed(123)
  expect_doppelganger(
    title = "checking paired two-way table - without NA",
    fig = ggbarstats(
      survey_data,
      `1st survey`,
      `2nd survey`,
      counts = Counts,
      paired = TRUE,
      ratio = c(0.4, 0.6)
    )
  )

  set.seed(123)
  expect_doppelganger(
    title = "checking paired two-way table - with NA",
    fig = ggbarstats(
      data = survey_data_NA,
      x = `1st survey`,
      y = `2nd survey`,
      counts = Counts,
      paired = TRUE
    )
  )
})

# changing labels and aesthetics -------------------------------------------

test_that("changing labels and aesthetics", {
  set.seed(123)
  expect_doppelganger(
    title = "checking percentage labels",
    fig = ggbarstats(
      data = mtcars,
      x = cyl,
      y = am,
      label = "percentage",
      results.subtitle = FALSE
    )
  )

  set.seed(123)
  expect_doppelganger(
    title = "checking count labels",
    fig = ggbarstats(
      data = mtcars,
      x = cyl,
      y = am,
      label = "counts",
      results.subtitle = FALSE
    )
  )

  set.seed(123)
  expect_doppelganger(
    title = "checking percentage and count labels",
    fig = ggbarstats(
      data = mtcars,
      x = cyl,
      y = am,
      label = "both",
      results.subtitle = FALSE
    )
  )

  set.seed(123)
  expect_doppelganger(
    title = "changing aesthetics works",
    fig = suppressWarnings(
      ggbarstats(
        data = mtcars,
        x = am,
        y = cyl,
        digits.perc = 2L,
        title = "mtcars dataset",
        palette = "wesanderson::Royal2",
        ggtheme = ggplot2::theme_bw(),
        label = "counts",
        legend.title = "transmission",
        results.subtitle = FALSE
      )
    )
  )

  # data
  df <- structure(
    list(
      epoch = structure(
        c(1L, 2L, 1L, 2L, 1L, 2L, 1L, 2L),
        levels = c("Before", "After"),
        class = "factor"
      ),
      mode = structure(
        c(1L, 1L, 2L, 2L, 3L, 3L, 4L, 4L),
        levels = c("A", "P", "C", "T"),
        class = "factor"
      ),
      counts = c(30916L, 21117L, 7676L, 1962L, 1663L, 462L, 7221L, 197L),
      perc = c(65.119, 88.958, 16.168, 8.265, 3.502, 1.946, 15.209, 0.829),
      label = c("65%", "89%", "16%", "8%", "4%", "2%", "15%", "1%")
    ),
    row.names = c(NA, -8L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  set.seed(123)
  expect_doppelganger(
    title = "label repelling works",
    fig = ggbarstats(
      df,
      mode,
      epoch,
      counts = counts,
      label.repel = TRUE,
      type = "bayes"
    )
  )
})

# edge cases ---------------------------------------------------------

test_that("edge cases", {
  # dropped level dataset
  mtcars_small <- dplyr::filter(mtcars, am == "0")

  set.seed(123)
  expect_doppelganger(
    title = "works with dropped levels",
    fig = ggbarstats(mtcars_small, cyl, am)
  )

  set.seed(123)
  expect_doppelganger(
    title = "prop test fails with dropped levels",
    fig = ggbarstats(mtcars_small, am, cyl)
  )
})

# expression output --------------------------------------------------

test_that("expression output", {
  set.seed(123)
  p_sub <- ggbarstats(
    data = ggplot2::msleep,
    x = conservation,
    y = vore,
    digits = 4L
  ) |>
    extract_subtitle()

  set.seed(123)
  stats_output <- suppressWarnings(contingency_table(
    data = ggplot2::msleep,
    x = conservation,
    y = vore,
    digits = 4L
  ))$expression[[1L]]

  expect_identical(p_sub, stats_output)
})

test_that("one-sample expression output", {
  set.seed(123)
  p_sub <- ggbarstats(mtcars, x = cyl) |> extract_subtitle()

  set.seed(123)
  stats_output <- contingency_table(
    data = mtcars,
    x = cyl
  )$expression[[1L]]

  expect_identical(p_sub, stats_output)
})

# pairwise comparisons --------------------------------------------------

test_that("pairwise comparisons data is returned for 3+ groups", {
  set.seed(123)
  stats_data <- extract_stats(ggbarstats(mtcars, cyl, am))
  expect_s3_class(stats_data$pairwise_comparisons_data, "tbl_df")
  expect_shape(stats_data$pairwise_comparisons_data, nrow = 3L)
  expect_true(all(
    c("group1", "group2", "p.value") %in%
      names(stats_data$pairwise_comparisons_data)
  ))

  # different p.adjust.method produces different adjusted p-values
  set.seed(123)
  stats_bonf <- extract_stats(
    ggbarstats(mtcars, cyl, am, p.adjust.method = "bonferroni")
  )
  expect_s3_class(stats_bonf$pairwise_comparisons_data, "tbl_df")
  expect_shape(stats_bonf$pairwise_comparisons_data, nrow = 3L)

  # 2 levels: no pairwise data
  set.seed(123)
  stats_data2 <- extract_stats(ggbarstats(mtcars, am, vs))
  expect_null(stats_data2$pairwise_comparisons_data)

  # paired test: no pairwise data
  set.seed(123)
  stats_paired <- extract_stats(ggbarstats(
    survey_data,
    `1st survey`,
    `2nd survey`,
    counts = Counts,
    paired = TRUE
  ))
  expect_null(stats_paired$pairwise_comparisons_data)

  # one-way test: no pairwise data
  set.seed(123)
  stats_data3 <- extract_stats(ggbarstats(mtcars, cyl))
  expect_null(stats_data3$pairwise_comparisons_data)
})

test_that("grouped_ggbarstats produces error when grouping variable not provided", {
  expect_snapshot(grouped_ggbarstats(mtcars, x = cyl, y = am), error = TRUE)
})

test_that("grouped_ggbarstats works", {
  set.seed(123)
  expect_doppelganger(
    title = "grouped_ggbarstats with one-way table",
    fig = grouped_ggbarstats(
      mtcars,
      grouping.var = am,
      x = cyl
    )
  )

  # creating a smaller data frame
  mpg_short <- ggplot2::mpg |>
    dplyr::filter(
      drv %in% c("4", "f"),
      class %in% c("suv", "midsize"),
      trans %in% c("auto(l4)", "auto(l5)")
    )

  # when arguments are entered as bare expressions
  set.seed(123)
  expect_doppelganger(
    title = "grouped_ggbarstats with two-way table",
    fig = grouped_ggbarstats(
      data = mpg_short,
      x = cyl,
      y = class,
      grouping.var = drv,
      label.repel = TRUE
    )
  )
})

# edge cases --------------------

test_that("edge case behavior", {
  df <- data.frame(
    dataset = c("a", "b", "c", "c", "c", "c"),
    measurement = c("old", "old", "old", "old", "new", "new"),
    flag = c("no", "no", "yes", "no", "yes", "no"),
    count = c(6, 8, 8, 62, 6, 33)
  )

  set.seed(123)
  expect_doppelganger(
    title = "common legend when levels are dropped",
    fig = grouped_ggbarstats(
      data = df,
      x = measurement,
      y = flag,
      grouping.var = dataset,
      counts = count,
      results.subtitle = FALSE,
      proportion.test = FALSE
    )
  )
})
