# entire dataset ------------------------------------------------

test_that("checking ggscatterstats with entire dataset", {
  set.seed(123)
  expect_doppelganger(
    title = "parametric correlation - without NAs",
    fig = ggscatterstats(mtcars, wt, mpg, type = "p")
  )

  set.seed(123)
  expect_doppelganger(
    title = "robust correlation - with NAs",
    fig = ggscatterstats(ggplot2::msleep, sleep_total, brainwt, type = "r")
  )
})

# aesthetic modifications work ---------------------------------------------

test_that("aesthetic modifications work", {
  set.seed(123)
  expect_doppelganger(
    title = "changing scales and aesthetics",
    fig = ggscatterstats(
      mtcars,
      wt,
      mpg,
      results.subtitle = FALSE,
      xsidehistogram.args = list(
        fill = "red",
        color = "blue",
        na.rm = TRUE
      ),
      ysidehistogram.args = list(
        fill = "yellow",
        color = "blue",
        na.rm = TRUE
      )
    ) +
      scale_x_continuous(breaks = seq(1, 6, 1), limits = c(1, 6)) +
      scale_y_continuous(breaks = seq(10, 40, 10), limits = c(10, 40))
  )
})

test_that("labeling variables and expressions work as expected", {
  df <- dplyr::filter(ggplot2::msleep, conservation == "lc")

  set.seed(123)
  expect_doppelganger(
    title = "label variable and expression",
    fig = ggscatterstats(
      data = df,
      x = sleep_total,
      y = sleep_cycle,
      label.expression = sleep_total > 17,
      label.var = order,
      results.subtitle = FALSE
    )
  )

  set.seed(123)
  expect_doppelganger(
    title = "no label variable but expression",
    fig = ggscatterstats(
      data = df,
      x = sleep_total,
      y = sleep_cycle,
      label.expression = sleep_total > 17,
      label.var = NULL,
      results.subtitle = FALSE
    )
  )
})

# subtitle output ----------------------------------------------------------

test_that("subtitle output - ggscatterstats", {
  set.seed(123)
  p_sub <- ggscatterstats(
    data = ggplot2::msleep,
    x = sleep_total,
    y = bodywt,
    conf.level = 0.90,
    type = "r"
  ) |>
    extract_subtitle()

  set.seed(123)
  fun_sub <- corr_test(
    data = ggplot2::msleep,
    x = sleep_total,
    y = bodywt,
    conf.level = 0.90,
    type = "r"
  )$expression[[1L]]

  expect_identical(p_sub, fun_sub)
})

# marginal histogram bins and scales ----------------------------------------

test_that("custom marginal histogram bins and scales", {
  set.seed(123)
  expect_doppelganger(
    title = "custom bins and scale for marginal histograms",
    fig = ggscatterstats(
      mtcars,
      wt,
      mpg,
      results.subtitle = FALSE,
      xsidehistogram.args = list(
        fill = "#009E73",
        color = "black",
        na.rm = TRUE,
        binwidth = 0.5
      ),
      ysidehistogram.args = list(
        fill = "#D55E00",
        color = "black",
        na.rm = TRUE,
        bins = 15
      ),
      xsidehistogram.scale = list(breaks = seq(0, 15, 5)),
      ysidehistogram.scale = list(breaks = seq(0, 15, 5))
    )
  )
})

# grouped_ggscatterstats -------------------------------------------------

test_that("grouped_ggscatterstats plotting works as expected", {
  set.seed(123)
  expect_doppelganger(
    title = "defaults work as expected",
    fig = grouped_ggscatterstats(
      data = iris,
      Sepal.Length,
      Petal.Width,
      grouping.var = Species
    )
  )

  set.seed(123)
  expect_doppelganger(
    title = "aesthetic modifications work",
    fig = grouped_ggscatterstats(
      data = ggplot2::msleep,
      x = sleep_total,
      y = bodywt,
      results.subtitle = FALSE,
      grouping.var = vore,
      xlab = "total sleep",
      ylab = "body weight",
      ggplot.component = scale_y_continuous(breaks = seq(0, 6000, 1000))
    )
  )
})

test_that("grouped_ggscatterstats errors when no grouping is present", {
  expect_snapshot_error(
    grouped_ggscatterstats(
      data = iris,
      x = Sepal.Length,
      y = Petal.Width
    )
  )
})
