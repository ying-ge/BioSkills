# grouped_ggcorrmat produces error when grouping isn't specified

    Code
      grouped_ggcorrmat(iris)
    Condition
      Error in `list()`:
      ! argument 1 is empty

