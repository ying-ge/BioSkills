# defaults plots

    argument 1 is empty

# grouped plots work

    argument 1 is empty

