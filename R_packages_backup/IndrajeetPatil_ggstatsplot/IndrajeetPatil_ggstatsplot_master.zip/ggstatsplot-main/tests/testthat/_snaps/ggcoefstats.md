# ggcoefstats doesn't work if no estimate column found

    The tidy data frame *must* contain 'estimate' column.

# works when CIs unavailable

    Elements in `term` column must be unique.

