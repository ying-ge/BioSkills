# grouped_ggbarstats produces error when grouping variable not provided

    Code
      grouped_ggbarstats(mtcars, x = cyl, y = am)
    Condition
      Error in `list()`:
      ! argument 1 is empty

