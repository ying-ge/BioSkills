# grouped functions built without a `.pre` hook capture `.pre = NULL`, so
# codetools reports `.pre(...)` as a call to an undefined global function
utils::globalVariables(".pre")

# nocov start
.p_adjust_text <- function(method) {
  recode(insight::format_capitalize(method), BH = "FDR", Fdr = "FDR")
}
# nocov end

#' @title Shared data-preparation step for two-variable plot functions
#' @name .prep_data
#'
#' @description
#'
#' Selects the specified columns from the data frame, drops rows with missing
#' values, and optionally converts `x` to a factor with unused levels dropped.
#'
#' @inheritParams ggbetweenstats
#'
#' @return A data frame.
#'
#' @autoglobal
#' @noRd
.prep_data <- function(data, x, y, x_as_factor = FALSE) {
  data <- data |>
    select({{ x }}, {{ y }}) |>
    tidyr::drop_na()

  if (x_as_factor) {
    data <- mutate(data, {{ x }} := droplevels(as.factor({{ x }})))
  }

  data
}


# nocov start
#' @noRd
.make_grouped_fn <- function(.fn, .pre = NULL, guides = "collect") {
  function(
    data,
    ...,
    grouping.var,
    plotgrid.args = list(),
    annotation.args = list()
  ) {
    if (!is.null(.pre)) {
      data <- .pre(data, ...)
    }
    .grouped_list(data, {{ grouping.var }}) |>
      purrr::pmap(.f = .fn, ...) |>
      combine_plots(plotgrid.args, annotation.args, guides = guides)
  }
}
# nocov end

#' @title Split data frame into a list by grouping variable
#'
#' @description
#'
#' This function splits the data frame by the levels of the grouping variable.
#' It returns a list with two elements: `data`, a list with one data frame per
#' level, and `title`, a character vector with the corresponding level names.
#'
#' @inheritParams ggbetweenstats
#' @param grouping.var A single grouping variable. A separate plot is created
#'   for each of its levels (in factor level order, or in order of appearance
#'   for character variables). Rows with a missing value in this variable are
#'   removed.
#'
#' @autoglobal
#' @examplesIf identical(Sys.getenv("NOT_CRAN"), "true")
#' ggstatsplot:::.grouped_list(ggplot2::msleep, grouping.var = vore)
#' @keywords internal
.grouped_list <- function(data, grouping.var) {
  data <- as_tibble(data) |> tidyr::drop_na({{ grouping.var }})
  grp_col <- pull(data, {{ grouping.var }})
  grp_fct <- if (is.character(grp_col)) {
    forcats::fct_inorder(grp_col)
  } else {
    as.factor(grp_col)
  }
  data <- mutate(data, {{ grouping.var }} := grp_fct) |>
    group_by({{ grouping.var }})
  list(
    data = group_split(data),
    title = as.character(pull(group_keys(data), 1L))
  )
}


#' @noRd
.validate_palette <- function(palette, default = "ggthemes::gdoc") {
  if (!grepl("::", palette, fixed = TRUE)) {
    # nocov start
    rlang::warn(c(
      "!" = paste0(
        "Palette '",
        palette,
        "' is not in the required 'package::palette' format."
      ),
      i = paste0(
        "Ignoring it and using the default palette '",
        default,
        "' instead."
      ),
      "*" = "Update your code: combine package and palette into one string, e.g., `palette = \"ggsci::nrc_npg\"`."
    ))
    return(default)
  } # nocov end
  palette
}

#' @autoglobal
#' @noRd
.stabilize_x_factor <- function(data, x, ...) {
  x <- ensym(x)
  mutate(data, !!x := factor(!!x, levels(as.factor(!!x))))
}


#' @noRd
.eval_f <- purrr::possibly(
  function(.f, ...) suppressWarnings(suppressMessages(exec(.f, ...))),
  otherwise = NULL
)


#' @noRd
.extract_expression <- function(data) {
  purrr::pluck(data, "expression", 1L)
}


# Callers store the result as `stats_output`, where `extract_stats()` looks up
# `subtitle_df` and `caption_df`.
#' @noRd
.subtitle_caption <- function(
  .f,
  .f.args,
  type,
  bf.message,
  bf.condition = type == "parametric"
) {
  subtitle_df <- .eval_f(.f, !!!.f.args, type = type)
  caption_df <- if (bf.condition && bf.message) {
    .eval_f(.f, !!!.f.args, type = "bayes")
  }

  list(
    subtitle = .extract_expression(subtitle_df),
    caption = .extract_expression(caption_df),
    subtitle_df = subtitle_df,
    caption_df = caption_df
  )
}
