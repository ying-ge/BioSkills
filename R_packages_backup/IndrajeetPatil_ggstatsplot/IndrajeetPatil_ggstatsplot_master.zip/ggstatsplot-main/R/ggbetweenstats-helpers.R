#' @title Compute subtitle and caption for box/violin plots
#' @name .bw_subtitle_caption
#'
#' @description
#'
#' Shared helper for `ggbetweenstats()` and `ggwithinstats()` that builds the
#' argument list for the statistical test function and optionally computes a
#' Bayes Factor caption.
#'
#' @param data Data frame for the statistical test.
#' @param x,y Column name symbols for the grouping and response variables.
#' @param test Character: `"t"` or `"anova"`.
#' @param type Character: statistical test type (e.g. `"parametric"`).
#' @param bf.message Logical: include Bayes Factor caption?
#' @param paired Logical: whether the test is paired (within-subjects).
#' @param subject.id Optional symbol for the subject identifier column
#'   (within-subjects designs only; `NULL` by default, omitted when `NULL`).
#' @inheritParams ggbetweenstats
#'
#' @return A list with elements `subtitle`, `caption`, `subtitle_df`, and
#'   `caption_df`.
#'
#' @autoglobal
#' @noRd
.bw_subtitle_caption <- function(
  data,
  x,
  y,
  test,
  type,
  bf.message,
  bf.prior,
  conf.level,
  digits,
  tr,
  alternative,
  paired,
  subject.id = NULL
) {
  .f.args <- purrr::compact(list(
    data = data,
    x = as_string(x),
    y = as_string(y),
    conf.level = conf.level,
    digits = digits,
    tr = tr,
    paired = paired,
    bf.prior = bf.prior,
    subject.id = subject.id,
    alternative = if (test == "t") alternative
  ))

  .f <- if (test == "t") two_sample_test else oneway_anova
  .subtitle_caption(.f, .f.args, type, bf.message)
}


#' @title Decorate a box/violin comparison plot
#' @name .bw_decorate
#'
#' @description
#'
#' Adds centrality labels, sample-size x-axis labels, pairwise-comparison
#' annotations (ggsignif), and final aesthetic theming shared by
#' `ggbetweenstats()` and `ggwithinstats()`.
#'
#' @param plot A `ggplot` object to decorate.
#' @param data Data frame used for plotting.
#' @param x,y Column name symbols for the grouping and response variables.
#' @param xlab,ylab Axis labels; `NULL` falls back to the names of `x` and `y`.
#' @param pairwise_args A named list of extra arguments forwarded to
#'   [statsExpressions::pairwise_comparisons()]: `paired`, `p.adjust.method`,
#'   and optionally `subject.id`.
#' @inheritParams ggbetweenstats
#' @inheritParams ggwithinstats
#'
#' @return A decorated `ggplot` object.
#'
#' @autoglobal
#' @noRd
.bw_decorate <- function(
  plot,
  data,
  x,
  y,
  type,
  test,
  centrality.plotting,
  centrality.type,
  digits,
  tr,
  centrality.point.args,
  centrality.label.args,
  pairwise.display,
  pairwise.alpha,
  pairwise_args,
  ggsignif.args,
  xlab,
  ylab,
  title,
  subtitle,
  caption,
  ggtheme,
  palette,
  ggplot.component,
  centrality.path = FALSE,
  centrality.path.args = list()
) {
  # centrality tagging
  if (isTRUE(centrality.plotting)) {
    centrality_df <- suppressWarnings(centrality_description(
      data,
      !!x,
      !!y,
      type = centrality.type,
      digits = digits,
      tr = tr
    ))

    plot <- suppressWarnings(.centrality_ggrepel(
      plot = plot,
      centrality_df = centrality_df,
      x = !!x,
      y = !!y,
      centrality.path = centrality.path,
      centrality.path.args = centrality.path.args,
      centrality.point.args = centrality.point.args,
      centrality.label.args = centrality.label.args
    ))
  } else {
    centrality_df <- suppressWarnings(centrality_description(data, !!x, !!y)) # nocov
  }

  # sample size labels on x-axis
  plot <- plot +
    scale_x_discrete(labels = unique(centrality_df$n.expression))

  # ggsignif labels
  seclabel <- NULL

  if (pairwise.display != "none" && test == "anova") {
    pw_args <- c(
      list(data = data, x = x, y = y, type = type, tr = tr, digits = digits),
      pairwise_args
    )
    mpc_df <- suppressWarnings(inject(pairwise_comparisons(!!!pw_args)))

    assign("mpc_df", mpc_df, envir = plot$plot_env)

    plot <- .ggsignif_adder(
      plot = plot,
      mpc_df = mpc_df,
      data = data,
      y = !!y,
      pairwise.display = pairwise.display,
      pairwise.alpha = pairwise.alpha,
      ggsignif.args = ggsignif.args
    )

    seclabel <- .pairwise_seclabel(
      test.description = unique(mpc_df$test),
      pairwise.display = if (type == "bayes") "all" else pairwise.display,
      pairwise.alpha = pairwise.alpha
    )
  }

  # annotations
  .aesthetic_addon(
    plot = plot,
    x = pull(data, !!x),
    xlab = xlab %||% as_name(x),
    ylab = ylab %||% as_name(y),
    title = title,
    subtitle = subtitle,
    caption = caption,
    seclabel = seclabel,
    ggtheme = ggtheme,
    palette = palette,
    ggplot.component = ggplot.component
  )
}


#' @title Adding labels for centrality values
#' @name .centrality_ggrepel
#'
#' @param plot A `ggplot` object for which means are to be displayed.
#' @param centrality_df A data frame produced by
#'   [statsExpressions::centrality_description()].
#' @inheritParams ggbetweenstats
#' @inheritParams ggwithinstats
#' @inheritParams ggrepel::geom_label_repel
#'
#' @autoglobal
#' @noRd
.centrality_ggrepel <- function(
  plot,
  centrality_df,
  x,
  y,
  centrality.path,
  centrality.path.args,
  centrality.point.args,
  centrality.label.args
) {
  # lines connecting mean values across groups
  if (isTRUE(centrality.path)) {
    plot <- plot +
      exec(
        geom_path,
        data = centrality_df,
        mapping = aes({{ x }}, {{ y }}, group = 1L),
        inherit.aes = FALSE,
        !!!centrality.path.args
      )
  }

  plot + # highlight the mean of each group
    exec(
      geom_point,
      mapping = aes({{ x }}, {{ y }}),
      data = centrality_df,
      inherit.aes = FALSE,
      !!!centrality.point.args
    ) + # attach the labels with means to the plot
    exec(
      ggrepel::geom_label_repel,
      data = centrality_df,
      mapping = aes({{ x }}, {{ y }}, label = expression),
      inherit.aes = FALSE,
      parse = TRUE,
      !!!centrality.label.args
    )
}

#' @title Adding `geom_signif` to `ggplot`
#' @name .ggsignif_adder
#'
#' @param plot A `ggplot` object to which `geom_signif` is to be added.
#' @param mpc_df A data frame containing results from pairwise comparisons
#'   (produced by [`pairwise_comparisons()`] function).
#' @inheritParams ggbetweenstats
#'
#' @autoglobal
#'
#' @examples
#' set.seed(123)
#' library(ggplot2)
#'
#' # plot
#' p <- ggplot(iris, aes(Species, Sepal.Length)) +
#'   geom_boxplot()
#'
#' # data frame with pairwise comparison test results
#' df_pair <- pairwise_comparisons(
#'   data = iris,
#'   x = Species,
#'   y = Sepal.Length
#' )
#'
#' # adding a geom for pairwise comparisons
#' ggstatsplot:::.ggsignif_adder(
#'   plot = p,
#'   data = iris,
#'   y = Sepal.Length,
#'   mpc_df = df_pair
#' )
#' @noRd
.ggsignif_adder <- function(
  plot,
  data,
  y,
  mpc_df,
  pairwise.display = "significant",
  pairwise.alpha = 0.05,
  ggsignif.args = list(textsize = 3, tip_length = 0.01, na.rm = TRUE)
) {
  # count all comparisons before filtering, so that bracket spacing stays the
  # same across `pairwise.display` values
  n_comps <- nrow(mpc_df)

  # for Bayes Factor, there will be no "p.value" column
  if ("p.value" %in% names(mpc_df)) {
    mpc_df <- switch(
      .pairwise_display_level(pairwise.display),
      significant = filter(mpc_df, p.value < pairwise.alpha),
      `non-significant` = filter(mpc_df, p.value >= pairwise.alpha),
      mpc_df
    )

    # proceed only if there are any comparisons left to display
    if (nrow(mpc_df) == 0L) {
      return(plot)
    } # nocov
  }

  # arrange the data frame so that annotations are properly aligned
  mpc_df <- arrange(mpc_df, group1, group2)
  y_values <- pull(data, {{ y }})
  y_range <- diff(range(y_values, na.rm = TRUE))

  # ggsignif positions the first bracket at max(y) + range(y) * margin_top.
  # Expressing the legacy 2.5% of max(y) offset in range units preserves the
  # old layout for positive outcomes; clamping at zero keeps brackets above
  # all-negative outcomes.
  # The legacy helper spread all group-pair brackets over n_comps / 20 of the
  # outcome range, so dividing that span among n_comps - 1 gaps gives the
  # equivalent step increase.
  # For a zero range, retain ggsignif's finite default instead of dividing by
  # zero; no range-based offset can separate identical outcomes.
  # User-supplied arguments override these compatibility defaults.
  ggsignif.args <- utils::modifyList(
    list(
      margin_top = if (y_range > 0) {
        0.05 + (0.025 * max(0, y_values)) / y_range
      } else {
        0.05 # nocov
      },
      step_increase = if (n_comps > 1L) n_comps / (20 * (n_comps - 1L)) else 0
    ),
    ggsignif.args
  )

  # adding ggsignif comparisons to the plot
  plot +
    exec(
      ggsignif::geom_signif,
      comparisons = purrr::map2(mpc_df$group1, mpc_df$group2, c),
      map_signif_level = TRUE,
      annotations = as.character(mpc_df$expression),
      test = NULL,
      parse = TRUE,
      !!!ggsignif.args
    )
}

#' @name .pairwise_seclabel
#' @title Pairwise comparison test expression
#'
#' @description
#'
#' This returns an expression containing details about the pairwise comparison
#' test, which comparisons are shown, and the alpha threshold. These details
#' are displayed as the secondary y-axis label in `{ggstatsplot}` plots.
#'
#' @param test.description Text describing the details of the test.
#' @inheritParams ggbetweenstats
#'
#' @examples
#' .pairwise_seclabel("Student's t-test")
#'
#' # non-significant pairwise comparisons
#' .pairwise_seclabel("Student's t-test", pairwise.display = "non-significant")
#'
#' # all pairwise comparisons
#' .pairwise_seclabel("Student's t-test", pairwise.display = "all")
#'
#' # custom alpha threshold
#' .pairwise_seclabel("Student's t-test", pairwise.alpha = 0.01)
#' @autoglobal
#' @noRd
.pairwise_seclabel <- function(
  test.description,
  pairwise.display = "significant",
  pairwise.alpha = 0.05
) {
  # single quote (') needs to be escaped inside glue expressions
  test <- sub("'", "\\'", test.description, fixed = TRUE)
  alpha_label <- format(pairwise.alpha, scientific = FALSE, trim = TRUE)

  display <- .pairwise_display_level(pairwise.display)

  parse(
    text = glue(
      "list('Pairwise test:'~bold('{test}'), 'Bars shown:'~bold('{display}'), alpha == {alpha_label})"
    )
  )
}

#' @title Resolve which pairwise comparisons are displayed
#'
#' @description
#'
#' Maps a (possibly abbreviated) `pairwise.display` value to one of
#' `"significant"`, `"non-significant"`, or `"all"`.
#'
#' @inheritParams ggbetweenstats
#'
#' @noRd
.pairwise_display_level <- function(pairwise.display) {
  if (startsWith(pairwise.display, "s")) {
    "significant"
  } else if (startsWith(pairwise.display, "n")) {
    "non-significant"
  } else {
    "all"
  }
}


#' @title Making aesthetic modifications to the plot
#' @name .aesthetic_addon
#'
#' @param plot Plot to be aesthetically modified.
#' @param x A factor with the `x` axis values; its number of levels sets how
#'   many palette colors are needed.
#' @param seclabel A label for secondary axis.
#' @inheritParams ggbetweenstats
#'
#' @noRd
.aesthetic_addon <- function(
  plot,
  x,
  xlab,
  ylab,
  title,
  subtitle,
  caption,
  seclabel,
  ggtheme,
  palette,
  ggplot.component
) {
  # Validate the requested number of discrete colors before plot rendering.
  paletteer::paletteer_d(palette, nlevels(x))

  plot +
    labs(
      x = xlab,
      y = ylab,
      title = title,
      subtitle = subtitle,
      caption = caption,
      color = xlab
    ) +
    ggtheme +
    # no matter the theme, the following ought to be part of a ggstatsplot plot
    theme(legend.position = "none", panel.grid.major.x = element_blank()) +
    paletteer::scale_color_paletteer_d(palette) +
    scale_y_continuous(
      sec.axis = dup_axis(name = seclabel, breaks = NULL, labels = NULL)
    ) +
    # this is the hail mary way for users to override these defaults
    ggplot.component
}
