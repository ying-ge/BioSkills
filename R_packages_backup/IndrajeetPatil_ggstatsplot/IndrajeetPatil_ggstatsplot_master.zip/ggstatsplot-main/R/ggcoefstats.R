#' @title Dot-and-whisker plots for regression analyses
#' @name ggcoefstats
#'
#' @description
#'
#' Plot with the regression coefficients' point estimates as dots with
#' confidence interval whiskers and other statistical details included as
#' labels.
#'
#' Although the statistical models displayed in the plot may differ based on the
#' class of models being investigated, there are a few aspects of the plot that
#' will be invariant across models:
#'
#'   - Each dot represents an **estimate**, and its whiskers the **confidence
#'     interval** (`95%` by default). Estimates can be effect sizes (for tests
#'     based on the `F`-statistic) or regression coefficients (for tests based
#'     on the `t`-, `chi^2`-, or `z`-statistic), etc. The confidence intervals
#'     can be asymmetric if bootstrapping was used.
#'
#'   - The label attached to each dot provides details from the statistical
#'     test, typically the estimate, statistic, and *p*-value.
#'
#'   - The caption contains model diagnostics, if available, that can be useful
#'     for model selection: the smaller the Akaike's Information Criterion
#'     (**AIC**) and the Bayesian Information Criterion (**BIC**) values, the
#'     "better" the model.
#'
#' @section Summary of graphics:
#'
#' ```{r child="man/rmd-fragments/ggcoefstats_graphics.Rmd"}
#' ```
#'
#' @param x A model object to be tidied, or a tidy data frame from a regression
#'   model. Function internally uses [`parameters::model_parameters()`] to get a
#'   tidy data frame. If a data frame, it *must* contain a column named
#'   `estimate` (estimates of coefficients or other quantities of interest). A
#'   `term` column (names of predictors) is recommended; if absent, terms are
#'   named `term_1`, `term_2`, etc. Columns `conf.low` and `conf.high` are
#'   needed for error bars, `statistic` and `p.value` for labels, and
#'   `std.error` for meta-analysis.
#' @param statistic Relevant statistic for the model (`"t"`, `"f"`, `"z"`, or
#'   `"chi"`) in the label. Relevant only if `x` is a *data frame*; if it is
#'   `NULL` (default), no labels are shown for data frames.
#' @param effectsize.type Effect size for ANOVA-like objects, passed as the
#'   `es_type` argument of [`parameters::model_parameters()`] (Default:
#'   `"omega"`, the unbiased estimator).
#' @param bf.message Logical that decides whether results from running a
#'   Bayesian meta-analysis assuming that the effect size *d* varies across
#'   studies with standard deviation *t* (i.e., a random-effects analysis)
#'   are displayed in the caption. Relevant only if
#'   `meta.analytic.effect = TRUE` and `meta.type = "parametric"` (Default:
#'   `TRUE`).
#' @param subtitle The text for the plot subtitle. Ignored if
#'   `meta.analytic.effect = TRUE`.
#' @param caption The text for the plot caption. It will be replaced by model
#'   fit indices (AIC and BIC), if available, or by the Bayesian meta-analysis
#'   results (see `bf.message`).
#' @param xlab Label for `x` axis. If `NULL` (default), `"estimate"` is used.
#' @param ylab Label for `y` axis. If `NULL` (default), `"term"` is used.
#' @param conf.int Logical that decides whether to display confidence intervals
#'   as error bars (Default: `TRUE`).
#' @param meta.analytic.effect Logical that decides whether to display a
#'   subtitle with results from a meta-analysis via linear (mixed-effects)
#'   models (Default: `FALSE`). If `TRUE`, `subtitle` is ignored. This is mostly
#'   relevant if a data frame with estimates and their standard errors is
#'   entered.
#' @param meta.type Type of statistics used to carry out random-effects
#'   meta-analysis. If `"parametric"` (default), [`metafor::rma()`] will be
#'   used. If `"robust"`, [`metaplus::metaplus()`] will be used. If `"bayes"`,
#'   [`metaBMA::meta_random()`] will be used.
#' @param exclude.intercept Logical that decides whether the intercept should be
#'   excluded from the plot (Default: `FALSE`).
#' @param errorbar.args A list of additional arguments passed to
#'   [`ggplot2::geom_errorbar()`].
#' @param vline Logical that decides whether to display a vertical line at `0`
#'   (Default: `TRUE`).
#' @param vline.args A list of additional arguments passed to
#'   [`ggplot2::geom_vline()`].
#' @param sort If `"none"` (default), do not sort; if `"ascending"` or
#'   `"descending"`, sort by increasing or decreasing coefficient value,
#'   respectively.
#' @param stats.labels Logical that decides whether the statistic and *p*-value
#'   for each coefficient are attached to its dot as a label using `{ggrepel}`
#'   (Default: `TRUE`).
#' @param stats.label.color Color for the labels: either a single color or a
#'   vector with one color per term. If set to `NULL` (default), colors will be
#'   chosen from the specified `palette`.
#' @param stats.label.args A list of additional arguments passed to
#'   [`ggrepel::geom_label_repel()`].
#' @param only.significant If `TRUE`, only stats labels for significant effects
#'   (*p* < `0.05`) are shown (Default: `FALSE`). This can be helpful when a
#'   large number of regression coefficients are to be displayed in a single
#'   plot.
#' @param ... Additional arguments passed to
#'   [`parameters::model_parameters()`].
#' @inheritParams ggbetweenstats
#'
#' @inheritSection statsExpressions::meta_analysis Random-effects meta-analysis
#'
#' @autoglobal
#'
#' @note
#'
#' 1. For meta-analysis, you will be asked to install the needed package
#'   (`{metafor}`, `{metaplus}`, or `{metaBMA}`) if it is unavailable.
#'
#' 2. Rows with a missing `estimate` are always removed. If labels are
#'   requested, rows where `statistic`, `std.error`, or `p.value` is missing
#'   are kept but get no label.
#'
#' 3. New model classes are frequently added to `{easystats}` packages, so it
#'   can help to install their development versions with
#'   `easystats::install_latest()`.
#'
#' @inherit ggbetweenstats return
#'
#' @details For details, see:
#' <https://www.indrapatil.com/ggstatsplot/articles/web_only/ggcoefstats.html>
#'
#' @examplesIf identical(Sys.getenv("NOT_CRAN"), "true")
#' # for reproducibility
#' set.seed(123)
#'
#' # model object
#' mod <- lm(formula = mpg ~ cyl * am, data = mtcars)
#'
#' # creating a plot
#' p <- ggcoefstats(mod)
#'
#' # looking at the plot
#' p
#'
#' # extracting details from statistical tests
#' extract_stats(p)
#'
#' # exclude intercept from the plot
#' ggcoefstats(mod, exclude.intercept = TRUE)
#'
#' # only show significant labels
#' ggcoefstats(mod, only.significant = TRUE)
#'
#' # ANOVA model (F-statistic)
#' ggcoefstats(aov(mpg ~ cyl * am, data = mtcars))
#'
#' # a tidy data frame can also be passed directly (model-free use)
#' ggcoefstats(data.frame(term = c("a", "b", "c"), estimate = c(0.5, -0.2, 1.1)))
#'
#' # without a `term` column (auto-generated)
#' ggcoefstats(data.frame(estimate = c(0.5, -0.2, 1.1)))
#'
#' # tidy data frames can also include stats-label inputs directly
#' df_tidy <- parameters::model_parameters(stats::lm(wt ~ am * cyl, mtcars), ci = 0.95)
#' names(df_tidy) <- c(
#'   "term", "estimate", "std.error", "conf.level", "conf.low",
#'   "conf.high", "statistic", "df.error", "p.value"
#' )
#' df_tidy$p.value[2L] <- 0.42
#'
#' ggcoefstats(
#'   df_tidy,
#'   statistic = "t",
#'   only.significant = TRUE,
#'   stats.label.color = c("firebrick", "grey50", "forestgreen", "navy")
#' )
#'
#' @examplesIf identical(Sys.getenv("NOT_CRAN"), "true") && requireNamespace("lme4", quietly = TRUE)
#' # further arguments can be passed to `parameters::model_parameters()`
#' library(lme4)
#' ggcoefstats(lmer(Reaction ~ Days + (Days | Subject), sleepstudy), effects = "fixed")
#' @export
ggcoefstats <- function(
  x,
  statistic = NULL,
  conf.int = TRUE,
  conf.level = 0.95,
  digits = 2L,
  exclude.intercept = FALSE,
  effectsize.type = "omega",
  meta.analytic.effect = FALSE,
  meta.type = "parametric",
  bf.message = TRUE,
  sort = "none",
  xlab = NULL,
  ylab = NULL,
  title = NULL,
  subtitle = NULL,
  caption = NULL,
  only.significant = FALSE,
  point.args = list(size = 3.0, color = "blue", na.rm = TRUE),
  errorbar.args = list(width = 0, na.rm = TRUE),
  vline = TRUE,
  vline.args = list(linewidth = 1.0, linetype = "dashed"),
  stats.labels = TRUE,
  stats.label.color = NULL,
  stats.label.args = list(
    size = 3.0,
    direction = "y",
    min.segment.length = 0,
    na.rm = TRUE
  ),
  palette = "ggthemes::gdoc",
  ggtheme = ggstatsplot::theme_ggstatsplot(),
  ...
) {
  palette <- .validate_palette(palette)

  # tidy data frame -------------------------

  if (insight::is_model(x)) {
    statistic <- insight::find_statistic(x)

    # converting model object to a tidy data frame
    tidy_df <- tidy_model_parameters(
      model = x,
      es_type = effectsize.type,
      ci = conf.level,
      table_wide = TRUE,
      ...
    )

    # anova objects need further cleaning
    if (all(c("df", "df.error") %in% names(tidy_df))) {
      tidy_df <- mutate(
        tidy_df,
        effectsize = paste0("partial ", effectsize.type, "-squared")
      )
    }
  } else {
    tidy_df <- as_tibble(x)
    # if a data frame is entered then `statistic` is necessary to create labels
    if (is.null(statistic)) stats.labels <- FALSE
  }

  tidy_df <- .preprocess_tidy_data(tidy_df, sort) |>
    filter(!is.na(estimate))

  # if tidy data frame doesn't contain p-value or statistic column, no label
  if (!all(c("p.value", "statistic") %in% names(tidy_df))) {
    stats.labels <- FALSE
  }

  # CIs and intercepts -------------------------

  # if tidy data frame doesn't contain CIs, show only the estimate dots
  if (!"conf.low" %in% names(tidy_df)) {
    tidy_df <- mutate(tidy_df, conf.low = NA, conf.high = NA)
    conf.int <- FALSE
  }

  if (exclude.intercept) {
    tidy_df <- filter(tidy_df, !grepl("(Intercept)", term, ignore.case = TRUE))
  }

  # label -------------------------

  if (stats.labels) {
    tidy_df <- tidy_model_expressions(
      tidy_df,
      statistic,
      digits,
      effectsize.type
    )
  }

  # summary caption -------------------------

  glance_df <- performance::model_performance(x, verbose = FALSE) |>
    as_tibble()

  if (all(c("AIC", "BIC") %in% names(glance_df))) {
    glance_df <- mutate(
      glance_df,
      expression = list(parse(
        text = glue(
          "list(AIC=='{format_value(AIC, 0L)}', BIC=='{format_value(BIC, 0L)}')"
        )
      ))
    )
    caption <- .extract_expression(glance_df)
  }

  # meta analysis -------------------------

  # nocov start
  if (meta.analytic.effect) {
    meta.type <- extract_stats_type(meta.type)

    subtitle_df <- meta_analysis(tidy_df, type = meta.type, digits = digits)
    subtitle <- .extract_expression(subtitle_df)

    if (meta.type == "parametric" && bf.message) {
      caption_df <- suppressWarnings(meta_analysis(
        tidy_df,
        type = "bayes",
        digits = digits
      ))
      caption <- .extract_expression(caption_df)
    }
  }
  # nocov end

  # basic plot -------------------------

  plot_coef <- ggplot(tidy_df, mapping = aes(estimate, term)) +
    exec(geom_point, !!!point.args)

  # adding confidence intervals
  if (conf.int) {
    plot_coef <- plot_coef +
      exec(
        geom_errorbar,
        mapping = aes(xmin = conf.low, xmax = conf.high),
        orientation = "y",
        !!!errorbar.args
      )
  }

  if (vline) {
    plot_coef <- plot_coef + exec(geom_vline, xintercept = 0, !!!vline.args)
  }

  # ggrepel labels -------------------------

  if (stats.labels) {
    tidy_df_labels <- .prepare_stats_label_data(tidy_df, only.significant)

    # no label layer if no term is left to label (e.g. no significant effects)
    if (nrow(tidy_df_labels) > 0L) {
      stats.label.color <- .prepare_stats_label_colors(
        tidy_df,
        tidy_df_labels,
        stats.label.color,
        palette
      )

      plot_coef <- plot_coef +
        exec(
          ggrepel::geom_label_repel,
          data = tidy_df_labels,
          mapping = aes(x = estimate, y = term, label = expression),
          parse = TRUE,
          color = stats.label.color,
          !!!stats.label.args
        )
    }
  }

  # annotations ---------------------------------------------

  plot_coef +
    labs(
      x = xlab %||% "estimate",
      y = ylab %||% "term",
      caption = caption,
      subtitle = subtitle,
      title = title
    ) +
    ggtheme +
    theme(plot.caption = element_text(size = 10))
}


#' @noRd
.preprocess_tidy_data <- function(data, sort) {
  # nocov start
  if (is.null(data) || !"estimate" %in% names(data)) {
    rlang::abort("The tidy data frame *must* contain 'estimate' column.")
  }
  # nocov end

  # create a new term column if it's not present
  if (!"term" %in% names(data)) {
    data <- mutate(data, term = paste0("term_", row_number()))
  }

  # check if there are repeated terms (relevant for `maov`, `lqm`, etc.)
  # nocov start
  if (anyDuplicated(data$term)) {
    data <- tidyr::unite(
      data,
      col = "term",
      matches(
        "term|variable|parameter|method|curve|response|component|contrast|group"
      ),
      remove = TRUE,
      sep = "_"
    )
  }

  # halt if there are still repeated terms
  if (anyDuplicated(data$term)) {
    rlang::abort("Elements in `term` column must be unique.")
  }
  # nocov end

  data <- parameters::sort_parameters(data, sort = sort, column = "estimate")

  # `ggplot2` draws discrete y-axis levels from bottom to top, so reverse the
  # factor levels to preserve the data order in the plotted top-to-bottom order.
  mutate(data, term = forcats::fct_rev(forcats::fct_inorder(term)))
}

#' @noRd
.prepare_stats_label_data <- function(data, only.significant) {
  if (only.significant) {
    data <- filter(data, p.value < 0.05)
  }

  filter(data, lengths(expression) > 0L)
}

#' @noRd
.prepare_stats_label_colors <- function(
  data,
  label_data,
  stats.label.color,
  palette
) {
  if (is.null(stats.label.color)) {
    return(paletteer::paletteer_d(palette, nrow(label_data)))
  }

  if (length(stats.label.color) > 1L) {
    return(stats.label.color[data$term %in% label_data$term])
  }

  stats.label.color # nocov
}
