#' @title Box/Violin plots for between-subjects comparisons
#' @name ggbetweenstats
#'
#' @description
#'
#' A combination of box and violin plots along with jittered data points for
#' between-subjects designs with statistical details included in the plot as a
#' subtitle.
#'
#' @section Summary of graphics:
#'
#' ```{r child="man/rmd-fragments/ggbetweenstats_graphics.Rmd"}
#' ```
#'
#' @param xlab Label for `x` axis variable. If `NULL` (default),
#'   variable name for `x` will be used.
#' @param ylab Label for `y` axis variable. If `NULL` (default),
#'   variable name for `y` will be used.
#' @param p.adjust.method Adjustment method for *p*-values for multiple
#'   comparisons. Possible methods are: `"holm"` (default), `"hochberg"`,
#'   `"hommel"`, `"bonferroni"`, `"BH"`, `"BY"`, `"fdr"`, `"none"`.
#' @param pairwise.display Decides *which* pairwise comparisons to display.
#'   Available options are:
#'   - `"significant"` (abbreviation accepted: `"s"`)
#'   - `"non-significant"` (abbreviation accepted: `"ns"`)
#'   - `"all"`
#'   - `"none"`
#'
#'   You can use this argument to make sure that your plot is not uber-cluttered
#'   when you have multiple groups being compared and scores of pairwise
#'   comparisons being displayed. Pairwise comparisons are carried out (and
#'   displayed) only when `x` has three or more levels. For `type = "bayes"`,
#'   there are no *p*-values, so all comparisons are displayed unless this is
#'   `"none"`.
#' @param pairwise.alpha Numeric alpha threshold used to decide which pairwise
#'   comparisons are displayed when `pairwise.display = "significant"` or
#'   `pairwise.display = "non-significant"` (Default: `0.05`). It is compared
#'   against *p*-values adjusted using `p.adjust.method`.
#' @param bf.message Logical that decides whether to display Bayes Factor in
#'   favor of the *null* hypothesis. This argument is relevant only **for
#'   parametric test** (Default: `TRUE`).
#' @param results.subtitle Decides whether the results of statistical tests are
#'   to be displayed as a subtitle (Default: `TRUE`). Setting this to `FALSE`
#'   also skips the automatic Bayes Factor caption. See the individual
#'   annotation arguments to control other plot details.
#' @param title The text for the plot title.
#' @param subtitle The text for the plot subtitle. Will work only if
#'   `results.subtitle = FALSE`.
#' @param caption The text for the plot caption. It will be replaced by the
#'   Bayes Factor caption whenever that is displayed (see `bf.message`).
#' @param centrality.plotting Logical that decides whether central tendency
#'   measure is to be displayed as a point with a label (Default: `TRUE`).
#'   Function decides which central tendency measure to show depending on the
#'   `type` argument.
#'   - **mean** for parametric statistics
#'   - **median** for non-parametric statistics
#'   - **trimmed mean** for robust statistics
#'   - **MAP estimator** for Bayesian statistics
#'
#'   If you want a different centrality parameter, you can specify this using
#'   `centrality.type` argument.
#' @param centrality.type Decides which centrality parameter is to be displayed.
#'   The default is to choose the same as `type` argument. You can specify this
#'   to be:
#'   - `"parametric"` (for **mean**)
#'   - `"nonparametric"` (for **median**)
#'   - `"robust"` (for **trimmed mean**)
#'   - `"bayes"` (for **MAP estimator**)
#'
#'   Just as `type` argument, abbreviations are also accepted.
#' @param point.args A list of additional aesthetic arguments to be passed to
#'   the [`ggplot2::geom_point()`].
#' @param boxplot.args A list of additional aesthetic arguments passed on to
#'   [`ggplot2::geom_boxplot()`]. By default, the whiskers extend to 1.5 times
#'   the interquartile range (IQR) from the box (Tukey-style). To customize
#'   whisker length, you can use the `coef` parameter, e.g.,
#'   `boxplot.args = list(coef = 3)` for whiskers extending to the most extreme
#'   observations within 3 * IQR of the hinges.
#' @param violin.args A list of additional aesthetic arguments to be passed to
#'   the [`ggplot2::geom_violin()`].
#' @param ggplot.component A `ggplot` component to be added to the plot prepared
#'   by `{ggstatsplot}`. This argument is primarily helpful for `grouped_`
#'   variants of all primary functions. Default is `NULL`. The argument should
#'   be entered as a `{ggplot2}` function or a list of `{ggplot2}` functions.
#' @param palette Name of the discrete palette in `"package::palette"` format
#'   to be used for coloring (via `{paletteer}`). Run
#'   `View(paletteer::palettes_d_names)` to see all available options.
#' @param ... Currently ignored.
#' @param centrality.point.args,centrality.label.args A list of additional aesthetic
#'   arguments to be passed to [`ggplot2::geom_point()`] and
#'   [`ggrepel::geom_label_repel()`] geoms, which are involved in centrality
#'   plotting.
#' @param ggsignif.args A list of additional aesthetic
#'   arguments to be passed to [`ggsignif::geom_signif()`].
#' @param ggtheme A `{ggplot2}` theme. Default value is
#'   [`ggstatsplot::theme_ggstatsplot()`]. Any of the `{ggplot2}` themes (e.g.,
#'   [`ggplot2::theme_bw()`]), or themes from extension packages are allowed
#'   (e.g., `ggthemes::theme_fivethirtyeight()`, `hrbrthemes::theme_ipsum_ps()`,
#'   etc.). But note that sometimes these themes will remove some of the details
#'   that `{ggstatsplot}` plots typically contain. For example, if relevant,
#'   [`ggbetweenstats()`] shows details about multiple comparison test as a
#'   label on the secondary Y-axis. Some themes (e.g.
#'   `ggthemes::theme_fivethirtyeight()`) will remove the secondary Y-axis and
#'   thus the details as well.
#' @param x The grouping (or independent) variable from `data`.
#' @inheritParams statsExpressions::oneway_anova
#' @inheritParams statsExpressions::two_sample_test
#'
#' @section Statistical defaults:
#'
#' This function uses statistically justified defaults that are not
#' user-configurable:
#'
#' - For **parametric tests**, effect sizes use Hedges' *g* for two groups
#'   and omega-squared for three or more groups. These estimators correct for
#'   positive bias, which can be especially relevant in small samples.
#'
#' - **Welch's *t*-test and one-way test** are used instead of Student's
#'   versions, so equal variances are not assumed.
#'
#' Users who need non-default values for these settings can call
#' \code{{statsExpressions}} directly.
#'
#' @inheritSection statsExpressions::centrality_description Centrality measures
#' @inheritSection statsExpressions::two_sample_test Two-sample tests
#' @inheritSection statsExpressions::oneway_anova One-way ANOVA
#' @inheritSection statsExpressions::pairwise_comparisons Pairwise comparison tests
#'
#' @seealso \code{\link{grouped_ggbetweenstats}}, \code{\link{ggwithinstats}},
#'  \code{\link{grouped_ggwithinstats}}
#'
#' @autoglobal
#'
#' @returns A `ggplot` object, which can be further modified with `{ggplot2}`
#'   functions. Use [`extract_stats()`] to get the statistical details shown in
#'   the plot as data frames.
#'
#' @details Rows with a missing value in either `x` or `y` are removed before
#'   plotting and analysis, and unused levels of `x` are dropped.
#'
#' For details, see:
#' <https://www.indrapatil.com/ggstatsplot/articles/web_only/ggbetweenstats.html>
#'
#' @examplesIf identical(Sys.getenv("NOT_CRAN"), "true")
#' # for reproducibility
#' set.seed(123)
#'
#' p <- ggbetweenstats(mtcars, am, mpg)
#' p
#'
#' # extracting details from statistical tests
#' extract_stats(p)
#'
#' # show non-significant pairwise comparisons (needs 3+ groups for ggsignif)
#' ggbetweenstats(mtcars, cyl, mpg, pairwise.display = "non-significant")
#'
#' # show all pairwise comparisons
#' ggbetweenstats(mtcars, cyl, mpg, pairwise.display = "all")
#'
#' # use a stricter alpha threshold for significant pairwise comparisons
#' ggbetweenstats(mtcars, cyl, mpg, pairwise.alpha = 0.001)
#'
#' # modifying defaults
#' ggbetweenstats(
#'   morley,
#'   x    = Expt,
#'   y    = Speed,
#'   type = "robust",
#'   xlab = "The experiment number",
#'   ylab = "Speed-of-light measurement"
#' )
#'
#' # you can remove a specific geom to reduce complexity of the plot
#' ggbetweenstats(
#'   mtcars,
#'   am,
#'   wt,
#'   # to remove violin plot
#'   violin.args = list(width = 0, linewidth = 0, colour = NA),
#'   # to remove boxplot
#'   boxplot.args = list(width = 0),
#'   # to remove points
#'   point.args = list(alpha = 0)
#' )
#' @export
ggbetweenstats <- function(
  data,
  x,
  y,
  type = "parametric",
  pairwise.display = "significant",
  pairwise.alpha = 0.05,
  p.adjust.method = "holm",
  bf.prior = 0.707,
  bf.message = TRUE,
  results.subtitle = TRUE,
  xlab = NULL,
  ylab = NULL,
  caption = NULL,
  title = NULL,
  subtitle = NULL,
  digits = 2L,
  conf.level = 0.95,
  tr = 0.2,
  alternative = "two.sided",
  centrality.plotting = TRUE,
  centrality.type = type,
  centrality.point.args = list(size = 5, color = "darkred"),
  centrality.label.args = list(
    size = 3,
    nudge_x = 0.4,
    segment.linetype = 4,
    min.segment.length = 0
  ),
  point.args = list(
    position = ggplot2::position_jitterdodge(dodge.width = 0.60),
    alpha = 0.4,
    size = 3,
    stroke = 0,
    na.rm = TRUE
  ),
  boxplot.args = list(width = 0.3, alpha = 0.2, na.rm = TRUE),
  violin.args = list(width = 0.5, alpha = 0.2, na.rm = TRUE),
  ggsignif.args = list(textsize = 3, tip_length = 0.01, na.rm = TRUE),
  ggtheme = ggstatsplot::theme_ggstatsplot(),
  palette = "ggthemes::gdoc",
  ggplot.component = NULL,
  ...
) {
  palette <- .validate_palette(palette)

  # data -----------------------------------

  # make sure both quoted and unquoted arguments are allowed
  x <- ensym(x)
  y <- ensym(y)
  type <- extract_stats_type(type)

  data <- .prep_data(data, {{ x }}, {{ y }}, x_as_factor = TRUE)

  # statistical analysis ------------------------------------------

  test <- if (nlevels(pull(data, {{ x }})) < 3L) "t" else "anova"

  if (results.subtitle) {
    stats_output <- .bw_subtitle_caption(
      data = data,
      x = x,
      y = y,
      test = test,
      type = type,
      bf.message = bf.message,
      bf.prior = bf.prior,
      conf.level = conf.level,
      digits = digits,
      tr = tr,
      alternative = alternative,
      paired = FALSE
    )
    subtitle <- stats_output$subtitle
    caption <- stats_output$caption %||% caption
    subtitle_df <- stats_output$subtitle_df
    caption_df <- stats_output$caption_df
  }

  # plot -----------------------------------

  plot_comparison <- ggplot(data, mapping = aes({{ x }}, {{ y }})) +
    exec(geom_point, aes(color = {{ x }}), !!!point.args) +
    exec(geom_boxplot, !!!boxplot.args, outlier.shape = NA) +
    exec(geom_violin, !!!violin.args)

  # decorate and return -----------------------------------

  .bw_decorate(
    plot = plot_comparison,
    data = data,
    x = x,
    y = y,
    type = type,
    test = test,
    centrality.plotting = centrality.plotting,
    centrality.type = centrality.type,
    digits = digits,
    tr = tr,
    centrality.point.args = centrality.point.args,
    centrality.label.args = centrality.label.args,
    pairwise.display = pairwise.display,
    pairwise.alpha = pairwise.alpha,
    pairwise_args = list(
      paired = FALSE,
      p.adjust.method = p.adjust.method
    ),
    ggsignif.args = ggsignif.args,
    xlab = xlab,
    ylab = ylab,
    title = title,
    subtitle = subtitle,
    caption = caption,
    ggtheme = ggtheme,
    palette = palette,
    ggplot.component = ggplot.component
  )
}


#' @title Violin plots for group or condition comparisons in between-subjects
#'   designs repeated across all levels of a grouping variable
#' @name grouped_ggbetweenstats
#'
#' @description
#'
#' Helper function for `ggstatsplot::ggbetweenstats` to apply this function
#' across multiple levels of a given factor and combine the resulting plots
#' using `ggstatsplot::combine_plots`.
#'
#' @inheritParams ggbetweenstats
#' @inheritParams .grouped_list
#' @inheritParams combine_plots
#' @inheritDotParams ggbetweenstats -title
#'
#' @autoglobal
#'
#' @seealso \code{\link{ggbetweenstats}}, \code{\link{ggwithinstats}},
#'  \code{\link{grouped_ggwithinstats}}
#'
#' @inherit ggbetweenstats references
#'
#' @returns A `patchwork` object combining one plot per level of
#'   `grouping.var` (see [`combine_plots()`]). Applying [`extract_stats()`] to
#'   it returns a list with the statistical details for each of these plots.
#'
#' @examplesIf identical(Sys.getenv("NOT_CRAN"), "true")
#' # for reproducibility
#' set.seed(123)
#'
#' library(dplyr, warn.conflicts = FALSE)
#' library(ggplot2)
#'
#' grouped_ggbetweenstats(
#'   data = filter(ggplot2::mpg, drv != "4"),
#'   x = year,
#'   y = hwy,
#'   grouping.var = drv
#' )
#'
#' # modifying individual plots using `ggplot.component` argument
#' grouped_ggbetweenstats(
#'   data = filter(
#'     movies_long,
#'     genre %in% c("Action", "Comedy"),
#'     mpaa %in% c("R", "PG")
#'   ),
#'   x = genre,
#'   y = rating,
#'   grouping.var = mpaa,
#'   ggplot.component = scale_y_continuous(
#'     breaks = seq(1, 9, 1),
#'     limits = (c(1, 9))
#'   ),
#'   annotation.args = list(title = "Ratings by genre for different MPAA ratings")
#' )
#' @export
grouped_ggbetweenstats <- .make_grouped_fn(ggbetweenstats)
