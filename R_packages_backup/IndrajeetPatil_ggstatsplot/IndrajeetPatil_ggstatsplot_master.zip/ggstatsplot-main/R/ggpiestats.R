#' @title Pie charts with statistical tests
#' @name ggpiestats
#'
#' @description
#' Pie charts for categorical data with statistical details included in the plot
#' as a subtitle.
#'
#' @section Summary of graphics:
#'
#' ```{r child="man/rmd-fragments/ggpiestats_graphics.Rmd"}
#' ```
#'
#' @param x The variable to use as the **rows** in the contingency table. Note
#'   that empty factor levels are *not* dropped: they are shown in the legend
#'   and counted (with zero observations) in the statistical test. Use
#'   [`droplevels()`] beforehand if this is not intended.
#' @param y The variable to use as the **columns** in the contingency table.
#'   If `NULL` (default), a one-sample proportion test (a goodness of fit test)
#'   is run for the `x` variable. Otherwise, an appropriate association test is
#'   run.
#' @param proportion.test Logical that decides whether a proportion test for
#'   `x` is carried out for each level of `y`. Defaults to `results.subtitle`.
#'   [`ggbarstats()`] displays only the *p*-values from this test. Always
#'   `FALSE` when `type = "bayes"`, when `y` is `NULL`, or when `x` has only one
#'   level.
#' @param bf.message Logical that decides whether to display the Bayes Factor in
#'   favor of the *null* hypothesis as a caption. Relevant only for
#'   non-Bayesian `type`s and unpaired designs (`paired = FALSE`) (Default:
#'   `TRUE`).
#' @param digits.perc Number of decimal places for percentage labels (Default:
#'   `0L`).
#' @param label Character that decides what each label displays: `"percentage"`
#'   (default), `"counts"`, or `"both"`.
#' @param label.args A list of additional aesthetic arguments passed to
#'   [`ggplot2::geom_label()`] (or [`ggrepel::geom_label_repel()`] if
#'   `label.repel = TRUE`).
#' @param label.repel Logical that decides whether labels are repelled using
#'   `{ggrepel}` to avoid overlaps (Default: `FALSE`).
#' @param legend.title Title text for the legend. If `NULL` (default), the name
#'   of the `x` variable is used.
#' @inheritParams ggbetweenstats
#' @inheritParams statsExpressions::contingency_table
#'
#' @inheritSection statsExpressions::contingency_table Contingency table analyses
#'
#' @section Pairwise comparisons:
#' When there is a two-way table, `x` has more than two levels, and
#' `paired = FALSE`, pairwise contingency table analyses (Fisher's exact tests)
#' are computed using [statsExpressions::pairwise_contingency_table()]. These
#' results are **not** displayed in the plot: unlike the brackets in box/violin
#' plots, pie and bar charts (which are designed to stay visually congruent)
#' have no natural or established way to show pairwise comparisons. Retrieve
#' them as a data frame with `extract_stats(plot)$pairwise_comparisons_data`.
#'
#' @seealso [grouped_ggpiestats()], [ggbarstats()], [grouped_ggbarstats()]
#'
#' @autoglobal
#'
#' @inherit ggbetweenstats return
#'
#' @details Rows with a missing value in `x`, `y`, or `counts` are removed
#'   before plotting and analysis.
#'
#' For details, see:
#' <https://www.indrapatil.com/ggstatsplot/articles/web_only/ggpiestats.html>
#'
#' @examplesIf identical(Sys.getenv("NOT_CRAN"), "true")
#' # for reproducibility
#' set.seed(123)
#'
#' # one sample goodness of fit proportion test
#' p <- ggpiestats(mtcars, vs)
#'
#' # looking at the plot
#' p
#'
#' # extracting details from statistical tests
#' extract_stats(p)
#'
#' # association test (or contingency table analysis)
#' ggpiestats(mtcars, vs, cyl)
#'
#' # Bayesian test
#' ggpiestats(mtcars, vs, cyl, type = "bayes")
#'
#' # with repelled labels to avoid overlapping
#' ggpiestats(mtcars, vs, label.repel = TRUE)
#'
#' # show counts instead of percentages
#' ggpiestats(mtcars, vs, label = "counts")
#'
#' # show both counts and percentages
#' ggpiestats(mtcars, vs, label = "both")
#'
#' # using pre-aggregated data with counts
#' ggpiestats(as.data.frame(Titanic), Survived, counts = Freq)
#'
#' @export
ggpiestats <- function(
  data,
  x,
  y = NULL,
  counts = NULL,
  type = "parametric",
  paired = FALSE,
  results.subtitle = TRUE,
  label = "percentage",
  label.args = list(direction = "both"),
  label.repel = FALSE,
  digits = 2L,
  proportion.test = results.subtitle,
  digits.perc = 0L,
  bf.message = TRUE,
  ratio = NULL,
  alternative = "two.sided",
  conf.level = 0.95,
  p.adjust.method = "holm",
  title = NULL,
  subtitle = NULL,
  caption = NULL,
  legend.title = NULL,
  ggtheme = ggstatsplot::theme_ggstatsplot(),
  palette = "ggthemes::gdoc",
  ggplot.component = NULL,
  ...
) {
  palette <- .validate_palette(palette)

  # data frame ------------------------------------------

  x <- ensym(x)
  y <- if (!quo_is_null(enquo(y))) ensym(y)
  type <- extract_stats_type(type)

  prep <- .pie_bar_data_prep(
    data = data,
    x = {{ x }},
    y = {{ y }},
    counts = {{ counts }}
  )
  data <- prep$data
  test <- prep$test
  x_levels <- prep$x_levels
  y_levels <- prep$y_levels

  facet <- y_levels > 1L
  if ((x_levels == 1L && facet) || type == "bayes") {
    proportion.test <- FALSE
  }

  # statistical analysis ------------------------------------------

  if (results.subtitle) {
    stats_output <- .pie_bar_subtitle_caption(
      data = data,
      x = {{ x }},
      y = {{ y }},
      type = type,
      paired = paired,
      bf.message = bf.message,
      alternative = alternative,
      conf.level = conf.level,
      digits = digits,
      ratio = ratio,
      x_levels = x_levels,
      y_levels = y_levels,
      p.adjust.method = p.adjust.method
    )
    subtitle <- stats_output$subtitle
    caption <- stats_output$caption %||% caption
  }

  # plot ------------------------------------------

  # data frame with summary labels
  descriptive_df <- descriptive_data(data, {{ x }}, {{ y }}, label, digits.perc)

  # data frame containing all details needed for proportion test
  if (test == "two.way") {
    onesample_df <- onesample_data(data, {{ x }}, {{ y }}, digits, ratio)
  }

  # Validate the requested number of discrete colors before plot rendering.
  paletteer::paletteer_d(palette, x_levels)

  # creating the basic plot
  plotPie <- ggplot(descriptive_df, mapping = aes(x = "", y = perc)) +
    geom_col(
      mapping = aes(fill = {{ x }}),
      position = "fill",
      color = "black",
      width = 1.0
    )

  # whether labels need to be repelled
  .fn <- if (label.repel) ggrepel::geom_label_repel else ggplot2::geom_label

  # adding label with percentages and/or counts
  suppressWarnings(suppressMessages({
    plotPie <- plotPie +
      exec(
        .fn,
        mapping = aes(label = .label, group = {{ x }}),
        position = position_fill(vjust = 0.5),
        min.segment.length = 0,
        fill = "white",
        alpha = 1.0,
        na.rm = TRUE,
        show.legend = FALSE,
        !!!label.args
      )
  }))

  # if facet_wrap *is* happening
  if (facet) {
    plotPie <- plotPie + facet_wrap(facets = vars({{ y }}))
  }

  # polar coordinates plus formatting
  plotPie <- plotPie +
    coord_polar(theta = "y") +
    scale_y_continuous(breaks = NULL) +
    paletteer::scale_fill_paletteer_d(palette, name = "", drop = FALSE) +
    ggtheme +
    theme(panel.grid = element_blank(), axis.ticks = element_blank()) +
    guides(fill = guide_legend(override.aes = list(color = NA)))

  # sample size + proportion test ------------------------------------------

  if (facet && proportion.test) {
    plotPie <- plotPie +
      geom_text(
        data = onesample_df,
        mapping = aes(label = .label, x = 1.65, y = 0.5),
        position = position_fill(vjust = 1.0),
        size = 2.8,
        parse = TRUE
      )
  }

  # annotations ------------------------------------------

  plotPie +
    labs(
      x = NULL,
      y = NULL,
      subtitle = subtitle,
      title = title,
      caption = caption
    ) +
    guides(fill = guide_legend(title = legend.title %||% as_name(x))) +
    ggplot.component
}


#' @title Grouped pie charts with statistical tests
#' @name grouped_ggpiestats
#'
#' @description
#'
#' Applies [`ggpiestats()`] across all levels of `grouping.var` and combines the
#' resulting plots using [`combine_plots()`].
#'
#' @inheritParams ggpiestats
#' @inheritParams grouped_ggbetweenstats
#' @inheritDotParams ggpiestats -title
#'
#' @seealso [ggpiestats()], [ggbarstats()], [grouped_ggbarstats()]
#'
#' @autoglobal
#'
#' @inherit ggpiestats details
#' @inherit grouped_ggbetweenstats return
#'
#' @examplesIf identical(Sys.getenv("NOT_CRAN"), "true")
#' set.seed(123)
#' # grouped one-sample proportion test
#' grouped_ggpiestats(
#'   data = mtcars,
#'   x = cyl,
#'   grouping.var = am,
#'   annotation.args = list(title = "Cylinder distribution by transmission type")
#' )
#' @export
grouped_ggpiestats <- .make_grouped_fn(ggpiestats, .pre = .stabilize_x_factor)
