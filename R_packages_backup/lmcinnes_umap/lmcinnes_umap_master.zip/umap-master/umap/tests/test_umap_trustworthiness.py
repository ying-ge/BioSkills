import pytest
from umap import UMAP
from umap.validation import trustworthiness_vector
from sklearn.datasets import make_blobs
from sklearn.metrics import pairwise_distances
import numpy as np
import scipy.sparse

try:
    # works for sklearn>=0.22
    from sklearn.manifold import trustworthiness
except ImportError:
    # this is to comply with requirements (scikit-learn>=0.20)
    # More recent versions of sklearn have exposed trustworthiness
    # in top level module API
    # see: https://github.com/scikit-learn/scikit-learn/pull/15337
    from sklearn.manifold.t_sne import trustworthiness

# ===================================================
#  UMAP Trustworthiness Test cases
# ===================================================


def test_umap_sparse_trustworthiness(sparse_test_data):
    embedding = UMAP(n_neighbors=10, n_epochs=100).fit_transform(sparse_test_data[:100])
    trust = trustworthiness(sparse_test_data[:100].toarray(), embedding, n_neighbors=10)
    assert (
        trust >= 0.85
    ), "Insufficiently trustworthy embedding for sparse test dataset: {}".format(trust)


def test_umap_trustworthiness_fast_approx(nn_data):
    data = nn_data[:150]
    embedding = UMAP(
        n_neighbors=10,
        min_dist=0.01,
        random_state=42,
        n_epochs=100,
        force_approximation_algorithm=True,
        init="recursive",
    ).fit_transform(data)
    trust = trustworthiness(data, embedding, n_neighbors=10)
    assert (
        trust >= 0.8
    ), "Insufficiently trustworthy embedding for" "nn dataset: {}".format(trust)


def test_umap_trustworthiness_random_init(nn_data):
    data = nn_data[:150]
    embedding = UMAP(
        n_neighbors=10, min_dist=0.01, random_state=42, n_epochs=200, init="random"
    ).fit_transform(data)
    trust = trustworthiness(data, embedding, n_neighbors=10)
    assert (
        trust >= 0.8
    ), "Insufficiently trustworthy embedding for" "nn dataset: {}".format(trust)


def test_supervised_umap_trustworthiness():
    data, labels = make_blobs(150, cluster_std=0.5, random_state=42)
    embedding = UMAP(
        n_neighbors=10, min_dist=0.01, random_state=42, n_epochs=100
    ).fit_transform(data, labels)
    trust = trustworthiness(data, embedding, n_neighbors=10)
    assert (
        trust >= 0.95
    ), "Insufficiently trustworthy embedding for" "blobs dataset: {}".format(trust)


def test_semisupervised_umap_trustworthiness():
    data, labels = make_blobs(150, cluster_std=0.5, random_state=42)
    labels[10:30] = -1
    embedding = UMAP(
        n_neighbors=10, min_dist=0.01, random_state=42, n_epochs=100
    ).fit_transform(data, labels)
    trust = trustworthiness(data, embedding, n_neighbors=10)
    assert (
        trust >= 0.95
    ), "Insufficiently trustworthy embedding for" "blobs dataset: {}".format(trust)


@pytest.mark.parametrize(
    "compatibility_layout, n_samples, n_epochs, threshold",
    [(True, 50, 100, 0.95), (False, 150, 200, 0.93)],
)
def test_metric_supervised_umap_trustworthiness(
    compatibility_layout, n_samples, n_epochs, threshold
):
    data, labels = make_blobs(n_samples, cluster_std=0.5, random_state=42)
    embedding = UMAP(
        n_neighbors=10,
        min_dist=0.01,
        target_metric="l1",
        target_weight=0.8,
        n_epochs=n_epochs,
        random_state=42,
        compatibility_layout=compatibility_layout,
    ).fit_transform(data, labels)
    trust = trustworthiness(data, embedding, n_neighbors=10)
    assert (
        trust >= threshold
    ), "Insufficiently trustworthy embedding for" "blobs dataset: {}".format(trust)


def test_string_metric_supervised_umap_trustworthiness():
    data, labels = make_blobs(150, cluster_std=0.5, random_state=42)
    labels = np.array(["this", "that", "other"])[labels]
    embedding = UMAP(
        n_neighbors=10,
        min_dist=0.01,
        target_metric="string",
        target_weight=0.8,
        n_epochs=100,
        random_state=42,
    ).fit_transform(data, labels)
    trust = trustworthiness(data, embedding, n_neighbors=10)
    assert (
        trust >= 0.95
    ), "Insufficiently trustworthy embedding for" "blobs dataset: {}".format(trust)


def test_discrete_metric_supervised_umap_trustworthiness():
    data, labels = make_blobs(150, cluster_std=0.5, random_state=42)
    embedding = UMAP(
        n_neighbors=10,
        min_dist=0.01,
        target_metric="ordinal",
        target_weight=0.8,
        n_epochs=100,
        random_state=42,
    ).fit_transform(data, labels)
    trust = trustworthiness(data, embedding, n_neighbors=10)
    assert (
        trust >= 0.95
    ), "Insufficiently trustworthy embedding for" "blobs dataset: {}".format(trust)


def test_count_metric_supervised_umap_trustworthiness():
    data, labels = make_blobs(150, cluster_std=0.5, random_state=42)
    labels = (labels**2) + 2 * labels
    embedding = UMAP(
        n_neighbors=10,
        min_dist=0.01,
        target_metric="count",
        target_weight=0.8,
        n_epochs=100,
        random_state=42,
    ).fit_transform(data, labels)
    trust = trustworthiness(data, embedding, n_neighbors=10)
    assert (
        trust >= 0.95
    ), "Insufficiently trustworthy embedding for" "blobs dataset: {}".format(trust)


def test_sparse_precomputed_metric_umap_trustworthiness():
    data, labels = make_blobs(150, cluster_std=0.5, random_state=42)
    dmat = scipy.sparse.csr_matrix(pairwise_distances(data))
    embedding = UMAP(
        n_neighbors=10,
        min_dist=0.01,
        random_state=42,
        n_epochs=100,
        metric="precomputed",
    ).fit_transform(dmat)
    trust = trustworthiness(data, embedding, n_neighbors=10)
    assert (
        trust >= 0.75
    ), "Insufficiently trustworthy embedding for" "nn dataset: {}".format(trust)


def test_trustworthiness_vector_matches_sklearn():
    # https://github.com/lmcinnes/umap/issues/963
    rng = np.random.RandomState(42)
    data = rng.rand(60, 5)
    embedding = rng.rand(60, 2)
    max_k = 10
    trust = trustworthiness_vector(data, embedding, max_k)
    assert trust.shape == (max_k + 1,)
    for k in range(1, max_k + 1):
        expected = trustworthiness(data, embedding, n_neighbors=k)
        np.testing.assert_allclose(trust[k], expected, rtol=1e-10)
