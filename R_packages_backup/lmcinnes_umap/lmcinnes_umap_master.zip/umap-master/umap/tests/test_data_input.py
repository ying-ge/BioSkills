import numpy as np
import pytest as pytest
import scipy.sparse
from numba import njit
from umap import UMAP


@pytest.fixture(scope="session")
def all_finite_data():
    return np.arange(100.0).reshape(25, 4)


@pytest.fixture(scope="session")
def inverse_data():
    return np.arange(50).reshape(25, 2)


@njit
def nan_dist(a: np.ndarray, b: np.ndarray):
    result = np.zeros(a.shape[0])
    result[0] = np.nan
    result[1] = np.inf
    return 0, result


def test_check_input_data(all_finite_data, inverse_data):
    """
    Data input to UMAP gets checked for liability.
    This tests checks the if data input is dismissed/accepted
    according to the "ensure_all_finite" keyword as used by
    sklearn.

    Parameters
    ----------
    all_finite_data
    inverse_data
    -------

    """

    inf_data = all_finite_data.copy()
    inf_data[0] = np.inf
    nan_data = all_finite_data.copy()
    nan_data[0] = np.nan
    inf_nan_data = all_finite_data.copy()
    inf_nan_data[0] = np.nan
    inf_nan_data[1] = np.inf

    # wrapper to call each data handling function of UMAP in a convenient way
    def call_umap_functions(data, ensure_all_finite):
        u = UMAP(metric=nan_dist)
        if ensure_all_finite is None:
            u.fit_transform(data)
            u.fit(data)
            u.transform(data)
            u.update(data)
            u.inverse_transform(inverse_data)
        else:
            u.fit_transform(data, ensure_all_finite=ensure_all_finite)
            u.fit(data, ensure_all_finite=ensure_all_finite)
            u.transform(data, ensure_all_finite=ensure_all_finite)
            u.update(data, ensure_all_finite=ensure_all_finite)
            u.inverse_transform(inverse_data)

    # Check whether correct data input is accepted
    call_umap_functions(all_finite_data, None)
    call_umap_functions(all_finite_data, True)

    call_umap_functions(nan_data, "allow-nan")
    call_umap_functions(all_finite_data, "allow-nan")

    call_umap_functions(inf_data, False)
    call_umap_functions(inf_nan_data, False)
    call_umap_functions(nan_data, False)
    call_umap_functions(all_finite_data, False)

    # Check whether illegal data raises a ValueError
    with pytest.raises(ValueError):
        call_umap_functions(nan_data, None)
        call_umap_functions(inf_data, None)
        call_umap_functions(inf_nan_data, None)

        call_umap_functions(nan_data, True)
        call_umap_functions(inf_data, True)
        call_umap_functions(inf_nan_data, True)

        call_umap_functions(inf_data, "allow-nan")
        call_umap_functions(inf_nan_data, "allow-nan")


@pytest.mark.parametrize("compatibility_layout", [True, False])
def test_transform_dense_model_with_sparse_input(compatibility_layout):
    data = np.random.RandomState(42).rand(50, 8)
    model = UMAP(
        n_neighbors=5,
        n_epochs=10,
        random_state=42,
        compatibility_layout=compatibility_layout,
    ).fit(data)
    new_data = data[:3] + 0.01
    expected = model.transform(new_data)
    result = model.transform(scipy.sparse.csr_matrix(new_data))
    np.testing.assert_allclose(result, expected)


@pytest.mark.parametrize("compatibility_layout", [True, False])
@pytest.mark.parametrize("metric", ["jaccard", "hamming"])
def test_transform_sparse_model_with_dense_input(metric, compatibility_layout):
    rng = np.random.RandomState(42)
    data = scipy.sparse.random(50, 30, density=0.2, format="csr", random_state=rng)
    model = UMAP(
        metric=metric,
        n_neighbors=5,
        n_epochs=10,
        random_state=42,
        compatibility_layout=compatibility_layout,
    )
    model.fit(data)
    new_data = scipy.sparse.random(3, 30, density=0.2, format="csr", random_state=rng)
    expected = model.transform(new_data)
    result = model.transform(new_data.toarray())
    np.testing.assert_allclose(result, expected)


@pytest.mark.parametrize(
    "kwargs",
    [
        dict(compatibility_layout=True),
        dict(compatibility_layout=False, nearest_neighbor_backend="pynndescent"),
        pytest.param(
            dict(compatibility_layout=False, nearest_neighbor_backend="rinnd"),
            marks=pytest.mark.skipif(
                not __import__("umap.umap_").umap_._HAVE_RINND,
                reason="requires RINND",
            ),
        ),
    ],
)
def test_fit_and_transform_do_not_modify_input(kwargs):
    rng = np.random.RandomState(0)
    data = np.abs(rng.normal(size=(300, 8))).astype(np.float32)
    query = np.abs(rng.normal(size=(20, 8))).astype(np.float32)
    data_copy, query_copy = data.copy(), query.copy()

    model = UMAP(
        metric="cosine",
        n_neighbors=10,
        n_epochs=10,
        random_state=0,
        force_approximation_algorithm=True,
        **kwargs,
    ).fit(data)
    model.transform(query)

    np.testing.assert_array_equal(data, data_copy)
    np.testing.assert_array_equal(query, query_copy)
