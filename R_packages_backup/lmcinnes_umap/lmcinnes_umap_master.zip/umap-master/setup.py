from setuptools import setup

# All package metadata is now defined in pyproject.toml as per PEP 621.
# This setup() call is retained for compatibility or other tooling purposes.
setup()
