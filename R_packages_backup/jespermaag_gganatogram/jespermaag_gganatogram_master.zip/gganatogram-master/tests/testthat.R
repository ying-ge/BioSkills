library(testthat)
library(gganatogram)

test_check("gganatogram")
