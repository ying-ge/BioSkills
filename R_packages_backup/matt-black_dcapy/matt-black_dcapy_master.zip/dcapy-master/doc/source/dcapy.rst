dcapy package
=============

Module contents
---------------

.. automodule:: dcapy
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

dcapy.algo module
-----------------

.. automodule:: dcapy.algo
    :members:
    :undoc-members:
    :show-inheritance:

dcapy.calc module
-----------------

.. automodule:: dcapy.calc
    :members:
    :undoc-members:
    :show-inheritance:

dcapy.validate module
---------------------

.. automodule:: dcapy.validate
    :members:
    :undoc-members:
    :show-inheritance: