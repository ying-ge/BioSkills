Decision Curve Analysis
=======================

"Decision curve analysis is a simple method for evaluating prediction models, diagnostic tests, and molecular markers."

The method was first published as:

Vickers AJ, Elkin, EB. Decision curve analysis: a novel method for evaluating prediction models. Medical Decision Making. 2006 Nov-Dec;26(6):565-74
