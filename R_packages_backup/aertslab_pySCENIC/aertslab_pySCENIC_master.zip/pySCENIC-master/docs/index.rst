.. pySCENIC documentation master file

.. toctree::
   :maxdepth: 2
   :hidden:

   Home <self>
   installation
   tutorial
   faq
   releasenotes

.. include:: ../README.rst

.. Indices and tables
.. ==================

.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`

