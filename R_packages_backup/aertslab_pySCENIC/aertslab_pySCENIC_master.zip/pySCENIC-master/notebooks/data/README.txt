Expression matrix for GSE60361 downloaded from: 
https://www.ncbi.nlm.nih.gov/geo/download/?acc=GSE60361&format=file&file=GSE60361%5FC1%2D3005%2DExpression%2Etxt%2Egz
