---
name: No questions here please!
about: Questions about the results, design, or run strategy for pySCENIC
title: "[results]"
labels: question
assignees: ''

---

For **questions** about using SCENIC, please use the Discussions: https://github.com/aertslab/SCENIC/discussions/

Create an issue only to report **bugs**.

> Mote that most *errors* are due to the input from the user, and therefore should be treated as questions in the Discussions. Please, only report them as bugs if you are quite certain that they are not behaving as expected.
