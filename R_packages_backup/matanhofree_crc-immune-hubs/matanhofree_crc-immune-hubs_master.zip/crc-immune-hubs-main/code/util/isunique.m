function isu = isunique(inV)
    
    isu = numel(inV) == luniq(inV(:));

end