function n = luniq(x)
    n = length(unique(x));
end
