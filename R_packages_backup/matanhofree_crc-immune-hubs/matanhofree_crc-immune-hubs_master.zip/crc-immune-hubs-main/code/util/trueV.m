function outV = trueV(posIdx,vSize)
    
    outV = false(vSize,1);
    outV(posIdx) = 1;

end