mg14's favourite R functions
----


This repository contains mg14's favourite R functions. It's early days, eventually this shall be transformed into an R package.


###Installation

	> library(devtools); install_github("mg14/mg14")
