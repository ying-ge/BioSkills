# gglayer 0.0.4

+ CRAN release
  - geom_cake
  - geom_ord_ellipse
  - geom_segment_c
  - geom_triangle
  