context("result-parsers")
skip_on_cran()

#setup (guarded so transient NCBI problems skip rather than abort the file)
ncbi_ok <- tryCatch({
    raw_rec <- entrez_fetch(db="pubmed", id=20674752, rettype="xml")
    xml_rec <- entrez_fetch(db="pubmed", id=20674752, rettype="xml", parsed=TRUE)
    multi_rec <- entrez_fetch(db="pubmed",
                               id=c(22883857, 25042335, 20203609,11959827),
                               rettype="xml", parsed=TRUE)
    parsed_raw <- parse_pubmed_xml(raw_rec)
    parsed_rec <- parse_pubmed_xml(xml_rec)
    parsed_multi <- parse_pubmed_xml(multi_rec)
    multi_pmid_eg <- parse_pubmed_xml(
           entrez_fetch(db="pubmed", id='29743284', rettype="xml")
    )
    TRUE
}, error = ncbi_setup_failed)

test_that("pubmed file parsers work",{
    skip_without_ncbi(ncbi_ok)
    expect_that(raw_rec, is_a("character"))

    expect_that(parsed_raw, is_a("pubmed_record"))
    expect_that(parsed_rec, is_a("pubmed_record"))
    expect_that(names(parsed_rec), is_a("character"))
    expect_that(parsed_rec$pmid, is_identical_to("20674752"))

    expect_that(parsed_multi, is_a("multi_pubmed_record"))
    expect_that(parsed_multi[[1]], is_a("pubmed_record"))
    expect_that(length(parsed_multi), equals(4))

    # Older (buggier) versions of the pubmed parser included data from every
    # record in an xml file in each parsed record. If that error is
    # re-introduced there will be 25 authors in each record and this will fail
    expect_that(length(parsed_multi[[1]]$authors), equals(1))

    # Bug #131 related to extracting all PMIDs from a pubmed xml that contained
    # references, not just the one true pm od teh artcle. Testing we don't
    # regress

    expect_that(length(multi_pmid_eg$pmid), equals(1))

})

test_that("we can print pubmed records", {
    skip_without_ncbi(ncbi_ok)
    expect_output(print(parsed_rec), "Pubmed record")
    expect_output(print(parsed_multi), "List of 4 pubmed records")
})

test_that("We warn about unknown pubmed record types", {
    skip_without_ncbi(ncbi_ok)
    rec = net(entrez_fetch(db="pubmed", id=25905152, rettype="xml"))
    expect_warning(parsed_rec <- parse_pubmed_xml(rec))
    expect_output(print(parsed_rec), "Pubmed record \\(empty\\)")
})
