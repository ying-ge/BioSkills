#' Search the NCBI databases using EUtils
#'
#' Search a given NCBI database with a particular query.
#'
#' The NCBI uses a search term syntax where search terms can be associated with 
#' a specific search field with square brackets. So, for instance ``Homo[ORGN]''
#' denotes a search for Homo in the ``Organism'' field. The names and
#' definitions of these fields can be identified using
#' \code{\link{entrez_db_searchable}}.
#'
#' Searches can make use of several fields by combining them via the boolean
#' operators AND, OR and NOT. So, using the search term``((Homo[ORGN] AND APP[GENE]) NOT
#' Review[PTYP])'' in PubMed would identify articles matching the gene APP in
#' humans, and exclude review articles. More examples of the use of these search
#' terms, and the more specific MeSH terms for precise searching, 
#' is given in the package vignette. \code{rentrez} handles special characters
#' and URL encoding (e.g. replacing spaces with plus signs) on the client side,
#' so there is no need to include these in search term
#'
#' The\code{rentrez} tutorial provides some tips on how to make the most of 
#' searches to the NCBI. In particular, the sections on uses of the "Filter"
#' field and MeSH terms may in formulating precise searches. 
#' 
#'@export
#'@param db character, name of the database to search for.
#'@param term character, the search term. The syntax used in making these
#'searches is described in the Details of this help message, the package
#'vignette and reference given below.
#'@param use_history logical. If TRUE return a web_history object for use in 
#' later calls to the NCBI
#'@param retmode character, one of xml (default) or json.
#'@param \dots character, additional terms to add to the request, see NCBI
#'documentation linked to in references for a complete list
#'@param config vector configuration options passed to httr::GET  
#'@seealso \code{\link[httr]{config}} for available httr configurations 
#'@seealso \code{\link{entrez_db_searchable}} to get a set of search fields that
#' can be used in \code{term} for any database
#'@return ids integer Unique IDS returned by the search
#'@return count integer Total number of hits for the search
#'@return retmax integer Maximum number of hits returned by the search
#'@return web_history A web_history object for use in subsequent calls to NCBI
#'@return QueryTranslation character, search term as the NCBI interpreted it
#'@return file either and XMLInternalDocument xml file resulting from search, parsed with
#'\code{\link[XML]{xmlTreeParse}} or, if \code{retmode} was set to json a list
#' resulting from the returned JSON file being parsed with
#' \code{\link[jsonlite]{fromJSON}}.
#'@references \url{https://www.ncbi.nlm.nih.gov/books/NBK25499/#_chapter4_ESearch_} 
#'@examples
#' \dontrun{
#'    query <- "Gastropoda[Organism] AND COI[Gene]"
#'    web_env_search <- entrez_search(db="nuccore", query, use_history=TRUE)
#'    cookie <- web_env_search$WebEnv
#'    qk <- web_env_search$QueryKey 
#'    snail_coi <- entrez_fetch(db = "nuccore", WebEnv = cookie, query_key = qk,
#'                              file_format = "fasta", retmax = 10)
#'}
#'\dontrun{
#' 
#' fly_id <- entrez_search(db="taxonomy", term="Drosophila")
#' #Oh, right. There is a genus and a subgenus name Drosophila...
#' #how can we limit this search
#' (tax_fields <- entrez_db_searchable("taxonomy"))
#' #"RANK" loots promising
#' tax_fields$RANK
#' entrez_search(db="taxonomy", term="Drosophila & Genus[RANK]")
#'}

entrez_search <- function(db, term, config=NULL, retmode="xml", use_history=FALSE, ... ){
    usehistory <- if(use_history) "y" else "n"
    response <- make_entrez_query("esearch", 
                                  db=db, 
                                  term=term, 
                                  config=config,
                                  retmode=retmode, 
                                  usehistory=usehistory,
                                  ...)
    parsed <- parse_response(response, retmode)
    parse_esearch(parsed, history=use_history)
}


parse_esearch <- function(x, history) UseMethod("parse_esearch")

#Build the message for an esearch reply that carried no result, quoting what
#NCBI said when it said anything. Mirrors elink_failure() in entrez_link.r.
#NCBI reports the reason in the body of an otherwise ordinary HTTP 200 reply,
#and it arrives as an <ERROR> node in xml or an ERROR field in json.
esearch_failure <- function(what, x){
    said <- if(inherits(x, "XMLInternalDocument")){
        sapply(x["//ERROR"], xmlValue)
    } else {
        x$esearchresult$ERROR
    }
    if(length(said) == 0){
        return(what)
    }
    said <- gsub("[[:space:]]+", " ", said)
    paste0(what, ". NCBI message: ", paste(unique(said), collapse="; "))
}

#'@exportS3Method   
parse_esearch.XMLInternalDocument <- function(x, history){
    check_xml_errors(x)
    if(length(x["/eSearchResult/Count"]) == 0){
        stop(esearch_failure("ESearch returned no result", x), call.=FALSE)
    }
    #some responses (e.g. rettype="count") omit RetMax/QueryTranslation, so
    #pull the scalar fields safely rather than indexing a missing node
    get1 <- function(xpath){ node <- x[xpath]; if(length(node)) xmlValue(node[[1]]) else NA_character_ }
    res <- list( ids      = xpathSApply(x, "//IdList/Id", xmlValue),
                 count    = as.integer(get1("/eSearchResult/Count")),
                 retmax   = as.integer(get1("/eSearchResult/RetMax")),
                 QueryTranslation   = get1("/eSearchResult/QueryTranslation"),
                 file     = x)
    if(history){
        #NCBI ignores usehistory for a count-only search and sends back a Count
        #and nothing else, so say that rather than build a history out of gaps
        query_key <- get1("/eSearchResult/QueryKey")
        web_env   <- get1("/eSearchResult/WebEnv")
        if(is.na(query_key) || is.na(web_env) || !nzchar(query_key) || !nzchar(web_env)){
            warning("NCBI returned no QueryKey or WebEnv for this search, so no ",
                    "web history is attached. A count-only search carries none.",
                    call.=FALSE)
        } else {
            res$web_history = web_history(QueryKey = query_key, WebEnv = web_env)
        }
    }
    class(res) <- c("esearch", "list")
    return(res)
}

#'@exportS3Method   
parse_esearch.list <- function(x, history){
    #NCBI reports a bad request in the body of an HTTP 200 reply, so the json
    #looks ordinary until these fields are read. Without this the record below
    #is built from missing pieces and comes back with NA names and no count.
    #parse_esummary.list already guards its own json the same way.
    if(!is.null(x$esearchresult$ERROR) || is.null(x$esearchresult$count)){
        stop(esearch_failure("ESearch returned no result", x), call.=FALSE)
    }
    #for consitancy between xml/json records we are going to change the
    #file names from lower -> CamelCase
    res <- x$esearchresult[ c("idlist", "count", "retmax", "querytranslation") ]
    names(res)[c(1,4)] <- c("ids", "QueryTranslation")
    if(history){
        res$web_history = web_history(QueryKey = x$esearch_result[["querykey"]], 
                                      WebEnv   = x$esearch_result[["webenv"]])
    }
    res$count <- as.integer(res$count)
    res$retmax <- as.integer(res$retmax)
    res$file <- x
    class(res) <- c("esearch", "list")
    return(res)
}

#'@export
print.esearch <- function(x, ...){
    #a count-only reply (rettype="count") carries no QueryTranslation. The xml
    #path leaves it NA and the json path leaves it zero-length, so test the
    #length first: is.na() on a zero-length value answers logical(0).
    if(length(x$QueryTranslation) == 0 || is.na(x$QueryTranslation)){
        cat(paste("Entrez search result with", x$count, "hits\n"))
        return(invisible(x))
    }
    display_term <- if(nchar(x$QueryTranslation) > 50){
        paste(substr(x$QueryTranslation, 1, 50), "...")
    } else x$QueryTranslation
    cookie_word <- if("web_history" %in% names(x)) "a" else "no"
    msg<- paste("Entrez search result with", x$count, "hits (object contains",
                length(x$ids), "IDs and", cookie_word, 
                "web_history object)\n Search term (as translated): "  , display_term, "\n")
    cat(msg)
}


 c("//IdList/Id", "/eSearchResult/Count", "/eSearchResult/RetMax", "/eSearchResult/QueryTranslation")
