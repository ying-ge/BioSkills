API
===

MAGIC
-----

.. automodule:: magic.magic
    :members:
    :inherited-members:
    :show-inheritance:

Plotting
--------

.. automodule:: magic.plot
    :members:
    :inherited-members:
    :show-inheritance:
