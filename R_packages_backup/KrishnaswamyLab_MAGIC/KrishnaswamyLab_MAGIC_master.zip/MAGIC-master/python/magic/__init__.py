from .magic import MAGIC
from .version import __version__

import magic.plot
