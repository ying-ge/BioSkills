#' Fake scRNAseq data for examples
#'
#' A subsampled dataset of epithelial to mesenchymal transition
#'
#' @format A matrix with 500 rows and 197 variables
#'
#' @source The authors
"magic_testdata"
