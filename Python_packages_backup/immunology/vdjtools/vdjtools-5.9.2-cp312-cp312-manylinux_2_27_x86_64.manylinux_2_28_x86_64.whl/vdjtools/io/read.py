"""Readers for the native vdjtools table format and AIRR Rearrangement TSV.

Both readers return the canonical clonotype frame described in :mod:`vdjtools.io.schema`.
Gzip-compressed inputs (``.gz``) are handled transparently by polars.
"""
from __future__ import annotations

import os
from pathlib import Path

import polars as pl

from . import schema
from .schema import (
    FREQ,
    C_CALL,
    JUNCTION_AA,
    JUNCTION_NT,
    COUNT,
    D_CALL,
    J_CALL,
    V_CALL,
)

# Native vdjtools output header (com.antigenomics.vdjtools.misc.Software.VDJtools):
#   count  freq  cdr3nt  cdr3aa  v  d  j  VEnd  DStart  DEnd  JStart  [annotation...]
# Only the first seven fields carry clonotype content; VEnd..JStart are optional
# integer markup columns we do not carry into the canonical frame.
_NATIVE_MAP = {
    "count": COUNT,
    "cdr3nt": JUNCTION_NT,
    "cdr3aa": JUNCTION_AA,
    "v": V_CALL,
    "d": D_CALL,
    "j": J_CALL,
}

# AIRR Rearrangement source header -> canonical column, most specific first.
# ``*_call`` is the AIRR standard and wins; ``*_gene`` is the fallback some exports use
# (e.g. isalgo/airr_yfv19), and is usually gene-level where ``*_call`` is allele-level.
_AIRR_ALIASES: dict[str, tuple[str, ...]] = {
    V_CALL: ("v_call", "v_gene"),
    D_CALL: ("d_call", "d_gene"),
    J_CALL: ("j_call", "j_gene"),
    C_CALL: ("c_call", "c_gene"),
    # Prefer the junction (conserved anchors INCLUDED) — the canonical vdjtools /
    # AIRR ``junction_aa`` convention; fall back to the IMGT ``cdr3_aa``/``cdr3``
    # (anchors excluded) only if no junction column is present.
    JUNCTION_AA: ("junction_aa", "cdr3_aa"),
    JUNCTION_NT: ("junction_nt", "junction", "cdr3_nt", "cdr3"),
    # AIRR-hybrid exports (e.g. isalgo/airr_ankspond) carry a vdjtools-style `count`.
    COUNT: ("duplicate_count", "count", "reads"),
    # `frequency` IS read from source when the file carries one -- see read(recompute_frequencies=).
    # It used to be unconditionally recomputed from counts, which silently discarded a
    # UMI-corrected or already-renormalised frequency and made "use the frequencies as in the
    # file" impossible to honour at any layer above.
    FREQ: ("frequency", "freq", "frequency_percent", "frac"),
}


def _read_tsv(path: str | os.PathLike, n_rows: int | None = None) -> pl.DataFrame:
    """Read a (optionally gzipped) TSV as all-Utf8; ``n_rows`` caps huge files."""
    return pl.read_csv(Path(path), separator="\t", infer_schema_length=0,
                       quote_char=None, null_values=["", "."], n_rows=n_rows)


def _first_call(expr: pl.Expr) -> pl.Expr:
    """Take the first (best) call from a comma/space-separated ambiguous call list."""
    return expr.str.split(",").list.first().str.strip_chars()


def _needs_freq(df, recompute_frequencies: bool) -> bool:
    """Whether ``frequency`` must be derived from counts for this frame.

    ``recompute_frequencies=True`` (the default, and the historical behaviour) always derives.
    ``False`` means *use the frequencies as in the file* -- but only if the file actually carries
    one that survived aliasing and is not all-null; a frame with no frequency column has nothing
    to preserve, so it still derives rather than handing back a column of nulls.
    """
    if recompute_frequencies:
        return True
    if FREQ not in df.columns:
        return True
    return df[FREQ].null_count() == df.height


def read_vdjtools(path: str | os.PathLike, n_rows: int | None = None, *,
                  keep: tuple[str, ...] = (),
                 recompute_frequencies: bool = True) -> pl.DataFrame:
    """Read a native vdjtools clonotype table into the canonical frame.

    The native header is ``count freq cdr3nt cdr3aa v d j VEnd DStart DEnd JStart``
    followed by optional annotation columns; ``.`` and empty strings mean missing.
    Ambiguous V/D/J calls (``"TRBV12-4, TRBV12-3"``) are reduced to the first
    (highest-confidence) call. ``c_call`` is always null (the format has no C gene).
    ``frequency`` is recomputed exactly from ``duplicate_count`` (the native ``freq``
    column is a rounded copy of the same ratio).

    Args:
        path: Path to a ``.txt`` or ``.txt.gz`` native vdjtools table.
        n_rows: If given, read at most this many data rows (preview huge files).
        keep: Annotation columns to preserve past the canonical set (this format's
            trailing annotation fields are otherwise dropped). Same contract as the
            other two readers: absent names are skipped, not raised.

    Returns:
        Canonical clonotype frame with a derived ``locus`` column.

    Raises:
        ValueError: If the required ``count`` and ``cdr3aa`` columns are absent.
    """
    raw = _read_tsv(path, n_rows=n_rows)
    # Some legacy exports comment out the header line (``#count freq ...``); strip a
    # leading ``#`` so the first column still maps to ``count``.
    lower = {c.lower().lstrip("#"): c for c in raw.columns}
    found = {canon: lower[src] for src, canon in _NATIVE_MAP.items() if src in lower}
    if COUNT not in found or JUNCTION_AA not in found:
        raise ValueError(
            f"not a native vdjtools table (need 'count' and 'cdr3aa'); have {raw.columns}"
        )
    df = raw.rename({src: canon for canon, src in found.items()})
    df = df.with_columns(_first_call(pl.col(c)) for c in (V_CALL, D_CALL, J_CALL)
                         if c in df.columns)
    extra = [c for c in keep if c in df.columns and c not in found]
    df = df.with_columns(pl.col(c).cast(pl.Float64, strict=False).alias(c)
                         for c in extra if _numeric_like(df, c))
    # The native ``freq`` column is just count/total; recompute it exactly from counts.
    df = schema.normalize(df, recompute_freq=_needs_freq(df, recompute_frequencies),
                          keep=tuple(extra))
    return schema.add_locus(df)


def _numeric_like(df: pl.DataFrame, col: str) -> bool:
    """Is this column numeric, or an all-Utf8 TSV column whose values parse as numbers?"""
    if col.endswith("_id"):
        return False  # identifiers retain leading zeros and take representative values
    if df.schema[col].is_numeric():
        return True
    s = df[col].drop_nulls().head(100)
    return s.len() > 0 and s.cast(pl.Float64, strict=False).null_count() == 0


def read_parquet(path: str | os.PathLike, n_rows: int | None = None, *,
                 keep: tuple[str, ...] = (),
                 recompute_frequencies: bool = True) -> pl.DataFrame:
    """Read a Parquet clonotype table into the canonical frame.

    Parquet is the at-scale storage format for repertoire cohorts: typed, columnar,
    compressed, and — laid out as a hive-partitioned directory — scannable as one
    :class:`polars.LazyFrame` with predicate/projection pushdown (see
    :mod:`vdjtools.io.cohort`). Columns already using the canonical names (e.g. a
    file written by :meth:`polars.DataFrame.write_parquet` from a canonical frame)
    are kept as-is; AIRR source names (``junction_aa``, ``duplicate_count`` …) are
    mapped to canonical only to fill a canonical column that is otherwise absent.
    Unlike the TSV path this reads native dtypes directly (no all-Utf8 pass), so it
    is both faster and lower-peak-memory on large files.

    Args:
        path: Path to a ``.parquet`` / ``.pq`` clonotype table.
        n_rows: If given, read at most this many data rows (preview huge files).
        keep: Extra source columns to carry through unrenamed, e.g.
            ``("v_identity",)``. The canonical set is deliberately small, but a
            feature can need a field outside it -- the signature's SHM block is a
            weighted mean of ``v_identity``, which no canonical column holds, so
            without this it is not merely missing but *uncomputable*, and ships as a
            permanently-nan column. Names absent from the file are skipped rather
            than raising: ``keep`` says what to preserve if present, not what to
            require.

    Returns:
        Canonical clonotype frame with a derived ``locus`` column.

    Raises:
        ValueError: If no CDR3 amino-acid column (``cdr3_aa`` / ``junction_aa``)
            is present.
    """
    df = pl.read_parquet(Path(path), n_rows=n_rows)
    have = set(df.columns)
    # Resolve each canonical column from its AIRR aliases with the SAME first-match
    # preference as read_airr (junction_aa before cdr3_aa, so the junction wins even
    # when a raw-AIRR parquet carries both). cdr3_nt is the one canonical column that
    # is not an AIRR alias, so fall back to an already-canonical column by name.
    found: dict[str, str] = {}
    for canon in schema.COLUMNS:
        src = next((s for s in _AIRR_ALIASES.get(canon, ()) if s in have), None)
        if src is None and canon in have:
            src = canon
        if src is not None:
            found[canon] = src
    if JUNCTION_AA not in found:
        raise ValueError(
            f"Parquet file lacks a CDR3 aa column (cdr3_aa/junction_aa); have {df.columns}"
        )
    extra = [c for c in keep if c in have and c not in found.values()]
    df = df.select([pl.col(src).alias(canon) for canon, src in found.items()]
                   + [pl.col(c) for c in extra])
    # Do NOT collapse comma ambiguity here (unlike read_vdjtools, whose legacy single-call format
    # takes the first token by convention). Parquet is the at-scale storage format for a canonical
    # frame: read_airr and scan_cohort preserve a tie like "IGHV3-23*01,IGHV3-23D*01" whole, so a
    # round-trip through write_parquet must too -- otherwise AIRR->parquet->read_parquet silently
    # drops IGHV3-23D, exactly the ambiguity the model.infer.call_alleles fix exists to keep.
    if COUNT not in df.columns:
        df = df.with_columns(pl.lit(1, dtype=pl.Int64).alias(COUNT))
    df = schema.normalize(df, recompute_freq=_needs_freq(df, recompute_frequencies),
                          keep=tuple(extra))
    return schema.add_locus(df)


def read_airr(path: str | os.PathLike, *, collapse: bool = True,
              n_rows: int | None = None, keep: tuple[str, ...] = (),
                 recompute_frequencies: bool = True) -> pl.DataFrame:
    """Read an AIRR Rearrangement TSV into the canonical frame.

    Prefers the junction columns ``junction_aa`` / ``junction`` (conserved anchors
    INCLUDED — the canonical vdjtools / AIRR convention) over the IMGT ``cdr3_aa`` /
    ``cdr3`` columns (anchors excluded), which are used only as a fallback. Known
    limitation: a file that provides *only* the IMGT ``cdr3_aa`` yields sequences two
    residues shorter than the junction, so downstream lengths / k-mers will differ.
    The count column may be ``duplicate_count`` or a vdjtools-style ``count`` /
    ``reads`` (AIRR-hybrid exports); absent, it defaults to 1. Per-read files (one
    row per rearrangement) collapse to unique clonotypes with summed counts;
    already-aggregated files pass through unchanged. ``frequency`` is always
    recomputed after collapsing.

    Clonotype identity for collapsing is ``(v_call, j_call, junction_nt, junction_aa)`` —
    matching legacy ``Clonotype`` equality (V, J, CDR3nt); ``d_call`` and ``c_call``
    are *not* part of the identity, so a representative (first non-null) value is
    attached to each collapsed clonotype.

    Args:
        path: Path to a ``.tsv`` / ``.tsv.gz`` AIRR Rearrangement file.
        collapse: If ``True`` (default), sum the count over clonotypes identical on
            ``(v_call, j_call, junction_nt, junction_aa)``.
        n_rows: If given, read at most this many data rows (preview huge files).
        keep: Extra source columns to carry through unrenamed, e.g. ``("v_identity",)``
            for the signature's SHM block, which no canonical column holds. Under
            ``collapse`` a numeric kept column is averaged over the clonotype's reads
            and anything else takes a representative value. Names absent from the file
            are skipped rather than raising.

    Returns:
        Canonical clonotype frame with a derived ``locus`` column.

    Raises:
        ValueError: If no CDR3 amino-acid column (``junction_aa`` or ``cdr3_aa``)
            is present.
    """
    options = dict(separator="\t", infer_schema_length=0,
                   quote_char=None, null_values=["", "."])
    columns = pl.read_csv(Path(path), n_rows=0, **options).columns
    lower = {c.lower(): c for c in columns}
    found: dict[str, str] = {}
    for canon, srcs in _AIRR_ALIASES.items():
        for s in srcs:
            if s in lower:
                found[canon] = lower[s]
                break
    if JUNCTION_AA not in found:
        raise ValueError(
            f"AIRR file lacks a CDR3 aa column (cdr3_aa/junction_aa); have {columns}"
        )
    # V/J are clonotype identity. If we cannot name them we must NOT fall through: the
    # collapse key below would narrow to the junction and sum counts across clonotypes
    # that differ only by V — a wrong number with no error, and `locus` (derived from
    # v_call) would be null everywhere. Fail loudly and name the columns we did see.
    missing = [c for c in (V_CALL, J_CALL) if c not in found]
    if missing:
        raise ValueError(
            f"AIRR file lacks {'/'.join(missing)} "
            f"(tried {', '.join(a for c in missing for a in _AIRR_ALIASES[c])}); "
            f"have {columns}"
        )
    # The TSV path reads every column as Utf8, so a kept numeric arrives as a string; cast it
    # here rather than leaving the caller to discover that its mean is a type error.
    extra = [c for c in keep if c in columns and c not in found.values()]
    # Project before parsing data: alignment/sequence columns can dwarf the clonotype fields.
    # Eager projected parsing avoids the asynchronous streaming CSV channel, which can stall
    # with a single Polars thread under repeated spawned-worker reads.
    raw = pl.read_csv(Path(path), columns=list(dict.fromkeys([*found.values(), *extra])),
                      n_rows=n_rows, **options)
    df = raw.select([pl.col(src).alias(canon) for canon, src in found.items()]
                    + [pl.col(c).cast(pl.Float64, strict=False).alias(c)
                       if _numeric_like(raw, c) else pl.col(c) for c in extra])
    df = schema.normalize_nt_frame(df)
    if COUNT not in df.columns:
        df = df.with_columns(pl.lit(1, dtype=pl.Int64).alias(COUNT))
    else:
        # Preserve integer text exactly, accept legacy fractional counts, and retain
        # the documented default of one for missing/unparseable counts.
        df = df.with_columns(
            schema.count_expr(COUNT).fill_null(1)
        )

    # Legacy clonotype identity is (V, J, CDR3nt); junction_aa is kept in the key so
    # files with no nt column still collapse (redundant when nt is present). D and C
    # are not identity — carry a representative (first non-null) value per clonotype.
    key = [c for c in (V_CALL, J_CALL, JUNCTION_NT, JUNCTION_AA) if c in df.columns]
    if collapse:
        reps = [pl.col(c).drop_nulls().first().alias(c)
                for c in (D_CALL, C_CALL) if c in df.columns]
        # A kept column needs an aggregation rule too. Numerics take the mean -- reads of one
        # clonotype share a V and a junction, so v_identity varies only by sequencing error, and a
        # first-non-null would hand the whole clonotype one read's error. Anything else takes the
        # representative rule D and C use.
        for c in extra:
            reps.append(pl.col(c).mean().alias(c) if df.schema[c].is_numeric()
                        else pl.col(c).drop_nulls().first().alias(c))
        # A source `frequency` is SUMMED, not averaged or dropped: two rows collapsing into one
        # clonotype contribute additively to that clonotype's share of the sample. Only carried
        # when the caller asked to keep the file's frequencies -- otherwise it is about to be
        # recomputed from counts anyway and summing it would be wasted work.
        if not recompute_frequencies and FREQ in df.columns:
            reps.append(pl.col(FREQ).cast(pl.Float64, strict=False).sum().alias(FREQ))
        df = df.group_by(key, maintain_order=True).agg(pl.col(COUNT).sum(), *reps)
    df = schema.normalize(df, recompute_freq=_needs_freq(df, recompute_frequencies),
                          keep=tuple(extra))
    return schema.add_locus(df)


def iter_table_batches(path: str | os.PathLike, *, batch_size: int = 65536,
                       columns=None, separator: str | None = None):
    """Yield ordered raw table batches without loading a complete sample.

    Supports CSV/TSV (including gzip) and Parquet. Text fields remain strings;
    Parquet preserves types. ``columns`` accepts a Polars projection/selector.
    This is deliberately a raw reader: it does not collapse clonotypes, derive
    frequencies from chunk totals, or assume paired chains share a batch. The
    consumer owns source-aware normalization and cross-batch reductions.
    ``batch_size`` bounds yielded rows, not total parser/native memory.
    """
    if type(batch_size) is not int or batch_size < 1:
        raise ValueError("batch_size must be a positive integer")
    path = Path(path)
    suffix = path.with_suffix("").suffix if path.suffix.lower() == ".gz" else path.suffix
    if suffix.lower() in {".parquet", ".pq"}:
        scan = pl.scan_parquet(path)
    else:
        sep = separator if separator is not None else ("," if suffix.lower() == ".csv" else "\t")
        scan = pl.scan_csv(path, separator=sep, infer_schema_length=0)
    if columns is not None:
        scan = scan.select(columns)
    yield from scan.collect_batches(chunk_size=batch_size, maintain_order=True,
                                    lazy=True, engine="streaming")
