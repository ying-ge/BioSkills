"""ALICE neighbourhood enrichment — the *generative* null, against TCRnet's *empirical* one.

ALICE (Pogorelyy et al., PLoS Biol 2019) asks the same question as :mod:`vdjtools.overlap.tcrnet`
— does this clonotype have more close CDR3 neighbours than chance? — but answers it from a V(D)J
**generation model** rather than from a control repertoire. For each amino-acid CDR3 ``σ`` within
one V–J class::

    λ_σ  =  N · Σ_{σ' : Hamming(σ,σ') ≤ 1}  Q · Pgen(σ', V, J)
    p    =  P(Poisson(λ_σ) ≥ d(σ))

where ``N`` is the number of eligible unique **nucleotide** clonotypes in the locus, ``d(σ)`` counts
the nucleotide clonotypes whose CDR3aa lies within one mismatch of ``σ`` (σ included — different
nucleotide variants of one amino-acid sequence are genuine neighbours), and ``Q`` is an explicit effective post-selection generation-mass multiplier.
A fitted multiplier is not itself a measured thymic survival probability.

The two nulls are complements, not rivals, and that is why both are here: ALICE's generative null
controls for the intrinsic biases of V(D)J recombination but knows nothing about selection or
about which clonotypes are *already* common in people; TCRnet's control repertoire absorbs thymic
selection and endemic-pathogen expansions but needs a large, HLA-matched cohort to do it.

Both share a known blind spot worth stating plainly: neighbourhood enrichment **cannot see a
monoclonal expansion**. A single hyperexpanded clone has no near neighbours by definition, so it
scores as unremarkable no matter how dominant it is. That is precisely why this module and
:mod:`vdjtools.dynamics` are complementary — enrichment measures *breadth*, the paired test
measures *magnitude*.

The Hamming-1 ball sum is exact and already native: ``pgen_aa_batch(..., mismatches=1)`` computes
``Σ_k Pgen(a_{k→*}) − (L−1)Pgen(a)``, which is the **closed** ball with the centre counted exactly
once — verified here against brute-force enumeration of all 19L neighbours to 2e-16.
"""
from __future__ import annotations

from vdjtools.cores import kernel_threads

import numpy as np
import polars as pl
from scipy.stats import poisson

from ..biomarker.stats import fdr_bh
from ..model.selection import ALICE_TRB_SELECTION_Q, selection_mass, selection_factor, load_selection_profile, selection_profile_factors
from ..model.native import _alleles_for as _alleles_for
from ..io.schema import COUNT, J_CALL, JUNCTION_AA, JUNCTION_NT, LOCUS, V_CALL, add_locus

#: Explicit historical factor; modern defaults use model-specific calibration.
DEFAULT_Q = ALICE_TRB_SELECTION_Q

_COLS = [JUNCTION_AA, V_CALL, J_CALL, COUNT, "n_neighbors", "n_group", "pgen_ball",
         "E", "p_enrichment", "q_value", "n_exposure", "selection_q", "probability_convention", LOCUS]



def _ball_pgen(model, seqs: list[str], v: str, j: str, threads: int, *, anchored_only=False) -> np.ndarray:
    """Closed Hamming-1 joint mass, summing the alleles of each gene."""
    from ..model.native import pgen_aa_gene_batch
    return np.asarray(pgen_aa_gene_batch(model, seqs, [v]*len(seqs), [j]*len(seqs),
                                       mismatches=1, threads=threads, anchored_only=anchored_only))


def _degrees(unique_aa: list[str], expanded_aa: list[str], scope: str, threads: int) -> np.ndarray:
    """Nucleotide-clonotype degree of each unique CDR3aa, self included.

    ``expanded_aa`` holds one entry per *nucleotide* clonotype, so a hit count over it is already
    in ALICE's units. ``vdjmatch.cluster.overlap`` returns self-pairs, so the ball is closed —
    matching ``λ``, which sums Pgen over the closed ball.
    """
    from vdjmatch.cluster import overlap

    pairs = overlap(unique_aa, expanded_aa, scope=scope, threads=kernel_threads(threads))
    counts = (pairs.group_by("a_idx").len()
                   .rename({"len": "d"}).sort("a_idx"))
    out = np.zeros(len(unique_aa), dtype=np.int64)
    out[counts["a_idx"].to_numpy()] = counts["d"].to_numpy()
    return out


def alice(sample: pl.DataFrame, model=None, *, locus: str | None = None,
          source: str = "isalgo", scope: str = "1,0,0,1", selection_q: float | None = None,
          min_degree: int = 3, min_count: int = 2, threads: int = 0,
          organism: str = "human", legacy: bool = False, selection_profile=None) -> pl.DataFrame:
    """Per-clonotype neighbourhood enrichment against a V(D)J generation model.

    Args:
        sample: Clonotype frame (canonical schema). ``junction_nt`` is used when present so
            degrees are in nucleotide-clonotype units, as ALICE defines them; without it each
            amino-acid sequence counts once.
        model: A :class:`~vdjtools.model.Model`. ``None`` loads the bundled model for ``locus``.
        locus: Locus to score (e.g. ``"TRB"``). ``None`` infers it from ``v_call``; a sample
            spanning several loci is scored per locus.
        source: Bundled model source, ``"isalgo"`` by default. Select ``"olga-legacy"`` explicitly
            to reproduce the historical model and its Pgen scale.
        scope: vdjmatch edit scope defining the neighbourhood (default one substitution).
        selection_q: Explicit positive effective multiplier. ``None`` looks up the
            calibrated factor for each bundled model/species/locus, checking model hashes.
            Supplied models and uncalibrated contexts require explicit Q. ``legacy=True``
            restores the historical 9.41 default; model source remains explicit.
        selection_profile: Optional calibration report or JSON path. Applies the fitted
            joint V/J and shared length shape inside the eligible closed ball. The report
            supplies global Q unless overridden; complete model identity is verified.
        organism: Species of the bundled model (human or mouse).
        legacy: Preserve the historical subgroup-sized exposure with joint mass.
            Modern mode uses total eligible locus exposure; model choice remains explicit.
        min_degree: Only clonotypes with at least this many neighbours (self included) are
            tested; the rest are dropped. ALICE tests ``d(σ) > 2``.
        min_count: Clonotypes below this count do not participate at all. Low-count variants of
            an abundant clonotype are usually sequencing error, and counting them as neighbours
            inflates every degree in their neighbourhood.
        threads: Worker threads (``0`` = all cores).

    Returns:
        One row per tested clonotype: the key columns, ``duplicate_count``, ``n_neighbors``
        (``d(σ)``, self included), ``n_group`` (``n``, the V–J class's nucleotide-clonotype
        count), ``pgen_ball`` (``Σ Pgen`` over the closed ball), ``E`` (``λ_σ``),
        ``p_enrichment`` (Poisson tail), ``q_value`` (BH FDR over the clonotypes tested in this
        call) and ``locus`` — sorted by ascending ``p_enrichment``. **No threshold is applied**:
        ALICE's own papers use BH < 0.001 while the TCRnet framework paper used 0.05 for the same
        family of tests, and that was never reconciled — so the caller chooses.

    Raises:
        ValueError: If no locus can be resolved, or the sample has no usable clonotypes.
        KeyError: If a V/J call is neither a model allele nor a gene of one.
    """
    from ..model.bundled import load_bundled

    if selection_profile is not None and scope != '1,0,0,1':
        raise ValueError('selection profiles require the Hamming-1 substitution scope')
    if legacy and selection_profile is not None:
        raise ValueError('selection profiles require modern ALICE mode')
    if selection_q is not None:
        selection_mass(0., selection_q)
    elif model is not None and not legacy and selection_profile is None:
        raise ValueError('supplied models require explicit selection_q')
    df = sample.filter(pl.col(COUNT) >= min_count)
    if df.is_empty():
        raise ValueError(f"no clonotypes with duplicate_count >= {min_count}")
    df = add_locus(df).filter(pl.col(LOCUS).is_not_null())
    if locus is not None:
        df = df.filter(pl.col(LOCUS) == locus)
    if df.is_empty():
        raise ValueError("cannot infer locus from v_call; pass locus=")

    if selection_profile is not None and not df[JUNCTION_AA].str.contains(
            r'^C[ACDEFGHIKLMNPQRSTVWY]*[FW]$').fill_null(False).all():
        raise ValueError('selection profiles require anchored stop-free AA junctions')
    parts = []
    for loc in sorted(df[LOCUS].unique().to_list()):
        mdl = model if model is not None else load_bundled(loc, source, organism=organism,
                                                           collapse=selection_profile is None)
        profile, profile_q = load_selection_profile(selection_profile, mdl) if selection_profile is not None else (None, None)
        q = selection_q if selection_q is not None else (profile_q if profile_q is not None else (
            DEFAULT_Q if legacy else selection_factor(loc, organism=organism, source=source)))
        parts.append(_score_locus(df.filter(pl.col(LOCUS) == loc), mdl, loc, scope,
                                  q, min_degree, threads, legacy=legacy, profile=profile))
    out = pl.concat([p for p in parts if not p.is_empty()]) if any(
        not p.is_empty() for p in parts) else parts[0]
    if out.is_empty():
        return out.select(_COLS)
    q = fdr_bh(out["p_enrichment"].to_numpy())
    return out.with_columns(pl.Series("q_value", q)).select(_COLS).sort("p_enrichment")


def _score_locus(df: pl.DataFrame, model, loc: str, scope: str, selection_q: float,
                 min_degree: int, threads: int, *, legacy: bool = False, profile=None) -> pl.DataFrame:
    """Score one locus, V–J class by V–J class (ALICE's null is defined per V–J)."""
    has_nt = JUNCTION_NT in df.columns and df[JUNCTION_NT].null_count() < df.height
    nt_key = [JUNCTION_NT, JUNCTION_AA, V_CALL, J_CALL] if has_nt else [JUNCTION_AA, V_CALL, J_CALL]
    nt = df.filter(pl.col(V_CALL).is_not_null() & pl.col(J_CALL).is_not_null()).group_by(nt_key).agg(pl.col(COUNT).sum())      # unique nucleotide clonotypes

    rows = []
    for (v, j), grp in nt.group_by([V_CALL, J_CALL]):
        if v is None or j is None:
            continue
        expanded = grp[JUNCTION_AA].to_list()              # one entry per nt clonotype
        agg = (grp.group_by(JUNCTION_AA).agg(pl.col(COUNT).sum())
                  .sort(JUNCTION_AA))
        uniq = agg[JUNCTION_AA].to_list()
        deg = _degrees(uniq, expanded, scope, threads)
        keep = deg >= min_degree                           # ALICE tests d(sigma) > 2
        if not keep.any():
            continue
        seqs = [s for s, k in zip(uniq, keep) if k]
        ball = (_ball_pgen(model, seqs, v, j, threads, anchored_only=True) if profile is not None
                else _ball_pgen(model, seqs, v, j, threads))
        q = selection_q if profile is None else selection_q * selection_profile_factors(
            profile, [len(s) for s in seqs], [v]*len(seqs), [j]*len(seqs))
        exposure = len(expanded) if legacy else nt.height
        lam = len(expanded) * selection_q * ball if legacy else exposure * selection_mass(ball, q)
        rows.append(agg.filter(pl.Series(keep)).with_columns(
            pl.Series("n_neighbors", deg[keep]),
            pl.lit(len(expanded), dtype=pl.Int64).alias("n_group"),
            pl.Series("pgen_ball", ball),
            pl.Series("E", lam),
            pl.lit(exposure).alias("n_exposure"),
            pl.Series("selection_q", np.full(len(seqs), q) if np.ndim(q) == 0 else q),
            pl.lit("legacy-subgroup-times-joint" if legacy else "locus-total-times-joint").alias("probability_convention"),
            pl.Series("p_enrichment", poisson.sf(deg[keep] - 1, lam)),
            pl.lit(v).alias(V_CALL), pl.lit(j).alias(J_CALL),
        ))
    if not rows:
        return pl.DataFrame(schema={c: pl.Utf8 for c in _COLS})
    return pl.concat(rows).with_columns(pl.lit(loc, dtype=pl.Utf8).alias(LOCUS))
