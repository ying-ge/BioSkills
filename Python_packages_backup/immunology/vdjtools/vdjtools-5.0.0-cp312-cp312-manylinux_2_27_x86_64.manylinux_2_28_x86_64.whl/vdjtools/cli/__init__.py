"""vdjtools command-line interface (typer) — one ``vdjtools`` entry point.

Command families:

* **Model engine** (OLGA/IGoR-style, on the native recombination core + built-in models):
  ``pgen`` (generation probability), ``generate`` (sample sequences), ``models`` (list built-ins).
* **Data** (format conversion + preprocessing): ``convert`` (any format → canonical TSV/Parquet),
  ``downsample``, ``filter`` (coding / frequency / segment), ``pool`` (pool or incidence-join samples).
* **Repertoire analytics** (vanilla-vdjtools-style, over sample files or a metadata table):
  ``diversity``, ``spectratype``, ``segment-usage``, ``overlap``.
* **Longitudinal & enrichment**: ``dynamics`` (paired within-donor expansion test), ``tcrnet`` /
  ``alice`` (neighbourhood enrichment vs a control cohort / a generation model).

Analytics commands take either a list of sample files or ``-m/--metadata <table>`` (+ ``--base-dir``),
mirroring the metadata-driven workflow of the legacy tool, and run in parallel over samples
(``-t/--threads``) or in one streamed pass over a pre-ingested Parquet cohort (``--cohort``). Every
command writes to ``-o`` — TSV, or Parquet when the path ends in ``.parquet`` / ``.pq`` — or, by
default, to stdout (progress/errors go to stderr), so commands pipe cleanly.
"""
from __future__ import annotations

import functools
import sys
from pathlib import Path
from typing import Optional

import polars as pl
import typer

app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help="vdjtools — TCR/BCR repertoire analysis: Pgen, sequence generation, diversity, overlap.",
)


def _no_emoji_help() -> None:
    """Stop rich turning a column name into a pictograph in ``--help``.

    rich rewrites any ``:name:`` token matching its emoji table, and our column contract is built
    out of exactly that shape: ``vsig:mask:TRB:present`` renders as ``vsig<mask emoji>*`` -- an
    emoji, which the repo forbids, standing where a column name the reader is meant to copy should
    be. No rewording fixes it, because every faithful rendering of the name contains the token, and
    rich's backslash escape leaves the backslash in the output. The substitution happens in
    ``Text.from_markup``, which typer calls per help string, so the switch has to be there rather
    than on the console. ``test_cli_help.py`` pins the rendered text.
    """
    from rich.text import Text
    from typer import rich_utils

    class PlainText(Text):
        @classmethod
        def from_markup(cls, text, **kw):  # type: ignore[override]
            return Text.from_markup(text, **{**kw, "emoji": False})

    rich_utils.Text = PlainText


_no_emoji_help()

_SEQ_COLS = ("junction_aa", "junction_nt", "cdr3_aa", "cdr3_nt", "cdr3aa", "cdr3nt", "cdr3", "junction")


# ---------------------------------------------------------------------------- helpers
def _err(msg: str) -> None:
    typer.secho(f"error: {msg}", fg=typer.colors.RED, err=True)
    raise typer.Exit(1)


def _info(msg: str) -> None:
    typer.secho(msg, fg=typer.colors.GREEN, err=True)


def _load_model(model: Optional[str], source: str, model_path: Optional[Path]):
    from vdjtools.model import load_bundled, load_model

    if model_path is not None:
        return load_model(model_path)
    if model is None:
        _err("give a model: --model <LOCUS> (built-in) or --model-path <DIR>")
    try:
        return load_bundled(model, source=source)
    except (ValueError, FileNotFoundError) as e:  # unknown source / locus not bundled
        _err(str(e))


def _write(df: pl.DataFrame, out: Optional[Path]) -> None:
    """Write a result frame. ``.parquet`` / ``.pq`` → Parquet; anything else (or stdout) → TSV."""
    if out is None:
        sys.stdout.write(df.write_csv(separator="\t"))
        return
    if out.suffix.lower() in (".parquet", ".pq"):
        df.write_parquet(out)
    else:
        df.write_csv(out, separator="\t")
    _info(f"wrote {df.height} rows → {out}")


def _is_nt(seq: str) -> bool:
    return bool(seq) and set(seq.upper()) <= set("ACGT")


def _read_seq_table(path: Path, column: Optional[str], no_header: bool) -> tuple[pl.DataFrame, str]:
    """Read a sequence table; return (frame, sequence-column-name). Tab-separated, strings only."""
    if no_header:
        df = pl.read_csv(path, separator="\t", has_header=False, infer_schema_length=0)
        return df, df.columns[0]
    df = pl.read_csv(path, separator="\t", infer_schema_length=0)
    if column:
        if column not in df.columns:
            _err(f"column {column!r} not found; columns: {df.columns}")
        return df, column
    low = {c.lower(): c for c in df.columns}
    col = next((low[c] for c in _SEQ_COLS if c in low), df.columns[0])
    return df, col


def _sample_items(samples, metadata, base_dir, sample_col, file_template) -> list:
    """[(sample_id, path), ...] — from a metadata table if given, else positional files.

    Returns paths, not loaded frames: the caller streams them through
    :func:`vdjtools.io.map_samples` so only ``O(workers)`` samples are ever resident.
    """
    from vdjtools.io.batch import read_metadata

    if metadata is not None:
        md = read_metadata(metadata)
        if sample_col not in md.columns:
            _err(f"--sample-col {sample_col!r} not in metadata columns: {md.columns}")
        base = base_dir or Path(metadata).parent
        return [(str(r[sample_col]), base / file_template.format(sample=r[sample_col]))
                for r in md.iter_rows(named=True)]
    if not samples:
        _err("give sample files as arguments, or -m/--metadata <table> (with --base-dir)")
    return [(Path(s).name.split(".")[0], s) for s in samples]


def _tag(df: pl.DataFrame, sample_id: str) -> pl.DataFrame:
    return df.with_columns(pl.lit(sample_id).alias("sample_id")).select(
        ["sample_id", *[c for c in df.columns if c != "sample_id"]]
    )


# ---------------------------------------------------------------------------- model commands
@app.command()
def models() -> None:
    """List the precomputed recombination models shipped with the package."""
    from vdjtools.model import list_bundled

    for src, loci in list_bundled().items():
        typer.echo(f"{src:8s} {' '.join(loci) if loci else '(none)'}")


@app.command()
def pgen(
    input: Path = typer.Argument(..., help="Table (TSV) or list of CDR3 sequences."),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Built-in locus: TRA TRB TRG TRD IGH IGK IGL."),
    source: str = typer.Option("olga", help="Built-in model set: olga | learned."),
    model_path: Optional[Path] = typer.Option(None, help="Load a custom model directory instead of a built-in."),
    column: Optional[str] = typer.Option(None, "--column", "-c", help="Sequence column (default: auto-detect / first)."),
    v_col: Optional[str] = typer.Option(None, "--v-col", help="V-allele column to condition on (default: marginalize)."),
    j_col: Optional[str] = typer.Option(None, "--j-col", help="J-allele column to condition on (default: marginalize)."),
    seq_type: str = typer.Option("auto", "--type", help="auto | aa | nt."),
    mismatches: int = typer.Option(0, help="Amino-acid Hamming ball: 0 exact, 1 sums all single-substitution neighbours."),
    no_header: bool = typer.Option(False, "--no-header", help="Input is a bare sequence list (no header row)."),
    out: Optional[Path] = typer.Option(None, "--out", "-o", help="Output TSV (default: stdout)."),
) -> None:
    """Compute generation probability (Pgen) for CDR3 sequences — like ``olga-compute_pgen``.

    Appends a ``pgen`` column. V/J are marginalized unless ``--v-col``/``--j-col`` are given.
    Nucleotide vs amino-acid is auto-detected per sequence; amino-acid input can also sum the
    Hamming-distance-1 ball with ``--mismatches 1`` (fast, native).
    """
    from vdjtools.model import native

    if seq_type not in ("auto", "aa", "nt"):
        _err("--type must be auto, aa or nt")
    m = _load_model(model, source, model_path)
    df, seqcol = _read_seq_table(input, column, no_header)
    seqs = df[seqcol].to_list()
    vs = df[v_col].to_list() if v_col and v_col in df.columns else [None] * len(seqs)
    js = df[j_col].to_list() if j_col and j_col in df.columns else [None] * len(seqs)

    # One batched native call per kind, never one call per sequence: both batch entry points
    # release the GIL and thread across the input. Detection is per sequence, so the two kinds are
    # interleaved -- split by index, score each group, scatter back into input order.
    pg: list[float] = [0.0] * len(seqs)
    groups: dict[bool, list[int]] = {True: [], False: []}
    for i, s in enumerate(seqs):
        if s:
            groups[_is_nt(s) if seq_type == "auto" else (seq_type == "nt")].append(i)
    for is_nt, idx in groups.items():
        if not idx:
            continue
        sub, subv, subj = [seqs[i] for i in idx], [vs[i] for i in idx], [js[i] for i in idx]
        got = (native.pgen_nt_batch(m, sub, subv, subj) if is_nt else
               native.pgen_aa_batch(m, sub, subv, subj, mismatches=mismatches))
        for i, p in zip(idx, got):
            pg[i] = p
    _write(df.with_columns(pl.Series("pgen", pg)), out)


@app.command()
def generate(
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Built-in locus: TRA TRB TRG TRD IGH IGK IGL."),
    source: str = typer.Option("olga", help="Built-in model set: olga | learned."),
    model_path: Optional[Path] = typer.Option(None, help="Load a custom model directory instead of a built-in."),
    n: int = typer.Option(100, "--number", "-n", help="Number of sequences to generate."),
    seed: Optional[int] = typer.Option(None, help="Random seed for reproducible draws."),
    productive: bool = typer.Option(False, help="Only keep in-frame, stop-free (productive) rearrangements."),
    out: Optional[Path] = typer.Option(None, "--out", "-o", help="Output TSV (default: stdout)."),
) -> None:
    """Sample recombined sequences from a model — like ``olga-generate_sequences``.

    Emits ``junction_nt, junction_aa, v_call, d_call, d2_call, j_call, productive`` (``d2_call`` is the
    tandem D on the learned D-bearing loci; null otherwise).
    """
    from vdjtools.model.generate import generate as _generate

    m = _load_model(model, source, model_path)
    _write(_generate(m, n, seed=seed, productive_only=productive), out)


# ---------------------------------------------------------------------------- analytics commands
_SAMPLES = typer.Argument(None, help="Clonotype sample files (native vdjtools or AIRR).")
_META = typer.Option(None, "--metadata", "-m", help="Metadata table (one row per sample).")
_BASE = typer.Option(None, "--base-dir", help="Directory holding the sample files (with -m).")
_SCOL = typer.Option("sample_name", "--sample-col", help="Metadata column with the sample name.")
_TMPL = typer.Option("{sample}.tsv.gz", "--file-template", help="Sample filename template (with -m).")
_FMT = typer.Option("auto", "--format", help="auto | vdjtools | airr.")
_OUT = typer.Option(None, "--out", "-o", help="Output TSV (default: stdout).")
_THREADS = typer.Option(
    0, "--threads", "-t",
    help="Worker threads over samples (0 = all cores). Threads, not processes: the heavy work "
         "releases the GIL, so this is the setting that scales. Lower it only to share the machine.",
)
_ONDUP = typer.Option(
    "error", "--on-duplicate",
    help="A frame with no junction_nt that repeats (junction_aa, v_call, j_call, c_call) cannot "
         "say whether those rows are two clonotypes or one: error (default) refuses, sum adds "
         "the counts together.")
_COHORT = typer.Option(
    None, "--cohort",
    help="Pre-ingested parquet cohort dir (vdjtools.io.ingest_cohort): one streamed "
         "out-of-core pass over the whole cohort instead of per-sample files.",
)


# ---------------------------------------------------------------------------- data commands
@app.command()
def convert(
    input: Path = typer.Argument(..., help="Clonotype file in any supported format."),
    fmt: str = _FMT, out: Optional[Path] = _OUT,
) -> None:
    """Read any supported format and write the canonical AIRR-junction table.

    Auto-detects native vdjtools / AIRR / Parquet and the third-party exports (MiXcr, MiGec,
    MiTCR, immunoSEQ, IMGT/HighV-QUEST, Vidjil, RTCR, TRUST4, arda). Output is TSV, or Parquet
    when ``-o`` ends in ``.parquet`` / ``.pq`` — the typed, columnar, at-scale store.
    """
    from vdjtools.io.batch import read

    try:
        _write(read(input, fmt=fmt), out)
    except ValueError as e:                          # unknown fmt / unrecognised header
        _err(str(e))


@app.command()
def downsample(
    input: Path = typer.Argument(..., help="Clonotype sample file."),
    size: int = typer.Argument(..., help="Target size (reads, or unique clonotypes with --clones)."),
    fmt: str = _FMT, out: Optional[Path] = _OUT,
    clones: bool = typer.Option(False, "--clones", help="Draw unique clonotypes, not reads."),
    seed: int = typer.Option(0, "--seed", help="Random seed for reproducible draws."),
) -> None:
    """Randomly down-sample a repertoire to a common depth (reads, or unique clonotypes)."""
    from vdjtools.io.batch import read
    from vdjtools.preprocess import downsample as _ds

    _write(_ds(read(input, fmt=fmt), size, by="clones" if clones else "reads", seed=seed), out)


@app.command(name="filter")
def filter_(
    input: Path = typer.Argument(..., help="Clonotype sample file."),
    fmt: str = _FMT, out: Optional[Path] = _OUT,
    productive: bool = typer.Option(False, "--productive", help="Keep only AIRR-productive rearrangements (in-frame, stop-free)."),
    nonproductive: bool = typer.Option(False, "--nonproductive", help="Keep only NON-productive rearrangements (the complement)."),
    functional_genes: bool = typer.Option(False, "--functional-genes", help="Keep only rearrangements whose V/J are IMGT-functional (F). A DIFFERENT axis from --productive."),
    keep_orf: bool = typer.Option(False, "--keep-orf", help="With --functional-genes: keep IMGT ORF alleles as well as F."),
    recompute_frequencies: bool = typer.Option(True, "--recompute-frequencies/--keep-frequencies", help="Renormalise `frequency` over the survivors (default), or leave the file's own frequencies untouched."),
    coding: bool = typer.Option(False, "--coding", hidden=True, help="Deprecated alias for --productive."),
    noncoding: bool = typer.Option(False, "--noncoding", hidden=True, help="Deprecated alias for --nonproductive."),
    min_len: Optional[int] = typer.Option(None, "--min-len", help="Shortest junction_aa to keep, INCLUSIVE (default bound 5)."),
    max_len: Optional[int] = typer.Option(None, "--max-len", help="Longest junction_aa to keep, INCLUSIVE (default bound 60)."),
    min_freq: Optional[float] = typer.Option(None, "--min-freq", help="Keep clonotypes with frequency >= this."),
    v: Optional[str] = typer.Option(None, "--v", help="Comma-separated V segments (prefix ok)."),
    j: Optional[str] = typer.Option(None, "--j", help="Comma-separated J segments (prefix ok)."),
    remove: bool = typer.Option(False, "--remove", help="With --v/--j: remove the listed segments instead of keeping them."),
) -> None:
    """Filter clonotypes: productive / non-productive, IMGT-functional genes, frequency, V/J segment.

    Two DIFFERENT axes, deliberately separate flags. `--productive` is a property of the
    REARRANGEMENT (AIRR: in frame, no stop codon); `--functional-genes` is a property of the
    GERMLINE GENE it uses (IMGT: F / ORF / P). A productive rearrangement can use a pseudogene V.
    """
    from vdjtools import preprocess
    from vdjtools.io.batch import read

    if coding:
        typer.echo("[vdjtools] --coding is deprecated; use --productive", err=True)
        productive = True
    if noncoding:
        typer.echo("[vdjtools] --noncoding is deprecated; use --nonproductive", err=True)
        nonproductive = True
    if productive and nonproductive:
        _err("--productive and --nonproductive are mutually exclusive")
    df = read(input, fmt=fmt)
    if productive or nonproductive:
        _, src = preprocess.productive_mask(df)
        typer.echo(f"[vdjtools] productivity read from: {src}", err=True)
        df = preprocess.filter_productive(
            df, keep="productive" if productive else "nonproductive",
            recompute_frequencies=recompute_frequencies)
    if functional_genes:
        df = preprocess.filter_functional_genes(
            df, keep=("F", "ORF") if keep_orf else ("F",),
            recompute_frequencies=recompute_frequencies)
    if min_len is not None or max_len is not None:
        from vdjtools.preprocess.filter import MAX_JUNCTION_AA, MIN_JUNCTION_AA
        df = preprocess.filter_length(
            df, min_len=MIN_JUNCTION_AA if min_len is None else min_len,
            max_len=MAX_JUNCTION_AA if max_len is None else max_len,
            recompute_frequencies=recompute_frequencies)
    if min_freq is not None:
        df = preprocess.filter_frequency(df, min_freq=min_freq)
    if v or j:
        df = preprocess.filter_segment(df, v=v.split(",") if v else None,
                                       j=j.split(",") if j else None, keep=not remove)
    _write(df, out)


@app.command(name="correct-vj")
def correct_vj(
    samples: list[Path] = typer.Argument(..., help="Two or more clonotype sample files, one per sample."),
    batches: str = typer.Option(..., "--batches", "-b", help="Comma-separated batch label per sample, in the same order as the files; or a TSV with sample_id/batch columns."),
    fmt: str = _FMT,
    outdir: Optional[Path] = typer.Option(None, "--outdir", help="Write one corrected clonotype table per sample here. Without it only the usage table is written."),
    usage_out: Optional[Path] = typer.Option(None, "--usage-out", help="Write the per-sample corrected V/J usage table here."),
    transform: str = typer.Option("location", "--transform", help="'location' (ComBat location term) or 'sigmoid' (sigma-standardised z-score, Vlasova et al. 2026)."),
    scope: str = typer.Option("vj", "--scope", help="Correction key: vj | v | j."),
    z_cap: float = typer.Option(6.0, "--z-cap", help="With --transform sigmoid: cap |Z| at this."),
    winsor_q: Optional[float] = typer.Option(None, "--winsor-q", help="Winsorize the per-batch mean/sigma at this quantile. Default off, matching the published method; 0.025 is a robustness setting for shallow/RNA-seq repertoires."),
    unweighted: bool = typer.Option(False, "--unweighted", help="Count clonotypes rather than reads when building usage."),
    rescale: bool = typer.Option(False, "--rescale", help="Deterministically rescale instead of roulette-wheel resampling."),
    seed: int = typer.Option(0, "--seed", help="Seed for the resample."),
) -> None:
    """Batch-correct V/J gene usage across samples, and optionally rewrite the clonotype tables.

    Different batches carry systematic V/J usage bias (primer mixes, amplification, extraction).
    Two transforms:

    \b
      location  the location term of ComBat on usage log-probabilities:
                log p - mu_batch + mu_grand.  Location only, no scale term.
      sigmoid   the sigma-standardised, grand-mean-preserving z-score:
                Z = (log p - mu_batch) / sigma_batch, capped at +-z_cap, then
                P = 2*P_avg / (1 + exp(-Z)).  Corrects a batch that is merely
                NOISIER in a gene, which the location adjustment cannot.

    NAME THE TECHNICAL VARIABLE. Point --batches at a primer mix, a run, an extraction protocol.
    Pointing it at a study identifier that is collinear with the biology being measured removes
    the effect along with the batch, and nothing reports that it happened.
    """
    from vdjtools import preprocess
    from vdjtools.io.batch import read

    if len(samples) < 2:
        _err("correct-vj needs at least two samples — a batch effect is a between-batch quantity")
    if transform not in ("location", "sigmoid"):
        _err(f"--transform must be 'location' or 'sigmoid'; got {transform!r}")

    labels = _batch_labels(batches, samples)
    frames = []
    for path, batch in zip(samples, labels):
        df = read(path, fmt=fmt)
        frames.append(df.with_columns(pl.lit(path.stem).alias("sample_id"),
                                      pl.lit(batch).alias("batch")))
    _info(f"{len(frames)} samples over {len(set(labels))} batches, transform={transform}")

    usage = preprocess.correct_vj_usage(
        frames, batch_col="batch", weighted=not unweighted, transform=transform,
        z_cap=z_cap, winsor_q=winsor_q)
    if usage_out is not None:
        _write(usage, usage_out)
    elif outdir is None:
        _write(usage, None)

    if outdir is not None:
        outdir.mkdir(parents=True, exist_ok=True)
        for path, df in zip(samples, frames):
            sid = path.stem
            corrected = preprocess.apply_vj_correction(
                df.drop(["sample_id", "batch"]), usage, scope=scope,
                weighted=not unweighted, resample=not rescale, sample_id=sid, seed=seed)
            _write(corrected, outdir / f"{sid}.corrected.tsv")


def _batch_labels(batches: str, samples: "list[Path]") -> "list[str]":
    """A batch label per sample, from a comma-separated list or a two-column TSV."""
    p = Path(batches)
    if p.exists():
        meta = pl.read_csv(p, separator="\t")
        cols = {c.lower(): c for c in meta.columns}
        sid_col = cols.get("sample_id") or cols.get("sample")
        b_col = cols.get("batch")
        if not sid_col or not b_col:
            _err(f"{batches!r} needs sample_id and batch columns; have {meta.columns}")
        m = dict(zip(meta[sid_col].to_list(), meta[b_col].to_list()))
        missing = [s.stem for s in samples if s.stem not in m]
        if missing:
            _err(f"no batch for {missing[:5]} in {batches!r} (matched on file stem)")
        return [str(m[s.stem]) for s in samples]
    labels = [b.strip() for b in batches.split(",") if b.strip()]
    if len(labels) != len(samples):
        _err(f"--batches has {len(labels)} labels for {len(samples)} samples")
    return labels


@app.command()
def pool(
    samples: list[Path] = typer.Argument(..., help="Two or more clonotype sample files."),
    fmt: str = _FMT, out: Optional[Path] = _OUT,
    key: str = typer.Option("aa", "--key", help="Match key: strict | nt | ntV | ntVJ | aa | aaV | aaVJ."),
    join: bool = typer.Option(False, "--join", help="Incidence join (clonotypes shared across samples) instead of a flat pool."),
    min_samples: int = typer.Option(2, "--min-samples", help="With --join: keep clonotypes seen in >= this many samples."),
) -> None:
    """Pool (sum counts) or join (incidence) clonotypes across several samples."""
    from vdjtools import preprocess
    from vdjtools.io.batch import read

    if len(samples) < 2:
        _err("pool needs at least two samples")
    frames = [read(s, fmt=fmt) for s in samples]
    try:
        res = (preprocess.join_samples(frames, key=key, min_samples=min_samples) if join
               else preprocess.pool_samples(frames, key=key))
    except ValueError as e:                          # unknown key
        _err(str(e))
    _write(res, out)


@app.command()
def diversity(
    samples: Optional[list[Path]] = _SAMPLES, metadata: Optional[Path] = _META,
    base_dir: Optional[Path] = _BASE, sample_col: str = _SCOL, file_template: str = _TMPL,
    fmt: str = _FMT, threads: int = _THREADS, cohort: Optional[Path] = _COHORT,
    on_duplicate: str = _ONDUP, out: Optional[Path] = _OUT,
) -> None:
    """Per-sample diversity (observed richness, Chao, Efron-Thisted, Shannon, Simpson, d50)."""
    import functools

    from vdjtools.io.batch import map_samples
    from vdjtools.stats.diversity import diversity_cohort, diversity_stats

    if cohort is not None:
        from vdjtools.io.cohort import scan_cohort
        _write(diversity_cohort(scan_cohort(cohort, join_metadata=False),
                                on_duplicate=on_duplicate), out)
        return
    items = _sample_items(samples, metadata, base_dir, sample_col, file_template)
    fn = functools.partial(diversity_stats, on_duplicate=on_duplicate)
    rows = [_tag(res, sid) for sid, res in
            map_samples(fn, items, fmt=fmt, workers=threads or None)]
    _write(pl.concat(rows, how="vertical_relaxed"), out)


@app.command()
def signature(
    samples: Optional[list[Path]] = _SAMPLES, metadata: Optional[Path] = _META,
    base_dir: Optional[Path] = _BASE, sample_col: str = _SCOL, file_template: str = _TMPL,
    fmt: str = _FMT,
    corpus: str = typer.Option(..., "--corpus",
                               help="Corpus to rotate through: a published name (blood, tissue, "
                                    "deep-tcr, blood-uncapped, tissue-uncapped, synthetic-blood, "
                                    "synthetic-tissue, naive, memory) or a path to an artifact. "
                                    "A published name is fetched on first use and cached. "
                                    "REQUIRED -- a silently chosen rotation makes two matrices "
                                    "look comparable when they are not."),
    winsorize: str = typer.Option("features", "--winsorize",
                                  help="features (clamp raw features, then rotate) | pcs (rotate, "
                                       "then clamp PC scores) | none. Whatever is clamped is "
                                       "reported in vsig:qc:-:winsor_frac -- never silently."),
    winsor_p: Optional[float] = typer.Option(None, "--winsor-p",
                                             help="Which stored percentile to clamp at: 0.01 or "
                                                  "0.05. Default: the one the corpus was fitted "
                                                  "at."),
    components: Optional[str] = typer.Option(None, "--components",
                                             help="Truncate the rotation: an integer count (128), "
                                                  "or a variance fraction (0.95). Exact -- the "
                                                  "first n of a longer rotation are the same "
                                                  "vectors. Asking for more than was fitted "
                                                  "refuses; the corpus manifest says what it has."),
    cstar_target: Optional[str] = typer.Option(None, "--cstar-target",
                                               help="Coverage level the Hill numbers are read at: "
                                                    "a number, or 'min' (default) for this "
                                                    "cohort's own per-locus minimum attained "
                                                    "coverage, or 'own' for each sample's own "
                                                    "(one pass, not comparable across samples)."),
    weight: str = typer.Option("log2p1", help="Clone-size weight g: log2p1 | duplicate_count | "
                                              "distinct | log1p | anscombe."),
    columns: Optional[Path] = typer.Option(None, "--columns",
                                           help="File of column names (one per line) to restrict "
                                                "the output to. Selects output; it does not skip "
                                                "work, because a locus is rotated jointly over all "
                                                "its feature groups."),
    named: str = typer.Option(None, "--named",
                              help="Also emit the reportable raw blocks in their own right: "
                                   "'all', or a comma-separated list (div,depth,clon,len,iso,shm,"
                                   "pair). These are the diversity, depth and clone-size numbers "
                                   "the rotation is fitted on; without this there is no route to "
                                   "reading them back. Values carry their declared transform -- "
                                   "see the 'transform' column of --describe."),
    describe: bool = typer.Option(False, "--describe",
                                  help="Print the columns THIS invocation emits, and exit."),
    jobs: int = typer.Option(1, "--jobs", "-j",
                             help="Worker processes over samples (default: 1, 0 = all available cores). "
                                  "Each spawned worker uses one kernel thread."),
    on_duplicate: str = _ONDUP, out: Optional[Path] = _OUT,
) -> None:
    """One repertoire in, one row of named features out -- rotated through a named corpus.

    \b
      vdjtools signature --corpus naive samples/*.tsv.gz -o sig.tsv
      vdjtools signature --corpus naive --components 32 --describe
      vdjtools signature --corpus memory --winsorize pcs -m meta.txt -o sig.tsv

    Three stages, and the corpus fixes the last two: raw features are computed from this sample
    alone, then clamped to the corpus's winsorization bounds, then rotated by the corpus's
    per-locus rotation and scaled by its per-PC median and MAD.

    \b
    What comes out, per locus:
      vsig:pc:<locus>:PCnn   the rotated coordinates
      vsig:cov:<locus>:cstar the coverage this sample actually attained, ALWAYS emitted
      vsig:mask:*            why a column is a hole -- absent locus, or not estimable
      vsig:qc:*              fallback fractions, and how much of this row was clamped

    The channels are never rotated and never clamped: a provenance number mixed with the
    measurements it qualifies is no longer provenance.

    A hole is `nan`, never 0. "This locus is absent", "this sample is too shallow" and "this field
    was not in the input" are different facts, and the mask channels say which.
    """
    from vdjtools.io import read
    from vdjtools.signature import corpus as CO
    from vdjtools.signature import layout as L
    from vdjtools.signature.signature import vsig_cohort

    if winsorize not in CO.MODES:
        _err(f"--winsorize must be one of {', '.join(CO.MODES)}; got {winsorize!r}")
    art = _resolve_corpus(corpus)
    ncomp = _parse_components(components)
    blocks: "bool | tuple[str, ...]" = ()
    if named is not None:
        blocks = True if named.strip().lower() == "all" else tuple(
            b for b in (x.strip() for x in named.split(",")) if b)
        try:
            L.resolve_named(art.sig, blocks)
        except ValueError as e:
            _err(str(e))
    want = None
    if columns is not None:
        want = [c for c in columns.read_text().split() if c]

    if describe:
        cols = art.columns(ncomp, named=blocks)
        if want is not None:
            cols = [c for c in cols if c in set(want)]
        named_set = set(L.named_columns(art.sig, blocks, art.vocab) if blocks else ())
        spec = {(r["block"], r["feature"]): r for r in L.channel_table(art.sig)}
        rows = []
        for c in cols:
            _sig, block, locus, feature = L.parse(c)
            kind = ("rotated" if block == L.PC_BLOCK
                    else "named" if c in named_set else "channel")
            rows.append({"column": c, "block": block, "locus": locus, "feature": feature,
                         "kind": kind,
                         "transform": spec.get((block, feature), {}).get("transform", "none"),
                         "support": L.support_of(c)})
        _write(pl.DataFrame(rows), out)
        return

    items = _sample_items(samples, metadata, base_dir, sample_col, file_template)
    target: object = "min"
    if cstar_target is not None:
        target = None if cstar_target == "own" else (
            "min" if cstar_target == "min" else float(cstar_target))

    deferred = [(sid, functools.partial(read, path, fmt=fmt, keep=("v_identity",)))
                for sid, path in items]
    result = vsig_cohort(deferred, art, n_jobs=jobs, mode=winsorize, winsor_p=winsor_p,
                         n_components=ncomp, cstar_target=target, weight=weight,
                         on_duplicate=on_duplicate, named=blocks, columns=want)
    cols = [c for c in art.columns(ncomp, named=blocks) if want is None or c in set(want)]
    typer.echo(f"{result.height} samples x {len(cols)} vsig columns | corpus {art.name} "
               f"({art.meta.get('content_sha256', '?')[:12]}) | winsorize={winsorize} | "
               f"k={art.resolve_k(ncomp)}", err=True)
    _write(result.select(["sample_id", *cols]), out)


def _parse_components(spec: Optional[str]):
    """``None``, an int count, or a float variance fraction -- whichever the string spells."""
    if spec is None:
        return None
    try:
        return int(spec) if "." not in spec else float(spec)
    except ValueError:
        _err(f"--components must be an integer count or a fraction in (0, 1); got {spec!r}")


def _resolve_corpus(name: str):
    """A bundled corpus name, or a path to an artifact."""
    from vdjtools.signature.corpus import Corpus, bundled_path

    path = bundled_path(name)
    if path is None:
        have = _bundled_names()
        _err(f"no corpus named {name!r}, and no artifact at that path. "
             + (f"Installed: {', '.join(have)}. " if have else
                "No corpus ships with this version yet. ")
             + "Build one with: vdjtools corpus --corpus naive --smoke -o naive.npz")
    try:
        return Corpus.load(path)
    except FileNotFoundError:
        _err(f"corpus artifact {path} is missing its .json sidecar")
    except ValueError as e:
        _err(str(e))


def _bundled_names() -> list[str]:
    from vdjtools.signature.corpus import bundled_names

    return bundled_names()


@app.command()
def corpus(
    name: str = typer.Option("naive", "--corpus",
                             help="naive (every clone size 1) | memory (Zipf rank-abundance clone "
                                  "sizes) | synthetic-blood | synthetic-tissue (the naive/memory "
                                  "mixture, drawn across that real cohort's measured per-locus "
                                  "richness, read depth and singleton fraction)."),
    out: Optional[Path] = typer.Option(None, "--out", "-o",
                                       help="Artifact path; writes .npz and .json. Required unless "
                                            "--fetch, which downloads into the cache instead."),
    n_samples: int = typer.Option(10000, "--samples", help="Repertoires in the corpus."),
    size: str = typer.Option("auto", "--size",
                             help="Receptors per repertoire: an integer, or n_eff / p05 / p95 for "
                                  "the measured real per-locus depths. Default `auto` is the "
                                  "corpus's own -- 10000 for naive/memory, the centre of the "
                                  "cohort's measured richness band for a synthetic-* one."),
    components: str = typer.Option("128", "--components",
                                   help="Components per locus: an integer count, or a variance "
                                        "fraction. A count is capped at what a locus supports."),
    winsorize: str = typer.Option("features", "--winsorize", help="Mode to fit at."),
    winsor_p: float = typer.Option(0.01, "--winsor-p", help="Percentile for the fitted bounds. "
                                                            "All stored percentiles are written."),
    seed: int = typer.Option(20260927, "--seed", help="Base seed; every draw is a recorded offset."),
    loci: Optional[str] = typer.Option(None, "--loci", help="Comma-separated subset (default: all "
                                                            "seven)."),
    source: str = typer.Option("olga", "--source", help="Bundled model set: olga | learned | arda."),
    depth_spread: Optional[float] = typer.Option(None, "--depth-spread",
                                                 help="Multiplicative depth range each repertoire's "
                                                      "size is drawn log-uniformly across, around "
                                                      "--size. Default is the measured real "
                                                      "p05-p95 spread per locus (2.4x-11.0x). Use "
                                                      "e.g. --size 3162 --depth-spread 1000 for a "
                                                      "corpus spanning 100 to 100000 receptors."),
    smoke: bool = typer.Option(False, "--smoke", help="Reduced build (200 samples of 1000) for "
                                                      "tests and the reproducibility check."),
    fetch: Optional[str] = typer.Option(None, "--fetch", metavar="NAME|all",
                                        help="Download a published corpus instead of building one, "
                                             "into the cache ($VDJTOOLS_CORPUS_DIR or "
                                             "~/.cache/vdjtools/signature). `all` pre-warms every "
                                             "corpus -- the install-time step, since an artifact is "
                                             "otherwise fetched on first use."),
    jobs: int = typer.Option(0, "--jobs", "-j", help="Worker PROCESSES across samples (not kernel "
                                                     "threads): 0 = every core, 1 = in-process. "
                                                     "The artifact is identical at any value."),
) -> None:
    """Build a synthetic corpus and fit its rotation, bounds and scaling.

    \b
      vdjtools corpus --corpus naive  --out naive.npz
      vdjtools corpus --corpus synthetic-blood  -o synthetic-blood.npz
      vdjtools corpus --corpus memory --size n_eff --components 0.95 -o memory.npz
      vdjtools corpus --smoke -o /tmp/smoke.npz     # minutes, not hours

    Uses **no samples from anybody's cohort**: every receptor is drawn from the bundled
    recombination models, so the artifact is reproducible by anyone who installs the library. The
    build is a deterministic function of (corpus, loci, samples, size, seed, source) and those
    models, and must be byte-identical across processes and thread counts -- run it twice and
    `cmp` the output.

    Each repertoire's depth is **drawn**, log-uniformly over the measured real p05-p95 spread for
    its locus, not fixed. A corpus at one depth has zero variance in its depth features and cannot
    fit the cross-locus block at all -- which fails quietly, as a rotation that simply omits them.

    For `naive` and `memory` that spread is under one decade (2.4x on TRD to 11.0x on IGH,
    measured on 1,168 deep blood samples), and a corpus describes only the depths it was drawn
    across: bounds, centre and per-PC scaling are all estimated from the draw and none of them
    extrapolates. The real cohorts are an order of magnitude wider -- blood TRB richness spans 43x
    (74 to 3,162 clonotypes, n = 34,365 samples) and tissue IGH 259x (40 to 10,352, n = 47,031) --
    which is what `--corpus synthetic-blood` / `synthetic-tissue` draw across, together with that
    cohort's measured reads per clonotype and its singleton fraction (the naive share: blood TRB
    0.215 to 0.949). To widen any of them by hand, `--size 3162 --depth-spread 1000` draws
    log-uniformly from 100 to 100,000 receptors per locus.
    """
    import sys
    import time

    from vdjtools.signature.corpus import synthesize

    if fetch is not None:
        from vdjtools.signature.corpus import (bundled_names, corpora_index, corpus_cache_dir,
                                               fetch_artifact)
        from vdjtools.signature.corpus import _RES as res
        idx = corpora_index(res)
        want = sorted(idx) if fetch == "all" else [fetch]
        if not idx:
            _err("this version ships no corpus index, so there is nothing to fetch; the corpora it "
                 f"knows are {', '.join(bundled_names()) or '(none)'}")
        for nm in want:
            if nm not in idx:
                _err(f"no published corpus named {nm!r}; have {', '.join(sorted(idx))}")
            p = fetch_artifact(nm, sig="vsig", res_dir=res, repo="antigenomics/vdjtools")
            typer.echo(f"{p}  {p.stat().st_size / 1e6:.2f} MB", err=True)
        typer.echo(f"cache: {corpus_cache_dir()}", err=True)
        raise typer.Exit(0)

    if out is None:
        _err("--out is required when building a corpus (it is not used by --fetch)")
    sz: object = None if size == "auto" else size
    if size not in ("auto", "n_eff", "p05", "p95"):
        try:
            sz = int(size)
        except ValueError:
            _err(f"--size must be an integer or one of auto, n_eff, p05, p95; got {size!r}")
    if smoke:
        n_samples, sz = 200, 1000
    ks = _parse_components(components)
    which = tuple(loci.split(",")) if loci else None

    t0 = time.time()
    kw = {} if which is None else {"loci": which}
    art, _rows = synthesize(name, n_samples=n_samples, size=sz, seed=seed, n_components=ks,
                            mode=winsorize, winsor_p=winsor_p, source=source, n_jobs=jobs,
                            depth_spread=depth_spread,
                            progress=lambda loc, d, t: print(
                                f"  {loc:4s} {d}/{t}  {time.time() - t0:5.0f}s",
                                file=sys.stderr, flush=True),
                            **kw)
    path = art.save(out)
    typer.echo(f"{path}  {path.stat().st_size / 1e6:.2f} MB  k={art.k}  "
               f"variance@k=" + str({loc: round(f.variance_at(f.k), 3)
                                     for loc, f in art.fits.items()})
               + f"  {time.time() - t0:.0f}s", err=True)



@app.command()
def spectratype(
    samples: Optional[list[Path]] = _SAMPLES, metadata: Optional[Path] = _META,
    base_dir: Optional[Path] = _BASE, sample_col: str = _SCOL, file_template: str = _TMPL,
    fmt: str = _FMT, kind: str = typer.Option("aa", help="aa | nt (length unit)."),
    weight: str = typer.Option("reads", help="reads | unique | freq."),
    threads: int = _THREADS, cohort: Optional[Path] = _COHORT, out: Optional[Path] = _OUT,
) -> None:
    """Per-sample CDR3 length spectratype."""
    from vdjtools.io.batch import map_samples
    from vdjtools.stats.spectratype import spectratype as _spec

    if cohort is not None:
        from vdjtools.io.cohort import scan_cohort
        _write(_spec(scan_cohort(cohort, join_metadata=False), kind=kind, weight=weight,
                     by=["sample_id"]).collect(engine="streaming"), out)
        return
    items = _sample_items(samples, metadata, base_dir, sample_col, file_template)
    fn = functools.partial(_spec, kind=kind, weight=weight)
    rows = [_tag(res, sid) for sid, res in
            map_samples(fn, items, fmt=fmt, workers=threads or None)]
    _write(pl.concat(rows, how="vertical_relaxed"), out)


@app.command(name="segment-usage")
def segment_usage(
    samples: Optional[list[Path]] = _SAMPLES, metadata: Optional[Path] = _META,
    base_dir: Optional[Path] = _BASE, sample_col: str = _SCOL, file_template: str = _TMPL,
    fmt: str = _FMT, segment: str = typer.Option("v", help="v | d | j | c."),
    weight: str = typer.Option("reads", help="reads | unique | freq."),
    threads: int = _THREADS, cohort: Optional[Path] = _COHORT, out: Optional[Path] = _OUT,
) -> None:
    """Per-sample V/D/J/C segment usage."""
    from vdjtools.io.batch import map_samples
    from vdjtools.stats.usage import segment_usage as _usage

    if cohort is not None:
        from vdjtools.io.cohort import scan_cohort
        _write(_usage(scan_cohort(cohort, join_metadata=False), segment=segment,
                      weight=weight, by=["sample_id"]).collect(engine="streaming"), out)
        return
    items = _sample_items(samples, metadata, base_dir, sample_col, file_template)
    fn = functools.partial(_usage, segment=segment, weight=weight)
    rows = [_tag(res, sid) for sid, res in
            map_samples(fn, items, fmt=fmt, workers=threads or None)]
    _write(pl.concat(rows, how="vertical_relaxed"), out)


@app.command()
def overlap(
    samples: Optional[list[Path]] = _SAMPLES, metadata: Optional[Path] = _META,
    base_dir: Optional[Path] = _BASE, sample_col: str = _SCOL, file_template: str = _TMPL,
    fmt: str = _FMT, threads: int = _THREADS, out: Optional[Path] = _OUT,
) -> None:
    """Exact-match pairwise repertoire overlap (D, F, F2, R) for every sample pair."""
    from vdjtools.io.batch import map_samples
    from vdjtools.overlap.metrics import DEFAULT_KEY, _aggregate, _overlap_from_agg

    items = _sample_items(samples, metadata, base_dir, sample_col, file_template)
    if len(items) < 2:
        _err("overlap needs at least two samples")
    key = list(DEFAULT_KEY)
    # Aggregate each sample ONCE (streamed + parallel), then every O(n^2) pair is a join
    # over the pre-aggregated frames — not a re-aggregation of both raw frames per pair
    # (bitwise-identical to overlap_metrics, which cluster.pairwise_distances also reuses).
    aggs = map_samples(lambda df: _aggregate(df, key), items, fmt=fmt, workers=threads or None)
    rows = []
    for i in range(len(aggs)):
        for k in range(i + 1, len(aggs)):
            (a_id, a), (b_id, b) = aggs[i], aggs[k]
            rows.append({"sample_a": a_id, "sample_b": b_id,
                         **_overlap_from_agg(a, b, key)[1]})
    _write(pl.DataFrame(rows), out)


@app.command()
def dynamics(
    pre: Path = typer.Argument(..., help="Earlier sample (e.g. pre-vaccination)."),
    post: Path = typer.Argument(..., help="Later sample (e.g. post-vaccination)."),
    fmt: str = _FMT, out: Optional[Path] = _OUT,
    neff: Optional[float] = typer.Option(
        None, "--neff", help="Pin the pair's effective sample size (default: estimate it)."),
    umi: bool = typer.Option(
        False, "--umi", help="Counts are UMI/molecule counts, not reads: skip the downscale "
                             "(there is no oversampling to undo)."),
    min_total: int = typer.Option(
        6, "--min-total", help="Testability floor: combined downscaled count below this is "
                               "reported as `untested`, not as unchanged."),
    alpha: float = typer.Option(0.01, "--alpha", help="BH FDR threshold for calling a change."),
) -> None:
    """Paired within-donor test: which clonotypes changed between two timepoints.

    Classifies every clonotype as emergent / expanded / persistent / contracted / vanishing
    (or `untested`). Depth is handled PER PAIR via the effective sample size — never by
    normalising a cohort to a common depth, which is not a defined operation here.
    """
    from vdjtools.dynamics import test_pair
    from vdjtools.io.batch import read

    a, b = read(pre, fmt=fmt), read(post, fmt=fmt)
    try:
        res = test_pair(a, b, neff=None if umi else (neff if neff is not None else "auto"),
                        min_total=min_total, alpha=alpha)
    except ValueError as e:                      # pair too shallow / too few shared clonotypes
        _err(str(e))
    _info("  ".join(f"{k}={v}" for k, v in
                    sorted(res["dynamics"].value_counts().iter_rows())))
    _write(res, out)


@app.command()
def tcrnet(
    sample: Path = typer.Argument(..., help="Clonotype sample file."),
    fmt: str = _FMT, out: Optional[Path] = _OUT,
    locus: Optional[str] = typer.Option(None, "--locus", help="Force one locus (else per-locus)."),
    species: str = typer.Option("human", "--species"),
    scope: str = typer.Option("1,0,0,1", "--scope", help="Edit scope subs,ins,dels,total."),
    threads: int = typer.Option(0, "--threads", help="0 = all cores."),
) -> None:
    """Neighbourhood enrichment against a CONTROL REPERTOIRE (TCRnet).

    The control absorbs thymic selection and endemic-pathogen expansions, which a generation
    model cannot — at the cost of needing a large, HLA-matched cohort. See `alice` for the
    generative null. Neither can see a monoclonal expansion: enrichment measures breadth.
    """
    from vdjtools.io.batch import read
    from vdjtools.overlap import tcrnet as _tcrnet

    try:
        res = _tcrnet(read(sample, fmt=fmt), locus=locus, species=species, scope=scope,
                      threads=threads)
    except (ImportError, ValueError) as e:
        _err(str(e))
    _write(res, out)


@app.command()
def alice(
    sample: Path = typer.Argument(..., help="Clonotype sample file."),
    fmt: str = _FMT, out: Optional[Path] = _OUT,
    locus: Optional[str] = typer.Option(None, "--locus", help="Force one locus (else per-locus)."),
    source: str = typer.Option("olga", "--source", help="Bundled model source; leave on olga."),
    scope: str = typer.Option("1,0,0,1", "--scope", help="Edit scope subs,ins,dels,total."),
    selection_q: float = typer.Option(9.41, "--q", help="Thymic-selection factor Q."),
    min_degree: int = typer.Option(3, "--min-degree", help="Only test clonotypes with >= this "
                                                           "many neighbours (self included)."),
    min_count: int = typer.Option(2, "--min-count", help="Ignore clonotypes below this count."),
    threads: int = typer.Option(0, "--threads", help="0 = all cores."),
) -> None:
    """Neighbourhood enrichment against a V(D)J GENERATION MODEL (ALICE).

    Controls for the intrinsic biases of recombination, but knows nothing about selection or
    about which clonotypes are already common in people — the complement of `tcrnet`. Returns
    q_value and picks no threshold: the published ones differ 100-fold and were never
    reconciled.
    """
    from vdjtools.io.batch import read
    from vdjtools.overlap import alice as _alice

    try:
        res = _alice(read(sample, fmt=fmt), locus=locus, source=source, scope=scope,
                     selection_q=selection_q, min_degree=min_degree, min_count=min_count,
                     threads=threads)
    except (ImportError, KeyError, ValueError) as e:
        _err(str(e))
    _write(res, out)


# ---------------------------------------------------------------------------- model workshop
model_app = typer.Typer(
    no_args_is_help=True,
    help="Recombination-model workshop: build, learn, check, compare, score, extend.\n\n"
         "A model is named either as a directory, or as LOCUS[:source[:organism]] for a built-in "
         "(TRB, TRB:learned, TRA:arda:mouse). The single-model commands also accept the "
         "-m/--model + --source + --model-path flags the top-level pgen/generate use.",
)
app.add_typer(model_app, name="model")

_MODEL_OUT = typer.Option(None, "--out", "-o", help="Output model directory.")


def _model_arg(spec: str):
    """Resolve ``LOCUS[:source[:organism]]`` or a model directory into a Model."""
    from vdjtools.model import load_bundled, load_model

    path = Path(spec)
    if path.exists() and path.is_dir():
        return load_model(path)
    parts = spec.split(":")
    locus = parts[0]
    source = parts[1] if len(parts) > 1 else "olga"
    organism = parts[2] if len(parts) > 2 else "human"
    try:
        return load_bundled(locus, source=source, organism=organism)
    except (ValueError, FileNotFoundError) as e:
        _err(f"{spec!r} is neither a model directory nor a built-in ({e})")


def _germline_arg(v, j, d, anchors, locus, organism):
    """A germline frame from user FASTA if given, else arda's for the locus/organism."""
    from vdjtools.model import load_germline, read_germline_fasta

    if v and j:
        return read_germline_fasta(v, j, d, anchors=anchors)
    if v or j:
        _err("--germline-v and --germline-j must be given together")
    if not locus:
        _err("give --germline-v/--germline-j, or --locus to take the germline from arda")
    try:
        return load_germline(locus, organism)
    except (ImportError, ValueError) as e:
        _err(str(e))


@model_app.command("list")
def model_list() -> None:
    """List the recombination models shipped with the package (same as ``vdjtools models``)."""
    models()


@model_app.command("check")
def model_check(
    spec: str = typer.Argument(..., help="Model: a directory, or LOCUS[:source[:organism]]."),
    germline: str = typer.Option("auto", help="Reference germline: auto | none | a FASTA path."),
    organism: Optional[str] = typer.Option(None, help="Reference organism; defaults to the model manifest."),
    out: Optional[Path] = _OUT,
) -> None:
    """Audit a model against its manifest, its germline, and a reference library.

    Writes a tidy issue frame (severity, check, event, segment, allele, detail, value) and
    **exits 1 if any issue has severity "error"**, so it works as a gate in a build script.
    """
    from vdjtools.model.check import check_model

    m = _model_arg(spec)
    gl = germline
    if germline == "auto" and organism is not None:
        from vdjtools.model.reference import load_germline

        gl = load_germline(m.locus, organism)
    if germline not in ("auto", "none"):
        from vdjtools.model import read_germline_fasta

        gl = read_germline_fasta(germline, germline)
    issues = check_model(m, germline=gl)
    _write(issues, out)
    n_err = issues.filter(pl.col("severity") == "error").height
    n_warn = issues.filter(pl.col("severity") == "warn").height
    _info(f"{n_err} error(s), {n_warn} warning(s)")
    if n_err:
        raise typer.Exit(1)


@model_app.command("template")
def model_template(
    locus: Optional[str] = typer.Option(None, "--locus", help="Locus, e.g. TRB."),
    organism: str = typer.Option("human", help="Organism (arda germline), when no FASTA is given."),
    germline_v: Optional[Path] = typer.Option(None, "--germline-v", help="V-allele FASTA."),
    germline_j: Optional[Path] = typer.Option(None, "--germline-j", help="J-allele FASTA."),
    germline_d: Optional[Path] = typer.Option(None, "--germline-d", help="D-allele FASTA (makes it VDJ)."),
    anchors: Optional[Path] = typer.Option(None, help="CDR3-anchor CSV, if the FASTAs are full-length."),
    ins_max: int = typer.Option(40, help="Largest N-region insertion in the placeholder tables."),
    out: Optional[Path] = _MODEL_OUT,
) -> None:
    """Build a model scaffold from a germline library — your own FASTA, or arda's.

    The marginals are placeholders meant to be refit with ``model learn``; their support ranges
    bound what EM can then learn, which is why ``--ins-max`` is here.
    """
    from vdjtools.model.io import from_germline

    if out is None:
        _err("give an output model directory with -o")
    gl = _germline_arg(germline_v, germline_j, germline_d, anchors, locus, organism)
    try:
        m = from_germline(gl, locus=locus or "CUSTOM", organism=organism, ins_max=ins_max,
                          strict=germline_v is not None)
    except ValueError as e:
        _err(str(e))
    m.save(out)
    _info(f"{m.chain_type} template for {m.locus}: "
          f"{m.genomic['genes_v'].height} V, {m.genomic['genes_j'].height} J -> {out}")


@model_app.command("learn")
def model_learn(
    input: Path = typer.Argument(..., help="Clonotype table (TSV/Parquet) with junction + V/J calls."),
    template: Optional[str] = typer.Option(None, "--template", "-t",
                                           help="Template model, or LOCUS[:source[:organism]]."),
    locus: Optional[str] = typer.Option(None, "--locus", help="Build an arda template for this locus."),
    organism: str = typer.Option("human", help="Organism, with --locus."),
    column: Optional[str] = typer.Option(None, "--column", "-c", help="Junction column (auto-detected)."),
    max_iter: int = typer.Option(15, help="EM iteration cap."),
    tol: float = typer.Option(1e-4, help="Stop below this relative log-likelihood improvement."),
    init: str = typer.Option("align", help="align | uniform | template (template = warm start / fine-tune)."),
    gene_prior: float = typer.Option(1.0, help="Dirichlet pseudocount over functional V/J alleles."),
    nd_prior: float = typer.Option(0.0, help="Pseudocount pushing P(n_D=2) toward 0."),
    single_d: bool = typer.Option(False, "--single-d", help="Force a strict single-D model."),
    no_calls: bool = typer.Option(False, "--no-calls", help="Ignore V/J calls (much slower)."),
    verbose: bool = typer.Option(False, "--verbose", "-v",
                                 help="Report each EM iteration as it happens (to stderr)."),
    checkpoint: Optional[Path] = typer.Option(
        None, "--checkpoint", help="Save the model after each iteration, so a long fit survives "
                                   "being interrupted (resume with --resume)."),
    checkpoint_every: int = typer.Option(1, help="Checkpoint every N iterations."),
    resume_from: Optional[Path] = typer.Option(
        None, "--resume", help="Continue a fit from a checkpoint instead of starting over."),
    out: Optional[Path] = _MODEL_OUT,
) -> None:
    """Fit a model's marginals from your own sequences by EM, writing the training log alongside.

    ``--init template`` warm-starts from the template instead of realigning, which is how you
    fine-tune an existing model on a new sample rather than fitting from scratch. ``-v`` prints the
    log-likelihood and its relative change per iteration, so a long fit is visibly converging
    rather than merely running.

    For a fit that will not finish in one sitting, ``--checkpoint DIR`` saves the model after every
    iteration and ``--resume DIR`` picks it back up — resuming reaches the same log-likelihood as an
    uninterrupted run, and the training log spans every attempt.
    """
    from vdjtools.io.batch import read as _read
    from vdjtools.model.infer import infer_frame, print_progress, training_frame

    if out is None:
        _err("give an output model directory with -o")
    if resume_from is not None:
        base = _model_arg(str(resume_from))
        init = "template"
        if checkpoint is None:
            checkpoint = resume_from
        _info(f"resuming from {resume_from}")
    elif template is None and locus is None:
        _err("give a template with --template, a locus with --locus, or --resume a checkpoint")
    elif template is not None:
        base = _model_arg(template)
    else:
        from vdjtools.model.io import from_arda

        base = from_arda(locus, organism)
    try:
        clones = _read(input, fmt="auto")
    except Exception:  # noqa: BLE001 - fall back to a plain table read
        clones = pl.read_parquet(input) if input.suffix in (".parquet", ".pq") else \
            pl.read_csv(input, separator="\t", infer_schema_length=20000)
    try:
        m, rep = infer_frame(base, clones, seq_col=column, use_calls=not no_calls,
                             max_iter=max_iter, tol=tol, init=init,
                             gene_prior=gene_prior, nd_prior=nd_prior, single_d=single_d,
                             progress=print_progress() if verbose else None,
                             checkpoint=checkpoint, checkpoint_every=checkpoint_every)
    except (ValueError, KeyError) as e:
        _err(str(e))
    m.save(out)
    log = training_frame(m)
    _info(f"{rep.n_iter} iterations, converged={rep.converged}, "
          f"loglik {log['loglik'][0]:.3f} -> {log['loglik'][-1]:.3f} -> {out}")


@model_app.command("build")
def model_build(
    chains: str = typer.Option(",".join(("TRA", "TRB")), "--chains", help="Comma-separated chains."),
    groups: str = typer.Option("human", "--groups", help="Comma-separated read groups."),
    workers: Optional[int] = typer.Option(None, help="Concurrent chain builds (default: cores/2)."),
    work_dir: Path = typer.Option(Path("/tmp/vdjtools_build"), help="Scratch dir for arda output."),
    cap: Optional[int] = typer.Option(None, help="Cap reads per chain (default: use every read)."),
    max_iter: int = typer.Option(15, help="EM iteration cap."),
    verbose: bool = typer.Option(False, "--verbose", "-v",
                                 help="Stream arda's mapping output and each EM iteration."),
    out: Optional[Path] = _MODEL_OUT,
) -> None:
    """Build models from the full AIRR read corpus: fetch, arda-map, then EM — several chains at once.

    This is the real training path (raw FASTQ from ``isalgo/airr_model_read``) and needs arda's
    mmseqs2. Mapping is minutes per chain and EM on a D-bearing locus can be far longer, so **use
    ``-v``** — without it the whole run is silent until a chain finishes, and a slow fit is
    indistinguishable from a stuck one.

    LAB-ONLY: ``isalgo/airr_model_read`` is a PRIVATE HuggingFace dataset, so without access this
    command stops at a 401. That is expected outside the lab and is not a bug. The bundled models
    ship with vdjtools, are the versioned reference, and need no rebuild — ``vdjtools models``
    lists them.
    """
    from vdjtools.model.data import build_all

    if out is None:
        _err("give an output directory with -o")
    res = build_all([c.strip() for c in chains.split(",") if c.strip()],
                    groups=tuple(g.strip() for g in groups.split(",") if g.strip()),
                    workers=workers, out_dir=out, work_dir=work_dir, cap=cap, iters=max_iter,
                    verbose=verbose)
    ok = [r["stats"] for r in res.values() if "stats" in r]
    for key, r in res.items():
        if "error" in r:
            typer.secho(f"{key}: FAILED {r['error']}", fg=typer.colors.RED, err=True)
    if not ok:
        _err("every build failed")
    _write(pl.DataFrame(ok), None)
    _info(f"{len(ok)}/{len(res)} chain(s) built -> {out}")


@model_app.command("extend")
def model_extend(
    spec: str = typer.Argument(..., help="Model: a directory, or LOCUS[:source[:organism]]."),
    locus: Optional[str] = typer.Option(None, "--locus", help="Locus for the arda germline (default: the model's)."),
    organism: str = typer.Option("human", help="Organism for the arda germline."),
    germline_v: Optional[Path] = typer.Option(None, "--germline-v", help="V-allele FASTA."),
    germline_j: Optional[Path] = typer.Option(None, "--germline-j", help="J-allele FASTA."),
    germline_d: Optional[Path] = typer.Option(None, "--germline-d", help="D-allele FASTA."),
    anchors: Optional[Path] = typer.Option(None, help="CDR3-anchor CSV, if the FASTAs are full-length."),
    weight: float = typer.Option(1.0, help="Mass for a new allele of a known gene, relative to its gene-mate."),
    out: Optional[Path] = _MODEL_OUT,
) -> None:
    """Add alleles from a larger germline library, seeded from what the model already knows.

    Each pre-existing gene keeps its total usage — a richer library splits a gene's mass more
    finely rather than multiplying it. This seeds; follow with ``model learn --init template``.
    """
    from vdjtools.model.infer import extend_alleles

    if out is None:
        _err("give an output model directory with -o")
    m = _model_arg(spec)
    gl = _germline_arg(germline_v, germline_j, germline_d, anchors, locus or m.locus, organism)
    before = {k: v.height for k, v in m.genomic.items()}
    try:
        e = extend_alleles(m, gl, weight=weight)
    except ValueError as ex:
        _err(str(ex))
    e.save(out)
    _info(", ".join(f"{k}: {before[k]}->{v.height}" for k, v in e.genomic.items()) + f" -> {out}")


@model_app.command("rescale")
def model_rescale(
    spec: str = typer.Argument(..., help="Model: a directory, or LOCUS[:source[:organism]]."),
    samples: list[Path] = typer.Argument(..., help="Clonotype sample file(s) supplying the target usage."),
    fmt: str = _FMT,
    no_v: bool = typer.Option(False, "--no-v", help="Leave P(V) alone."),
    no_j: bool = typer.Option(False, "--no-j", help="Leave P(J) alone."),
    aggregate: str = typer.Option("pool", help="Combine several samples: pool | mean."),
    out: Optional[Path] = _MODEL_OUT,
) -> None:
    """Replace a model's V/J usage with your own sample's, keeping its junction model.

    V/J usage is protocol-dependent (5'RACE and DNA-multiplex amplify different V genes at very
    different rates); the recombination machinery underneath is not. Pass the repertoire you are
    actually going to score.
    """
    from vdjtools.io.batch import read as _read
    from vdjtools.model import rescale_usage

    if out is None:
        _err("give an output model directory with -o")
    m = _model_arg(spec)
    frames = [_read(s, fmt=fmt) for s in samples]
    try:
        r = rescale_usage(m, frames if len(frames) > 1 else frames[0],
                          v=not no_v, j=not no_j, aggregate=aggregate)
    except ValueError as e:
        _err(str(e))
    r.save(out)
    _info(f"usage rescaled from {len(frames)} sample(s) -> {out}")


@model_app.command("export")
def model_export(
    spec: str = typer.Argument(..., help="Model: a directory, or LOCUS[:source[:organism]]."),
    long: bool = typer.Option(False, "--long", help="One flat long table of every marginal."),
    format: str = typer.Option("tsv", "--format", help="Model-directory format: tsv | csv | parquet."),
    out: Optional[Path] = typer.Option(None, "--out", "-o", help="Output file (--long) or directory."),
) -> None:
    """Export a model's probabilities as tables — a hand-editable directory, or one long frame.

    Both round-trip: a TSV model directory loads straight back with ``--model-path``, and the long
    frame goes back through ``vdjtools.model.set_marginals``.
    """
    from vdjtools.model.io import marginals_frame

    m = _model_arg(spec)
    if long:
        _write(marginals_frame(m), out)
        return
    if out is None:
        _err("give an output directory with -o (or use --long to write one table)")
    try:
        m.save(out, fmt=format)
    except ValueError as e:
        _err(str(e))
    _info(f"{len(m.tables)} marginal + {len(m.genomic)} germline table(s) as {format} -> {out}")


@model_app.command("net")
def model_net(
    spec: str = typer.Argument(..., help="Model: a directory, or LOCUS[:source[:organism]]."),
    format: str = typer.Option("dot", "--format", help="dot | svg | pdf | png (non-dot needs graphviz)."),
    out: Optional[Path] = typer.Option(None, "--out", "-o", help="Output file (default: stdout, dot only)."),
) -> None:
    """Render the model's recombination Bayes net, nodes annotated with entropy and edges with MI."""
    from vdjtools.model.analyze import bayes_net_dot, render_dot

    m = _model_arg(spec)
    dot = bayes_net_dot(m)
    if format == "dot":
        if out is None:
            typer.echo(dot)
        else:
            Path(out).write_text(dot)
            _info(f"wrote {out}")
        return
    if out is None:
        _err("give an output path with -o for a rendered format")
    try:
        _info(f"wrote {render_dot(dot, out, fmt=format)}")
    except RuntimeError as e:
        _err(str(e))


@model_app.command("entropy")
def model_entropy(
    spec: str = typer.Argument(..., help="Model: a directory, or LOCUS[:source[:organism]]."),
    table: str = typer.Option("entropy", help="entropy | mi | total."),
    out: Optional[Path] = _OUT,
) -> None:
    """Information content per recombination event: entropy, mutual information, or the total."""
    from vdjtools.model.analyze import entropy_table, mutual_information, total_entropy

    m = _model_arg(spec)
    if table == "entropy":
        _write(entropy_table(m), out)
    elif table == "mi":
        _write(mutual_information(m), out)
    elif table == "total":
        t = total_entropy(m)
        _write(t, out)
        _info(f"scenario entropy {t['contribution_bits'].sum():.2f} bits "
              f"({2 ** t['contribution_bits'].sum():.3g} distinct rearrangements)")
    else:
        _err("--table must be entropy, mi or total")


@model_app.command("diversity")
def model_diversity(
    spec: str = typer.Argument(..., help="Model: a directory, or LOCUS[:source[:organism]]."),
    n: int = typer.Option(5000, "--number", "-n", help="Sequences to generate for the estimate."),
    seed: int = typer.Option(0, help="Generation seed."),
    productive: bool = typer.Option(False, "--productive", help="Estimate over productive rearrangements only."),
    out: Optional[Path] = _OUT,
) -> None:
    """Estimate total diversity: scenario entropy, sequence entropy, and effective diversity.

    Reports both Hill numbers — ``2^H`` (the usual "~10^x distinct sequences" figure) and
    ``1/E[Pgen]`` (how many draws before two coincide). Monte Carlo, so give it a seed.
    """
    from vdjtools.model.score import diversity as _div

    m = _model_arg(spec)
    try:
        d = _div(m, n=n, seed=seed, productive_only=productive)
    except ValueError as e:
        _err(str(e))
    _write(d, out)
    r = d.to_dicts()[0]
    _info(f"scenario {r['scenario_entropy_bits']:.1f} bits, sequence "
          f"{r['sequence_entropy_bits']:.2f}+-{r['sequence_entropy_se_bits']:.2f} bits -> "
          f"Shannon {r['diversity_shannon']:.3g}, Simpson {r['diversity_simpson']:.3g}")


@model_app.command("compare")
def model_compare(
    a: str = typer.Argument(..., help="First model: a directory, or LOCUS[:source[:organism]]."),
    b: str = typer.Argument(..., help="Second model."),
    by: str = typer.Option("allele", help="Align on allele | gene. Use gene across germline sources."),
    usage: Optional[str] = typer.Option(None, "--usage", help="Instead emit V/J usage side by side: v | j | d."),
    dot: Optional[Path] = typer.Option(None, "--dot", help="Also write the comparison graph here."),
    dot_format: str = typer.Option("dot", "--dot-format", help="dot | svg | pdf | png."),
    out: Optional[Path] = _OUT,
) -> None:
    """Compare two models parameter by parameter: per-event divergence and support differences.

    Jensen-Shannon is the headline (symmetric, bounded, finite when the supports differ);
    ``tv_max`` finds the one broken gene an average hides.
    """
    from vdjtools.model.analyze import compare_models, compare_net_dot, compare_usage, render_dot

    ma, mb = _model_arg(a), _model_arg(b)
    labels = (a, b)
    if usage:
        _write(compare_usage(ma, mb, usage), out)
    else:
        if by not in ("allele", "gene"):
            _err("--by must be allele or gene")
        _write(compare_models(ma, mb, by=by), out)
    if dot is not None:
        src = compare_net_dot(ma, mb, labels=labels)
        if dot_format == "dot":
            Path(dot).write_text(src)
            _info(f"wrote {dot}")
        else:
            try:
                _info(f"wrote {render_dot(src, dot, fmt=dot_format)}")
            except RuntimeError as e:
                _err(str(e))


@model_app.command("compare-pgen")
def model_compare_pgen(
    a: str = typer.Argument(..., help="First model: a directory, or LOCUS[:source[:organism]]."),
    b: str = typer.Argument(..., help="Second model."),
    input: Path = typer.Argument(..., help="Table (TSV) or list of CDR3 sequences."),
    column: Optional[str] = typer.Option(None, "--column", "-c", help="Sequence column (auto-detected)."),
    v_col: Optional[str] = typer.Option(None, "--v-col", help="V-call column to condition on."),
    j_col: Optional[str] = typer.Option(None, "--j-col", help="J-call column to condition on."),
    seq_type: str = typer.Option("auto", "--type", help="auto | aa | nt."),
    summary: bool = typer.Option(False, "--summary", help="One row of distribution statistics instead."),
    no_header: bool = typer.Option(False, "--no-header", help="Input is a bare sequence list."),
    out: Optional[Path] = _OUT,
) -> None:
    """Score one sequence set under two models and compare the Pgen distributions.

    ``--summary`` gives correlations, the KS statistic, and — the number that usually matters —
    how many sequences each model can score that the other assigns Pgen 0.
    """
    from vdjtools.model.score import compare_pgen, pgen_summary

    ma, mb = _model_arg(a), _model_arg(b)
    df, seqcol = _read_seq_table(input, column, no_header)
    use_calls = bool(v_col or j_col)
    try:
        cmp = compare_pgen(ma, mb, df, labels=("a", "b"), kind=seq_type, use_calls=use_calls,
                           on_unknown="marginalize", seq_col=seqcol, v_col=v_col, j_col=j_col)
    except (ValueError, KeyError) as e:
        _err(str(e))
    _write(pgen_summary(cmp) if summary else cmp, out)


@model_app.command("loglik")
def model_loglik(
    input: Path = typer.Argument(..., help="Table (TSV) or list of CDR3 sequences."),
    spec: str = typer.Argument(..., help="Model: a directory, or LOCUS[:source[:organism]]."),
    column: Optional[str] = typer.Option(None, "--column", "-c", help="Sequence column (auto-detected)."),
    v_col: Optional[str] = typer.Option(None, "--v-col", help="V-call column to condition on."),
    j_col: Optional[str] = typer.Option(None, "--j-col", help="J-call column to condition on."),
    weights_col: Optional[str] = typer.Option(None, "--weights-col", help="Per-clonotype weight column."),
    seq_type: str = typer.Option("auto", "--type", help="auto | aa | nt."),
    per_sequence: bool = typer.Option(False, "--per-sequence", help="Emit per-sequence Pgen instead."),
    no_header: bool = typer.Option(False, "--no-header", help="Input is a bare sequence list."),
    out: Optional[Path] = _OUT,
) -> None:
    """How well a model explains a sequence set: log-likelihood, free parameters, AIC and BIC.

    Nucleotide input gives a properly normalized likelihood, so BIC is meaningful; amino-acid input
    is a relative score on one fixed sequence set only. Sequences the model cannot generate are
    counted in ``n_scoreable``, never turned into -inf.
    """
    from vdjtools.model.score import model_fit, pgen_frame

    m = _model_arg(spec)
    df, seqcol = _read_seq_table(input, column, no_header)
    use_calls = bool(v_col or j_col)
    kw = dict(kind=seq_type, use_calls=use_calls, on_unknown="marginalize",
              seq_col=seqcol, v_col=v_col, j_col=j_col)
    try:
        if per_sequence:
            _write(pgen_frame(m, df, **kw), out)
            return
        fit = model_fit(m, df, weights=weights_col, **kw)
    except (ValueError, KeyError) as e:
        _err(str(e))
    _write(fit, out)
    r = fit.to_dicts()[0]
    _info(f"loglik {r['loglik_sum']:.1f} over {r['n_scoreable']:.0f}/{r['n']:.0f} scoreable, "
          f"k={r['k']}, AIC={r['aic']:.1f}, BIC={r['bic']:.1f}")


@model_app.command("log")
def model_log(
    spec: str = typer.Argument(..., help="Model: a directory, or LOCUS[:source[:organism]]."),
    out: Optional[Path] = _OUT,
) -> None:
    """Show a model's EM training log — log-likelihood per iteration, one block per run."""
    from vdjtools.model.infer import training_frame

    m = _model_arg(spec)
    log = training_frame(m)
    if not log.height:
        _err(f"{spec!r} carries no training log (it was not fitted by this tool)")
    _write(log, out)


# ------------------------------------------------------------------------------ single-cell
sc_app = typer.Typer(
    no_args_is_help=True,
    help="Single-cell (10x / AIRR Cell) ingestion, pairing QC, paired Pgen, and interop.\n\n"
         "Inputs are auto-detected: a 10x contig-annotation CSV (all_/filtered_"
         "contig_annotations.csv) or any AIRR Rearrangement TSV carrying a cell_id column "
         "(CellRanger's airr_rearrangement.tsv, arda's barcoded output, our own).",
)
app.add_typer(sc_app, name="sc")


SC_FORMATS = ("auto", "10x", "airr", "arda")


def _sniff_sc(path: Path) -> str:
    """Detect a single-cell input format from its HEADER, not its filename.

    Filenames are not a contract -- people rename exports, and ``arda cells`` and CellRanger
    both produce files with "contig" in the name but different layouts. So dispatch on the
    columns actually present: 10x contig CSVs are keyed by ``barcode`` + ``contig_id``, arda's
    single-cell AIRR carries its tandem-D ``d2_call``, and anything else with a ``cell_id`` is
    plain AIRR.
    """
    sep = "," if path.name.lower().replace(".gz", "").endswith(".csv") else "\t"
    try:
        cols = set(pl.read_csv(path, separator=sep, n_rows=0,
                               infer_schema_length=0).columns)
    except Exception as e:  # unreadable / not tabular
        _err(f"{path}: cannot read a header ({e})")
    if {"barcode", "contig_id"} <= cols:
        return "10x"
    if "d2_call" in cols and "cell_id" in cols:
        return "arda"
    if "cell_id" in cols:
        return "airr"
    _err(f"{path}: not a single-cell table -- no 'cell_id', and no 10x 'barcode'/'contig_id' "
         f"(columns: {sorted(cols)[:8]}...). Pass --fmt to force a reader.")


def _read_sc(path: Path, fmt: str = "auto", *,
             require_cell: bool = True, require_high_conf: bool = True,
             consensus: Optional[Path] = None) -> pl.DataFrame:
    """Read any supported single-cell input into the canonical long frame."""
    from vdjtools import sc as _sc

    if fmt not in SC_FORMATS:
        _err(f"--fmt must be one of {', '.join(SC_FORMATS)}; got {fmt!r}")
    if fmt == "auto":
        fmt = _sniff_sc(path)
    try:
        if fmt == "10x":
            return _sc.read_10x(path, consensus, require_cell=require_cell,
                                require_high_conf=require_high_conf)
        if fmt == "arda":
            return _sc.read_arda_cells(path)
        return _sc.read_airr_cell(path)
    except (FileNotFoundError, ValueError) as e:
        _err(f"{path}: {e}")


# Shared single-cell options. The input is a positional argument on every command, so the
# reader flags live here rather than being repeated five times.
_SC_IN = typer.Argument(..., help="10x contig CSV, AIRR TSV with cell_id, or an `arda cells` prefix.")
_SC_FMT = typer.Option("auto", "--fmt", help="Input format: auto (sniff the header) | 10x | airr | arda.")
_SC_PAIR = typer.Option("TRA_TRB", "--locus-pair", help="TRA_TRB, TRG_TRD, IGH_IGK or IGH_IGL.")
_SC_CELL = typer.Option(True, "--require-cell/--no-require-cell",
                        help="10x only: keep only contigs flagged is_cell.")
_SC_CONF = typer.Option(True, "--require-high-conf/--no-require-high-conf",
                        help="10x only: keep only high_confidence contigs.")
_SC_CONS = typer.Option(None, "--consensus",
                        help="10x only: consensus_annotations.csv to source V/D/J calls from.")


@sc_app.command("convert")
def sc_convert(
    contigs: Path = _SC_IN,
    out: Optional[Path] = _OUT,
    fmt: str = _SC_FMT,
    airr: bool = typer.Option(False, "--airr", help="Emit the AIRR Rearrangement spelling "
                                                    "(junction, consensus_count) instead of "
                                                    "the canonical vdjtools columns."),
    require_cell: bool = _SC_CELL,
    require_high_conf: bool = _SC_CONF,
    consensus: Optional[Path] = _SC_CONS,
) -> None:
    """Read a single-cell contig table into the canonical (or AIRR) long frame."""
    from vdjtools import sc as _sc

    cells = _read_sc(contigs, fmt, require_cell=require_cell,
                     require_high_conf=require_high_conf, consensus=consensus)
    _write(_sc.to_airr(cells) if airr else cells, out)


@sc_app.command("pair")
def sc_pair(
    contigs: Path = _SC_IN,
    out: Optional[Path] = _OUT,
    fmt: str = _SC_FMT,
    locus_pair: str = _SC_PAIR,
    resolve: bool = typer.Option(True, "--resolve/--no-resolve",
                                 help="Reduce each cell to one heavy + one (or two) light "
                                      "chains first. --no-resolve pairs every combination."),
    flag_mispairing: bool = typer.Option(False, "--flag-mispairing",
                                         help="Add mispairing_flag / mispairing_reason."),
    max_slaves_per_master: Optional[int] = typer.Option(
        None, "--max-slaves-per-master",
        help="With --flag-mispairing: flag a beta paired with more than N distinct alphas "
             "as ambient (default: an automatic threshold)."),
    drop_mispaired: bool = typer.Option(False, "--drop-mispaired",
                                        help="With --flag-mispairing: drop the flagged rows "
                                             "instead of labelling them."),
    require_cell: bool = _SC_CELL,
    require_high_conf: bool = _SC_CONF,
) -> None:
    """Resolve each cell's chains and emit one row per paired receptor."""
    from vdjtools import sc as _sc

    if (max_slaves_per_master is not None or drop_mispaired) and not flag_mispairing:
        _err("--max-slaves-per-master / --drop-mispaired need --flag-mispairing")
    cells = _read_sc(contigs, fmt, require_cell=require_cell,
                     require_high_conf=require_high_conf)
    try:
        paired = _sc.pair_chains(cells, locus_pair=locus_pair, resolve=resolve)
        if flag_mispairing:
            paired = _sc.flag_mispairing(paired,
                                         max_slaves_per_master=max_slaves_per_master,
                                         drop=drop_mispaired)
    except ValueError as e:
        _err(str(e))
    _write(paired, out)


@sc_app.command("qc")
def sc_qc(
    contigs: Path = _SC_IN,
    out: Optional[Path] = _OUT,
    fmt: str = _SC_FMT,
    locus_pair: str = _SC_PAIR,
    require_cell: bool = _SC_CELL,
    require_high_conf: bool = _SC_CONF,
) -> None:
    """Chain-multiplicity quadrants: how many cells carry n light x n heavy chains."""
    from vdjtools import sc as _sc

    cells = _read_sc(contigs, fmt, require_cell=require_cell,
                     require_high_conf=require_high_conf)
    try:
        mult = _sc.chain_multiplicity(cells, locus_pair=locus_pair)
    except ValueError as e:
        _err(str(e))
    _info(f"{cells['cell_id'].n_unique()} cells, {cells.height} contigs")
    _write(mult, out)


@sc_app.command("pgen")
def sc_pgen(
    contigs: Path = _SC_IN,
    out: Optional[Path] = _OUT,
    fmt: str = _SC_FMT,
    locus_pair: str = _SC_PAIR,
    source: str = typer.Option("olga", "--source", help="Bundled model source: olga | learned."),
    condition_vj: bool = typer.Option(True, "--condition-vj/--no-condition-vj",
                                      help="Condition each chain's Pgen on its V/J call. "
                                           "--no-condition-vj marginalises over all V/J."),
    resolve_genes: bool = typer.Option(True, "--resolve-genes/--no-resolve-genes",
                                       help="Resolve a gene-level call (TRBV10-3, what "
                                            "CellRanger emits) to its representative model "
                                            "allele. --no-resolve-genes scores only exact "
                                            "allele matches, leaving the rest null."),
    alpha_locus: Optional[str] = typer.Option(None, "--alpha-locus",
                                              help="Force the light-chain locus (else inferred "
                                                   "from the V-call prefix)."),
    beta_locus: Optional[str] = typer.Option(None, "--beta-locus",
                                             help="Force the heavy-chain locus."),
) -> None:
    """Paired generation probability per cell: Pgen(alpha) * Pgen(beta)."""
    from vdjtools import sc as _sc

    try:
        paired = _sc.pair_chains(_read_sc(contigs, fmt), locus_pair=locus_pair)
        scored = _sc.paired_pgen(paired, source=source, condition_vj=condition_vj,
                                 resolve_genes=resolve_genes, alpha_locus=alpha_locus,
                                 beta_locus=beta_locus)
    except (ImportError, KeyError, ValueError) as e:
        _err(str(e))
    n_scored = scored["pgen_paired"].drop_nulls().len()
    _info(f"scored {n_scored}/{scored.height} receptors")
    _write(scored, out)


SC_EXPORT_TARGETS = ("airr", "screpertoire", "screpertoire-10x", "scirpy", "dandelion",
                     "airr-cell")


@sc_app.command("export")
def sc_export(
    contigs: Path = _SC_IN,
    to: str = typer.Option(..., "--to", help="airr | screpertoire | screpertoire-10x | "
                                             "scirpy | dandelion | airr-cell."),
    out: Path = typer.Option(..., "--out", "-o", help="Output file."),
    fmt: str = _SC_FMT,
    index_chains: bool = typer.Option(True, "--index-chains/--no-index-chains",
                                      help="--to scirpy: run scirpy.pp.index_chains, which its "
                                           "tools need."),
    repertoire_id: str = typer.Option("", "--repertoire-id",
                                      help="--to airr-cell: the AIRR Cell repertoire_id."),
) -> None:
    """Export for a downstream tool (scirpy / dandelion / scRepertoire / AIRR)."""
    from vdjtools import sc as _sc

    if to not in SC_EXPORT_TARGETS:
        _err(f"--to must be one of {', '.join(SC_EXPORT_TARGETS)}; got {to!r}")
    cells = _read_sc(contigs, fmt)
    try:
        if to == "airr":
            _sc.write_airr(cells, out)
        elif to == "screpertoire":
            _sc.write_screpertoire(cells, out)
        elif to == "screpertoire-10x":
            _sc.write_screpertoire(cells, out, format="10x")
        elif to == "airr-cell":
            _sc.write_airr_cell(cells, out, repertoire_id=repertoire_id)
        elif to == "scirpy":
            # ponytail: VDJ-only AnnData. Pairing with gene expression is
            # sc.to_scirpy(cells, gex=...) in Python, where you already hold the GEX
            # AnnData; a --gex flag here only added a MuData serialisation step.
            _sc.to_scirpy(cells, index_chains=index_chains).write_h5ad(out)
        elif to == "dandelion":
            _sc.to_dandelion(cells).write_h5ddl(out)
    except (ImportError, ValueError) as e:
        _err(str(e))
    _info(f"wrote {cells.height} contigs ({cells['cell_id'].n_unique()} cells) -> {out}")
