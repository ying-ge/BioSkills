"""Model I/O: import from OLGA's format, and save/load our native parquet directory.

``from_olga`` uses OLGA's own parser (an optional, import-time dependency — the ``[oracle]``
extra) to read a bootstrap model, then tabularises its processed arrays into our long-format
polars schema. Native ``load_model`` reads the parquet directory and needs no OLGA.

Conventions reproduced exactly (so a loaded model is bit-faithful to OLGA — verified by the
round-trip test):

- Gene order follows OLGA's IGoR gene index (``genV``/``genD``/``genJ`` list order).
- ``ndel = array_index - max_palindrome`` (biological deletion; negatives are palindromic P-nt).
- ``PDJ`` (VDJ) is factored to ``j_choice`` (marginal ``P(J)``) × ``d_gene`` given J (``P(D|J)``);
  ``PVJ`` (VJ) to ``v_choice`` (``P(V)``) × ``j_choice`` given V (``P(J|V)``). Both reconstruct exactly.
- Dinucleotide row ``(from_nt, to_nt, p)`` = ``R[to_nt, from_nt]`` (OLGA's column-stochastic Markov).
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import polars as pl

from .events import Event, EventKind
from .model import Model
from .schema import Manifest, table_columns

_NT = "ACGT"
_ACGT = frozenset(_NT)


def _gene(allele: str) -> str:
    return allele.split("*")[0]


def _read_anchors(path: Path) -> dict[str, tuple[int, str]]:
    """Anchor CSV -> {gene_allele: (anchor_index, functionality_char)}."""
    if not path.exists():
        return {}
    df = pl.read_csv(path)
    return {r[0]: (int(r[1]), str(r[2])) for r in df.iter_rows()}


#: How far a V anchor may be stepped, in whole framework codons, when the recorded one does not land
#: on Cys104. Two covers every case seen (all observed drift is exactly one codon) and is small
#: enough that a genuinely different germline is never silently re-anchored.
_ANCHOR_SEARCH_CODONS = 2


def _anchored(seg: str, cdr3: str) -> bool:
    """Does ``cdr3`` start at the conserved Cys (V) or end at the conserved Phe/Trp (J)?"""
    from . import reference as ref

    if len(cdr3) < 3:
        return False
    return ref.translate(cdr3[:3]) == "C" if seg == "v" else ref.translate(cdr3[-3:]) in ("F", "W")


def _reanchor(seg: str, cdr3: str, full: str, a: int) -> "tuple[int, str] | None":
    """A corrected ``(anchor, cdr3_segment)`` for an allele whose CDR3 region is not anchored.

    The two segments get different treatment because their failure modes are different, and both
    rules are deliberately unable to *shorten* a germline -- a shorter germline strands the allele's
    own deletion mass on trims it can no longer reach, which is the ``IGKV3-20`` trap.

    * **V**: step the anchor by whole framework codons, smallest shift first, until the region starts
      at Cys104. Drift here is an off-by-one-codon index against the germline it points into.
    * **J**: no search. A J's CDR3 region runs from the 5' end *through* the ``[FW]118`` codon, so
      ``full[anchor:]`` takes the framework on the wrong side of it -- a structural error, not a
      shifted index, and it is repaired only when the stored region is exactly that wrong slice and
      the right one is properly anchored. Searching a J instead finds an earlier in-frame Phe by
      coincidence and truncates the region: measured on mouse ``TRAJ19*01``, a two-codon search cut
      arda's 30-nt germline to 24. Alleles that genuinely do not end at Phe/Trp (``TRBJ2-7*02``
      templates ``SYEQYV``) must stay as they are, and this rule leaves them alone.
    """
    if seg == "v":
        for shift in sorted(range(-_ANCHOR_SEARCH_CODONS * 3, _ANCHOR_SEARCH_CODONS * 3 + 1, 3),
                            key=lambda d: (abs(d), d)):
            b = a + shift
            if 0 <= b and b + 3 <= len(full) and _anchored("v", full[b:]) and set(full[b:]) <= _ACGT:
                return b, full[b:]
        return None
    if cdr3 == full[a:] and a + 3 <= len(full):
        right = full[:a + 3]
        if _anchored("j", right) and set(right) <= _ACGT:
            return a, right
    return None


def repair_anchors(genomic: dict, *, report: bool = False) -> dict:
    """Re-anchor any V/J allele whose CDR3-region germline does not start/end at its conserved codon.

    A V segment's CDR3 region begins at the Cys104 codon and a J's ends at the Phe/Trp118 codon.
    That is the definition, so an allele failing it carries a germline sliced at the wrong index, and
    every Pgen through that allele is **exactly 0** with no error raised. See :func:`_reanchor` for
    the per-segment rule, and note that an allele it cannot correct is left untouched: a missing
    conserved codon is a different problem from a shifted index, and inventing one is worse than the
    hole. Applied on build **and on load**, so a shipped artifact is corrected on read.

    Wanted for **every allele**, not only a gene's representative: an allele-level Pgen query names
    the allele directly, and :func:`~vdjtools.model.collapse.collapse_alleles` may pick any of them.

    Measured origin: OLGA's ``human_T_beta`` ships ``TRBV4-3*02`` with anchor 267 against its own
    287-nt germline while ``*01`` is 284 nt at the same 267, so OLGA's own cut segment for ``*02``
    starts one Leu codon (``CTC``) before Cys104. OLGA never returns 0 for a *gene*-level TRBV4-3
    query because it marginalises over the alleles and ``*01`` carries the mass; our collapsed model
    chose ``*02`` (24 nt against ``*01``'s 21, and length led the ranking) and so returned
    ``pgen_aa == 0`` for **698 of 698** real TRBV4-3 junctions in a 25,000-clonotype human TRB
    control set -- 2.8% of it -- against OLGA's 1.06e-08 for the same junction.

    Args:
        genomic: A model's ``{"genes_v": ..., "genes_j": ..., ...}`` frames.
        report: Also return the list of repaired alleles.

    Returns:
        The frames, with ``anchor``, ``cdr3_segment`` and ``cut_segment`` corrected where needed
        (``{name: frame}``, or ``(frames, repaired)`` when ``report``).
    """
    from . import reference as ref

    out, repaired = dict(genomic), []
    for name, g in genomic.items():
        seg = name.split("_")[1][0]
        if seg not in ("v", "j") or "anchor" not in g.columns:
            continue
        # The palindrome extension the existing cuts were built with, read off the frame rather than
        # plumbed in: cut_segment is cdr3_segment plus up to max_pal palindromic nt.
        max_pal = max((len(c or "") - len(d or "")
                       for c, d in zip(g["cut_segment"], g["cdr3_segment"])), default=0)
        rows = g.to_dicts()
        for r in rows:
            cut, cdr3 = r["cut_segment"] or "", r["cdr3_segment"] or ""
            full, a = r["full_germline"] or "", int(r["anchor"])
            if not cut or a < 0 or _anchored(seg, cdr3):
                continue
            got = _reanchor(seg, cdr3, full, a)
            if got is None:
                continue
            r["anchor"], r["cdr3_segment"] = got
            r["cut_segment"] = ref.cut_segment(got[1], seg.upper(), max_pal)
            r["functional"] = len(r["cut_segment"]) > 0
            repaired.append(f"{r[f'{seg}_allele']}: anchor {a} -> {got[0]}, "
                            f"{len(cdr3)} -> {len(got[1])} nt")
        out[name] = pl.DataFrame(rows, schema=g.schema)
    return (out, repaired) if report else out


def _genomic_table(gen_list, anchors, cut_segs, *, seg: str, has_anchor: bool,
                   max_pal: int = 0, derive_orf: bool = False) -> pl.DataFrame:
    """Build a genes_<seg> frame from OLGA's gen* list + cut segments (+ anchors for V/J).

    ``derive_orf`` (opt-in, off by default): OLGA leaves the CDR3-trim and cut segment EMPTY for a
    handful of ORF V/J alleles even though their full germline + CDR3 anchor are present, so an ORF
    gene an aligner (arda) actually calls — TRBV23-1 is 8.6% of a real TRB repertoire — is unscoreable
    and pinned to P(V)=0. With ``derive_orf=True`` the missing CDR3-region germline is reconstructed
    (``full[anchor:]``, palindrome-cut) so EM can learn its usage. **Off for the ``from_olga`` oracle**:
    OLGA itself excludes those empty-cut genes from Pgen, so deriving them there would break the
    exact-OLGA-Pgen invariant — the model *builder* turns it on for arda-native learned models only.
    """
    from . import reference as ref

    rows = []
    for i, entry in enumerate(gen_list):
        name = entry[0].strip()   # OLGA's "% TRBD1*01;..." leaves a leading space — see from_olga
        cut = cut_segs[i]
        if has_anchor:  # genV/genJ entries are [name, cdr3_trim, full_germline]
            cdr3_seg, full = entry[1], entry[2]
            anchor = anchors.get(name, (-1, ""))[0]
            if derive_orf and not cut and anchor >= 0 and len(full) > anchor:
                # The anchor is an nt offset into the FULL germline marking the conserved codon, and
                # the CDR3 region lies on opposite sides of it per segment: V runs from the Cys104
                # codon to the 3' end, J from the 5' end THROUGH the [FW]118 codon. Slicing
                # `full[anchor:]` for a J takes the framework *downstream* of Phe118 instead — the
                # wrong side, and silent, because the result is still a plausible in-locus sequence.
                derived = full[anchor:] if seg == "v" else full[:anchor + 3]
                if set(derived) <= _ACGT:  # skip IUPAC-ambiguous germlines (e.g. IGHV3-54 'Y'): unencodable
                    cdr3_seg = derived
                    cut = ref.cut_segment(cdr3_seg, seg.upper(), max_pal)
        else:  # genD entries are [name, germline]
            full, cdr3_seg, anchor = entry[1], entry[1], -1
        rows.append(
            {
                f"{seg}_allele": name,
                "gene": _gene(name),
                "full_germline": full,
                "cdr3_segment": cdr3_seg,
                "cut_segment": cut,
                "anchor": anchor,
                "functional": len(cut) > 0,
            }
        )
    return pl.DataFrame(rows)


def _gene_choice_table(alleles: list[str], p: np.ndarray, col: str) -> pl.DataFrame:
    return pl.DataFrame({col: alleles, "p": p.astype(np.float64)})


def _deletion_table(alleles: list[str], p_del_given: np.ndarray, max_pal: int, col: str) -> pl.DataFrame:
    """p_del_given is [del_index, gene]; emit (gene_allele, ndel, p) with ndel = index - max_pal."""
    n_idx, n_gene = p_del_given.shape
    ndel = np.arange(n_idx) - max_pal
    a = np.repeat(alleles, n_idx)
    d = np.tile(ndel, n_gene)
    return pl.DataFrame(
        {col: a, "ndel": d.astype(np.int16), "p": p_del_given.T.reshape(-1).astype(np.float64)}
    )


def _ins_len_table(p_ins: np.ndarray) -> pl.DataFrame:
    return pl.DataFrame(
        {"length": np.arange(len(p_ins), dtype=np.int16), "p": p_ins.astype(np.float64)}
    )


def _dinucl_table(R: np.ndarray) -> pl.DataFrame:
    """R[next, prev], columns sum to 1 -> rows (from_nt=prev, to_nt=next, p=P(next|prev))."""
    frm = np.repeat(np.arange(4), 4)  # prev
    to = np.tile(np.arange(4), 4)  # next
    p = R[to, frm]
    return pl.DataFrame(
        {"from_nt": frm.astype(np.uint8), "to_nt": to.astype(np.uint8), "p": p.astype(np.float64)}
    )


def from_olga(model_dir: str | Path, *, locus: str, organism: str = "human", derive_orf: bool = False) -> Model:
    """Import an OLGA default-model directory into a :class:`Model`.

    Args:
        model_dir: Directory with ``model_params.txt``, ``model_marginals.txt`` and the
            ``V/J_gene_CDR3_anchors.csv`` files (e.g. an OLGA ``default_models/*`` folder).
        locus: Locus label to record (e.g. ``"TRB"``).
        organism: Organism label (default ``"human"``).

    Returns:
        A validated :class:`Model` whose tables reproduce OLGA's arrays exactly.
    """
    import olga.load_model as olm  # optional dep (the [oracle] extra)

    d = Path(model_dir)
    params, marg = d / "model_params.txt", d / "model_marginals.txt"
    v_anchors = _read_anchors(d / "V_gene_CDR3_anchors.csv")
    j_anchors = _read_anchors(d / "J_gene_CDR3_anchors.csv")
    chain_type = "VDJ" if "@d_gene" in marg.read_text() else "VJ"

    tables: dict[str, pl.DataFrame] = {}
    events: dict[str, Event] = {}

    if chain_type == "VDJ":
        g = olm.GenomicDataVDJ()
        g.load_igor_genomic_data(str(params), str(d / "V_gene_CDR3_anchors.csv"), str(d / "J_gene_CDR3_anchors.csv"))
        m = olm.GenerativeModelVDJ()
        m.load_and_process_igor_model(str(marg))

        v_alleles = [x[0] for x in g.genV]
        # .strip(): OLGA's human_T_beta/model_params.txt writes "% TRBD1*01;..." with a space
        # after the '%', and its parser keeps it -- so the D names arrive as ' TRBD1*01'. Harmless
        # inside OLGA (it never name-matches D against anything external) but here it silently
        # breaks every by-name join with arda, whose calls are 'TRBD1*01'. Measured: TRB is the
        # only affected locus (45 d_gene + 1323 d_del rows); V/J and the other 6 loci are clean.
        # Pgen is unaffected -- D is summed by index, not name.
        d_alleles = [x[0].strip() for x in g.genD]
        j_alleles = [x[0] for x in g.genJ]

        pj = m.PDJ.sum(axis=0)  # P(J), shape (J,)
        # P(D | J): PDJ[d, j] / P(J); where P(J)=0, use a uniform placeholder (reconstruction is 0 either way).
        safe_pj = np.where(pj > 0, pj, 1.0)
        p_d_given_j = m.PDJ / safe_pj[np.newaxis, :]
        p_d_given_j[:, pj == 0] = 1.0 / len(d_alleles)

        tables["v_choice"] = _gene_choice_table(v_alleles, m.PV, "v_allele")
        tables["j_choice"] = _gene_choice_table(j_alleles, pj, "j_allele")
        tables["d_gene"] = pl.DataFrame(
            {
                "j_allele": np.repeat(j_alleles, len(d_alleles)),
                "d_allele": np.tile(d_alleles, len(j_alleles)),
                "p": p_d_given_j.T.reshape(-1).astype(np.float64),  # [j, d] order
            }
        )
        tables["n_d"] = pl.DataFrame({"n_d": np.array([1], np.uint8), "p": np.array([1.0])})
        tables["v_3_del"] = _deletion_table(v_alleles, m.PdelV_given_V, g.max_delV_palindrome, "v_allele")
        tables["j_5_del"] = _deletion_table(j_alleles, m.PdelJ_given_J, g.max_delJ_palindrome, "j_allele")
        tables["d_del"] = _d_del_table(d_alleles, m.PdelDldelDr_given_D, g.max_delDl_palindrome, g.max_delDr_palindrome)
        tables["vd_ins"] = _ins_len_table(m.PinsVD)
        tables["dj_ins"] = _ins_len_table(m.PinsDJ)
        tables["vd_dinucl"] = _dinucl_table(m.Rvd)
        tables["dj_dinucl"] = _dinucl_table(m.Rdj)

        events = {
            "v_choice": Event("v_choice", EventKind.GENE_CHOICE),
            "j_choice": Event("j_choice", EventKind.GENE_CHOICE),
            "d_gene": Event("d_gene", EventKind.GENE_CHOICE, ("j_choice",)),
            "n_d": Event("n_d", EventKind.N_D),
            "v_3_del": Event("v_3_del", EventKind.DELETION, ("v_choice",)),
            "j_5_del": Event("j_5_del", EventKind.DELETION, ("j_choice",)),
            "d_del": Event("d_del", EventKind.DELETION_2D, ("d_gene",)),
            "vd_ins": Event("vd_ins", EventKind.INS_LENGTH),
            "dj_ins": Event("dj_ins", EventKind.INS_LENGTH),
            "vd_dinucl": Event("vd_dinucl", EventKind.DINUCLEOTIDE),
            "dj_dinucl": Event("dj_dinucl", EventKind.DINUCLEOTIDE),
        }
        palindrome_max = {
            "v_3": int(g.max_delV_palindrome),
            "d_5": int(g.max_delDl_palindrome),
            "d_3": int(g.max_delDr_palindrome),
            "j_5": int(g.max_delJ_palindrome),
        }
        genomic = {
            **repair_anchors({
            "genes_v": _genomic_table(g.genV, v_anchors, g.cutV_genomic_CDR3_segs, seg="v", has_anchor=True, max_pal=int(g.max_delV_palindrome), derive_orf=derive_orf),
            "genes_d": _genomic_table(g.genD, {}, g.cutD_genomic_CDR3_segs, seg="d", has_anchor=False),
            "genes_j": _genomic_table(g.genJ, j_anchors, g.cutJ_genomic_CDR3_segs, seg="j", has_anchor=True, max_pal=int(g.max_delJ_palindrome), derive_orf=derive_orf)}),
        }
    else:  # VJ
        g = olm.GenomicDataVJ()
        g.load_igor_genomic_data(str(params), str(d / "V_gene_CDR3_anchors.csv"), str(d / "J_gene_CDR3_anchors.csv"))
        m = olm.GenerativeModelVJ()
        m.load_and_process_igor_model(str(marg))

        v_alleles = [x[0] for x in g.genV]
        j_alleles = [x[0] for x in g.genJ]

        pv = m.PVJ.sum(axis=1)  # P(V), shape (V,)
        safe_pv = np.where(pv > 0, pv, 1.0)
        p_j_given_v = m.PVJ / safe_pv[:, np.newaxis]
        p_j_given_v[pv == 0, :] = 1.0 / len(j_alleles)

        tables["v_choice"] = _gene_choice_table(v_alleles, pv, "v_allele")
        tables["j_choice"] = pl.DataFrame(
            {
                "v_allele": np.repeat(v_alleles, len(j_alleles)),
                "j_allele": np.tile(j_alleles, len(v_alleles)),
                "p": p_j_given_v.reshape(-1).astype(np.float64),  # [v, j] order
            }
        )
        tables["v_3_del"] = _deletion_table(v_alleles, m.PdelV_given_V, g.max_delV_palindrome, "v_allele")
        tables["j_5_del"] = _deletion_table(j_alleles, m.PdelJ_given_J, g.max_delJ_palindrome, "j_allele")
        tables["vj_ins"] = _ins_len_table(m.PinsVJ)
        tables["vj_dinucl"] = _dinucl_table(m.Rvj)

        events = {
            "v_choice": Event("v_choice", EventKind.GENE_CHOICE),
            "j_choice": Event("j_choice", EventKind.GENE_CHOICE, ("v_choice",)),
            "v_3_del": Event("v_3_del", EventKind.DELETION, ("v_choice",)),
            "j_5_del": Event("j_5_del", EventKind.DELETION, ("j_choice",)),
            "vj_ins": Event("vj_ins", EventKind.INS_LENGTH),
            "vj_dinucl": Event("vj_dinucl", EventKind.DINUCLEOTIDE),
        }
        palindrome_max = {"v_3": int(g.max_delV_palindrome), "j_5": int(g.max_delJ_palindrome)}
        genomic = {
            **repair_anchors({
            "genes_v": _genomic_table(g.genV, v_anchors, g.cutV_genomic_CDR3_segs, seg="v", has_anchor=True, max_pal=int(g.max_delV_palindrome), derive_orf=derive_orf),
            "genes_j": _genomic_table(g.genJ, j_anchors, g.cutJ_genomic_CDR3_segs, seg="j", has_anchor=True, max_pal=int(g.max_delJ_palindrome), derive_orf=derive_orf)}),
        }

    manifest = Manifest(
        locus=locus,
        organism=organism,
        chain_type=chain_type,
        events=events,
        palindrome_max=palindrome_max,
        source=f"olga:{d.name}",
    )
    return Model(manifest=manifest, tables=tables, genomic=genomic).validate()


def _d_del_table(d_alleles, p_joint: np.ndarray, max_dl: int, max_dr: int) -> pl.DataFrame:
    """PdelDldelDr_given_D is [delDl, delDr, D]; emit (d_allele, ndel5, ndel3, p)."""
    n5, n3, nd = p_joint.shape
    ndel5 = np.arange(n5) - max_dl
    ndel3 = np.arange(n3) - max_dr
    # index order: d (outer), then ndel5, then ndel3 (inner)
    a = np.repeat(d_alleles, n5 * n3)
    g5 = np.tile(np.repeat(ndel5, n3), nd)
    g3 = np.tile(ndel3, n5 * nd)
    p = np.transpose(p_joint, (2, 0, 1)).reshape(-1)  # [D, delDl, delDr] -> flat
    return pl.DataFrame(
        {
            "d_allele": a,
            "ndel5": g5.astype(np.int16),
            "ndel3": g3.astype(np.int16),
            "p": p.astype(np.float64),
        }
    )


# --------------------------------------------------------------------------------------------
# arda-native model construction (germline + names from arda; marginals are placeholders that
# EM (`infer_native`) refits). Generation/Pgen read only `{seg}_allele`, `cut_segment`,
# `functional` from `genomic`, so an arda-built genomic yields arda IMGT allele names verbatim.
# --------------------------------------------------------------------------------------------

_DEFAULT_PALINDROME_MAX = {"v_3": 4, "d_5": 4, "d_3": 4, "j_5": 4}


def _decay_p(values: np.ndarray, scale: float) -> np.ndarray:
    """Normalized weights ``∝ exp(-|value|/scale)`` — a placeholder favouring small trims/inserts
    while keeping full support so EM can move the mass."""
    w = np.exp(-np.abs(values) / scale)
    return w / w.sum()


def _vj_genomic(gl_seg: pl.DataFrame, seg: str, max_pal: int) -> pl.DataFrame:
    """genes_v / genes_j frame from a germline frame: cut_segment via palindrome extension.

    ``full_germline`` / ``cdr3_anchor`` are carried through when the frame has them (arda's
    scaffolds, or a full-length FASTA sliced by anchors) and default to ``""`` / ``-1``, which
    only disables contig stitching. ``functional = F & has a cut_segment``.
    """
    from . import reference as ref

    S = seg.upper()
    rows = []
    for r in gl_seg.iter_rows(named=True):
        allele, cdr3 = r["allele"], r["sequence"]
        cut = ref.cut_segment(cdr3, S, max_pal) if cdr3 else ""
        if set(cut) - set("ACGT"):  # ambiguous (N) germline — unusable in the native DP; drop
            continue
        rows.append({
            f"{seg}_allele": allele, "gene": r["gene"], "full_germline": r.get("full_germline") or "",
            "cdr3_segment": cdr3, "cut_segment": cut,
            "anchor": int(r.get("cdr3_anchor") if r.get("cdr3_anchor") is not None else -1),
            "functional": bool(r["functional"]) and len(cut) > 0,
        })
    return pl.DataFrame(rows)


def _d_genomic(gl_d: pl.DataFrame, max5: int, max3: int) -> pl.DataFrame:
    """genes_d frame from D germline (full = CDR3-region = D; anchor -1)."""
    from . import reference as ref

    rows = []
    for r in gl_d.iter_rows(named=True):
        seq = r["sequence"]
        cut = ref.cut_segment_d(seq, max5, max3)
        if set(cut) - set("ACGT"):  # ambiguous (N) germline — unusable in the native DP; drop
            continue
        rows.append({
            "d_allele": r["allele"], "gene": r["gene"], "full_germline": seq,
            "cdr3_segment": seq, "cut_segment": cut, "anchor": -1, "functional": len(cut) > 0,
        })
    return pl.DataFrame(rows)


def _uniform_choice(alleles: list[str], functional: list[bool], col: str) -> pl.DataFrame:
    """Uniform gene choice over *functional* alleles (0 for the rest); sums to 1."""
    f = np.asarray(functional, dtype=bool)
    n = int(f.sum())
    p = (f / n) if n else np.full(len(alleles), 1.0 / len(alleles))
    return pl.DataFrame({col: alleles, "p": p.astype(np.float64)})


def _uniform_cond_choice(parents: list[str], children: list[str], child_functional: list[bool],
                         parent_col: str, child_col: str) -> pl.DataFrame:
    """P(child|parent) uniform over functional children, identical for every parent."""
    f = np.asarray(child_functional, dtype=bool)
    n = int(f.sum())
    pc = (f / n) if n else np.full(len(children), 1.0 / len(children))
    return pl.DataFrame({
        parent_col: np.repeat(parents, len(children)),
        child_col: np.tile(children, len(parents)),
        "p": np.tile(pc, len(parents)).astype(np.float64),
    })


def _placeholder_deletion(alleles: list[str], ndel_min: int, ndel_max: int, col: str) -> pl.DataFrame:
    """Per-allele deletion table ``∝ exp(-|ndel|/3)`` over ``[ndel_min, ndel_max]`` (wide support)."""
    ndel = np.arange(ndel_min, ndel_max + 1)
    p = _decay_p(ndel.astype(float), 3.0)
    return pl.DataFrame({
        col: np.repeat(alleles, len(ndel)),
        "ndel": np.tile(ndel, len(alleles)).astype(np.int16),
        "p": np.tile(p, len(alleles)).astype(np.float64),
    })


def _placeholder_d_del(d_alleles: list[str], n5min: int, n5max: int, n3min: int, n3max: int) -> pl.DataFrame:
    """Per-D joint 5'/3' deletion ``∝ exp(-(|n5|+|n3|)/3)``, normalized per D."""
    ndel5, ndel3 = np.arange(n5min, n5max + 1), np.arange(n3min, n3max + 1)
    w = np.exp(-np.abs(ndel5)[:, None] / 3.0) * np.exp(-np.abs(ndel3)[None, :] / 3.0)
    p = (w / w.sum()).reshape(-1)
    n5, n3 = len(ndel5), len(ndel3)
    return pl.DataFrame({
        "d_allele": np.repeat(d_alleles, n5 * n3),
        "ndel5": np.tile(np.repeat(ndel5, n3), len(d_alleles)).astype(np.int16),
        "ndel3": np.tile(ndel3, n5 * len(d_alleles)).astype(np.int16),
        "p": np.tile(p, len(d_alleles)).astype(np.float64),
    })


def _placeholder_ins(ins_max: int) -> pl.DataFrame:
    length = np.arange(0, ins_max + 1)
    return pl.DataFrame({"length": length.astype(np.int16), "p": _decay_p(length.astype(float), 5.0)})


def _uniform_dinucl() -> pl.DataFrame:
    frm, to = np.repeat(np.arange(4), 4), np.tile(np.arange(4), 4)
    return pl.DataFrame({"from_nt": frm.astype(np.uint8), "to_nt": to.astype(np.uint8),
                         "p": np.full(16, 0.25)})


def from_germline(germline: pl.DataFrame, *, locus: str, organism: str = "custom",
                  palindrome_max: dict[str, int] | None = None, ins_max: int = 40,
                  strict: bool = True, source: str | None = None) -> Model:
    """Build a recombination :class:`Model` scaffold from **any** V(D)J germline library.

    This is the entry point for a custom reference: supply your own alleles (from
    :func:`vdjtools.model.reference.read_germline_fasta`, from arda, or assembled by hand) and
    get back a model with the right gene set, germline geometry and event graph, whose marginal
    ``tables`` are **placeholders** — uniform gene usage, small-trim / small-insert biased
    deletions and insertions with wide support — meant to be refit by
    :func:`vdjtools.model.infer.infer_native`. The placeholders' ``ndel`` / ``length`` support
    ranges **bound what EM can learn**, so they are sized to each segment's full cut-segment
    length and to ``ins_max``.

    Args:
        germline: Germline frame in :func:`vdjtools.model.reference.load_germline`'s schema —
            required ``allele, segment, sequence``, optional ``gene, functional, cdr3_anchor,
            full_germline``. ``sequence`` is the **CDR3-region** germline for V/J and the full
            germline for D. Alleles with non-ACGT bases are dropped (the native DP cannot encode
            them); ``strict`` decides whether that and the other audit findings are fatal.
        locus: e.g. ``"TRB"``, ``"IGH"``.
        organism: Free-text organism tag carried in the manifest.
        palindrome_max: Max palindromic nt per trimmable end (default matches OLGA human).
        ins_max: Maximum N-region insertion length in the placeholder tables.
        strict: Raise if :func:`vdjtools.model.reference.validate_germline` reports an ``error``.
            Warnings (a misplaced-looking anchor, ambiguous bases, a gene-level allele name) are
            never fatal — call ``validate_germline`` yourself to inspect them.
        source: Manifest provenance string; defaults to ``"germline:<locus>"``.

    Returns:
        A validated :class:`Model` — ``VDJ`` if the frame carries any D allele, else ``VJ``.

    Raises:
        ValueError: If the germline frame is unusable (missing columns, no V or no J, duplicate
            or empty alleles) and ``strict`` is set.
    """
    from . import reference as ref

    issues = ref.validate_germline(germline)
    errors = issues.filter(pl.col("severity") == "error")
    if strict and errors.height:
        detail = "; ".join(errors["detail"].to_list()[:5])
        raise ValueError(f"germline library has {errors.height} error(s): {detail}")

    pal = palindrome_max or _DEFAULT_PALINDROME_MAX
    gl = ref.normalize_germline(germline)
    v_gl = gl.filter(pl.col("segment") == "V")
    j_gl = gl.filter(pl.col("segment") == "J")
    d_gl = gl.filter(pl.col("segment") == "D")
    chain_type = "VDJ" if d_gl.height else "VJ"

    genes_v = _vj_genomic(v_gl, "v", pal["v_3"])
    genes_j = _vj_genomic(j_gl, "j", pal["j_5"])
    if not genes_v.height or not genes_j.height:
        raise ValueError(
            f"no usable {'V' if not genes_v.height else 'J'} alleles left after germline filtering "
            f"(empty or non-ACGT sequences) — cannot build a {locus} model"
        )
    v_alleles = genes_v["v_allele"].to_list()
    j_alleles = genes_j["j_allele"].to_list()
    v_cut = max((len(x) for x in genes_v["cut_segment"]), default=1)
    j_cut = max((len(x) for x in genes_j["cut_segment"]), default=1)

    tables: dict[str, pl.DataFrame] = {
        "v_choice": _uniform_choice(v_alleles, genes_v["functional"].to_list(), "v_allele"),
        "v_3_del": _placeholder_deletion(v_alleles, -pal["v_3"], v_cut, "v_allele"),
        "j_5_del": _placeholder_deletion(j_alleles, -pal["j_5"], j_cut, "j_allele"),
    }

    if chain_type == "VDJ":
        genes_d = _d_genomic(d_gl, pal["d_5"], pal["d_3"])
        d_alleles = genes_d["d_allele"].to_list()
        d_cut = max((len(x) for x in genes_d["cut_segment"]), default=1)
        tables["j_choice"] = _uniform_choice(j_alleles, genes_j["functional"].to_list(), "j_allele")
        tables["d_gene"] = _uniform_cond_choice(j_alleles, d_alleles, genes_d["functional"].to_list(),
                                                "j_allele", "d_allele")
        tables["n_d"] = pl.DataFrame({"n_d": np.array([1], np.uint8), "p": np.array([1.0])})
        tables["d_del"] = _placeholder_d_del(d_alleles, -pal["d_5"], d_cut, -pal["d_3"], d_cut)
        tables["vd_ins"] = _placeholder_ins(ins_max)
        tables["dj_ins"] = _placeholder_ins(ins_max)
        tables["vd_dinucl"] = _uniform_dinucl()
        tables["dj_dinucl"] = _uniform_dinucl()
        events = {
            "v_choice": Event("v_choice", EventKind.GENE_CHOICE),
            "j_choice": Event("j_choice", EventKind.GENE_CHOICE),
            "d_gene": Event("d_gene", EventKind.GENE_CHOICE, ("j_choice",)),
            "n_d": Event("n_d", EventKind.N_D),
            "v_3_del": Event("v_3_del", EventKind.DELETION, ("v_choice",)),
            "j_5_del": Event("j_5_del", EventKind.DELETION, ("j_choice",)),
            "d_del": Event("d_del", EventKind.DELETION_2D, ("d_gene",)),
            "vd_ins": Event("vd_ins", EventKind.INS_LENGTH),
            "dj_ins": Event("dj_ins", EventKind.INS_LENGTH),
            "vd_dinucl": Event("vd_dinucl", EventKind.DINUCLEOTIDE),
            "dj_dinucl": Event("dj_dinucl", EventKind.DINUCLEOTIDE),
        }
        genomic = {"genes_v": genes_v, "genes_d": genes_d, "genes_j": genes_j}
    else:  # VJ
        tables["j_choice"] = _uniform_cond_choice(v_alleles, j_alleles, genes_j["functional"].to_list(),
                                                  "v_allele", "j_allele")
        tables["vj_ins"] = _placeholder_ins(ins_max)
        tables["vj_dinucl"] = _uniform_dinucl()
        events = {
            "v_choice": Event("v_choice", EventKind.GENE_CHOICE),
            "j_choice": Event("j_choice", EventKind.GENE_CHOICE, ("v_choice",)),
            "v_3_del": Event("v_3_del", EventKind.DELETION, ("v_choice",)),
            "j_5_del": Event("j_5_del", EventKind.DELETION, ("j_choice",)),
            "vj_ins": Event("vj_ins", EventKind.INS_LENGTH),
            "vj_dinucl": Event("vj_dinucl", EventKind.DINUCLEOTIDE),
        }
        genomic = {"genes_v": genes_v, "genes_j": genes_j}

    manifest = Manifest(locus=locus, organism=organism, chain_type=chain_type, events=events,
                        palindrome_max={k: int(v) for k, v in pal.items()},
                        source=source or f"germline:{locus}")
    return Model(manifest=manifest, tables=tables, genomic=genomic).validate()


def from_arda(locus: str, organism: str = "human", *,
              palindrome_max: dict[str, int] | None = None, ins_max: int = 40) -> Model:
    """Build a recombination :class:`Model` whose gene set + germline come from **arda**.

    A thin wrapper over :func:`from_germline` that sources the germline library from arda — the
    single source of germline truth — so generated sequences carry arda's IMGT allele names and
    germline, and stitching gets the full-length V/J germline + anchor from arda's scaffolds.
    The marginal tables are placeholders meant to be refit; see :func:`from_germline`.

    Args:
        locus: e.g. ``"TRB"``, ``"IGH"``.
        organism: e.g. ``"human"``, ``"mouse"``.
        palindrome_max: Max palindromic nt per trimmable end (default matches OLGA human).
        ins_max: Maximum N-region insertion length in the placeholder tables.

    Returns:
        A validated :class:`Model` (VDJ if arda has D germline for the locus, else VJ).

    Raises:
        ImportError: If arda is not importable (it is a base dependency; a plain
            ``pip install vdjtools`` ships it).
        ValueError: If arda has no germline for ``locus`` / ``organism``.
    """
    from . import reference as ref

    gl = ref.load_germline(locus, organism)
    full = ref.arda_full_germline(locus, organism)
    gl = gl.with_columns(
        full_germline=pl.struct(["segment", "allele"]).map_elements(
            lambda r: full.get((r["segment"], r["allele"]), ("", -1))[0], return_dtype=pl.Utf8),
        cdr3_anchor=pl.struct(["segment", "allele"]).map_elements(
            lambda r: full.get((r["segment"], r["allele"]), ("", -1))[1], return_dtype=pl.Int64),
    )
    # strict=False: arda's own library legitimately carries pseudogenes with empty/ambiguous
    # germline and (for D) gene-level names; those are dropped/warned, never fatal.
    return from_germline(gl, locus=locus, organism=organism, palindrome_max=palindrome_max,
                         ins_max=ins_max, strict=False, source=f"arda:{locus}")


# --- flat table export / import --------------------------------------------------------------

#: Every realization column any event kind can contribute, in a stable display order.
_REALIZATION_COLS = ("v_allele", "j_allele", "d_allele", "d2_allele",
                     "n_d", "ndel", "ndel5", "ndel3", "length", "from_nt", "to_nt")


def marginals_frame(model: Model) -> pl.DataFrame:
    """Flatten every marginal into ONE long, self-describing table.

    The per-event tables are already tidy polars, but they have different schemas, so inspecting a
    whole model means juggling a dozen frames. This stacks them into a single frame with the union
    of all realization columns (null where a column does not apply to that event), which is what
    you want for eyeballing, diffing, spreadsheeting or shipping a model as one file.

    Args:
        model: The model to flatten.

    Returns:
        ``event, kind, given`` + :data:`_REALIZATION_COLS` + ``p``, one row per probability.

    Example:
        >>> marginals_frame(m).filter(pl.col("event") == "v_choice").head()
    """
    parts = []
    for name, event in model.manifest.events.items():
        df = model.tables[name]
        parts.append(df.with_columns(
            event=pl.lit(name), kind=pl.lit(event.kind.value),
            given=pl.lit(",".join(event.given)),
        ))
    out = pl.concat(parts, how="diagonal")
    cols = ["event", "kind", "given", *[c for c in _REALIZATION_COLS if c in out.columns], "p"]
    return out.select(cols)


def set_marginals(model: Model, frame: pl.DataFrame, *, validate: bool = True) -> Model:
    """Rebuild a model's marginals from a :func:`marginals_frame`-shaped table.

    The inverse of :func:`marginals_frame`, and the reason a hand-edited TSV is a first-class model
    input: edit the probabilities in whatever tool you like, read the table back, and get a model.
    The germline frames and the event graph come from ``model`` — this replaces probabilities only.

    Args:
        model: Supplies the manifest and germline; its own tables are replaced.
        frame: Long-format marginals with at least ``event`` and ``p``, plus whichever realization
            columns the events need. Extra columns are ignored; rows for unknown events are an error.
        validate: Run :meth:`~vdjtools.model.model.Model.validate` on the result.

    Returns:
        A new :class:`Model`; the input is not modified.

    Raises:
        ValueError: If an event has no rows, an event name is unknown, or a required realization
            column is missing for some event.
    """
    if "event" not in frame.columns or "p" not in frame.columns:
        raise ValueError("marginals frame needs at least an 'event' and a 'p' column")
    unknown = sorted(set(frame["event"].to_list()) - set(model.manifest.events))
    if unknown:
        raise ValueError(f"marginals frame names event(s) not in the manifest: {unknown}")

    tables: dict[str, pl.DataFrame] = {}
    for name, event in model.manifest.events.items():
        want = table_columns(event)
        sub = frame.filter(pl.col("event") == name)
        if not sub.height:
            raise ValueError(f"marginals frame has no rows for event {name!r}")
        missing = [c for c in want if c not in sub.columns]
        if missing:
            raise ValueError(f"event {name!r} needs column(s) {missing} in the marginals frame")
        # Casting per column rather than trusting the reader: a TSV round-trip loses every dtype,
        # and the native packer requires the schema's exact integer widths.
        tables[name] = sub.select([pl.col(c).cast(dt) for c, dt in want.items()])
    out = Model(manifest=model.manifest, tables=tables, genomic=model.genomic,
                training=model.training)
    return out.validate() if validate else out


# --- model directories ------------------------------------------------------------------------

_TABLE_SUFFIX = {"parquet": ".parquet", "tsv": ".tsv", "csv": ".csv"}


def _write_table(df: pl.DataFrame, path: Path, fmt: str) -> None:
    if fmt == "parquet":
        df.write_parquet(path)
    else:
        df.write_csv(path, separator="\t" if fmt == "tsv" else ",")


def _read_table(src: Path, name: str) -> pl.DataFrame:
    """Read one model table, whichever of the three formats it was written in."""
    for fmt, suffix in _TABLE_SUFFIX.items():
        path = src / f"{name}{suffix}"
        if path.exists():
            if fmt == "parquet":
                return pl.read_parquet(path)
            return pl.read_csv(path, separator="\t" if fmt == "tsv" else ",")
    raise FileNotFoundError(f"no table {name!r} in {src} (tried {', '.join(_TABLE_SUFFIX.values())})")


def save_model(model: Model, path: str | Path, *, fmt: str = "parquet") -> None:
    """Write a model to ``path/`` as ``manifest.json`` + one file per event/germline table.

    Args:
        model: The model to write.
        path: Destination directory (created if absent).
        fmt: ``"parquet"`` (default, exact and compact), or ``"tsv"`` / ``"csv"`` for a
            hand-editable directory. Text formats lose dtypes on the way out;
            :func:`load_model` restores them from the manifest, so the round-trip is still exact.

    Raises:
        ValueError: On an unknown ``fmt``.
    """
    if fmt not in _TABLE_SUFFIX:
        raise ValueError(f"fmt must be one of {sorted(_TABLE_SUFFIX)}, got {fmt!r}")
    out = Path(path)
    out.mkdir(parents=True, exist_ok=True)
    (out / "manifest.json").write_text(model.manifest.to_json())
    suffix = _TABLE_SUFFIX[fmt]
    for name, df in {**model.tables, **model.genomic}.items():
        _write_table(df, out / f"{name}{suffix}", fmt)
    if model.training:
        import json

        (out / "training.json").write_text(json.dumps(model.training, indent=2))


def load_model(path: str | Path, *, validate: bool = False) -> Model:
    """Load a native model directory written by :func:`save_model`.

    The on-disk format is detected per table, so parquet, TSV and CSV directories all load, and
    text-format tables are cast back to the schema's dtypes. ``training.json`` is read when
    present; a model written before training logs existed simply has ``training is None``.

    Args:
        path: The model directory.
        validate: Also run :meth:`~vdjtools.model.model.Model.validate`. Off by default so a
            deliberately-broken model can still be loaded for
            :func:`~vdjtools.model.check.check_model` to diagnose.

    Returns:
        The loaded :class:`Model`.
    """
    src = Path(path)
    manifest = Manifest.from_json((src / "manifest.json").read_text())
    tables = {}
    for name, event in manifest.events.items():
        df = _read_table(src, name)
        want = table_columns(event)
        tables[name] = df.select([pl.col(c).cast(dt) for c, dt in want.items()])
    genomic_names = ["genes_v", "genes_j"] + (["genes_d"] if manifest.chain_type == "VDJ" else [])
    genomic = repair_anchors({name: _read_table(src, name) for name in genomic_names})

    training = None
    training_path = src / "training.json"
    if training_path.exists():
        import json

        training = json.loads(training_path.read_text())
    model = Model(manifest=manifest, tables=tables, genomic=genomic, training=training)
    return model.validate() if validate else model
