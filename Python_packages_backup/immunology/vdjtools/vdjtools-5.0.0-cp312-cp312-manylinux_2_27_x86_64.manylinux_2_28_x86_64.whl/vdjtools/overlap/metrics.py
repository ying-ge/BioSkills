"""Exact-match pairwise repertoire-overlap metrics (pure polars + numpy).

Implements the four legacy vdjtools overlap metrics (``OverlapEvaluator``) on an
exact clonotype match key. This is exact-match only; fuzzy / e-value overlap and
TCRnet are delegated to vdjmatch (``cluster.overlap`` / ``evalue.query_evalues``).
"""
from __future__ import annotations

import numpy as np
import polars as pl

from ..io.schema import JUNCTION_AA, COUNT, J_CALL, V_CALL

#: Default exact match key (legacy "Strict" overlap: CDR3 aa + V + J).
DEFAULT_KEY = (JUNCTION_AA, V_CALL, J_CALL)

#: CDR3s outside this alphabet (``*``, ``_``, ``X``) are not scoreable by the similarity kernels.
STANDARD_AA = r"^[ACDEFGHIKLMNPQRSTVWY]+$"


def _aggregate(df: pl.DataFrame, key: list[str], *,
               index: bool = False, standard_aa: bool = False) -> pl.DataFrame:
    """Collapse to unique clonotype keys, summing counts and recomputing frequency.

    ``standard_aa`` first drops CDR3s with non-standard amino acids; ``index`` adds a
    0-based ``_idx`` row index (the positional key vdjmatch/seqtree return).
    """
    agg = df.group_by(key, maintain_order=True).agg(pl.col(COUNT).sum().alias("_count"))
    if standard_aa:
        agg = agg.filter(pl.col(JUNCTION_AA).str.contains(STANDARD_AA))
    total = agg["_count"].sum() or 1
    out = [(pl.col("_count") / total).alias("_freq")]
    if index:
        out.append(pl.int_range(pl.len(), dtype=pl.Int64).alias("_idx"))
    return agg.with_columns(out)


def _overlap_from_agg(a_agg: pl.DataFrame, b_agg: pl.DataFrame,
                      key: list[str]) -> "tuple[pl.DataFrame, dict]":
    """Shared-clonotype table + metrics from two **already-aggregated** samples.

    ``a_agg`` / ``b_agg`` are the output of :func:`_aggregate` (unique ``key`` rows plus
    ``_count`` / ``_freq``). Factored out of :func:`overlap_pair` so an all-pairs caller
    can aggregate each sample once and reuse it across every pair instead of
    re-aggregating per pair (see :func:`vdjtools.overlap.cluster.pairwise_distances`).
    Bitwise-identical to the inline body it replaced.
    """
    d1, d2 = a_agg.height, b_agg.height
    shared = a_agg.join(b_agg, on=key, how="inner", suffix="_b").rename({
        "_count": "count_a", "_freq": "freq_a", "_count_b": "count_b", "_freq_b": "freq_b",
    })
    d12 = shared.height

    fa = shared["freq_a"].to_numpy()
    fb = shared["freq_b"].to_numpy()
    div = float(d12) / (d1 * d2) if d1 and d2 else 0.0
    freq = float(np.sqrt(fa.sum() * fb.sum())) if d12 else 0.0
    freq2 = float(np.sum(np.sqrt(fa * fb))) if d12 else 0.0
    if d12 > 2:
        with np.errstate(invalid="ignore", divide="ignore"):
            r = float(np.corrcoef(fa, fb)[0, 1])
        if np.isnan(r):
            r = None
    else:
        r = None

    metrics = {"D": div, "F": freq, "F2": freq2, "R": r, "d1": d1, "d2": d2, "d12": d12}
    return shared.select([*key, "count_a", "count_b", "freq_a", "freq_b"]), metrics


def overlap_pair(a: pl.DataFrame, b: pl.DataFrame,
                 key: "tuple[str, ...]" = DEFAULT_KEY) -> "tuple[pl.DataFrame, dict]":
    """Compute the shared-clonotype table and overlap metrics for two samples.

    Both frames are first collapsed to unique clonotype keys (summing counts;
    frequencies are recomputed within each sample). The four legacy metrics are:

    - **D** (diversity): ``d12 / (d1 * d2)``.
    - **F** (frequency): ``sqrt(Σ_shared f_a · Σ_shared f_b)``.
    - **F2**: ``Σ_shared sqrt(f_a · f_b)``.
    - **R**: Pearson correlation of the **raw** shared-clonotype frequencies (legacy
      ``OverlapEvaluator``: ``x[k] = it.getFreq(i)`` fed straight to
      ``PearsonsCorrelation``, no log transform). Requires at least three shared
      clonotypes (legacy guard ``n > 2``); with fewer, or when the correlation is
      undefined (a constant/degenerate vector yields NaN), ``R`` is ``None``. Legacy
      coerced both of these cases to ``0.0``; ``None`` keeps "undefined" distinct
      from a genuine zero correlation.

    Args:
        a: First clonotype frame.
        b: Second clonotype frame.
        key: Columns forming the exact match key (default
            ``("junction_aa", "v_call", "j_call")``; use ``("junction_aa",)`` for CDR3-only
            or add ``"junction_nt"`` for nucleotide-level matching).

    Returns:
        A tuple ``(shared, metrics)`` where ``shared`` is a ``pl.DataFrame`` of the
        joined shared clonotypes (key columns plus ``count_a, count_b, freq_a,
        freq_b``) and ``metrics`` is a dict with keys ``D, F, F2, R, d1, d2, d12``
        (``R`` is ``None`` when undefined; see above).
    """
    key = list(key)
    return _overlap_from_agg(_aggregate(a, key), _aggregate(b, key), key)


def overlap_metrics(a: pl.DataFrame, b: pl.DataFrame,
                    key: "tuple[str, ...]" = DEFAULT_KEY) -> dict:
    """Compute the four exact-match overlap metrics (D, F, F2, R) for two samples.

    Args:
        a: First clonotype frame.
        b: Second clonotype frame.
        key: Exact match key (see :func:`overlap_pair`).

    Returns:
        Dict with keys ``D, F, F2, R, d1, d2, d12``.
    """
    return overlap_pair(a, b, key)[1]
