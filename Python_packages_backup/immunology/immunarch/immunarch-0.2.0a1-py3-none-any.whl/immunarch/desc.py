"""Descriptive repertoire summaries for AIRR-style chain tables."""

from collections.abc import Sequence
from typing import Literal

import ibis
import polars as pl

from immundata import ImmunData
from immundata.spec import Schema

from .utils import (
    ANALYSIS,
    ANALYSIS_INPUT,
    require_columns,
    require_repertoires,
    resolve_by,
    sort_result,
    with_repertoire_metadata,
)


def chains(
    idata: ImmunData,
    locus_col: str | None = Schema.locus,
) -> pl.DataFrame:
    """Count observed chain rows by repertoire and optionally by locus.

    A paired receptor contributes one observation to each of its captured
    loci. With ``locus_col=None`` those chain observations are pooled.
    """
    require_repertoires(idata)
    table = idata.annotations
    require_columns(table, [Schema.repertoire], "idata.annotations")
    if locus_col is not None and locus_col not in table.columns:
        raise ValueError(
            f"Column `{locus_col}` not found in idata.annotations."
        )

    groups = [Schema.repertoire]
    if locus_col is not None:
        groups.append(locus_col)
    counts = table.group_by(*groups).agg(**{ANALYSIS.n_chains: table.count()})
    if locus_col is None:
        counts = counts.mutate(**{Schema.locus: ibis.null().cast("string")})
    elif locus_col != Schema.locus:
        counts = counts.select(
            Schema.repertoire,
            counts[locus_col].name(Schema.locus),
            ANALYSIS.n_chains,
        )
    frame = counts.to_polars()
    frame = with_repertoire_metadata(frame, idata, include_summary=True)
    return sort_result(frame, [Schema.repertoire, Schema.locus])


def lengths(
    idata: ImmunData,
    seq_col: str = ANALYSIS_INPUT.sequence,
    by: str | Sequence[str] | None = "auto",
) -> pl.DataFrame:
    """Count sequence lengths for chain rows within each group.

    By default, rows are grouped by canonical ``locus`` when that field is
    present. ``by=None`` pools loci. ``n`` counts rows, not receptor abundance.
    """
    require_repertoires(idata)
    require_columns(
        idata.annotations, [Schema.repertoire, seq_col], "idata.annotations"
    )
    by_cols = resolve_by(idata, by)
    table = idata.annotations.select(
        *dict.fromkeys([Schema.repertoire, *by_cols, seq_col])
    )
    lengths_table = table.mutate(
        **{ANALYSIS.seq_len: table[seq_col].cast("string").length()}
    )
    group_cols = [Schema.repertoire, *by_cols, ANALYSIS.seq_len]
    counts = lengths_table.group_by(*group_cols).agg(
        **{ANALYSIS.n: lengths_table.count()}
    )
    window = ibis.window(
        group_by=[counts[column] for column in [Schema.repertoire, *by_cols]]
    )
    result = counts.mutate(
        **{
            ANALYSIS.prop: counts[ANALYSIS.n]
            / counts[ANALYSIS.n].sum().over(window),
            ANALYSIS.pct: 100.0
            * counts[ANALYSIS.n]
            / counts[ANALYSIS.n].sum().over(window),
        }
    )
    frame = with_repertoire_metadata(result.to_polars(), idata)
    return sort_result(frame, [Schema.repertoire, *by_cols, ANALYSIS.seq_len])


def genes(
    idata: ImmunData,
    gene_col: str = "v_call",
    level: Literal["receptor", "barcode"] = "receptor",
    by: str | Sequence[str] | None = "auto",
) -> pl.DataFrame:
    """Summarise gene usage by distinct receptors or summed abundance.

    ``level='receptor'`` counts distinct biological receptor IDs. ``level='barcode'``
    sums ``imd_count`` once per receptor and gene/group combination. The latter
    avoids adding a paired receptor's copied abundance twice within one locus.
    """
    require_repertoires(idata)
    if level not in {"receptor", "barcode"}:
        raise ValueError("`level` must be 'receptor' or 'barcode'.")
    by_cols = resolve_by(idata, by)
    required = [Schema.repertoire, Schema.receptor, gene_col, *by_cols]
    if level == "barcode":
        required.append(Schema.counts)
    require_columns(idata.annotations, required, "idata.annotations")

    selected = idata.annotations.select(*dict.fromkeys(required)).distinct()
    group_cols = [Schema.repertoire, *by_cols, gene_col]
    if level == "receptor":
        result = selected.group_by(*group_cols).agg(
            **{ANALYSIS.n: selected[Schema.receptor].count()}
        )
    else:
        clone_gene_cols = [
            Schema.repertoire,
            Schema.receptor,
            *by_cols,
            gene_col,
        ]
        clone_gene = selected.group_by(*clone_gene_cols).agg(
            _count=selected[Schema.counts].max()
        )
        result = clone_gene.group_by(*group_cols).agg(
            **{ANALYSIS.n: clone_gene["_count"].sum()}
        )

    frame = with_repertoire_metadata(result.to_polars(), idata)
    return sort_result(frame, [Schema.repertoire, *by_cols, ANALYSIS.n])


__all__ = ["chains", "genes", "lengths"]
