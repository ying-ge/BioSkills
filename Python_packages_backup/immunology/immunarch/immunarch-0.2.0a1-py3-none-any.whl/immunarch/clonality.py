"""Ranked abundance summaries for biological receptors."""

import math
from collections.abc import Mapping, Sequence

import ibis
import polars as pl

from immundata import ImmunData
from immundata.spec import Schema

from .utils import (
    ANALYSIS,
    clone_table,
    require_repertoires,
    sort_result,
    with_repertoire_metadata,
)

DEFAULT_RANK_BINS = (10, 30, 100, 300, 1000, 10000, 100000)
DEFAULT_PROP_BINS = {
    "Hyperexpanded": 1e-2,
    "Large": 1e-3,
    "Medium": 1e-4,
    "Small": 1e-5,
    "Rare": 1e-6,
}


def line(idata: ImmunData, limit: int = 100000) -> pl.DataFrame:
    """Return one ranked row per repertoire/receptor, ordered by abundance."""
    require_repertoires(idata)
    if isinstance(limit, bool) or not isinstance(limit, int):
        raise TypeError("`limit` must be an integer.")
    if limit < 10:
        raise ValueError(
            "`limit` must be an integer greater than or equal to 10."
        )
    table = clone_table(idata, [Schema.counts, Schema.proportion])
    window = ibis.window(
        group_by=[table[Schema.repertoire]],
        order_by=[table[Schema.counts].desc(), table[Schema.receptor].asc()],
    )
    ranked = table.mutate(
        **{ANALYSIS.index: ibis.row_number().over(window) + 1}
    )
    result = (
        ranked.filter(ranked[ANALYSIS.index] <= limit)
        .select(
            Schema.repertoire,
            ANALYSIS.index,
            Schema.counts,
            Schema.proportion,
        )
        .order_by(Schema.repertoire, ANALYSIS.index)
    )
    frame = with_repertoire_metadata(result.to_polars(), idata)
    return sort_result(frame, [Schema.repertoire, ANALYSIS.index])


def rank(
    idata: ImmunData,
    bins: Sequence[int | float] = DEFAULT_RANK_BINS,
) -> pl.DataFrame:
    """Sum clone proportions through each requested rank threshold.

    A null ``clonal_rank_bin`` row contains clones ranked beyond the largest
    requested threshold, matching the R v1 result contract.
    """
    require_repertoires(idata)
    thresholds: list[int] = []
    for value in bins:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("`bins` entries must be numbers.")
        if not math.isfinite(value) or int(value) != value or value < 1:
            raise ValueError("`bins` must contain positive integers.")
        thresholds.append(int(value))
    if not thresholds:
        raise ValueError("`bins` cannot be empty.")
    thresholds = sorted(set(thresholds))
    table = clone_table(idata, [Schema.counts, Schema.proportion])
    window = ibis.window(
        group_by=[table[Schema.repertoire]],
        order_by=[
            table[Schema.proportion].desc(),
            table[Schema.receptor].asc(),
        ],
    )
    ranked = table.mutate(_rank=ibis.row_number().over(window) + 1)
    rank_expr = ibis.cases(
        *[
            (ranked["_rank"] <= threshold, threshold)
            for threshold in thresholds
        ],
        else_=ibis.null().cast("int64"),
    )
    bucketed = ranked.mutate(**{ANALYSIS.clonal_rank_bin: rank_expr})
    result = bucketed.group_by(Schema.repertoire, ANALYSIS.clonal_rank_bin).agg(
        **{ANALYSIS.occupied_prop: bucketed[Schema.proportion].sum()}
    )
    frame = with_repertoire_metadata(result.to_polars(), idata)
    return sort_result(frame, [Schema.repertoire, ANALYSIS.clonal_rank_bin])


def prop(
    idata: ImmunData,
    bins: Mapping[str, float | int]
    | Sequence[tuple[str, float | int]] = DEFAULT_PROP_BINS,
) -> pl.DataFrame:
    """Sum clone proportions in abundance threshold bins."""
    require_repertoires(idata)
    values = list(bins.items()) if isinstance(bins, Mapping) else list(bins)
    if not values:
        raise ValueError("`bins` cannot be empty.")
    thresholds: list[tuple[str, float]] = []
    for label, threshold in values:
        if not isinstance(label, str):
            raise TypeError("Proportion bin labels must be strings.")
        if isinstance(threshold, bool) or not isinstance(
            threshold, (int, float)
        ):
            raise TypeError("Proportion bin thresholds must be numbers.")
        value = float(threshold)
        if not str(label).strip() or not math.isfinite(value) or value < 0:
            raise ValueError(
                "Proportion bin labels must be non-empty and thresholds non-negative."
            )
        thresholds.append((str(label), value))
    thresholds.sort(key=lambda item: item[1], reverse=True)
    table = clone_table(idata, [Schema.counts, Schema.proportion])
    cases = [
        (table[Schema.proportion] >= threshold, label)
        for label, threshold in thresholds
    ]
    bucketed = table.mutate(
        **{ANALYSIS.clonal_prop_bin: ibis.cases(*cases, else_="Ultra-rare")}
    )
    result = bucketed.group_by(Schema.repertoire, ANALYSIS.clonal_prop_bin).agg(
        **{ANALYSIS.occupied_prop: bucketed[Schema.proportion].sum()}
    )
    frame = with_repertoire_metadata(result.to_polars(), idata)
    return sort_result(frame, [Schema.repertoire, ANALYSIS.clonal_prop_bin])


__all__ = ["line", "prop", "rank"]
