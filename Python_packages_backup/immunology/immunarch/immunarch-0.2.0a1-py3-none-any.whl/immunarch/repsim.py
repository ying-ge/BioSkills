"""Pairwise repertoire similarity from distinct receptor sets."""

import polars as pl

from immundata import ImmunData
from immundata.spec import Schema

from .utils import ANALYSIS, require_columns, require_repertoires, sort_result

_RIGHT_REPERTOIRE = ANALYSIS.repertoire_2


def _pairwise(idata: ImmunData) -> pl.DataFrame:
    repertoires = require_repertoires(idata)
    require_columns(
        idata.annotations,
        [Schema.repertoire, Schema.receptor],
        "idata.annotations",
    )
    ids = (
        repertoires.select(Schema.repertoire)
        .order_by(Schema.repertoire)
        .to_polars()
    )
    receptor_rep = idata.annotations.select(
        Schema.repertoire, Schema.receptor
    ).distinct()

    if ids.is_empty():
        return pl.DataFrame(
            schema={
                Schema.repertoire: ids.schema[Schema.repertoire],
                _RIGHT_REPERTOIRE: ids.schema[Schema.repertoire],
                ANALYSIS.intersection: pl.Int64,
                "size": pl.Int64,
                "size_2": pl.Int64,
            }
        )

    left = receptor_rep.select(
        left_repertoire=receptor_rep[Schema.repertoire],
        left_receptor=receptor_rep[Schema.receptor],
    )
    right = receptor_rep.select(
        right_repertoire=receptor_rep[Schema.repertoire],
        right_receptor=receptor_rep[Schema.receptor],
    )
    shared = left.join(
        right,
        left["left_receptor"] == right["right_receptor"],
        how="inner",
    )
    intersections = (
        shared.group_by("left_repertoire", "right_repertoire")
        .agg(**{ANALYSIS.intersection: shared["left_receptor"].count()})
        .to_polars()
        .rename(
            {
                "left_repertoire": Schema.repertoire,
                "right_repertoire": _RIGHT_REPERTOIRE,
            }
        )
    )
    sizes = (
        receptor_rep.group_by(Schema.repertoire)
        .agg(size=receptor_rep[Schema.receptor].count())
        .to_polars()
    )

    grid = ids.select(Schema.repertoire).join(
        ids.select(pl.col(Schema.repertoire).alias(_RIGHT_REPERTOIRE)),
        how="cross",
    )
    size_left = sizes.rename({"size": "size"})
    size_right = sizes.rename(
        {Schema.repertoire: _RIGHT_REPERTOIRE, "size": "size_2"}
    )
    return (
        grid.join(
            intersections, on=[Schema.repertoire, _RIGHT_REPERTOIRE], how="left"
        )
        .join(size_left, on=Schema.repertoire, how="left")
        .join(size_right, on=_RIGHT_REPERTOIRE, how="left")
        .with_columns(
            pl.col("intersection").fill_null(0).cast(pl.Int64),
            pl.col("size").fill_null(0).cast(pl.Int64),
            pl.col("size_2").fill_null(0).cast(pl.Int64),
        )
    )


def intersection(idata: ImmunData) -> pl.DataFrame:
    """Count shared receptors for every ordered repertoire pair.

    The long result includes typed ``imd_repertoire_id`` and
    ``imd_repertoire_id_2`` columns. Diagonal values are each repertoire's
    observed receptor richness.
    """
    pairs = _pairwise(idata)
    result = pairs.select(
        Schema.repertoire, _RIGHT_REPERTOIRE, ANALYSIS.intersection
    )
    return sort_result(result, [Schema.repertoire, _RIGHT_REPERTOIRE])


def jaccard(idata: ImmunData) -> pl.DataFrame:
    """Compute set-based Jaccard similarity for every repertoire pair.

    Similarity is ``intersection / union``. The diagonal is one, including an
    empty repertoire; two different empty repertoires have a null similarity.
    """
    pairs = _pairwise(idata)
    union = pl.col("size") + pl.col("size_2") - pl.col("intersection")
    result = pairs.select(
        Schema.repertoire,
        _RIGHT_REPERTOIRE,
        pl.when(pl.col(Schema.repertoire) == pl.col(_RIGHT_REPERTOIRE))
        .then(1.0)
        .when(union > 0)
        .then(pl.col(ANALYSIS.intersection) / union)
        .otherwise(None)
        .alias(ANALYSIS.jaccard),
    )
    return sort_result(result, [Schema.repertoire, _RIGHT_REPERTOIRE])


__all__ = ["intersection", "jaccard"]
