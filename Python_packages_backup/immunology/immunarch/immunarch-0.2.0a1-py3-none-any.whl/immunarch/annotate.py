"""Receptor-level publicness and explicit-key database annotation."""

from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from typing import Any

import ibis
import polars as pl
from ibis import _
from ibis.expr.types import Table

from immundata import ImmunData
from immundata.spec import Schema

from .utils import ANALYSIS, require_columns, require_repertoires


def _public_metrics(source: Table, denominator: float) -> Table:
    repertoire_col = Schema.repertoire
    receptor_col = Schema.receptor
    metrics = source.group_by(receptor_col).agg(
        **{
            ANALYSIS.public_incidence: source[repertoire_col].count(),
            ANALYSIS.public_count_min: source["_public_count"].min(),
            ANALYSIS.public_count_max: source["_public_count"].max(),
            ANALYSIS.public_count_mean: source["_public_count"].mean(),
            ANALYSIS.public_count_median: source["_public_count"].median(),
            ANALYSIS.public_prop_min: source["_public_prop"].min(),
            ANALYSIS.public_prop_max: source["_public_prop"].max(),
            ANALYSIS.public_prop_mean: source["_public_prop"].mean(),
            ANALYSIS.public_prop_median: source["_public_prop"].median(),
        }
    )
    return metrics.mutate(
        **{
            ANALYSIS.public_incidence_prop: metrics[ANALYSIS.public_incidence]
            / denominator
        }
    )


def public(idata: ImmunData) -> ImmunData:
    """Annotate each receptor with global and available strata publicness.

    Incidence is the number of repertoires containing a receptor. Count and
    proportion summaries use one abundance value per receptor/repertoire,
    even when the source receptor has multiple paired-chain rows.
    """
    repertoires = require_repertoires(idata)
    required = [
        Schema.repertoire,
        Schema.receptor,
        Schema.counts,
        Schema.proportion,
    ]
    require_columns(idata.annotations, required, "idata.annotations")
    n_repertoires = repertoires.count().execute()
    if n_repertoires == 0:
        raise ValueError("No repertoires found in idata.repertoires.")

    receptor_per_rep = (
        idata.annotations.select(*required)
        .group_by(Schema.receptor, Schema.repertoire)
        .agg(
            _public_count=_[Schema.counts].max(),
            _public_prop=_[Schema.proportion].max(),
        )
    )
    public_annotation = _public_metrics(receptor_per_rep, float(n_repertoires))

    if Schema.strata in repertoires.columns:
        receptor_per_strata = (
            repertoires.select(Schema.repertoire, Schema.strata)
            .distinct()
            .filter(_[Schema.strata].notnull())
        )
        strata_counts = (
            receptor_per_strata.group_by(Schema.strata)
            .agg(_n_repertoires=_[Schema.repertoire].count())
            .to_polars()
        )
        for row in strata_counts.iter_rows(named=True):
            stratum_id = row[Schema.strata]
            n_in_stratum = int(row["_n_repertoires"])
            members = receptor_per_strata.filter(
                receptor_per_strata[Schema.strata] == stratum_id
            )
            stats = receptor_per_rep.join(
                members, Schema.repertoire, how="inner"
            )
            metrics = _public_metrics(stats, float(n_in_stratum))
            suffix = stratum_id
            renamed = metrics.select(
                Schema.receptor,
                **{
                    f"{column}_strata_{suffix}": metrics[column]
                    for column in ANALYSIS.public_metrics
                },
            )
            public_annotation = public_annotation.join(
                renamed, Schema.receptor, how="left"
            )
            right_key = f"{Schema.receptor}_right"
            if right_key in public_annotation.columns:
                public_annotation = public_annotation.drop(right_key)

    return idata.annotate_receptors(
        annotations=public_annotation,
        conflicts="replace",
        remove_limit=True,
    )


# AGENT: are you sure we really need _database_table and _filter_database as separate functions? The `with_database` is quite small, we can just have one `with_database` function.
def _database_table(db: object) -> Table:
    if isinstance(db, Table):
        return db
    if isinstance(db, pl.DataFrame):
        return ibis.memtable(db)
    if isinstance(db, (str, Path)):
        path = Path(db)
        if not path.exists():
            raise FileNotFoundError(f"Database path does not exist: {path}")
        suffix = path.suffix.lower()
        if suffix in {".parquet", ".parq"}:
            return ibis.read_parquet(path)
        if suffix in {".csv", ".tsv", ".txt"}:
            return ibis.read_csv(path, delim="\t" if suffix == ".tsv" else ",")
        raise ValueError(
            "Database path must point to CSV, TSV, TXT, or Parquet."
        )
    try:
        return ibis.memtable(db)
    except Exception as exc:
        raise TypeError(
            "`db` must be an Ibis table, Polars DataFrame, file path, or table-like value."
        ) from exc


def _filter_database(
    table: Table,
    filters: Mapping[str, Any]
    | Sequence[Any]
    | Callable[[Table], Table]
    | None,
) -> Table:
    if filters is None:
        return table
    if callable(filters):
        filtered = filters(table)
        if not isinstance(filtered, Table):
            raise TypeError("Callable `filters` must return an Ibis table.")
        return filtered
    if isinstance(filters, Mapping):
        for column, value in filters.items():
            require_columns(table, [column], "database table")
            if isinstance(value, Sequence) and not isinstance(
                value, (str, bytes)
            ):
                table = table.filter(table[column].isin(list(value)))
            else:
                table = table.filter(table[column] == value)
        return table
    if isinstance(filters, Sequence) and not isinstance(filters, (str, bytes)):
        for predicate in filters:
            table = table.filter(predicate)
        return table
    raise TypeError(
        "`filters` must be a mapping, predicate sequence, callable, or None."
    )


def with_database(
    idata: ImmunData,
    db: object,
    by: Mapping[str, str],
    label_col: str = "species",
    filters: Mapping[str, Any]
    | Sequence[Any]
    | Callable[[Table], Table]
    | None = None,
) -> ImmunData:
    """Add a selected database label using explicit ImmunData-to-database keys."""
    if not isinstance(idata, ImmunData):
        raise TypeError("`idata` must be an ImmunData object.")
    if not isinstance(by, Mapping) or not by:
        raise ValueError(
            "`by` must be a non-empty mapping of input to database columns."
        )
    if not isinstance(label_col, str) or not label_col:
        raise ValueError("`label_col` must be a non-empty column name.")

    database = _filter_database(_database_table(db), filters)
    require_columns(idata.annotations, list(by), "idata.annotations")
    require_columns(database, [*by.values(), label_col], "database table")
    selected = database.select(*dict.fromkeys([*by.values(), label_col]))
    return idata.annotate(annotations=selected, by=by)


__all__ = ["public", "with_database"]
