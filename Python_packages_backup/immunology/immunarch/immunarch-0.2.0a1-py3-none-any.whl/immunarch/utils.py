"""Small helpers shared by the first immunarch analysis functions."""

from collections.abc import Sequence

import polars as pl
from ibis.expr.types import Table
from pydantic import BaseModel, ConfigDict

from immundata import ImmunData
from immundata.spec import Schema


class AnalysisInputSchema(BaseModel):
    """Normalized input-column defaults for immunarch analyses."""

    model_config = ConfigDict(frozen=True)

    sequence: str = "junction_aa"


class AnalysisSchema(BaseModel):
    """Names for immunarch result columns that are not core data columns."""

    model_config = ConfigDict(frozen=True)

    n_chains: str = "n_chains"
    seq_len: str = "seq_len"
    n: str = "n"
    prop: str = "prop"
    pct: str = "pct"
    index: str = "index"
    clonal_rank_bin: str = "clonal_rank_bin"
    clonal_prop_bin: str = "clonal_prop_bin"
    occupied_prop: str = "occupied_prop"
    shannon: str = "shannon"
    richness: str = "richness"
    perc: str = "perc"
    dxx: str = "dxx"
    repertoire_2: str = "imd_repertoire_id_2"
    intersection: str = "intersection"
    jaccard: str = "jaccard"
    public_incidence: str = "imd_public_incidence"
    public_count_min: str = "imd_public_count_min"
    public_count_max: str = "imd_public_count_max"
    public_count_mean: str = "imd_public_count_mean"
    public_count_median: str = "imd_public_count_median"
    public_prop_min: str = "imd_public_prop_min"
    public_prop_max: str = "imd_public_prop_max"
    public_prop_mean: str = "imd_public_prop_mean"
    public_prop_median: str = "imd_public_prop_median"
    public_incidence_prop: str = "imd_public_incidence_prop"

    @property
    def public_metrics(self) -> tuple[str, ...]:
        return (
            self.public_incidence,
            self.public_count_min,
            self.public_count_max,
            self.public_count_mean,
            self.public_count_median,
            self.public_prop_min,
            self.public_prop_max,
            self.public_prop_mean,
            self.public_prop_median,
            self.public_incidence_prop,
        )


ANALYSIS_INPUT = AnalysisInputSchema()
ANALYSIS = AnalysisSchema()


def require_idata(idata: ImmunData) -> None:
    if not isinstance(idata, ImmunData):
        raise TypeError("`idata` must be an ImmunData object.")


def require_repertoires(idata: ImmunData) -> Table:
    require_idata(idata)
    if idata.repertoires is None or idata.schema_repertoire is None:
        raise ValueError(
            "Repertoire aggregation is required for this analysis."
        )
    return idata.repertoires


def require_columns(
    table: Table, columns: Sequence[str], location: str
) -> None:
    missing = [column for column in columns if column not in table.columns]
    if missing:
        raise ValueError(
            f"Column(s) not found in {location}: " + ", ".join(missing)
        )


def resolve_by(
    idata: ImmunData,
    by: str | Sequence[str] | None,
    *,
    auto_locus: bool = True,
) -> list[str]:
    if by is None:
        return []
    if by == "auto":
        columns = [Schema.locus] if auto_locus else []
    elif isinstance(by, str):
        columns = [by]
    else:
        columns = list(by)
    if not columns:
        raise ValueError("`by` must contain at least one column when provided.")
    if len(set(columns)) != len(columns):
        raise ValueError("`by` columns must be unique.")
    if by == "auto" and Schema.locus not in idata.annotations.columns:
        return []
    require_columns(idata.annotations, columns, "idata.annotations")
    return columns


def clone_table(idata: ImmunData, columns: Sequence[str]) -> Table:
    """Return one lazy row per biological receptor and repertoire."""
    require_columns(
        idata.annotations,
        [Schema.repertoire, Schema.receptor, *columns],
        "idata.annotations",
    )
    names = list(dict.fromkeys([Schema.repertoire, Schema.receptor, *columns]))
    selected = idata.annotations.select(*names)
    if not columns:
        return selected.select(Schema.repertoire, Schema.receptor).distinct()
    return selected.group_by(Schema.repertoire, Schema.receptor).agg(
        **{column: selected[column].max() for column in columns}
    )


def with_repertoire_metadata(
    result: pl.DataFrame,
    idata: ImmunData,
    *,
    include_summary: bool = False,
) -> pl.DataFrame:
    """Add repertoire keys (and optionally count summaries) to a small result."""
    if idata.repertoires is None or Schema.repertoire not in result.columns:
        return result
    if include_summary:
        wanted = list(idata.repertoires.columns)
    else:
        wanted = [Schema.repertoire, *(idata.schema_repertoire or [])]
    wanted = [
        column
        for column in wanted
        if column in idata.repertoires.columns and column not in result.columns
    ]
    if not wanted:
        return result
    metadata = idata.repertoires.select(Schema.repertoire, *wanted).to_polars()
    return result.join(metadata, on=Schema.repertoire, how="left")


def sort_result(result: pl.DataFrame, columns: Sequence[str]) -> pl.DataFrame:
    sort_columns = [column for column in columns if column in result.columns]
    if not sort_columns or result.is_empty():
        return result
    return result.sort(sort_columns, nulls_last=True)
