"""Observed diversity and abundance coverage for receptor repertoires."""

from collections.abc import Sequence

import ibis
import polars as pl

from immundata import ImmunData
from immundata.spec import Schema

from .utils import (
    ANALYSIS,
    clone_table,
    require_repertoires,
    sort_result,
    with_repertoire_metadata,
)


def _percentages(value: float | Sequence[float | int]) -> list[float]:
    if isinstance(value, (bool, str, bytes)):
        raise TypeError(
            "`perc` must be a number or a non-empty sequence of numbers."
        )
    if isinstance(value, (int, float)):
        values = [float(value)]
    elif isinstance(value, Sequence):
        if any(
            isinstance(item, bool) or not isinstance(item, (int, float))
            for item in value
        ):
            raise TypeError("`perc` values must be numbers.")
        values = [float(item) for item in value]
    else:
        raise TypeError(
            "`perc` must be a number or a non-empty sequence of numbers."
        )
    if not values:
        raise ValueError("`perc` cannot be empty.")
    if any(not 0 < item <= 100 for item in values):
        raise ValueError("`perc` must be in the interval (0, 100].")
    return values


def _fill_empty_repertoires(
    result: pl.DataFrame, idata: ImmunData, value_columns: Sequence[str]
) -> pl.DataFrame:
    """Keep declared repertoires with zero observed receptors in summaries."""
    if idata.repertoires is None:
        return result
    reps = idata.repertoires.select(Schema.repertoire).to_polars()
    out = reps.join(result, on=Schema.repertoire, how="left")
    return out.with_columns(
        pl.col(column).fill_null(0) for column in value_columns
    )


def shannon(idata: ImmunData) -> pl.DataFrame:
    """Compute Shannon entropy in bits from one abundance per receptor."""
    require_repertoires(idata)
    table = clone_table(idata, [Schema.proportion])
    table = table.filter(table[Schema.proportion] > 0)
    p = table[Schema.proportion]
    result = table.group_by(Schema.repertoire).agg(
        **{ANALYSIS.shannon: (-(p * p.log2())).sum()}
    )
    frame = _fill_empty_repertoires(
        result.to_polars(), idata, [ANALYSIS.shannon]
    )
    frame = with_repertoire_metadata(frame, idata)
    return sort_result(frame, [Schema.repertoire])


def richness(idata: ImmunData) -> pl.DataFrame:
    """Count observed distinct receptors, independent of their abundance."""
    require_repertoires(idata)
    table = clone_table(idata, [])
    result = table.group_by(Schema.repertoire).agg(
        **{ANALYSIS.richness: table[Schema.receptor].count()}
    )
    frame = _fill_empty_repertoires(
        result.to_polars(), idata, [ANALYSIS.richness]
    )
    frame = with_repertoire_metadata(frame, idata)
    return sort_result(frame, [Schema.repertoire])


def dxx(
    idata: ImmunData,
    perc: float | Sequence[float | int] = 50,
) -> pl.DataFrame:
    """Return the minimum number of top clones covering each ``perc`` percent.

    The ranking weights clone proportions (abundance), while ``dxx`` itself is
    a number of distinct receptors.
    """
    require_repertoires(idata)
    percentages = _percentages(perc)
    table = clone_table(idata, [Schema.proportion])
    window = ibis.cumulative_window(
        group_by=[table[Schema.repertoire]],
        order_by=[
            table[Schema.proportion].desc(),
            table[Schema.receptor].asc(),
        ],
    )
    repertoire_window = ibis.window(group_by=[table[Schema.repertoire]])
    ranked = table.mutate(
        _rank=ibis.row_number().over(window) + 1,
        _cumulative=table[Schema.proportion].sum().over(window),
        _n_receptors=table[Schema.receptor].count().over(repertoire_window),
    )
    out: ibis.Table | None = None
    for value in percentages:
        current = (
            ranked.filter(
                (ranked["_cumulative"] >= value / 100.0 - 1e-12)
                | (ranked["_rank"] == ranked["_n_receptors"])
            )
            .group_by(Schema.repertoire)
            .agg(**{ANALYSIS.dxx: ranked["_rank"].min()})
            .mutate(**{ANALYSIS.perc: ibis.literal(value)})
        )
        out = current if out is None else out.union(current, distinct=False)
    assert out is not None
    result = out.select(
        Schema.repertoire, ANALYSIS.perc, ANALYSIS.dxx
    ).order_by(Schema.repertoire, ANALYSIS.perc)
    frame = with_repertoire_metadata(result.to_polars(), idata)
    return sort_result(frame, [Schema.repertoire, ANALYSIS.perc])


__all__ = ["dxx", "richness", "shannon"]
