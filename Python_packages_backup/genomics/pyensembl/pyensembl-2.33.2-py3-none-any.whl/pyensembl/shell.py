# PYTHON_ARGCOMPLETE_OK
# (argcomplete's global activation completes only scripts with this marker.)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Command-line tool for installing and managing PyEnsembl data.

Tab completion re-runs this module up to ``argcomplete.autocomplete`` on every
key press, so module-level imports stay cheap: argparse, argcomplete and
small pyensembl modules. Genome, database and download code is imported by the
functions that run an action.
"""

import argparse
import json
import logging
import os
import re
import sys

import argcomplete

from .ensembl_versions import is_dated_release, normalize_release
from .version import __version__

logger = logging.getLogger(__name__)


class _ConciseFormatter(logging.Formatter):
    """Plain progress messages; warnings and errors keep their level."""

    def format(self, record):
        message = super().format(record)
        if record.levelno >= logging.WARNING:
            return "%s: %s" % (record.levelname.lower(), message)
        return message


_cli_handler = None


def configure_logging(verbose=False):
    """Show progress on stderr: one line per step, or every detail if verbose.

    Only the command-line entrypoint (``run``) calls this, so importing
    pyensembl never changes the host application's logging.
    """
    global _cli_handler
    handler = logging.StreamHandler()  # stderr; stdout carries results
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(name)s %(levelname)s: %(message)s")
        if verbose
        else _ConciseFormatter()
    )
    for name, level in (
        ("pyensembl", logging.DEBUG if verbose else logging.INFO),
        # datacache reports each download step and SQL statement.
        ("datacache", logging.DEBUG if verbose else logging.WARNING),
    ):
        package_logger = logging.getLogger(name)
        if _cli_handler is not None:
            package_logger.removeHandler(_cli_handler)
        package_logger.setLevel(level)
        package_logger.addHandler(handler)
        # Our handler prints; a host application's root handler must not too.
        package_logger.propagate = False
    _cli_handler = handler


_ACTIONS_AND_EXAMPLES = """\
actions:
  install             download and index genome data (skips what is already done)
  list                show installed genomes, whether they are indexed, and their DNA
  inspect             inspect selected source files, indexes, and download provenance offline
  verify              verify recorded dated-annotation checksums without repair
  available           show supported species, assemblies, and Ensembl releases
  delete-index-files  delete indexes, keeping downloaded files (needs --release)
  delete-all-files    delete all of a genome's local data (needs --release)
  prune               delete shared reference DNA that no installed release uses

examples:
  pyensembl install --release 75 77                     human releases 75 and 77
  pyensembl install --release 110 --species mouse       a mouse release
  pyensembl install --release 2026_04                   a dated release (new Ensembl platform)
  pyensembl install --reference-name GRCh37             newest release for GRCh37
  pyensembl install --release 110 --with-genome-fasta   also install reference DNA
  pyensembl install --reference-name GRCh38 --annotation-name my_genes \\
      --gtf URL_OR_PATH --transcript-fasta URL_OR_PATH  a custom genome
  pyensembl list
  pyensembl inspect --release 93 --json
  pyensembl delete-all-files --release 75
  pyensembl prune --dry-run
"""

parser = argparse.ArgumentParser(
    prog="pyensembl",
    usage="%(prog)s ACTION [options]",
    description="Install and manage the genome data PyEnsembl uses.",
    epilog=_ACTIONS_AND_EXAMPLES,
    formatter_class=argparse.RawDescriptionHelpFormatter,
)

parser.add_argument(
    "--version", 
    action="version",
    version='%(prog)s {version}'.format(version=__version__)
)

parser.add_argument(
    "-v",
    "--verbose",
    action="store_true",
    help="Show detailed progress, including download and database steps",
)

parser.add_argument(
    "--json",
    action="store_true",
    help="With inspect, available, or verify, print JSON",
)

parser.add_argument(
    "--overwrite",
    default=False,
    action="store_true",
    help="Force download and indexing even if files already exist locally",
)


def _release_argument(value):
    if value.strip() == "latest":
        return "latest"
    try:
        return normalize_release(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError(str(error))


def installed_releases(root):
    """List the releases that have a cache directory, by directory name only.

    Genomes live in ``<root>/<reference>/ensembl<release>``; dated releases
    of non-default datasets use
    ``ensembl-<provider>-<accession>-<coverage>-<date>``. Only directory names
    are read: no file is opened, indexed or downloaded, so this is fast enough
    for tab completion on a large cache.

    Parameters
    ----------
    root : str
        The pyensembl cache directory, e.g. ``cache_root()``.

    Returns
    -------
    list of str
        Distinct release labels such as ``"75"`` or ``"2026_04"``: numbered
        releases in order, then annotation dates in order. Empty if ``root``
        does not exist or cannot be read.
    """
    releases = set()
    try:
        references = [entry for entry in os.scandir(root) if entry.is_dir()]
    except OSError:
        return []
    for reference in references:
        try:
            names = [entry.name for entry in os.scandir(reference.path) if entry.is_dir()]
        except OSError:
            continue
        for name in names:
            match = re.fullmatch(r"ensembl(?:-.+-)?(\d+|\d{4}_(?:0[1-9]|1[0-2]))", name)
            if match:
                releases.add(match.group(1))
    return sorted(releases, key=_release_sort_key)


def complete_release(prefix, **kwargs):
    """Suggest ``--release`` values: the releases installed in the local cache.

    An argcomplete completer. It lists cache directory names (see
    ``installed_releases``) and never touches the network. Resolving the
    default cache location imports datacache, whose import is lazy (a few
    milliseconds) from datacache 1.30.

    Parameters
    ----------
    prefix : str
        What has been typed so far; argcomplete filters the suggestions by it.
    **kwargs
        The other arguments argcomplete passes (``action``, ``parser``,
        ``parsed_args``); unused.

    Returns
    -------
    list of str
        Release labels, e.g. ``["75", "93", "2026_04"]``.
    """
    from .cache_location import cache_root

    return installed_releases(cache_root())


def complete_species(prefix, **kwargs):
    """Suggest ``--species`` values: every registered species name.

    An argcomplete completer. It reads pyensembl's built-in species registry;
    it never touches the cache or the network.

    Parameters
    ----------
    prefix : str
        What has been typed so far; argcomplete filters the suggestions by it.
    **kwargs
        The other arguments argcomplete passes (``action``, ``parser``,
        ``parsed_args``); unused.

    Returns
    -------
    list of str
        Common names (e.g. ``"human"``) and latin names
        (e.g. ``"homo_sapiens"``), sorted.
    """
    from .species import Species, find_species_by_name

    names = set()
    for latin_name in Species.all_registered_latin_names():
        names.add(latin_name)
        names.update(find_species_by_name(latin_name).synonyms)
    return sorted(names)


release_group = parser.add_argument_group("Ensembl release options")
release_group.add_argument(
    "--release",
    type=_release_argument,
    nargs="+",
    default=[],
    help=(
        "Ensembl release version(s): numbered, YYYY_MM, or opt-in latest on "
        "the new Ensembl platform; required for deletion "
        "(install default=newest supported release for --reference-name, "
        "otherwise for each species)"
    ),
).completer = complete_release

release_group.add_argument(
    "--species",
    default=[],
    nargs="+",
    help=(
        "Which species to download Ensembl data for "
        "(default=inferred from --reference-name, otherwise human)"
    ),
).completer = complete_species

release_group.add_argument(
    "--assembly", help="Optional build, full assembly name, or versioned GCA/GCF accession",
)
release_group.add_argument(
    "--assembly-accession", help="Explicit accession (uses the compatible accession cache layout)",
)
release_group.add_argument("--provider", help="Annotation provider for a dated release")
release_group.add_argument(
    "--server", help="Mirror root preserving Ensembl's directory structure (advanced)",
)
release_group.add_argument(
    "--include-alt", action=argparse.BooleanOptionalAction, default=None,
    help="Select dated annotation coverage explicitly",
)
release_group.add_argument(
    "--cache-reference-name", help="Preserve a custom reference label when reopening an accession dataset",
)
release_group.add_argument(
    "--cache-directory", help="Explicit existing cache directory for one selected dataset",
)

release_group.add_argument(
    "--custom-mirror",
    default=None,
    help=("Flat mirror URL/directory; repeat it to reuse mirror data. In Python use "
          "EnsemblRelease(...).with_mirror(URL). New mirror caches are separate "
          "from default EnsemblRelease caches."),
)

parser.add_argument(
    "--reference-name",
    type=str,
    default=None,
    help=(
        "Reference assembly, e.g. GRCh37 (case-insensitive for Ensembl). "
        "Selects its newest supported release unless --release is given; "
        "with custom source files, names the custom reference."
    ),
)

path_group = parser.add_argument_group("Custom genome options")

path_group.add_argument(
    "--annotation-name", default=None, help="Name of annotation source (e.g. refseq)"
)

path_group.add_argument(
    "--annotation-version", default=None, help="Version of annotation database"
)

path_group.add_argument(
    "--gtf",
    type=str,
    default=None,
    help="URL or local path to a GTF file containing annotations.",
)

path_group.add_argument(
    "--transcript-fasta",
    type=str,
    action="append",
    default=[],
    help="URL or local path to a FASTA files containing the transcript "
    "data. This option can be specified multiple times for multiple "
    "FASTA files.",
)

path_group.add_argument(
    "--protein-fasta",
    type=str,
    default=[],
    action="append",
    help="URL or local path to a FASTA file containing protein data.",
)

path_group.add_argument(
    "--shared-prefix",
    default="",
    help="Add this prefix to URLs or paths specified by --gtf, --transcript-fasta, --protein-fasta",
)

dna_group = parser.add_argument_group("Optional reference DNA")
dna_group.add_argument("--with-genome-fasta", action="store_true",
                       help="Also download and index reference DNA (several GB for human)")
dna_group.add_argument("--only-genome-fasta", action="store_true",
                       help="Download/index only reference DNA, without annotation or transcript data")
dna_group.add_argument("--genome-fasta-path", default=None,
                       help="Attach a local reference FASTA; custom Genome sources also accept a URL")
dna_group.add_argument("--genome-fasta-type", choices=("toplevel", "primary_assembly"),
                       default="toplevel", help="Toplevel includes patch/haplotype contigs (default)")
dna_group.add_argument("--masked", choices=("none", "soft", "hard"), default="none",
                       help="Masking of downloaded reference DNA (default: none)")
dna_group.add_argument("--check-genome-fasta", action="store_true",
                       help="With list or inspect, check DNA indexes without downloading or rebuilding")
# Accepted for 2.11.0 scripts; unused DNA is what prune removes.
dna_group.add_argument("--orphan-genome-fastas", action="store_true", help=argparse.SUPPRESS)
dna_group.add_argument("--dry-run", action="store_true",
                       help="With prune, report candidates without deleting files")

parser.add_argument(
    "action",
    type=lambda arg: arg.lower().strip(),
    choices=(
        "install",
        "list",
        "inspect",
        "verify",
        "available",
        "delete-index-files",
        "delete-all-files",
        "prune",
    ),
    metavar="ACTION",
    help="one of the actions listed below",
)


parser.add_argument("--refresh", action="store_true",
                    help="With available, refresh dated listings from Ensembl")
parser.add_argument("--check-remote", action="store_true",
                    help="With verify, compare recorded MD5s with current upstream manifests")


def available_catalogue(args):
    from .release_catalogue import available_releases
    if args.reference_name and args.assembly and args.reference_name != args.assembly:
        raise ValueError("Use one assembly selector with available")
    rows = []
    for species in args.species or [None]:
        rows.extend(available_releases(
            species=species, assembly=args.assembly or args.reference_name,
            assembly_accession=args.assembly_accession, provider=args.provider,
            include_alt=args.include_alt, refresh=args.refresh,
        ))
    if args.json:
        return json.dumps(rows, indent=2)
    return _format_table(("Release", "Assembly", "Provider", "Coverage", "Evidence", "Latest"), [
        (r["release"], r.get("assembly_name") or r.get("assembly_accession"), r["provider"],
         r["coverage"], "subset" if r["subset"] else
         "; ".join(c["relationship"] + " to " + str(c["numbered"]) for c in r["comparisons"])
         or ("frozen" if r["kind"] == "numbered" else "uncompared"),
         "yes" if r["latest"] else "") for r in rows
    ])


def _dna_status(cache_directory, check=False):
    """Describe DNA recorded in a genome cache directory, or None if none.

    A broken reference is reported rather than raised, so one bad release
    cannot hide the others.
    """
    from .genome_fasta import GenomeFasta
    from .genome_fasta_cache import canonical_source_options

    try:
        dna = GenomeFasta.installed_source(cache_directory)
    except (OSError, ValueError) as error:
        logger.warning("Invalid reference DNA record in %s: %s", cache_directory, error)
        return "invalid reference"
    if dna is None:
        return None
    if not dna.remote:
        kind = "local " + os.path.basename(dna.source)
    else:
        options = canonical_source_options(dna.source)
        kind = "downloaded"
        if options is not None:
            fasta_type, mask = options
            kind = fasta_type if mask == "none" else "%s, %s-masked" % (fasta_type, mask)
    return "%s, %s" % (kind, dna.status(check=check))


def genome_fasta_status(genome, check=False):
    """Describe the reference DNA recorded for a genome's cache, or None."""
    return _dna_status(genome.download_cache.cache_directory_path, check=check)


# Reference DNA bookkeeping in a genome's cache directory.
_DNA_ENTRIES = {"genome_fasta", "genome_fasta.json", "genome_fasta_refs"}


def _directory_annotation_status(directory):
    """Best-effort status for a cache directory whose genome is unknown."""
    from .database import is_complete_database

    try:
        names = [
            name for name in os.listdir(directory)
            if not name.startswith(".") and name not in _DNA_ENTRIES
        ]
    except OSError:
        return None
    if not names:
        return None
    databases = [name for name in names if name.endswith(".db")]
    if databases:
        complete = all(
            is_complete_database(os.path.join(directory, name)) for name in databases
        )
        return "indexed" if complete else "not indexed"
    if any(name.endswith((".gtf", ".gtf.gz")) for name in names):
        return "not indexed"
    return "indexed" if any(name.endswith(".pickle") for name in names) else "not indexed"


def _subdirectories(path):
    from pathlib import Path

    try:
        return sorted(
            entry for entry in Path(path).iterdir()
            if not entry.name.startswith(".") and entry.is_dir()
        )
    except FileNotFoundError:
        return []
    except OSError as error:
        logger.warning("Cannot read %s: %s", path, error)
        return []


def _other_genome_labels(reference, annotation):
    """(species, release) cells for a cache directory pyensembl did not match."""
    from .reference_name import find_species_by_reference

    release = annotation[len("ensembl"):] if annotation.startswith("ensembl") else ""
    if not (re.fullmatch(r"[0-9]+", release) or is_dated_release(release)):
        return "custom", annotation
    try:
        species = _species_display_name(find_species_by_reference(reference))
    except (KeyError, ValueError):
        species = "unknown"
    return species, release  # e.g. installed by a newer pyensembl


def _display_path(path):
    home = os.path.expanduser("~")
    path = os.fspath(path)
    return "~" + path[len(home):] if path == home or path.startswith(home + os.sep) else path


def _format_table(header, rows, use_color=None):
    """Align rows under a header; cells are printed with ``str``, so a
    numbered release can be the ``int`` it is everywhere else."""
    if use_color is None:
        use_color = sys.stdout.isatty()
    rows = [[str(cell) for cell in row] for row in rows]
    widths = [max(len(cell) for cell in column) for column in zip(header, *rows)]

    def line(cells):
        return "  ".join(cell.ljust(width) for cell, width in zip(cells, widths)).rstrip()

    bold, reset = ("\x1b[1m", "\x1b[0m") if use_color else ("", "")
    return "\n".join([bold + line(header) + reset] + [line(row) for row in rows])


def inspect_genomes(genomes, check_genome_fasta=False, json_output=False):
    """Render the same offline inventory exposed by ``Genome.inspect_data``."""
    from dataclasses import fields

    reports = []
    tables = []
    for genome in genomes:
        report = genome.inspect_data(check_genome_fasta=check_genome_fasta)
        report.update(
            reference_name=genome.reference_name,
            annotation_name=genome.annotation_name,
            annotation_version=genome.annotation_version,
            cache_directory=genome.download_cache.cache_directory_path,
        )
        if json_output:
            report["files"] = {
                role: {field.name: (str(file.error) if file.error else None)
                       if field.name == "error" else getattr(file, field.name)
                       for field in fields(file)}
                for role, file in report["files"].items()
            }
            reports.append(report)
        else:
            rows = [(role, file.status, str(file.size) if file.size is not None else "-",
                     _display_path(file.path), file.source_url or "-")
                    for role, file in report["files"].items()]
            lines = ["%s: annotation=%s, reference DNA=%s" % (
                _genome_description(genome), report["annotation"] or "not configured",
                report["reference_dna"] or "not configured",
            ), _format_table(("File", "Status", "Bytes", "Path", "Fetched from"), rows)]
            lines.extend("%s: %s" % (role, file.error)
                         for role, file in report["files"].items() if file.error)
            tables.append("\n".join(lines))
    return json.dumps(reports, indent=2) if json_output else "\n\n".join(tables)


def _ensembl_releases():
    """Every numbered release, plus dated releases with a cache directory."""
    from .ensembl_release import EnsemblRelease
    from .species import Species

    numbered = [
        EnsemblRelease(release, species=species)
        for species, release in Species.all_species_release_pairs()
    ]
    return numbered + _cached_dated_releases()


def _cached_dated_releases():
    from .release_catalogue import cached_dated_releases
    return cached_dated_releases()


def _release_sort_key(release):
    """Numbered releases in order, then annotation dates in order."""
    release = str(release)
    return (0, int(release), "") if release.isdigit() else (1, 0, release)


def _has_data(annotation, dna):
    return annotation not in (None, "missing") or dna is not None


def collect_all_installed_ensembl_releases():
    """Ensembl releases with annotation data or reference DNA in the cache."""
    return sorted(
        (
            genome for genome in _ensembl_releases()
            if _has_data(genome._annotation_status(), genome_fasta_status(genome))
        ),
        key=lambda genome: (genome.species.latin_name, _release_sort_key(genome.release)),
    )


def format_installed_genomes(check_genome_fasta=False, use_color=None):
    """A table of genomes in the local cache, or a note that there are none."""
    from pathlib import Path

    from .download_cache import cache_root

    rows = []
    ensembl_directories = set()
    ensembl_named = set()
    for genome in _ensembl_releases():
        directory = genome.download_cache.cache_directory_path
        ensembl_named.add(os.path.normpath(directory))
        annotation = genome._annotation_status()
        dna = _dna_status(directory, check=check_genome_fasta)
        if not _has_data(annotation, dna):
            continue  # Possibly a custom genome with the same name; listed below.
        ensembl_directories.add(os.path.normpath(directory))
        rows.append((
            _species_display_name(genome.species),
            genome.reference_name,
            str(genome.release),
            annotation if annotation not in (None, "missing") else "-",
            dna or "-",
            _display_path(directory),
        ))
    rows.sort(key=lambda row: (row[0], row[1], _release_sort_key(row[2])))
    # Custom genomes (e.g. install --gtf ...) live beside Ensembl releases.
    root = Path(cache_root())
    for reference in _subdirectories(root):
        if reference.name == "dna_cache":
            continue
        for directory in _subdirectories(reference):
            if os.path.normpath(directory) in ensembl_directories:
                continue
            annotation = _directory_annotation_status(directory)
            dna = _dna_status(directory, check=check_genome_fasta)
            if not _has_data(annotation, dna):
                continue
            if os.path.normpath(directory) in ensembl_named:
                # Named like an Ensembl release, but holding other files.
                species, release = "custom", directory.name
            else:
                species, release = _other_genome_labels(reference.name, directory.name)
            rows.append((
                species,
                reference.name,
                release,
                annotation or "-",
                dna or "-",
                _display_path(directory),
            ))
    if not rows:
        return "No genomes installed in %s" % _display_path(root)
    header = ("Species", "Assembly", "Release", "Annotation", "Reference DNA", "Location")
    return _format_table(header, rows, use_color)


def _newest_release(species_name):
    """Newest release supported for a species; Ensembl Genomes numbers end at 63."""
    from .species import find_species_by_name

    species = find_species_by_name(species_name)
    return max(end for _, end in species.reference_assemblies.values())


def all_combinations_of_ensembl_genomes(args):
    """
    Use all combinations of species and release versions specified by the
    commandline arguments to return a list of EnsemblRelease or Genome objects.
    A reference name constrains the species and releases; omitted values are
    inferred from that reference's newest supported release.
    The results will typically be of type EnsemblRelease unless the
    --custom-mirror argument was given.
    """
    from .ensembl_release import EnsemblRelease
    from .reference_name import find_species_by_reference, normalize_reference_name
    from .species import find_species_by_name

    assembly = getattr(args, "assembly", None)
    accession = getattr(args, "assembly_accession", None)
    if getattr(args, "server", None) and args.custom_mirror:
        raise ValueError("Choose --server for a structured mirror or --custom-mirror for a flat mirror")
    if (assembly or accession) and len(args.species) > 1:
        raise ValueError("An explicit assembly requires at most one --species")
    species_list = args.species or ([None] if assembly or accession else ["human"])
    release_list = args.release
    if args.reference_name is not None:
        reference_name = normalize_reference_name(args.reference_name)
        reference_species = find_species_by_reference(reference_name)
        species_list = args.species or [reference_species.latin_name]
        for species_name in species_list:
            species = find_species_by_name(species_name)
            if species != reference_species:
                raise ValueError(
                    "Reference %s belongs to %s, not %s"
                    % (reference_name, reference_species.latin_name, species.latin_name)
                )
        first_release, last_release = reference_species.reference_assemblies[reference_name]
        release_list = args.release or [last_release]
        for version in release_list:
            if version == "latest" or is_dated_release(version):
                # The shared resolver handles historical dated assemblies too.
                EnsemblRelease(version, species=reference_species, assembly=reference_name)
            elif not first_release <= version <= last_release:
                raise ValueError(
                    "Reference %s supports Ensembl releases %d-%d, not --release %d"
                    % (reference_name, first_release, last_release, version)
                )
    dna_requested = args.with_genome_fasta or args.only_genome_fasta
    if args.genome_fasta_path is not None and not args.custom_mirror:
        if not args.genome_fasta_path or "://" in args.genome_fasta_path:
            raise ValueError(
                "--genome-fasta-path must be a local file for an Ensembl release; "
                "use --annotation-name to install a custom genome with a DNA URL"
            )
        genome_fasta = args.genome_fasta_path
    else:
        # A mirror serves Ensembl's filenames; the release only names them.
        genome_fasta = dna_requested
    genomes = []
    for species in species_list:
        # Otherwise, use Ensembl release information
        if not release_list and (assembly or accession):
            raise ValueError("--assembly requires an explicit --release")
        for version in release_list or [_newest_release(species)]:
            selected_assembly = assembly
            if args.reference_name is not None:
                if assembly is not None:
                    probe = EnsemblRelease(version, species=species, assembly=assembly,
                                           assembly_accession=accession)
                    if probe.assembly != reference_name and probe.reference_name != reference_name:
                        raise ValueError("--assembly conflicts with --reference-name")
                else:
                    selected_assembly = reference_name
            if getattr(args, "cache_directory", None) and (
                len(species_list) != 1 or len(release_list or [version]) != 1
            ):
                raise ValueError("--cache-directory requires exactly one dataset")
            ensembl_release = EnsemblRelease(
                version, species=species,
                genome_fasta=genome_fasta,
                genome_fasta_type=args.genome_fasta_type,
                genome_fasta_mask=args.masked,
                assembly=selected_assembly, assembly_accession=accession,
                provider=getattr(args, "provider", None),
                include_alt=getattr(args, "include_alt", None),
                reference_name=getattr(args, "cache_reference_name", None),
                cache_directory_path=getattr(args, "cache_directory", None),
                server=getattr(args, "server", None),
            )

            if not args.custom_mirror:
                genomes.append(ensembl_release)
            else:
                genomes.append(ensembl_release.with_mirror(
                    args.custom_mirror,
                    genome_fasta_path_or_url=args.genome_fasta_path,
                ))
    return genomes


def collect_selected_genomes(args):
    from .genome import Genome

    # An explicitly empty source is an argument error, not an omitted option.
    # In particular, do not let --gtf "" or --custom-mirror "" select the
    # default human download through the truthiness checks below.
    sources = [
        ("--gtf", args.gtf),
        ("--genome-fasta-path", args.genome_fasta_path),
        ("--custom-mirror", args.custom_mirror),
        ("--server", getattr(args, "server", None)),
        *(("--transcript-fasta", path) for path in args.transcript_fasta),
        *(("--protein-fasta", path) for path in args.protein_fasta),
    ]
    for option, value in sources:
        if value == "":
            raise ValueError("%s must not be empty" % option)
    # If specific genome source URLs are provided, use those
    if args.gtf or args.transcript_fasta or args.protein_fasta or (
        args.genome_fasta_path and args.annotation_name
    ):
        if any(getattr(args, key, None) is not None for key in (
            "assembly", "assembly_accession", "provider", "include_alt",
            "cache_reference_name", "cache_directory", "server",
        )):
            raise ValueError("Ensembl assembly options cannot be combined with custom source files")
        if args.release:
            raise ValueError(
                "An Ensembl release cannot be specified if "
                "specific paths are also given"
            )
        if not args.reference_name:
            raise ValueError("Must specify a reference name")
        if not args.annotation_name:
            raise ValueError("Must specify the name of the annotation source")
        if (args.with_genome_fasta or args.only_genome_fasta) and not args.genome_fasta_path:
            raise ValueError("Custom genomes require --genome-fasta-path for reference DNA")

        return [
            Genome(
                reference_name=args.reference_name,
                annotation_name=args.annotation_name,
                annotation_version=args.annotation_version,
                gtf_path_or_url=os.path.join(args.shared_prefix, args.gtf) if args.gtf else None,
                transcript_fasta_paths_or_urls=[
                    os.path.join(args.shared_prefix, transcript_fasta)
                    for transcript_fasta in args.transcript_fasta
                ],
                protein_fasta_paths_or_urls=[
                    os.path.join(args.shared_prefix, protein_fasta)
                    for protein_fasta in args.protein_fasta
                ],
                genome_fasta_path_or_url=(
                    os.path.join(args.shared_prefix, args.genome_fasta_path)
                    if args.genome_fasta_path else None
                ),
            )
        ]
    else:
        return all_combinations_of_ensembl_genomes(args)


_DIVISION_LABELS = (
    ("vertebrates", "Vertebrates"),
    ("metazoa", "Invertebrates"),
    ("plants", "Plants"),
    ("fungi", "Fungi"),
    ("protists", "Protists"),
    ("bacteria", "Bacteria"),
)


def _format_release_range(start, end):
    # Inclusive range; collapse a single-value range to just that integer.
    if start == end:
        return str(start)
    return "%d–%d" % (start, end)  # en-dash


def _species_display_name(species):
    if species.synonyms:
        return species.synonyms[0]
    return species.latin_name


def format_available_species(use_color=None, dated_releases=None):
    """
    Render the table printed by the "available" CLI action: every registered
    species and its supported Ensembl release ranges, grouped by division.

    When ``use_color`` is ``None`` (the default), ANSI styling is applied if
    stdout is a TTY and suppressed otherwise. ``dated_releases`` optionally
    maps latin names to the annotation dates of their registered dated assembly
    (``None`` when unknown) and adds a column for them.
    """
    from .species import Species

    if use_color is None:
        use_color = sys.stdout.isatty()
    BOLD = "\x1b[1m" if use_color else ""
    DIM = "\x1b[2m" if use_color else ""
    RESET = "\x1b[0m" if use_color else ""

    species_by_division = {key: [] for key, _ in _DIVISION_LABELS}
    for latin_name in sorted(Species._latin_names_to_species):
        species = Species._latin_names_to_species[latin_name]
        species_by_division.setdefault(species.division, []).append(species)

    all_species = [s for group in species_by_division.values() for s in group]
    if not all_species:
        return ""

    def _w(values, fallback):
        return max((len(v) for v in values), default=fallback)

    name_w = _w([_species_display_name(s) for s in all_species], 8)
    asm_w = _w(
        [asm for s in all_species for asm in s.reference_assemblies], 8
    )
    rng_w = _w(
        [
            _format_release_range(start, end)
            for s in all_species
            for (start, end) in s.reference_assemblies.values()
        ],
        8,
    )
    latin_w = _w([s.latin_name for s in all_species], 8)

    def dates_cell(species, assembly):
        if dated_releases is None or species.dated_releases is None:
            return ""
        if assembly != species.dated_reference_name:
            return ""
        dates = dated_releases.get(species.latin_name)
        return "?" if dates is None else ", ".join(dates)

    dates_w = _w(
        [dates_cell(s, asm) for s in all_species for asm in s.reference_assemblies], 0
    )

    col_name = max(name_w, len("Species")) + 2
    col_asm = max(asm_w, len("Assembly")) + 2
    col_rng = max(rng_w, len("Releases")) + 2
    col_dates = max(dates_w, len("Dated releases")) + 2 if dated_releases is not None else 0
    col_latin = max(latin_w, len("Latin name"))
    total_w = col_name + col_asm + col_rng + col_dates + col_latin

    lines = []
    header_row = "%-*s%-*s%-*s%-*s%s" % (
        col_name, "Species",
        col_asm, "Assembly",
        col_rng, "Releases",
        col_dates, "Dated releases" if col_dates else "",
        "Latin name",
    )
    lines.append("%s%s%s" % (BOLD, header_row, RESET))
    lines.append("─" * total_w)

    for division_key, division_label in _DIVISION_LABELS:
        members = species_by_division.get(division_key, [])
        if not members:
            continue
        members.sort(key=_species_display_name)
        lines.append("")
        section = "── %s " % division_label
        section += "─" * max(2, total_w - len(section))
        lines.append("%s%s%s" % (BOLD, section, RESET))
        for species in members:
            for i, (asm, (start, end)) in enumerate(
                species.reference_assemblies.items()
            ):
                if i == 0:
                    name_cell = _species_display_name(species)
                    latin_cell = "%s%s%s" % (DIM, species.latin_name, RESET)
                else:
                    name_cell = ""
                    latin_cell = ""
                lines.append(
                    "%-*s%-*s%-*s%-*s%s"
                    % (
                        col_name, name_cell,
                        col_asm, asm,
                        col_rng, _format_release_range(start, end),
                        col_dates, dates_cell(species, asm),
                        latin_cell,
                    )
                )
    if any(
        dates_cell(species, asm) == "?"
        for species in all_species for asm in species.reference_assemblies
    ):
        lines.append("")
        lines.append("? = dates could not be fetched and none are cached")
    return "\n".join(lines)


def _genome_description(genome):
    from .ensembl_release import EnsemblRelease

    if isinstance(genome, EnsemblRelease):
        species = genome.species
        name = (
            species.synonyms[0] if species.synonyms else species.latin_name
        ) if species is not None else "assembly"
        return "%s %s release %s" % (name, genome.reference_name, genome.release)
    description = "%s %s" % (genome.reference_name, genome.annotation_name)
    if genome.annotation_version is not None:
        description += " %s" % genome.annotation_version
    return description


def _directory_size(path):
    """Sum file sizes without following links outside the cache directory."""
    size = 0
    for root, directories, files in os.walk(path):
        for name in files + directories:
            entry = os.path.join(root, name)
            if os.path.isfile(entry) or os.path.islink(entry):
                size += os.lstat(entry).st_size
    return size


def _progress_available():
    """Show progress bars when someone is watching stderr."""
    return sys.stderr.isatty()


def _install(genome, only_genome_fasta=False, overwrite=False, show_progress=False):
    description = _genome_description(genome)
    if only_genome_fasta:
        installed = genome._genome_fasta.status() == "indexed"
    else:
        installed = genome.installed()
    if installed and not overwrite:
        # The steps below then only confirm that everything is in place.
        logger.info("%s is already installed", description)
    else:
        logger.info("Installing %s", description)
    if only_genome_fasta:
        genome.download_genome_fasta(overwrite=overwrite, show_progress=show_progress)
        genome.index_genome_fasta(overwrite=overwrite, show_progress=show_progress)
    else:
        genome.download(overwrite=overwrite, show_progress=show_progress)
        genome.index(overwrite=overwrite, show_progress=show_progress)


def _delete_genome_files(genome, action):
    from .genome_fasta_cache import dna_cache_lock

    if action == "delete-index-files":
        deleted = genome.delete_index_files()
    else:
        directory = genome.download_cache.cache_directory_path
        deleted = []
        # Serialize reference removal with shared-DNA install/prune. Shared
        # objects themselves are removed only by the explicit prune action.
        if os.path.isdir(directory):
            with dna_cache_lock():
                if os.path.isdir(directory):
                    genome.close()
                    size = _directory_size(directory)
                    genome.download_cache.delete_cache_directory()
                    deleted.append((directory, size))
    for path, size in deleted:
        print("Deleted %s (%s bytes)" % (path, format(size, ",")))
    if not deleted:
        print("Nothing to delete for %s" % _genome_description(genome))


DELETE_ACTIONS = ("delete-all-files", "delete-index-files")


def validate_arguments(action, json_output, refresh, check_remote, releases):
    """Check that action-specific flags are used with the right action.

    Parameters
    ----------
    action : str
        The CLI action, e.g. ``"install"``.
    json_output : bool
        Whether ``--json`` was given.
    refresh : bool
        Whether ``--refresh`` was given.
    check_remote : bool
        Whether ``--check-remote`` was given.
    releases : list
        Values of ``--release`` (``"latest"`` or normalized releases).

    Raises
    ------
    ValueError
        With the usage message when a flag does not fit the action.
    """
    if json_output and action not in ("inspect", "available", "verify"):
        raise ValueError("--json requires inspect, available, or verify")
    if refresh and action != "available":
        raise ValueError("--refresh requires available")
    if check_remote and action != "verify":
        raise ValueError("--check-remote requires verify")
    if action in DELETE_ACTIONS and "latest" in releases:
        raise ValueError("Deletion requires a concrete --release, not latest")


def run_prune(dry_run):
    """Delete (or with ``dry_run`` only list) reference DNA no release uses.

    Parameters
    ----------
    dry_run : bool
        Report candidates without deleting files.

    Returns
    -------
    str
        One line per candidate, or a note that there are none.

    Raises
    ------
    ValueError
        If the shared DNA cache cannot be pruned safely.
    """
    from .genome_fasta_cache import prune_genome_fastas

    candidates = prune_genome_fastas(dry_run=dry_run)
    if not candidates:
        return "No orphan genome FASTAs"
    verb = "Would delete" if dry_run else "Deleted"
    return "\n".join(
        "%s %s (%s bytes)" % (verb, path, format(size, ",")) for path, size in candidates
    )


def selects_catalogue(args):
    """Tell whether ``available`` should print the filtered release catalogue.

    Parameters
    ----------
    args : argparse.Namespace
        Parsed CLI arguments; the selector flags and ``json`` are used.

    Returns
    -------
    bool
        True when any of ``--species``, ``--assembly``,
        ``--assembly-accession``, ``--provider``, ``--reference-name``,
        ``--include-alt``/``--no-include-alt`` or ``--json`` was given;
        False for the plain table of supported species.
    """
    return bool(
        args.species or args.assembly or args.assembly_accession or args.provider
        or args.reference_name or args.include_alt is not None or args.json
    )


def run_available(args):
    """Describe what Ensembl data is available.

    Parameters
    ----------
    args : argparse.Namespace
        Parsed CLI arguments; the selector flags, ``json`` and ``refresh``
        are used.

    Returns
    -------
    str
        A filtered release catalogue when any selector or ``--json`` is
        given, otherwise the table of supported species.

    Raises
    ------
    ValueError
        If the selectors conflict. Only this case is a command-line mistake:
        ``run`` reports it as an argument error when ``selects_catalogue``
        is true and lets other errors keep their tracebacks.
    """
    from .dated_releases import AVAILABLE_EXPIRE_AFTER, fetch_all_dated_releases

    if selects_catalogue(args):
        return available_catalogue(args)
    return format_available_species(dated_releases=fetch_all_dated_releases(
        expire_after=0 if args.refresh else AVAILABLE_EXPIRE_AFTER,
    ))


def require_ensembl_releases(genomes):
    """Check that every genome is an Ensembl release, as ``verify`` requires.

    Only Ensembl releases have upstream checksum manifests to verify against.

    Parameters
    ----------
    genomes : list of Genome
        Genomes selected on the command line.

    Raises
    ------
    ValueError
        If any genome is not an ``EnsemblRelease``.
    """
    from .ensembl_release import EnsemblRelease

    if any(not isinstance(g, EnsemblRelease) for g in genomes):
        raise ValueError("verify requires an Ensembl release; use inspect for custom sources")


def run_verify(genomes, check_remote=False, json_output=False):
    """Verify recorded checksums of Ensembl releases without repairing them.

    Parameters
    ----------
    genomes : list of EnsemblRelease
        Releases to verify.
    check_remote : bool
        Also compare recorded MD5s with current upstream manifests.
    json_output : bool
        Return JSON instead of a table.

    Returns
    -------
    (str, bool)
        The report text and whether every source is fine (``False`` means
        the command should exit non-zero).

    Raises
    ------
    ValueError
        If any genome is not an Ensembl release (see
        ``require_ensembl_releases``). Checksum problems found while
        verifying, such as ``AnnotationIntegrityError`` for an ambiguous
        upstream manifest, also propagate.
    """
    require_ensembl_releases(genomes)
    reports = [dict(release=g.release, sources=g.verify_sources(check_remote)) for g in genomes]
    if json_output:
        text = json.dumps(reports, indent=2)
    else:
        text = _format_table(("Release", "Source", "Local", "Upstream"), [
            (r["release"], s["source"], s["status"], s.get("upstream_status", "not checked"))
            for r in reports for s in r["sources"]
        ])
    ok = not any(
        s["status"] not in ("verified", "unrecorded") or s.get("upstream_status") == "changed"
        for r in reports for s in r["sources"]
    )
    return text, ok


class InstallError(Exception):
    """An install failed because a source file is missing."""


def run_install(genome, only_genome_fasta=False, overwrite=False):
    """Download and index one genome, reporting missing source files as ``InstallError``.

    Parameters
    ----------
    genome : Genome
        Genome to download and index.
    only_genome_fasta : bool
        Install only reference DNA.
    overwrite : bool
        Redo downloads and indexing even when files exist.

    Raises
    ------
    UnpublishedDateError
        If a dated release is not published.
    InstallError
        For missing local or remote source files; ``str`` is the message.
    """
    from .download_cache import MissingGenomeDataFile, MissingLocalFile
    from .genome_fasta import MissingGenomeFastaError

    try:
        _install(
            genome, only_genome_fasta, overwrite,
            show_progress=_progress_available(),
        )
    except (MissingLocalFile, MissingGenomeDataFile, MissingGenomeFastaError) as error:
        # Missing remote cache entries are converted to the narrow
        # MissingGenomeDataFile type by DownloadCache. Parser,
        # integrity and database failures keep their tracebacks.
        message = ("file not found: %s" % error.path
                   if isinstance(error, MissingLocalFile) else str(error))
        raise InstallError(message) from error


def run(argv=None):
    """Command-line entry point (console script ``pyensembl``).

    Parameters
    ----------
    argv : list of str, optional
        Arguments after the program name; defaults to ``sys.argv[1:]``.
    """
    # When the shell asks for completions, this prints them and exits.
    argcomplete.autocomplete(parser)
    args = parser.parse_args(argv)
    configure_logging(verbose=args.verbose)
    try:
        validate_arguments(
            args.action, args.json, args.refresh, args.check_remote, args.release
        )
    except ValueError as error:
        parser.error(str(error))
    if args.action == "prune":
        try:
            print(run_prune(args.dry_run))
        except ValueError as error:
            parser.error(str(error))
        return
    if args.orphan_genome_fastas or args.dry_run:
        parser.error("--orphan-genome-fastas and --dry-run require prune")
    if (
        args.action in DELETE_ACTIONS
        and not args.release
        and not (args.gtf or args.transcript_fasta or args.protein_fasta or
                 (args.genome_fasta_path and args.annotation_name))
    ):
        parser.error("%s requires an explicit --release" % args.action)
    if args.action == "list":
        print(format_installed_genomes(check_genome_fasta=args.check_genome_fasta))
        return
    if args.action == "available":
        try:
            print(run_available(args))
        except ValueError as error:
            # Conflicting selectors are argument errors; failures while
            # reading release listings keep their tracebacks.
            if not selects_catalogue(args):
                raise
            parser.error(str(error))
        return

    try:
        genomes = collect_selected_genomes(args)
    except ValueError as error:
        parser.error(str(error))
    if len(genomes) == 0:
        logger.error("ERROR: No genomes selected!")
        parser.print_help()

    if args.action == "verify":
        try:
            require_ensembl_releases(genomes)
        except ValueError as error:
            parser.error(str(error))
        # Checksum and manifest errors keep their tracebacks.
        text, ok = run_verify(genomes, args.check_remote, args.json)
        print(text)
        if not ok:
            raise SystemExit(1)
    elif args.action == "inspect":
        print(inspect_genomes(genomes, args.check_genome_fasta, args.json))
    elif args.action in DELETE_ACTIONS:
        for genome in genomes:
            _delete_genome_files(genome, args.action)
    elif args.action == "install":
        from .dated_releases import UnpublishedDateError

        for genome in genomes:
            try:
                run_install(genome, args.only_genome_fasta, args.overwrite)
            except UnpublishedDateError as error:
                parser.error(str(error))
            except InstallError as error:
                parser.exit(1, "%s: error: %s\n" % (parser.prog, error))
    else:
        raise ValueError("Invalid action: %s" % args.action)
