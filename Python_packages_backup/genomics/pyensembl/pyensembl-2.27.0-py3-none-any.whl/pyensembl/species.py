# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from serializable import Serializable

from .ensembl_versions import (
    MAX_ENSEMBL_RELEASE,
    MAX_ENSEMBL_GENOMES_RELEASE,
    is_dated_release,
)

# TODO: replace Serializable with data class


class Species(Serializable):
    """
    Container for combined information about a species name, its synonyn names
    and which reference to use for this species in each Ensembl release.
    """

    # as species instances get created, they get registered in these
    # dictionaries
    _latin_names_to_species = {}
    _common_names_to_species = {}
    _reference_names_to_species = {}

    @classmethod
    def register(
        cls,
        latin_name,
        synonyms,
        reference_assemblies,
        division="vertebrates",
        ensembl_genomes=False,
        ensembl_names=None,
        dated_releases=None,
    ):
        """
        Create a Species object from the given arguments and enter into
        all the dicts used to look the species up by its fields.
        """
        species = Species(
            latin_name=latin_name,
            synonyms=synonyms,
            reference_assemblies=reference_assemblies,
            division=division,
            ensembl_genomes=ensembl_genomes,
            ensembl_names=ensembl_names,
            dated_releases=dated_releases,
        )
        cls._latin_names_to_species[species.latin_name] = species
        # Names Ensembl later published the species under also find it.
        for synonym in list(synonyms) + list(species.ensembl_names.values()):
            if synonym in cls._common_names_to_species:
                raise ValueError(
                    "Can't use synonym '%s' for both %s and %s"
                    % (synonym, species, cls._common_names_to_species[synonym])
                )
            cls._common_names_to_species[synonym] = species
        for reference_name in reference_assemblies:
            if reference_name in cls._reference_names_to_species:
                raise ValueError(
                    "Can't use reference '%s' for both %s and %s"
                    % (
                        reference_name,
                        species,
                        cls._reference_names_to_species[reference_name],
                    )
                )
            cls._reference_names_to_species[reference_name] = species
        return species

    @classmethod
    def all_registered_latin_names(cls):
        """
        Returns latin name of every registered species.
        """
        return list(cls._latin_names_to_species.keys())

    @classmethod
    def all_species_release_pairs(cls):
        """
        Generator which yields (species, release) pairs
        for all possible combinations.
        """
        for species_name in cls.all_registered_latin_names():
            species = cls._latin_names_to_species[species_name]
            for _, release_range in species.reference_assemblies.items():
                for release in range(release_range[0], release_range[1] + 1):
                    yield species_name, release

    VALID_DIVISIONS = frozenset(
        {"vertebrates", "plants", "fungi", "metazoa", "protists", "bacteria"}
    )

    def __init__(
        self,
        latin_name,
        synonyms=[],
        reference_assemblies={},
        division="vertebrates",
        ensembl_genomes=False,
        ensembl_names=None,
        dated_releases=None,
    ):
        """
        Parameters
        ----------
        latin_name : str

        synonyms : list of strings

        reference_assemblies : dict
            Mapping of names of reference genomes onto inclusive ranges of
            Ensembl releases Example: {"GRCh37": (54, 75)}

        division : str
            Ensembl division this species belongs to. One of
            ``"vertebrates"``, ``"plants"``, ``"fungi"``, ``"metazoa"``,
            ``"protists"``, ``"bacteria"``. Defaults to ``"vertebrates"``.

        ensembl_genomes : bool
            If True, the species' annotation and FASTA files live on the
            Ensembl Genomes server (``ftp.ensemblgenomes.ebi.ac.uk``) under
            the ``/{division}/...`` subtree, with their own release
            numbering (1..MAX_ENSEMBL_GENOMES_RELEASE). If False (default)
            the species is served from the main Ensembl FTP at
            ``ftp.ensembl.org``.

        ensembl_names : dict, optional
            Names Ensembl publishes the species under from a given release on,
            when it renamed it, e.g. {100: "canis_lupus_familiaris"}.

        dated_releases : tuple of (str, str), optional
            Assembly accession and provider under which the new Ensembl
            platform publishes dated releases (e.g. "2026_04") of the
            assembly of the last numbered release, e.g.
            ("GCA_000001405.29", "ensembl").
        """
        if division not in self.VALID_DIVISIONS:
            raise ValueError(
                "Invalid division %r for %s; must be one of %s"
                % (division, latin_name, sorted(self.VALID_DIVISIONS))
            )
        self.latin_name = latin_name.lower().replace(" ", "_")
        self.synonyms = synonyms
        self.reference_assemblies = reference_assemblies
        self.division = division
        self.ensembl_genomes = ensembl_genomes
        self.ensembl_names = dict(ensembl_names or {})
        self.dated_releases = tuple(dated_releases) if dated_releases else None
        self._release_to_genome = {}
        for genome_name, (start, end) in self.reference_assemblies.items():
            for i in range(start, end + 1):
                if i in self._release_to_genome:
                    raise ValueError(
                        "Ensembl release %d for %s already has an associated genome"
                        % (i, latin_name)
                    )
                self._release_to_genome[i] = genome_name

    def ensembl_name(self, release):
        """The name of this species' directories and files in an Ensembl release."""
        name = self.latin_name
        for first_release, renamed in sorted(self.ensembl_names.items()):
            if release >= first_release:
                name = renamed
        return name

    @property
    def is_plant(self):
        return self.division == "plants"

    @property
    def is_fungus(self):
        return self.division == "fungi"

    @property
    def is_vertebrate(self):
        return self.division == "vertebrates"

    @property
    def is_invertebrate(self):
        return self.division == "metazoa"

    @property
    def is_animal(self):
        return self.division in ("vertebrates", "metazoa")

    @property
    def is_protist(self):
        return self.division == "protists"

    @property
    def is_bacterium(self):
        return self.division == "bacteria"

    @property
    def current_reference_name(self):
        """Assembly of the last numbered release, which dated releases annotate."""
        return max(
            self.reference_assemblies,
            key=lambda name: self.reference_assemblies[name][1],
        )

    def which_reference(self, ensembl_release):
        if is_dated_release(ensembl_release):
            if self.dated_releases is None:
                raise ValueError(
                    "No dated Ensembl releases for %s" % (self.latin_name,)
                )
            return self.current_reference_name
        if ensembl_release not in self._release_to_genome:
            raise ValueError(
                "No genome for %s in Ensembl release %s"
                % (self.latin_name, ensembl_release)
            )
        return self._release_to_genome[ensembl_release]

    def __str__(self):
        return "Species(latin_name='%s', synonyms=%s, reference_assemblies=%s)" % (
            self.latin_name,
            self.synonyms,
            self.reference_assemblies,
        )

    def __eq__(self, other):
        return (
            type(self) is type(other)
            and self.latin_name == other.latin_name
            and self.synonyms == other.synonyms
            and self.reference_assemblies == other.reference_assemblies
            and self.division == other.division
            and self.ensembl_genomes == other.ensembl_genomes
            and self.ensembl_names == other.ensembl_names
            and self.dated_releases == other.dated_releases
        )

    def to_dict(self):
        return {"latin_name": self.latin_name}

    @classmethod
    def from_dict(cls, state_dict):
        return cls._latin_names_to_species[state_dict["latin_name"]]

    def __hash__(self):
        return hash(
            (
                self.latin_name,
                tuple(self.synonyms),
                frozenset(self.reference_assemblies.items()),
                self.division,
                self.ensembl_genomes,
                frozenset(self.ensembl_names.items()),
                self.dated_releases,
            )
        )


def normalize_species_name(name):
    """
    If species name was "Homo sapiens" then replace spaces with underscores
    and return "homo_sapiens". Also replace common names like "human" with
    "homo_sapiens".
    """
    lower_name = name.lower().strip()

    # if given a common name such as "human", look up its latin equivalent
    for candidate in (lower_name, lower_name.replace(" ", "_")):
        if candidate in Species._common_names_to_species:
            return Species._common_names_to_species[candidate].latin_name

    return lower_name.replace(" ", "_")


def find_species_by_name(species_name):
    latin_name = normalize_species_name(species_name)
    if latin_name not in Species._latin_names_to_species:
        raise ValueError(
            "Species not found: %s, for non-Ensembl data see https://github.com/openvax/pyensembl#non-ensembl-data"
            % (species_name,)
        )
    return Species._latin_names_to_species[latin_name]


def check_species_object(species_name_or_object):
    """
    Helper for validating user supplied species names or objects.
    """
    if isinstance(species_name_or_object, Species):
        return species_name_or_object
    elif isinstance(species_name_or_object, str):
        return find_species_by_name(species_name_or_object)
    else:
        raise ValueError(
            "Unexpected type for species: %s : %s"
            % (species_name_or_object, type(species_name_or_object))
        )


human = Species.register(
    latin_name="homo_sapiens",
    synonyms=["human"],
    reference_assemblies={
        "GRCh38": (76, MAX_ENSEMBL_RELEASE),
        "GRCh37": (55, 75),
        "NCBI36": (54, 54),
    },
    dated_releases=("GCA_000001405.29", "ensembl"),
)

mouse = Species.register(
    latin_name="mus_musculus",
    synonyms=["mouse", "house mouse"],
    reference_assemblies={
        "NCBIM37": (54, 67),
        "GRCm38": (68, 102),
        "GRCm39": (103, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_000001635.9", "ensembl"),
)

dog = Species.register(
    latin_name="canis_familiaris",
    synonyms=["dog"],
    reference_assemblies={
        "CanFam3.1": (75, 104),
        "ROS_Cfam_1.0": (105, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_014441545.1", "ensembl"),
    ensembl_names={100: "canis_lupus_familiaris"},
)

# Other dog genomes Ensembl publishes, with ranges checked against its
# archive (the dingo from release 95; breed assemblies from 99-107).
dingo = Species.register(
    latin_name="canis_lupus_dingo",
    synonyms=["dingo"],
    reference_assemblies={"ASM325472v1": (95, MAX_ENSEMBL_RELEASE)},
    dated_releases=("GCA_003254725.1", "ensembl"),
)

dog_basenji = Species.register(
    latin_name="canis_lupus_familiarisbasenji",
    synonyms=["dog_basenji", "basenji"],
    reference_assemblies={"Basenji_breed-1.1": (99, MAX_ENSEMBL_RELEASE)},
    dated_releases=("GCA_004886185.1", "ensembl"),
)

dog_great_dane = Species.register(
    latin_name="canis_lupus_familiarisgreatdane",
    synonyms=["dog_great_dane", "great_dane"],
    reference_assemblies={"UMICH_Zoey_3.1": (99, MAX_ENSEMBL_RELEASE)},
    dated_releases=("GCA_005444595.1", "ensembl"),
)

dog_boxer = Species.register(
    latin_name="canis_lupus_familiarisboxer",
    synonyms=["dog_boxer", "boxer"],
    reference_assemblies={"Dog10K_Boxer_Tasha": (105, MAX_ENSEMBL_RELEASE)},
    dated_releases=("GCA_000002285.4", "ensembl"),
)

dog_german_shepherd = Species.register(
    latin_name="canis_lupus_familiarisgsd",
    synonyms=["dog_german_shepherd", "german_shepherd"],
    reference_assemblies={"UU_Cfam_GSD_1.0": (107, MAX_ENSEMBL_RELEASE)},
    dated_releases=("GCA_011100685.1", "ensembl"),
)

cat = Species.register(
    latin_name="felis_catus",
    synonyms=["cat"],
    reference_assemblies={
        "Felis_catus_6.2": (75, 90),
        "Felis_catus_8.0": (91, 92),
        "Felis_catus_9.0": (93, 113),
        "F.catus_Fca126_mat1.0": (114, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_018350175.1", "ensembl"),
)

chicken = Species.register(
    latin_name="gallus_gallus",
    synonyms=["chicken"],
    reference_assemblies={
        "Galgal4": (75, 85),
        "Gallus_gallus-5.0": (86, 94),
        "GRCg6a": (95, 106),
        "bGalGal1.mat.broiler.GRCg7b": (107, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_016699485.1", "ensembl"),
)

# Does the black rat (Rattus Rattus) get used for research too?
brown_rat = Species.register(
    latin_name="rattus_norvegicus",
    synonyms=["brown rat", "lab rat", "rat"],
    reference_assemblies={
        "Rnor_5.0": (75, 79),
        "Rnor_6.0": (80, 104),
        "mRatBN7.2": (105, 113),
        "GRCr8": (114, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_036323735.1", "ensembl"),
)

macaque = Species.register(
    latin_name="macaca_fascicularis",
    synonyms=["macaque", "Crab-eating macaque"],
    reference_assemblies={
        "Macaca_fascicularis_6.0": (103, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_011100615.1", "ensembl"),
)

green_monkey = Species.register(
    latin_name="chlorocebus_sabaeus",
    synonyms=["green_monkey", "african_green_monkey"],
    reference_assemblies={
        "ChlSab1.1": (86, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_000409795.2", "ensembl"),
)

rhesus = Species.register(
    latin_name="macaca_mulatta",
    synonyms=["rhesus"],
    reference_assemblies={
        "MMUL_1": (75, 85),
        "Mmul_8.0.1": (86, 97),
        "Mmul_10": (98, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_003339765.3", "ensembl"),
)

rabbit = Species.register(
    latin_name="oryctolagus_cuniculus",
    synonyms=["rabbit"],
    reference_assemblies={"OryCun2.0": (75, MAX_ENSEMBL_RELEASE)},
    dated_releases=("GCA_000003625.1", "ensembl"),
)

gerbil = Species.register(
    latin_name="meriones_unguiculatus",
    synonyms=["gerbil"],
    reference_assemblies={"MunDraft-v1.0": (96, MAX_ENSEMBL_RELEASE)},
    dated_releases=("GCA_002204375.1", "ensembl"),
)

syrian_hamster = Species.register(
    latin_name="mesocricetus_auratus",
    synonyms=["syrian_hamster"],
    reference_assemblies={"MesAur1.0": (90, MAX_ENSEMBL_RELEASE)},
    dated_releases=("GCA_000349665.1", "ensembl"),
)

chinese_hamster = Species.register(
    latin_name="cricetulus_griseus_chok1gshd",
    synonyms=["chinese_hamster"],
    reference_assemblies={"CHOK1GS_HDv1": (90, MAX_ENSEMBL_RELEASE)},
    dated_releases=("GCA_900186095.1", "community"),
)

naked_mole_rat = Species.register(
    latin_name="heterocephalus_glaber_female",
    synonyms=["naked_mole_rat"],
    reference_assemblies={
        "HetGla_female_1.0": (90, 109),
        "Naked_mole-rat_maternal": (110, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_944319715.1", "ensembl"),
)

guinea_pig = Species.register(
    latin_name="cavia_porcellus",
    synonyms=["guinea_pig"],
    reference_assemblies={
        "cavPor3": (75, 89),
        "Cavpor3.0": (90, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_000151735.1", "ensembl"),
)

pig = Species.register(
    latin_name="sus_scrofa",
    synonyms=["pig"],
    reference_assemblies={
        "Sscrofa10.2": (75, 89),
        "Sscrofa11.1": (90, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_000003025.6", "ensembl"),
)

zebrafish = Species.register(
    latin_name="danio_rerio",
    synonyms=["zebrafish"],
    reference_assemblies={
        "ZFISH7": (48, 53),
        "Zv8": (54, 59),
        "Zv9": (60, 79),
        "GRCz10": (80, 91),
        "GRCz11": (92, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_000002035.4", "ensembl"),
)

xenopus = Species.register(
    latin_name="xenopus_tropicalis",
    synonyms=["xenopus", "western_clawed_frog", "tropical_clawed_frog"],
    reference_assemblies={
        "Xenopus_tropicalis_v9.1": (98, 106),
        "UCB_Xtro_10.0": (107, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_000004195.4", "ensembl"),
)

fly = Species.register(
    latin_name="drosophila_melanogaster",
    synonyms=["drosophila", "fruit fly", "fly"],
    reference_assemblies={
        "BDGP5": (75, 78),
        "BDGP6": (79, 95),
        "BDGP6.22": (96, 98),
        "BDGP6.28": (99, 102),
        # Release 110 also offers BDGP6.46; keep existing 110 installs valid.
        "BDGP6.32": (103, 110),
        "BDGP6.46": (111, 113),
        "BDGP6.54": (114, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_000001215.4", "flybase"),
    division="metazoa",
)

nematode = Species.register(
    latin_name="caenorhabditis_elegans",
    synonyms=["nematode", "C_elegans"],
    reference_assemblies={
        "WS180": (48, 49),
        "WS190": (50, 54),
        "WS200": (55, 57),
        "WS210": (58, 60),
        "WS220": (61, 66),
        "WBcel215": (67, 70),
        "WBcel235": (71, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_000002985.3", "wormbase"),
    division="metazoa",
)

yeast = Species.register(
    latin_name="saccharomyces_cerevisiae",
    synonyms=["yeast", "budding_yeast"],
    reference_assemblies={
        "R64-1-1": (76, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_000146045.2", "community"),
    division="fungi",
)

arabidopsis_thaliana = Species.register(
    latin_name="arabidopsis_thaliana",
    synonyms=["arabidopsis"],
    reference_assemblies={
        "TAIR10": (40, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    dated_releases=("GCA_000001735.1", "community_araport11"),
    division="plants",
    ensembl_genomes=True,
)

rice = Species.register(
    latin_name="oryza_sativa",
    synonyms=["rice"],
    reference_assemblies={
        "IRGSP-1.0": (40, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    dated_releases=("GCA_001433935.1", "community_rapdb"),
    division="plants",
    ensembl_genomes=True,
)

# Additional Ensembl Genomes species (issue #298).
# Release ranges use the conservative lower bound 40 to match the existing
# plants entries; older releases at this assembly version may 404.

wheat = Species.register(
    latin_name="triticum_aestivum",
    synonyms=["wheat", "bread_wheat"],
    reference_assemblies={
        "IWGSC": (40, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    dated_releases=("GCA_900519105.1", "community_iwgsc"),
    division="plants",
    ensembl_genomes=True,
)

maize = Species.register(
    latin_name="zea_mays",
    synonyms=["maize", "corn"],
    reference_assemblies={
        # Zm-B73-REFERENCE-NAM-5.0 was introduced at Ensembl Plants release
        # 54; earlier releases used a different assembly and returned 404
        # for this asset.
        "Zm-B73-REFERENCE-NAM-5.0": (54, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    dated_releases=("GCA_902167145.1", "community_cshl"),
    division="plants",
    ensembl_genomes=True,
)

tomato = Species.register(
    latin_name="solanum_lycopersicum",
    synonyms=["tomato"],
    reference_assemblies={
        # Ensembl Genomes 63 removed SL3.0.
        "SL3.0": (42, 62),
    },
    dated_releases=("GCA_000188115.3", "community_sol"),
    division="plants",
    ensembl_genomes=True,
)

soybean = Species.register(
    latin_name="glycine_max",
    synonyms=["soybean", "soya_bean"],
    reference_assemblies={
        "Glycine_max_v2.1": (43, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    dated_releases=("GCA_000004515.4", "community_jgi"),
    division="plants",
    ensembl_genomes=True,
)

fission_yeast = Species.register(
    latin_name="schizosaccharomyces_pombe",
    synonyms=["fission_yeast", "pombe"],
    reference_assemblies={
        "ASM294v2": (40, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    dated_releases=("GCA_000002945.2", "community"),
    division="fungi",
    ensembl_genomes=True,
)

aspergillus_nidulans = Species.register(
    latin_name="aspergillus_nidulans",
    synonyms=["aspergillus"],
    reference_assemblies={
        "ASM1142v1": (40, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    dated_releases=("GCA_000011425.1", "refseq"),
    division="fungi",
    ensembl_genomes=True,
)

candida_albicans = Species.register(
    latin_name="candida_albicans",
    synonyms=["candida"],
    reference_assemblies={
        "GCA000182965v3": (52, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    dated_releases=("GCA_000182965.3", "community"),
    division="fungi",
    ensembl_genomes=True,
)

anopheles_gambiae = Species.register(
    latin_name="anopheles_gambiae",
    synonyms=["mosquito", "malaria_mosquito"],
    reference_assemblies={
        "AgamP4": (40, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    dated_releases=("GCA_000005575.1", "veupathdb"),
    division="metazoa",
    ensembl_genomes=True,
)

plasmodium_falciparum = Species.register(
    latin_name="plasmodium_falciparum",
    synonyms=["plasmodium", "malaria_parasite"],
    reference_assemblies={
        "EPr1": (40, 44),
        "ASM276v2": (45, 60),
        "GCA000002765v3": (61, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    dated_releases=("GCA_000002765.3", "community"),
    division="protists",
    ensembl_genomes=True,
)

toxoplasma_gondii = Species.register(
    latin_name="toxoplasma_gondii",
    synonyms=["toxoplasma"],
    reference_assemblies={
        "TGA4": (40, 60),
        "GCA000006565v2": (61, MAX_ENSEMBL_GENOMES_RELEASE),
    },
    division="protists",
    ensembl_genomes=True,
)

# Mouse strain GTFs in releases 87-91 kept release 86's filenames, so
# supported releases start at 92.
#BALB/c
mus_musculus_balbc = Species.register(
    latin_name='mus_musculus_balbcj',
    synonyms=['mus_balbc', 'BALB/c'],
    reference_assemblies = {
        'BALB_cJ_v1':(92, 113),
        'BALB_cJ_v3':(114, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_921997145.2", "ensembl"),
)
#129
mus_musculus_129 = Species.register(
    latin_name='mus_musculus_129s1svimj',
    synonyms=['mus_129', '129'],
    reference_assemblies = {
        '129S1_SvImJ_v1':(92, 113),
        '129S1_SvImJ_v3':(114, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_921998555.2", "ensembl"),
)
#FVB
mus_musculus_fvb = Species.register(
    latin_name='mus_musculus_fvbnj',
    synonyms=['mus_fvb', 'FVB'],
    reference_assemblies = {
        'FVB_NJ_v1':(92, 113),
        'FVB_NJ_v3':(114, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_921998635.2", "ensembl"),
)
#NOD
mus_musculus_nod = Species.register(
    latin_name='mus_musculus_nodshiltj',
    synonyms=['mus_nod', 'NOD'],
    reference_assemblies = {
        'NOD_ShiLtJ_v1':(92, 113),
        'NOD_ShiLtJ_v3':(114, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_921998325.2", "ensembl"),
)
#6NJ
mus_musculus_c57bl6nj = Species.register(
    latin_name='mus_musculus_c57bl6nj',
    synonyms=['mus_6nj', '6NJ'],
    reference_assemblies = {
        'C57BL_6NJ_v1':(92, 113),
        'C57BL_6NJ_v3':(114, MAX_ENSEMBL_RELEASE),
    },
    dated_releases=("GCA_921999865.2", "ensembl"),
)
