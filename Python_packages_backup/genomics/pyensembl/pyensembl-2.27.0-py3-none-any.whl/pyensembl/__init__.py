# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging

from .database import Database
from .dated_releases import (
    UnpublishedDateError,
    available_annotation_dates,
    available_dated_releases,
)
from .download_cache import DownloadCache
from .ensembl_annotation import EnsemblAnnotation
from .ensembl_release import EnsemblRelease, cached_release
from .ensembl_versions import MAX_ENSEMBL_RELEASE
from .exon import Exon
from .genome import Genome
from .genome_fasta import MissingGenomeFastaError
from .genome_fasta_cache import prune_genome_fastas
from .gene import Gene
from .gene_name_aliases import GeneNameAliases
from .locus import Locus
from .reference_name import (
    ensembl_grch36,
    ensembl_grch37,
    ensembl_grch38,
    normalize_reference_name,
    find_species_by_reference,
    which_reference,
    genome_for_reference_name,
)

from .protein import Protein
from .search import find_nearest_locus
from .sequence_data import SequenceData
from .species import find_species_by_name, check_species_object, normalize_species_name
from .transcript import Transcript
from .version import __version__

# Per the Python logging HOWTO ("Configuring Logging for a Library"), attach a
# no-op handler to the package logger so that library usage neither emits log
# output nor triggers "No handlers could be found" warnings, while leaving the
# root logger and any application-configured loggers untouched.
logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = [
    "__version__",
    "available_annotation_dates",
    "available_dated_releases",
    "UnpublishedDateError",
    "DownloadCache",
    "Database",
    "EnsemblAnnotation",
    "EnsemblRelease",
    "cached_release",
    "MAX_ENSEMBL_RELEASE",
    "Gene",
    "GeneNameAliases",
    "Transcript",
    "Protein",
    "Exon",
    "SequenceData",
    "find_nearest_locus",
    "find_species_by_name",
    "find_species_by_reference",
    "genome_for_reference_name",
    "which_reference",
    "check_species_object",
    "normalize_reference_name",
    "normalize_species_name",
    "Genome",
    "MissingGenomeFastaError",
    "prune_genome_fastas",
    "Locus",
    "Exon",
    "ensembl_grch36",
    "ensembl_grch37",
    "ensembl_grch38",
]
