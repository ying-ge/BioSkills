
# THIS FILE IS GENERATED FROM SETUP.PY
version = '0.12.0'
__version__ = version