import os

import anndata
import numpy as np
import pandas as pd

from scvi.data._built_in_data._dataset_10x import _load_dataset_10x
from scvi.data._download import _download


def _load_purified_pbmc_dataset(
    save_path: str = "data/",
    subset_datasets: list[str] = None,
) -> anndata.AnnData:
    url = "https://exampledata.scverse.org/scvi-tools/PurifiedPBMCDataset.h5ad"
    save_fn = "PurifiedPBMCDataset.h5ad"
    _download(url, save_path, save_fn)
    path_to_file = os.path.join(save_path, save_fn)
    adata = anndata.read_h5ad(path_to_file)

    dataset_names = [
        "cd4_t_helper",
        "regulatory_t",
        "naive_t",
        "memory_t",
        "cytotoxic_t",
        "naive_cytotoxic",
        "b_cells",
        "cd34",
        "cd56_nk",
        "cd14_monocytes",
    ]
    # the raw file has 11 batches but only 10 unique cell types: batch "7" is a byte-for-byte
    # duplicate of batch "0" (both "cd4_t_helper"), from a copy-paste bug in the original scVI
    adata = adata[adata.obs["batch"].astype(str) != "7"].copy()
    if subset_datasets is not None:
        row_indices = []
        for dataset in subset_datasets:
            assert dataset in dataset_names
            idx = np.where(adata.obs["cell_types"] == dataset)[0]
            row_indices.append(idx)
        row_indices = np.concatenate(row_indices)
        adata = adata[row_indices].copy()

    return adata


def _load_pbmc_dataset(
    save_path: str = "data/",
    remove_extracted_data: bool = True,
) -> anndata.AnnData:
    urls = [
        "https://github.com/YosefLab/scVI-data/raw/master/gene_info.csv",
        "https://github.com/YosefLab/scVI-data/raw/master/pbmc_metadata.pickle",
    ]
    save_fns = ["gene_info_pbmc.csv", "pbmc_metadata.pickle"]

    for i in range(len(urls)):
        _download(urls[i], save_path, save_fns[i])

    de_metadata = pd.read_csv(os.path.join(save_path, "gene_info_pbmc.csv"), sep=",")
    pbmc_metadata = pd.read_pickle(os.path.join(save_path, "pbmc_metadata.pickle"))
    pbmc8k = _load_dataset_10x(
        "pbmc8k",
        save_path=save_path,
        var_names="gene_ids",
        remove_extracted_data=remove_extracted_data,
    )
    pbmc4k = _load_dataset_10x(
        "pbmc4k",
        save_path=save_path,
        var_names="gene_ids",
        remove_extracted_data=remove_extracted_data,
    )
    # 51 barcodes occur in both runs (unrelated cells); pbmc_metadata.pickle renames the
    # pbmc4k copy "-1" -> "-11", so do the same here before joining on barcode
    in_8k = set(pbmc8k.obs_names)
    pbmc4k.obs_names = [b + "1" if b in in_8k else b for b in pbmc4k.obs_names]
    barcodes = np.concatenate((pbmc8k.obs_names, pbmc4k.obs_names))

    adata = anndata.concat([pbmc8k, pbmc4k], keys=["0", "1"], label="batch")
    adata.obs_names = barcodes

    dict_barcodes = dict(zip(barcodes, np.arange(len(barcodes)), strict=True))
    barcodes_metadata = pbmc_metadata["barcodes"].index.values.ravel().astype(str)
    subset_cells = [dict_barcodes[barcode] for barcode in barcodes_metadata]
    adata = adata[np.asarray(subset_cells), :].copy()
    genes_to_keep = list(
        de_metadata["ENSG"].values
    )  # only keep the genes for which we have de data
    difference = list(
        set(genes_to_keep).difference(set(adata.var_names))
    )  # Non empty only for unit tests
    for gene in difference:
        genes_to_keep.remove(gene)

    adata = adata[:, genes_to_keep].copy()
    design = pbmc_metadata["design"]
    raw_qc = pbmc_metadata["raw_qc"]
    normalized_qc = pbmc_metadata["normalized_qc"]

    design.index = adata.obs_names
    raw_qc.index = adata.obs_names
    normalized_qc.index = adata.obs_names
    adata.obs["batch"] = adata.obs["batch"].astype(np.int64)
    adata.obsm["design"] = design
    adata.obsm["raw_qc"] = raw_qc
    adata.obsm["normalized_qc"] = normalized_qc

    adata.obsm["qc_pc"] = pbmc_metadata["qc_pc"]
    labels = pbmc_metadata["clusters"]
    cell_types = pbmc_metadata["list_clusters"]
    adata.obs["labels"] = labels
    adata.uns["cell_types"] = cell_types
    adata.obs["str_labels"] = [cell_types[i] for i in labels]

    adata.var["n_counts"] = np.squeeze(np.asarray(np.sum(adata.X, axis=0)))

    return adata
