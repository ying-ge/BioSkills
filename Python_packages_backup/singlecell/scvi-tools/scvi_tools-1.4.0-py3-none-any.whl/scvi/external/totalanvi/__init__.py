from ._model import TOTALANVI

__all__ = ["TOTALANVI"]
