import warnings

from scvi import settings
from scvi.utils import error_on_missing_dependencies

from . import utils
from ._amortizedlda import AmortizedLDA
from ._autozi import AUTOZI
from ._condscvi import CondSCVI
from ._destvi import DestVI
from ._linear_scvi import LinearSCVI
from ._multivi import MULTIVI
from ._peakvi import PEAKVI
from ._scanvi import SCANVI
from ._scvi import SCVI
from ._totalvi import TOTALVI
from ._utils import get_max_epochs_heuristic

__all__ = [
    "SCVI",
    "TOTALVI",
    "LinearSCVI",
    "AUTOZI",
    "SCANVI",
    "PEAKVI",
    "CondSCVI",
    "DestVI",
    "MULTIVI",
    "AmortizedLDA",
    "utils",
    "get_max_epochs_heuristic",
]


def __getattr__(name: str):
    """Lazily provide object. If optional deps are missing, raise a helpful ImportError

    only when object is actually requested.
    """
    if name == "mlxSCVI":
        warnings.warn(
            "In order to use the MLX version of SCVI make sure to install mlx",
            DeprecationWarning,
            stacklevel=settings.warnings_stacklevel,
        )

        error_on_missing_dependencies("mlx")
        from ._mlxscvi import mlxSCVI as _mlxSCVI

        return _mlxSCVI
    raise AttributeError(f"module {__name__!r} has no attribute {name}")
