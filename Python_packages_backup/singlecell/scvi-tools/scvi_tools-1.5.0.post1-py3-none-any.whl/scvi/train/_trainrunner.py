from __future__ import annotations

import gc
import logging
import os
import pickle
import traceback
import warnings
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd
import torch

from scvi import settings
from scvi.model._utils import parse_device_args
from scvi.train import Trainer
from scvi.train._config import merge_kwargs
from scvi.utils import is_package_installed, mlflow_logger

if TYPE_CHECKING:
    import lightning.pytorch as pl

    from scvi.dataloaders import DataSplitter, SemiSupervisedDataSplitter
    from scvi.model.base import BaseModelClass
    from scvi.train._config import KwargsLike

logger = logging.getLogger(__name__)


def _safe_load_logger_history(trainer):
    hist = getattr(trainer.logger, "history", None)
    if hist:
        return {k: v.copy() for k, v in hist.items()}  # deep copy from memory
    history_path = getattr(trainer.logger, "history_path", None)  #  file (written by rank-0)
    if history_path and os.path.exists(history_path):
        with open(history_path, "rb") as f:
            return pickle.load(f)
    return None


class TrainRunner:
    """TrainRunner calls Trainer.fit() and handles pre and post training procedures.

    Parameters
    ----------
    model
        model to train
    training_plan
        initialized TrainingPlan
    data_splitter
        initialized :class:`~scvi.dataloaders.SemiSupervisedDataSplitter` or
        :class:`~scvi.dataloaders.DataSplitter`
    max_epochs
        max_epochs to train for
    accelerator
        Supports passing different accelerator types ("cpu", "gpu", "tpu", "ipu", "hpu",
        "mps, "auto") as well as custom accelerator instances.
    devices
        The devices to use. Can be set to a positive number (int or str), a sequence of
        device indices (list or str), the value -1 to indicate all available devices should
        be used, or "auto" for automatic selection based on the chosen accelerator.
    trainer_config
        Configuration for :class:`~scvi.train.Trainer`. Values here are merged with
        ``trainer_kwargs``; explicitly passed ``trainer_kwargs`` take precedence.
    trainer_kwargs
        Extra kwargs for :class:`~scvi.train.Trainer`

    Examples
    --------
    >>> # The following code should be within a subclass of BaseModelClass
    >>> data_splitter = DataSplitter(self.adata)
    >>> training_plan = TrainingPlan(self.module, len(data_splitter.train_idx))
    >>> runner = TrainRunner(
    >>>     self,
    >>>     training_plan=trianing_plan,
    >>>     data_splitter=data_splitter,
    >>>     max_epochs=max_epochs)
    >>> runner()
    """

    _trainer_cls = Trainer

    def __init__(
        self,
        model: BaseModelClass,
        training_plan: pl.LightningModule,
        data_splitter: SemiSupervisedDataSplitter | DataSplitter,
        max_epochs: int,
        accelerator: str = "auto",
        devices: int | list[int] | str = "auto",
        trainer_config: KwargsLike | None = None,
        **trainer_kwargs,
    ):
        self.training_plan = training_plan
        self.data_splitter = data_splitter
        self.model = model
        accelerator, lightning_devices, device = parse_device_args(
            accelerator=accelerator,
            devices=devices,
            return_device="torch",
        )
        self.accelerator = accelerator
        self.lightning_devices = lightning_devices
        self.device = device

        trainer_kwargs = merge_kwargs(trainer_config, trainer_kwargs, name="trainer")
        if getattr(self.training_plan, "reduce_lr_on_plateau", False):
            trainer_kwargs["learning_rate_monitor"] = True
        ckpt_path = trainer_kwargs.pop("ckpt_path", None)
        self.ckpt_path = ckpt_path
        trainer_kwargs.pop("max_epochs", None)
        trainer_kwargs.pop("accelerator", None)
        trainer_kwargs.pop("devices", None)

        self.trainer = self._trainer_cls(
            max_epochs=max_epochs,
            accelerator=accelerator,
            devices=lightning_devices,
            **trainer_kwargs,
        )

        # Sanity checks for usage of early Stopping
        if self.trainer.early_stopping_callback is not None:
            if type(data_splitter).__name__ == "DataSplitter":
                # for other data splitter need to think on something else...
                if (data_splitter.n_val == 0) and (
                    "valid" in self.trainer.early_stopping_callback.monitor
                ):
                    raise ValueError(
                        "Can't run Early Stopping with validation monitor with no validation set"
                    )
                if (model.adata.n_obs - data_splitter.n_train - data_splitter.n_val) and (
                    "test" in self.trainer.early_stopping_callback.monitor
                ):
                    raise ValueError("Can't run Early Stopping with test monitor with no test set")

        self.trainer._model = model  # needed to savecheckpoint callback

    def _run_training_core(self):
        # training without mlflow
        try:
            self.trainer.fit(self.training_plan, self.data_splitter, ckpt_path=self.ckpt_path)
        except BaseException as e:
            self._update_history()
            print("Exception raised during training.", NameError, e)
            gc.collect()

            if torch.cuda.is_available():
                torch.cuda.empty_cache()

            # Clean up XLA/TPU memory if using TPU
            if self.accelerator == "tpu" and is_package_installed("torch_xla"):
                import torch_xla.core.xla_model as xm

                xm.mark_step()  # Ensure all operations are completed

            raise
        self._update_history()

        # data splitter only gets these attrs after fit
        self.model.train_indices = getattr(self.data_splitter, "train_idx", None)
        self.model.test_indices = getattr(self.data_splitter, "test_idx", None)
        self.model.validation_indices = getattr(self.data_splitter, "val_idx", None)

        self.model.module.eval()
        self.model.is_trained_ = True
        self.model.to_device(self.device)
        self.model.trainer = self.trainer

        return

    def __call__(self):
        """Run training."""
        if hasattr(self.data_splitter, "n_train"):
            self.training_plan.n_obs_training = self.data_splitter.n_train
        if hasattr(self.data_splitter, "n_val"):
            self.training_plan.n_obs_validation = self.data_splitter.n_val

        if settings.mlflow_set_tracking_uri != "":
            if is_package_installed("mlflow"):
                import mlflow

                mlflow.set_tracking_uri(settings.mlflow_set_tracking_uri)
                mlflow.set_experiment(settings.mlflow_set_experiment)

                with mlflow.start_run(run_name=self.model.run_name, log_system_metrics=True):
                    try:
                        self._run_training_core()

                        self.model.run_id = mlflow.active_run().info.run_id

                        # log all relevant metrics
                        mlflow_logger(
                            model=self.model,
                            trainer=self.trainer,
                            training_plan=self.training_plan,
                            data_splitter=self.data_splitter,
                            run_id=self.model.run_id,
                        )

                        mlflow.set_tag("status", "success")

                    except Exception as e:
                        # Capture and log error
                        error_msg = "".join(
                            traceback.format_exception(type(e), e, e.__traceback__)
                        )
                        with open("error_log.txt", "w") as f:
                            f.write(error_msg)

                        mlflow.log_artifact("error_log.txt", artifact_path="errors")
                        mlflow.set_tag("status", "failed")
                        mlflow.log_param("error_type", type(e).__name__)
                        mlflow.log_param("error_message", str(e))
                        print(f"Error logged to MLflow: {e}")
                        raise
            else:
                raise ModuleNotFoundError("Please install mlflow to use this functionality.")
        else:
            # training without mlflow
            self._run_training_core()

    def _update_history(self):
        # only the global-zero process populates history from the logger;
        # non-zero ranks get an empty dict so that model.history is not None
        if not self.trainer.is_global_zero:
            if self.model.history_ is None:
                self.model.history_ = {}
            return

        # model is being further trained
        # this was set to true during the first training session
        if self.model.is_trained_ is True:
            # if not using the default logger (e.g., tensorboard)
            if not isinstance(self.model.history_, dict):
                warnings.warn(
                    "Training history cannot be updated. Logger can be accessed from "
                    "`model.trainer.logger`",
                    UserWarning,
                    stacklevel=settings.warnings_stacklevel,
                )
                return
            else:
                new_history = _safe_load_logger_history(self.trainer) or {}
                for key, val in self.model.history_.items():
                    # e.g., no validation loss due to training params
                    if key not in new_history:
                        continue
                    prev_len = len(val)
                    new_len = len(new_history[key])
                    index = np.arange(prev_len, prev_len + new_len)
                    new_history[key].index = index
                    self.model.history_[key] = pd.concat(
                        [
                            val,
                            new_history[key],
                        ]
                    )
                    self.model.history_[key].index.name = val.index.name
        else:
            # set history_ attribute if it exists
            # other pytorch lightning loggers might not have history attr
            try:
                # set model.history_ from persisted or in-memory logger now
                loaded = _safe_load_logger_history(self.trainer)
                self.model.history_ = loaded if loaded is not None else {}
            except AttributeError:
                self.history_ = None
