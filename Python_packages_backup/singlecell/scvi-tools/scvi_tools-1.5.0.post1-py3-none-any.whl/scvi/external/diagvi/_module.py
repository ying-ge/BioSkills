"""DIAGVAE module for multi-modal variational autoencoder."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical, Independent, MixtureSameFamily, kl_divergence

from scvi import REGISTRY_KEYS
from scvi.distributions import (
    Log1pNormal,
    NegativeBinomial,
    NegativeBinomialMixture,
    Normal,
    ZeroInflatedGamma,
    ZeroInflatedLogNormal,
    ZeroInflatedNegativeBinomial,
)
from scvi.module import Classifier
from scvi.module._constants import MODULE_KEYS
from scvi.module.base import BaseModuleClass, LossOutput, auto_move_data
from scvi.nn import Encoder

from ._base_components import DecoderDualPathway, DecoderSinglePathway, GraphEncoder

if TYPE_CHECKING:
    from torch_geometric.data import Data

logger = logging.getLogger(__name__)

# Decoder selection based on likelihood function
# Single-pathway: outputs (scale, r, rate, dropout)
# Dual-pathway: outputs ((scale1, scale2), r, (rate1, rate2), mixture_logits)
LIKELIHOOD_TO_DECODER = {
    # Single-pathway likelihoods (unimodal distributions)
    "nb": DecoderSinglePathway,
    "zinb": DecoderSinglePathway,
    "normal": DecoderSinglePathway,
    "log1pnormal": DecoderSinglePathway,
    "ziln": DecoderSinglePathway,
    "zig": DecoderSinglePathway,
    # Dual-pathway likelihoods (mixture distributions)
    "nbmixture": DecoderDualPathway,
}

# Likelihoods that require softmax normalization (count data)
NORMALIZE_LIKELIHOODS = {"nb", "zinb", "nbmixture"}
NON_NORMALIZE_LIKELIHOODS = {"log1pnormal", "ziln", "zig"}
OTHER_LIKELIHOODS = {"normal"}


class DIAGVAE(BaseModuleClass):
    """Variational autoencoder module for DIAGVI multi-modal integration.

    Supports GMM priors, semi-supervised classification, and flexible
    modality-specific decoders.

    Parameters
    ----------
    n_inputs
        Number of input features for each modality.
    n_batches
        Number of batches for each modality.
    n_labels
        Number of labels/classes for each modality.
    modality_likelihoods
        Likelihood model for each modality.
        One of: 'nb', 'zinb', 'normal', 'log1pnormal', 'zig', 'nbmixture'.
    normalize_lib
        Whether to normalize counts with library size in the model for each modality.
    guidance_graph
        Graph object encoding feature correspondences.
    use_gmm_prior
        Whether to use a GMM prior for each modality.
    semi_supervised
        Whether to use semi-supervised classification for each modality.
    n_mixture_components
        Number of mixture components for the GMM prior for each modality. If semi_supervised
        is True, this parameter is ignored and set to the number of unique labels in labels_key.
    n_latent
        Dimensionality of the latent space.
    n_hidden
        Number of nodes per hidden layer.
    n_layers
        Number of hidden layers.
    dropout_rate
        Dropout rate for encoders.
    """

    def __init__(
        self,
        n_inputs: dict[str, int],
        n_batches: dict[str, int],
        n_labels: dict[str, int],
        modality_likelihoods: dict[str, str],
        normalize_lib: dict[str, bool],
        guidance_graph: Data,
        use_gmm_prior: dict[str, bool],
        semi_supervised: dict[str, bool],
        n_mixture_components: dict[str, int],
        n_latent: int,
        n_hidden: int,
        n_layers: int,
        dropout_rate: float,
    ):
        super().__init__()

        # Learnable parameters
        self.gmm_logits = nn.ParameterDict()
        self.gmm_means = nn.ParameterDict()
        self.gmm_scales = nn.ParameterDict()

        # Model attributes
        self.use_gmm_prior = use_gmm_prior
        self.semi_supervised = semi_supervised
        self.n_mixture_components = n_mixture_components
        self.n_labels = n_labels
        self.n_input_list = n_inputs
        self.n_batches_list = n_batches
        self.modality_likelihoods = modality_likelihoods
        self.normalize_lib = normalize_lib
        self.guidance_graph = guidance_graph
        self.n_latent = n_latent

        self.input_names = list(n_inputs.keys())

        # GMM prior parameters
        for name in use_gmm_prior.keys():
            if self.use_gmm_prior[name]:
                k = self.n_mixture_components[name]
                # Overwrite the number of mixture components if semi_supervised = True
                if self.semi_supervised[name]:
                    k = self.n_labels[name]
                self.gmm_logits[name] = nn.Parameter(torch.zeros(k))
                self.gmm_means[name] = nn.Parameter(torch.randn(k, n_latent))
                self.gmm_scales[name] = nn.Parameter(torch.zeros(k, n_latent))

        # Encoders
        self.encoder_0 = Encoder(
            n_input=n_inputs[self.input_names[0]],
            n_output=n_latent,
            n_hidden=n_hidden,
            n_layers=n_layers,
            dropout_rate=dropout_rate,
            return_dist=True,
        )

        self.encoder_1 = Encoder(
            n_input=n_inputs[self.input_names[1]],
            n_output=n_latent,
            n_hidden=n_hidden,
            n_layers=n_layers,
            dropout_rate=dropout_rate,
            return_dist=True,
        )

        # Decoders - selected based on likelihood function
        likelihood_0 = modality_likelihoods[self.input_names[0]]
        likelihood_1 = modality_likelihoods[self.input_names[1]]

        # Determine decoder class based on likelihood
        decoder_class_0 = LIKELIHOOD_TO_DECODER.get(likelihood_0, DecoderSinglePathway)
        decoder_class_1 = LIKELIHOOD_TO_DECODER.get(likelihood_1, DecoderSinglePathway)

        # Determine whether to apply softmax normalization based on likelihood
        normalize_0 = likelihood_0 in NORMALIZE_LIKELIHOODS
        normalize_1 = likelihood_1 in NORMALIZE_LIKELIHOODS
        if likelihood_0 in OTHER_LIKELIHOODS:
            normalize_0 = normalize_lib[self.input_names[0]]
        if likelihood_1 in OTHER_LIKELIHOODS:
            normalize_1 = normalize_lib[self.input_names[1]]

        logger.debug(
            f"Decoder for '{self.input_names[0]}' (likelihood={likelihood_0}): "
            f"{decoder_class_0.__name__}, normalize={normalize_0}"
        )
        self.decoder_0 = decoder_class_0(
            n_output=n_inputs[self.input_names[0]],
            n_batches=n_batches[self.input_names[0]],
            normalize=normalize_0,
        )

        logger.debug(
            f"Decoder for '{self.input_names[1]}' (likelihood={likelihood_1}): "
            f"{decoder_class_1.__name__}, normalize={normalize_1}"
        )
        self.decoder_1 = decoder_class_1(
            n_output=n_inputs[self.input_names[1]],
            n_batches=n_batches[self.input_names[1]],
            normalize=normalize_1,
        )

        # Graph encoder
        self.graph_encoder = GraphEncoder(
            vnum=n_inputs[self.input_names[0]] + n_inputs[self.input_names[1]],
            out_features=self.n_latent,
        )

        # Classifiers for semi-supervised learning
        if self.semi_supervised[self.input_names[0]]:
            cls_parameters = {
                "n_layers": 0,
                "n_hidden": 128,
                "dropout_rate": 0.0,
            }
            self.classifier_0 = Classifier(
                n_latent,
                n_labels=self.n_labels[self.input_names[0]],
                use_batch_norm=False,
                use_layer_norm=True,
                **cls_parameters,
            )
        else:
            self.classifier_0 = None

        if self.semi_supervised[self.input_names[1]]:
            cls_parameters = {
                "n_layers": 0,
                "n_hidden": 128,
                "dropout_rate": 0.0,
            }
            self.classifier_1 = Classifier(
                n_latent,
                n_labels=self.n_labels[self.input_names[1]],
                use_batch_norm=False,
                use_layer_norm=True,
                **cls_parameters,
            )
        else:
            self.classifier_1 = None

    def _get_inference_input(
        self, tensors: dict[str, torch.Tensor]
    ) -> dict[str, torch.Tensor | None]:
        """Prepare input dictionary for the inference step."""
        return {
            MODULE_KEYS.X_KEY: tensors[REGISTRY_KEYS.X_KEY],
        }

    def _get_generative_input(
        self, tensors: dict[str, torch.Tensor], inference_outputs: dict[str, torch.Tensor]
    ) -> dict[str, torch.Tensor]:
        """Prepare input dictionary for the generative step."""
        return {
            MODULE_KEYS.Z_KEY: inference_outputs[MODULE_KEYS.Z_KEY],
            MODULE_KEYS.LIBRARY_KEY: inference_outputs[MODULE_KEYS.LIBRARY_KEY],
            MODULE_KEYS.BATCH_INDEX_KEY: tensors[REGISTRY_KEYS.BATCH_KEY],
            MODULE_KEYS.Y_KEY: tensors[REGISTRY_KEYS.LABELS_KEY],
            "v": inference_outputs["v"],
        }

    def encode_graph(
        self, device: torch.device
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Run the graph encoder, moving the guidance graph to device on first call.

        Parameters
        ----------
        device
            Target device.

        Returns
        -------
        Tuple of (v_all, mu_all, logvar_all) graph embeddings.
        """
        if self.guidance_graph.edge_index.device != device:
            self.guidance_graph = self.guidance_graph.to(device)
        return self.graph_encoder(self.guidance_graph.edge_index)

    @auto_move_data
    def inference(
        self,
        x: torch.Tensor,
        mode: str | None = None,
        v_all: torch.Tensor | None = None,
        mu_all: torch.Tensor | None = None,
        logvar_all: torch.Tensor | None = None,
        deterministic: bool = False,
    ) -> dict[str, torch.Tensor]:
        """Run the inference (encoder and graph) step for a given modality.

        Parameters
        ----------
        x
            Input data tensor.
        mode
            Name of the modality.
        v_all
            Pre-computed graph node embeddings. If None, computed from graph encoder.
        mu_all
            Pre-computed graph encoder means. Required when v_all is provided.
        logvar_all
            Pre-computed graph encoder log-variances. Required when v_all is provided.
        deterministic
            Whether to use the mean instead of a sample.

        Returns
        -------
        Dictionary of inference outputs, including latent variables and
        graph embeddings.
        """
        library = torch.log(x.sum(1)).unsqueeze(1)

        if v_all is None:
            v_all, mu_all, logvar_all = self.encode_graph(x.device)

        if deterministic:
            v_all = mu_all

        graph = self.guidance_graph
        v = v_all[getattr(graph, f"{mode}_indices")]
        other_mode = [m for m in self.input_names if m != mode][0]
        v_other_mod = v_all[getattr(graph, f"{other_mode}_indices")]

        # Data inference
        if mode == self.input_names[0]:
            qz, z = self.encoder_0(x)
        else:
            qz, z = self.encoder_1(x)

        if deterministic:
            z = qz.loc

        return {
            MODULE_KEYS.QZ_KEY: qz,
            MODULE_KEYS.Z_KEY: z,
            MODULE_KEYS.LIBRARY_KEY: library,
            "v": v,
            "v_other": v_other_mod,
            "v_all": v_all,
            "mu_all": mu_all,
            "logvar_all": logvar_all,
        }

    @auto_move_data
    def generative(
        self,
        z: torch.Tensor,
        library: torch.Tensor,
        batch_index: torch.Tensor | None = None,
        y: torch.Tensor | None = None,
        v: torch.Tensor | None = None,
        mode: str | None = None,
    ) -> dict[str, torch.Tensor]:
        """Run the generative (decoder) model for a given modality.

        Parameters
        ----------
        z
            Latent variable tensor.
        library
            Library size tensor.
        batch_index
            Batch index tensor.
        y
            Cell type labels (for semi-supervised GMM prior).
        v
            Feature embedding from the graph encoder.
        mode
            Name of the modality.

        Returns
        -------
        Dictionary containing generative model outputs and distributions.
        """
        EPS = 1e-8

        # Get decoder outputs (generative distribution parameters) based on modality
        if mode == self.input_names[0]:
            px_scale, px_r, px_rate, px_dropout = self.decoder_0(z, library, batch_index, v)
        elif mode == self.input_names[1]:
            px_scale, px_r, px_rate, px_dropout = self.decoder_1(z, library, batch_index, v)

        # Adjust parameters based on likelihood (count vs continuous)
        if self.modality_likelihoods[mode] in NORMALIZE_LIKELIHOODS:
            px_r = px_r.exp()
        elif self.modality_likelihoods[mode] in OTHER_LIKELIHOODS and self.normalize_lib[mode]:
            px_r = px_r.exp()
        else:
            px_r = F.softplus(px_r) + EPS

        # Construct the appropriate generative distribution p(x) based on likelihood
        if self.modality_likelihoods[mode] == "nb":
            px = NegativeBinomial(mu=px_rate, theta=px_r)
        elif self.modality_likelihoods[mode] == "zinb":
            px = ZeroInflatedNegativeBinomial(
                mu=px_rate,
                theta=px_r,
                zi_logits=px_dropout,
                scale=px_scale,
            )
        elif self.modality_likelihoods[mode] == "normal":
            px = Normal(px_rate, px_r, normal_mu=px_scale)
        elif self.modality_likelihoods[mode] == "nbmixture":
            px = NegativeBinomialMixture(
                mu1=px_rate[0],
                mu2=px_rate[1],
                theta1=px_r,
                mixture_logits=px_dropout,
            )
        elif self.modality_likelihoods[mode] == "log1pnormal":
            px = Log1pNormal(mu=px_rate, sigma=px_r, scale=px_scale)
        elif self.modality_likelihoods[mode] == "ziln":
            px = ZeroInflatedLogNormal(
                mu=px_rate,
                scale=px_r,
                zi_logits=px_dropout,
                normal_mu=px_scale,
            )
        elif self.modality_likelihoods[mode] == "zig":
            # Clamp concentration and rate to avoid lgamma numerical issues
            # with negative values
            px = ZeroInflatedGamma(
                concentration=torch.clamp(px_rate, min=EPS),
                rate=torch.clamp(px_r, min=EPS),
                zi_logits=px_dropout,
                scale=px_scale,
            )
        else:
            raise ValueError(
                f"Unknown likelihood '{self.modality_likelihoods[mode]}' for modality '{mode}'. "
                f"Supported likelihoods: {list(LIKELIHOOD_TO_DECODER.keys())}"
            )

        # Construct variational prior p(z) based on GMM settings
        if self.use_gmm_prior[mode]:
            logits = self.gmm_logits[mode]
            means = self.gmm_means[mode]
            scales = torch.exp(self.gmm_scales[mode]) + 1e-4
            if self.semi_supervised[mode]:
                # Vectorized one-hot encoding
                n_labels = self.n_labels[mode]
                y_flat = y.ravel().to(z.device)

                # Clamp invalid labels to 0 (will be zeroed out below)
                valid_mask = (y_flat >= 0) & (y_flat < n_labels)
                y_clamped = y_flat.clamp(0, n_labels - 1).long()

                # One-hot encode on device
                logits_input = F.one_hot(y_clamped, num_classes=n_labels).float()

                # Zero out rows for invalid labels (unlabeled cells)
                logits_input = logits_input * valid_mask.unsqueeze(-1).float()
                logits = logits + 100 * logits_input
                means = means.expand(y.shape[0], -1, -1)
                scales = scales.expand(y.shape[0], -1, -1)
            cats = Categorical(logits=logits)
            normal_dists = Independent(Normal(means, scales), reinterpreted_batch_ndims=1)
            pz = MixtureSameFamily(cats, normal_dists)
        else:
            pz = Normal(torch.zeros_like(z), torch.ones_like(z))

        return {
            MODULE_KEYS.PX_KEY: px,
            MODULE_KEYS.PZ_KEY: pz,
            "px_rate": px_rate,
        }

    def loss(
        self,
        tensors: dict[str, torch.Tensor],
        inference_outputs: dict[str, torch.Tensor],
        generative_outputs: dict[str, torch.Tensor],
        lam_kl: torch.Tensor | float,
        lam_data: torch.Tensor | float,
        mode: str | None = None,
    ) -> LossOutput:
        """Compute the loss for a batch.

        Parameters
        ----------
        tensors
            Input data tensors.
        inference_outputs
            Outputs from the inference step.
        generative_outputs
            Outputs from the generative step.
        lam_kl
            Weight for the KL divergence term.
        lam_data
            Weight for the reconstruction loss term.
        mode
            Name of the modality.

        Returns
        -------
        Object containing loss components and metrics.
        """
        x = tensors[REGISTRY_KEYS.X_KEY]
        n_obs = x.shape[0]
        n_var = x.shape[1]

        # Data nll calculation (reconstruction loss)
        reconst_loss = -generative_outputs[MODULE_KEYS.PX_KEY].log_prob(x).sum(-1)
        reconstruction_loss_norm = torch.mean(reconst_loss)

        # KL divergence calculation
        if self.use_gmm_prior[mode]:
            kl_div = inference_outputs[MODULE_KEYS.QZ_KEY].log_prob(inference_outputs["z"]).sum(
                -1
            ) - generative_outputs[MODULE_KEYS.PZ_KEY].log_prob(inference_outputs["z"])
        else:
            kl_div = kl_divergence(
                inference_outputs[MODULE_KEYS.QZ_KEY], generative_outputs[MODULE_KEYS.PZ_KEY]
            ).sum(dim=-1)
        kl_local_norm = torch.sum(kl_div) / (n_obs * n_var)

        # Total loss
        loss = lam_data * reconstruction_loss_norm + lam_kl * kl_local_norm

        # Graph inference
        mu_all = inference_outputs["mu_all"]
        logvar_all = inference_outputs["logvar_all"]
        v_all = inference_outputs["v_all"]

        # Semi-supervised classification loss (per modality if specified)
        classification_loss = 0.0
        if self.classifier_0 is not None and mode == self.input_names[0]:
            y = tensors[REGISTRY_KEYS.LABELS_KEY].ravel().long()
            z_mean = inference_outputs[MODULE_KEYS.QZ_KEY].loc
            y_logits = self.classifier_0(z_mean)
            classification_loss += torch.nn.functional.cross_entropy(y_logits, y, reduction="mean")
        if self.classifier_1 is not None and mode == self.input_names[1]:
            y = tensors[REGISTRY_KEYS.LABELS_KEY].ravel().long()
            z_mean = inference_outputs[MODULE_KEYS.QZ_KEY].loc
            y_logits = self.classifier_1(z_mean)
            classification_loss += torch.nn.functional.cross_entropy(y_logits, y, reduction="mean")

        return LossOutput(
            loss=loss,
            reconstruction_loss=reconst_loss,
            kl_local=kl_local_norm,
            extra_metrics={
                "z": inference_outputs[MODULE_KEYS.Z_KEY],
                "mu_all": mu_all,
                "logvar_all": logvar_all,
                "v_all": v_all,
                "guidance_graph": self.guidance_graph,
                "classification_loss": classification_loss,
            },
        )

    @torch.inference_mode()
    def sample(
        self,
        tensors: dict[str, dict[str, torch.Tensor]],
        n_samples: int = 1,
    ) -> dict[str, torch.Tensor]:
        """Sample from the generative model for each modality.

        Parameters
        ----------
        tensors
            Dictionary mapping modality names to their respective input tensors.
            Can contain one or both modalities.
        n_samples
            Number of samples to generate per cell.

        Returns
        -------
        Dictionary mapping modality names to sampled tensors of shape
        ``(n_samples, n_cells, n_features)`` if ``n_samples > 1``, else
        ``(n_cells, n_features)``.
        """
        samples = {}

        # Iterate only over modalities present in tensors (allows single-modality sampling)
        for mode in tensors.keys():
            mode_tensors = tensors[mode]

            # Run inference for this modality
            inference_outputs = self.inference(
                **self._get_inference_input(mode_tensors),
                mode=mode,
            )

            # Run generative model
            generative_input = self._get_generative_input(mode_tensors, inference_outputs)
            generative_outputs = self.generative(**generative_input, mode=mode)

            # Get the distribution and sample from it
            px = generative_outputs[MODULE_KEYS.PX_KEY]

            if n_samples > 1:
                # Sample multiple times and stack
                sample_list = [px.sample() for _ in range(n_samples)]
                mode_sample = torch.stack(sample_list, dim=0)  # (n_samples, n_cells, n_features)
            else:
                mode_sample = px.sample()  # (n_cells, n_features)

            samples[mode] = mode_sample.cpu()

        return samples
