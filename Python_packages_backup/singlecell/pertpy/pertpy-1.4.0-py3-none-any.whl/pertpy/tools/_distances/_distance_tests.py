from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd
from rich.progress import track
from scverse_misc import Deprecation, deprecated_arg
from sklearn.metrics import pairwise_distances
from statsmodels.stats.multitest import multipletests

from pertpy._types import cast_matrix

from ._distances import Distance, Metric

if TYPE_CHECKING:
    from anndata import AnnData


def _permutation_pvalues(results: list[pd.DataFrame], df: pd.DataFrame, n_perms: int) -> pd.Series:
    """Fraction of permutations that reached a larger distance than the observed one, per group of `df`."""
    comparison_results = pd.concat([r["distance"] - df["distance"] for r in results], axis=1) > 0
    n_failures = comparison_results.sum(axis=1).clip(lower=1).reindex(df.index)

    return n_failures / n_perms


class DistanceTest:
    """Run permutation tests using a distance of choice between groups of cells.

    Performs Monte-Carlo permutation testing using a distance metric of choice
    as test statistic. Tests all groups of cells against a specified contrast
    group (which normally would be your "control" cells).

    Args:
        metric: Distance metric to use between groups of cells.
        n_perms: Number of permutations to run.
        layer_key: Name of the counts layer containing raw counts to calculate distances for.
                   Mutually exclusive with 'obsm_key'.
                   If equal to `None` the parameter is ignored.
        obsm_key: Name of embedding in adata.obsm to use.
                  Mutually exclusive with 'counts_layer_key'.
                  Defaults to None, but is set to "X_pca" if not set explicitly internally.
        padj_threshold: Significance level, applied to the raw p-values and to the p-values after multiple testing correction.
        correction: Multiple testing correction method.
        cell_wise_metric: Metric to use between single cells.
        alpha: Deprecated and will be removed in a future release. Use `padj_threshold`.

    Examples:
        >>> import pertpy as pt
        >>> adata = pt.ds.distance_example()
        >>> distance_test = pt.tl.DistanceTest("edistance", n_perms=1000)
        >>> tab = distance_test(adata, groupby="perturbation", contrast="control")
    """

    @deprecated_arg(  # type: ignore[misc]
        "alpha",
        Deprecation("1.1.2", "Use `padj_threshold`."),
    )
    def __init__(
        self,
        metric: Metric,
        *,
        n_perms: int = 1000,
        layer_key: str | None = None,
        obsm_key: str | None = None,
        padj_threshold: float = 0.05,
        correction: str = "holm-sidak",
        cell_wise_metric=None,
        alpha: float | None = None,
    ):
        if alpha is not None:
            padj_threshold = alpha

        self.metric = metric
        self.n_perms = n_perms

        if layer_key and obsm_key:
            raise ValueError(
                "Cannot use 'counts_layer_key' and 'obsm_key' at the same time.\n"
                "Please provide only one of the two keys."
            )
        if not layer_key and not obsm_key:
            obsm_key = "X_pca"
        self.layer_key = layer_key
        self.obsm_key = obsm_key
        self.padj_threshold = padj_threshold
        self.correction = correction
        self.cell_wise_metric = (
            cell_wise_metric if cell_wise_metric else Distance(self.metric, obsm_key=self.obsm_key).cell_wise_metric
        )

        self.distance = Distance(
            self.metric,
            layer_key=self.layer_key,
            obsm_key=self.obsm_key,
            cell_wise_metric=self.cell_wise_metric,
        )

    def __call__(
        self,
        adata: AnnData,
        groupby: str,
        contrast: str,
        show_progressbar: bool = True,
    ) -> pd.DataFrame:
        """Run a permutation test using the specified distance metric, testing all groups of cells against a specified contrast group ("control").

        Args:
            adata: Annotated data matrix.
            groupby: Key in adata.obs for grouping cells.
            contrast: Name of the contrast group.
            show_progressbar: Whether to print progress.

        Returns:
            pandas.DataFrame: Results of the permutation test, with columns:
                - distance: distance between the contrast group and the group
                - pvalue: p-value of the permutation test
                - significant: whether the group is significantly different from the contrast group
                - pvalue_adj: p-value after multiple testing correction
                - significant_adj: whether the group is significantly different from the contrast group after multiple testing correction

        Examples:
            >>> import pertpy as pt
            >>> adata = pt.ds.distance_example()
            >>> distance_test = pt.tl.DistanceTest("edistance", n_perms=1000)
            >>> tab = distance_test(adata, groupby="perturbation", contrast="control")
        """
        if self.distance.metric_fct.accepts_precomputed:
            # Much faster if the metric can be called on the precomputed
            # distance matrix, but not all metrics can do that.
            return self.test_precomputed(adata, groupby, contrast, show_progressbar)
        else:
            return self.test_xy(adata, groupby, contrast, show_progressbar)

    def test_xy(self, adata: AnnData, groupby: str, contrast: str, show_progressbar: bool = True) -> pd.DataFrame:
        """Run permutation test for metric not supporting precomputed distances.

        Runs a permutation test for a metric that can not be computed using
        precomputed pairwise distances, but need the actual data points. This is
        generally slower than test_precomputed.

        Args:
            adata: Annotated data matrix.
            groupby: Key in adata.obs for grouping cells.
            contrast: Name of the contrast group.
            show_progressbar: Whether to print progress.

        Returns:
            pandas.DataFrame: Results of the permutation test, with columns:
                - distance: distance between the contrast group and the group
                - pvalue: p-value of the permutation test
                - significant: whether the group is significantly different from the contrast group
                - pvalue_adj: p-value after multiple testing correction
                - significant_adj: whether the group is significantly different from the contrast group after multiple testing correction

        Examples:
            >>> import pertpy as pt
            >>> adata = pt.ds.distance_example()
            >>> distance_test = pt.tl.DistanceTest("edistance", n_perms=1000)
            >>> test_results = distance_test.test_xy(adata, groupby="perturbation", contrast="control")
        """
        groups = adata.obs[groupby].unique()
        if contrast not in groups:
            raise ValueError(f"Contrast group {contrast} not found in {groupby} of adata.obs.")
        fct = track if show_progressbar else lambda iterable: iterable
        if self.obsm_key is None:
            raise ValueError("`obsm_key` must be set to run a permutation test on an embedding.")
        embedding = cast_matrix(adata.obsm[self.obsm_key])

        # Generate the null distribution
        obs_labels = np.asarray(adata.obs[groupby].values)
        masks = {group: adata.obs[groupby].isin([group, contrast]).to_numpy() for group in groups if group != contrast}
        distances = np.full((self.n_perms, len(groups)), np.nan)
        for i, group in enumerate(fct(groups)):
            if group == contrast:
                continue
            in_group = obs_labels[masks[group]] == group
            group_embedding = embedding[masks[group]]
            for permutation in range(self.n_perms):
                # Shuffle the labels of the groups
                rng = np.random.default_rng()
                idx = rng.permutation(in_group)
                X = group_embedding[idx]  # shuffled group
                Y = group_embedding[~idx]  # shuffled contrast
                distances[permutation, i] = self.distance(X, Y)
        results = [pd.DataFrame({"distance": row}, index=groups).sort_index() for row in distances]

        # Generate the empirical distribution
        df = pd.DataFrame(index=groups, columns=["distance"], dtype=float)
        for group in groups:
            if group == contrast:
                continue
            X = embedding[adata.obs[groupby] == group]
            Y = embedding[adata.obs[groupby] == contrast]
            df.loc[group, "distance"] = self.distance(X, Y)

        # Evaluate the test
        pvalues = _permutation_pvalues(results, df, self.n_perms)

        # Apply multiple testing correction
        significant_adj, pvalue_adj, _, _ = multipletests(
            pvalues.values, alpha=self.padj_threshold, method=self.correction
        )

        # Aggregate results
        tab = pd.DataFrame(
            {
                "distance": df["distance"],
                "pvalue": pvalues,
                "significant": pvalues < self.padj_threshold,
                "pvalue_adj": pvalue_adj,
                "significant_adj": significant_adj,
            },
            index=df.index,
        )

        # Set the contrast group
        tab.loc[contrast, "distance"] = 0
        tab.loc[contrast, "pvalue"] = 1
        tab.loc[contrast, "significant"] = False
        tab.loc[contrast, "pvalue_adj"] = 1
        tab.loc[contrast, "significant_adj"] = False

        return tab

    def test_precomputed(self, adata: AnnData, groupby: str, contrast: str, verbose: bool = True) -> pd.DataFrame:
        """Run permutation test for metrics that take precomputed distances.

        Args:
            adata: Annotated data matrix.
            groupby: Key in adata.obs for grouping cells.
            contrast: Name of the contrast group.
            cell_wise_metric: Metric to use for pairwise distances.
            verbose: Whether to print progress.

        Returns:
            pandas.DataFrame: Results of the permutation test, with columns:
                - distance: distance between the contrast group and the group
                - pvalue: p-value of the permutation test
                - significant: whether the group is significantly different from the contrast group
                - pvalue_adj: p-value after multiple testing correction
                - significant_adj: whether the group is significantly different from the contrast group after multiple testing correction

        Examples:
            >>> import pertpy as pt
            >>> adata = pt.ds.distance_example()
            >>> distance_test = pt.tl.DistanceTest("edistance", n_perms=1000)
            >>> test_results = distance_test.test_precomputed(adata, groupby="perturbation", contrast="control")
        """
        if not self.distance.metric_fct.accepts_precomputed:
            raise ValueError(f"Metric {self.metric} does not accept precomputed distances.")

        groups = adata.obs[groupby].unique()
        if contrast not in groups:
            raise ValueError(f"Contrast group {contrast} not found in {groupby} of adata.obs.")
        fct = track if verbose else lambda iterable: iterable

        # Precompute the pairwise distances
        precomputed_distances = {}
        for group in groups:
            subset = adata[adata.obs[groupby].isin([group, contrast])]
            if self.layer_key:
                cells = subset.layers[self.layer_key].copy()  # type: ignore[union-attr]
            elif self.obsm_key is not None:
                cells = subset.obsm[self.obsm_key].copy()  # type: ignore[union-attr]
            else:
                raise ValueError("Either `layer_key` or `obsm_key` must be set.")
            pwd = pairwise_distances(cells, cells, metric=self.distance.cell_wise_metric)
            precomputed_distances[group] = pwd, pwd.sum(dtype=np.float64)

        # Generate the null distribution
        obs_labels = np.asarray(adata.obs[groupby].values)
        masks = {group: adata.obs[groupby].isin([group, contrast]).to_numpy() for group in groups if group != contrast}
        in_group = {group: obs_labels[mask] == group for group, mask in masks.items()}
        results = []
        for _permutation in fct(range(self.n_perms)):
            # per perturbation, shuffle with control and compute e-distance
            distances = np.full(len(groups), np.nan)
            for i, group in enumerate(groups):
                if group == contrast:
                    continue
                # Shuffle the labels of the groups
                rng = np.random.default_rng()
                idx = rng.permutation(in_group[group])
                pwd, total = precomputed_distances[group]
                distances[i] = self.distance.metric_fct.from_precomputed(pwd, idx, total=total)
            results.append(pd.DataFrame({"distance": distances}, index=groups).sort_index())

        # Generate the empirical distribution
        df = pd.DataFrame(index=groups, columns=["distance"], dtype=float)
        for group in groups:
            if group == contrast:
                continue
            pwd, total = precomputed_distances[group]
            distance_result = self.distance.metric_fct.from_precomputed(pwd, in_group[group], total=total)
            df.loc[group, "distance"] = distance_result

        # Evaluate the test
        pvalues = _permutation_pvalues(results, df, self.n_perms)

        # Apply multiple testing correction
        significant_adj, pvalue_adj, _, _ = multipletests(
            pvalues.values, alpha=self.padj_threshold, method=self.correction
        )

        # Aggregate results
        tab = pd.DataFrame(
            {
                "distance": df["distance"],
                "pvalue": pvalues,
                "significant": pvalues < self.padj_threshold,
                "pvalue_adj": pvalue_adj,
                "significant_adj": significant_adj,
            },
            index=df.index,
        )

        # Set the contrast group
        tab.loc[contrast, "distance"] = 0
        tab.loc[contrast, "pvalue"] = 1
        tab.loc[contrast, "significant"] = False
        tab.loc[contrast, "pvalue_adj"] = 1
        tab.loc[contrast, "significant_adj"] = False
        return tab
