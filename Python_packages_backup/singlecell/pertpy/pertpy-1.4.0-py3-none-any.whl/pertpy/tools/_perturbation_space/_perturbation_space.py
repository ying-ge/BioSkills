from __future__ import annotations

import contextlib
import itertools
import warnings
from typing import TYPE_CHECKING, Literal

import numpy as np
import pandas as pd
import scanpy as sc
from anndata import AnnData
from fast_array_utils.conv import to_dense
from joblib import delayed, effective_n_jobs
from numba import njit, prange
from scipy import sparse
from scipy.optimize import curve_fit
from scipy.special import expit
from scipy.stats import entropy

from pertpy._doc import _doc_params, doc_common_plot_args
from pertpy._logger import logger
from pertpy._parallel import _block_slices, _parallelize_with_joblib
from pertpy._types import CSBase, cast_dense, cast_frame, cast_matrix

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Sequence

    from matplotlib.figure import Figure

    from pertpy._types import RandomStateLike
    from pertpy.tools._distances._distances import Metric


def _sklearn_random_state(random_state: RandomStateLike) -> int | np.random.RandomState | None:
    """Normalize a random state to something scikit-learn accepts (an int, a ``RandomState`` or ``None``)."""
    if isinstance(random_state, np.random.Generator):
        return int(random_state.integers(np.iinfo(np.int32).max))
    return random_state


def _resolve_matrix(adata: AnnData, *, layer_key: str | None, embedding_key: str | None) -> np.ndarray | CSBase:
    """Pick the cell-by-feature matrix from a layer, an obsm embedding, or ``.X``.

    Layer wins over embedding; both default back to ``.X``; passing both raises.
    """
    if layer_key is not None and embedding_key is not None:
        raise ValueError("Please, select just either layer or embedding for computation.")
    if layer_key is not None:
        if layer_key not in adata.layers:
            raise ValueError(f"Layer {layer_key!r} does not exist in the .layers attribute.")
        matrix = adata.layers[layer_key]
    elif embedding_key is not None:
        if embedding_key not in adata.obsm:
            raise ValueError(f"Embedding {embedding_key!r} does not exist in the .obsm attribute.")
        matrix = adata.obsm[embedding_key]
    else:
        matrix = adata.X
    return cast_matrix(matrix) if sparse.issparse(matrix) else np.asarray(matrix)


def _constant_obs_per_group(obs: pd.DataFrame, group_cols: Sequence[str]) -> pd.DataFrame:
    """Collapse ``obs`` to one row per ``group_cols`` combination, keeping only columns constant within every group.

    Columns that vary within any group are dropped so the result can be safely mapped back onto a perturbation-level AnnData.
    """
    grouped = obs.groupby(list(group_cols), observed=True)
    collapsed = grouped.first().loc[:, grouped.nunique(dropna=False).max() == 1]
    return collapsed.loc[:, ~collapsed.isna().all()]


def _carry_constant_obs(ps_adata: AnnData, source_obs: pd.DataFrame, group_cols: str | Sequence[str]) -> None:
    """Copy every ``source_obs`` column that is constant within each ``group_cols`` group onto ``ps_adata``."""
    cols = [group_cols] if isinstance(group_cols, str) else list(group_cols)
    extra = _constant_obs_per_group(source_obs, cols)
    if extra.columns.empty:
        return

    ps_obs = cast_frame(ps_adata.obs)
    keys = pd.Index(ps_obs[cols[0]]) if len(cols) == 1 else pd.MultiIndex.from_frame(ps_obs[cols])
    aligned = extra.reindex(keys)
    aligned.index = ps_adata.obs_names
    for col in aligned.columns:
        ps_adata.obs[col] = aligned[col]


def _vector_distance(u: np.ndarray, v: np.ndarray, metric: str) -> float:
    """Distance between two 1D perturbation vectors."""
    if metric == "euclidean":
        return float(np.linalg.norm(u - v))
    if metric == "cosine":
        denom = float(np.linalg.norm(u) * np.linalg.norm(v))
        return 1.0 - float(np.dot(u, v)) / denom if denom else float("nan")
    if metric == "pearson":
        if u.std() == 0 or v.std() == 0:
            return float("nan")
        return 1.0 - float(np.corrcoef(u, v)[0, 1])
    raise ValueError(f"Unknown metric {metric!r}. Choose from 'euclidean', 'cosine', 'pearson'.")


def _log_dose(dose: np.ndarray) -> np.ndarray:
    """Natural logarithm of the doses, with -inf for a zero dose."""
    log_dose = np.full_like(dose, -np.inf, dtype=float)
    np.log(dose, out=log_dose, where=dose > 0)
    return log_dose


def _four_parameter_logistic(
    dose: np.ndarray, e0: float, emax: float, log_midpoint: float, hill_coefficient: float
) -> np.ndarray:
    """Calculate predicted responses at the given doses from four-parameter Hill curve parameters."""
    fraction = expit(hill_coefficient * (_log_dose(dose) - log_midpoint))
    return e0 + (emax - e0) * fraction


def _four_parameter_logistic_jacobian(
    dose: np.ndarray, e0: float, emax: float, log_midpoint: float, hill_coefficient: float
) -> np.ndarray:
    """Calculate the derivatives of :func:`_four_parameter_logistic` with respect to each of its parameters."""
    log_ratio = _log_dose(dose) - log_midpoint
    fraction = expit(hill_coefficient * log_ratio)
    sensitivity = (emax - e0) * fraction * (1 - fraction)
    log_ratio[dose == 0] = 0
    return np.column_stack((1 - fraction, fraction, -hill_coefficient * sensitivity, sensitivity * log_ratio))


def _fit_hill(doses: np.ndarray, responses: np.ndarray) -> dict[str, float | bool]:
    """Fit a four-parameter Hill curve to one perturbation's responses."""
    unique_doses, dose_index = np.unique(doses, return_inverse=True)
    if unique_doses.size < 4:
        raise ValueError("at least four distinct dose values are required.")
    response_offset = float(np.min(responses))
    response_scale = float(np.ptp(responses))
    if response_scale == 0:
        raise ValueError("the response is constant.")

    responses = (responses - response_offset) / response_scale
    mean_response = np.bincount(dose_index, weights=responses) / np.bincount(dose_index)
    e0_guess, emax_guess = float(mean_response[0]), float(mean_response[-1])
    positive = unique_doses > 0
    halfway_distance = np.abs(mean_response[positive] - (e0_guess + emax_guess) / 2)
    midpoint_guess = float(unique_doses[positive][np.argmin(halfway_distance)])

    parameters, covariance = curve_fit(
        _four_parameter_logistic,
        doses,
        responses,
        p0=(e0_guess, emax_guess, np.log(midpoint_guess), 1.0),
        jac=_four_parameter_logistic_jacobian,
        bounds=((-np.inf, -np.inf, -np.inf, np.finfo(float).eps), np.inf),
        absolute_sigma=True,
        maxfev=20_000,
    )
    e0, emax, log_midpoint, hill_coefficient = parameters
    midpoint = float(np.exp(log_midpoint))
    residual_sum_squares = float(np.sum((responses - _four_parameter_logistic(doses, *parameters)) ** 2))
    total_sum_squares = float(np.sum((responses - responses.mean()) ** 2))
    positive_doses = doses[doses > 0]

    # Check conditioning before scaling covariance by residual variance, which may be zero.
    degrees_of_freedom = len(responses) - len(parameters)
    if (
        degrees_of_freedom <= 0
        or not np.isfinite(covariance).all()
        or np.linalg.matrix_rank(covariance) < len(parameters)
    ):
        midpoint_standard_error = np.nan
    else:
        residual_variance = residual_sum_squares / degrees_of_freedom
        midpoint_standard_error = midpoint * np.sqrt(float(covariance[2, 2]) * residual_variance)

    return {
        "e0": float(e0 * response_scale + response_offset),
        "emax": float(emax * response_scale + response_offset),
        "slope": float(hill_coefficient),
        "ec50": midpoint,
        "ec50_se": float(midpoint_standard_error),
        "r_squared": 1 - residual_sum_squares / total_sum_squares,
        "ec50_in_range": bool(positive_doses.min() < midpoint < positive_doses.max()),
    }


def _fit_hill_block(
    doses: Sequence[np.ndarray], responses: Sequence[np.ndarray]
) -> list[dict[str, float | bool] | ValueError | RuntimeError]:
    """Fit a Hill curve per perturbation, returning the error instead for curves that cannot be fit."""
    fits: list[dict[str, float | bool] | ValueError | RuntimeError] = []
    for perturbation_doses, perturbation_responses in zip(doses, responses, strict=True):
        try:
            fits.append(_fit_hill(perturbation_doses, perturbation_responses))
        except (ValueError, RuntimeError) as e:
            fits.append(e)
    return fits


@njit(cache=True)
def _group_control_sums(
    matrix: np.ndarray, groups: np.ndarray, control_mask: np.ndarray, sums: np.ndarray
) -> np.ndarray:
    """Add up the control rows of every group in row order like ``np.sum(axis=0)``, keeping a lone control row as is."""
    counts = np.zeros(sums.shape[0], dtype=np.int64)
    last_rows = np.zeros(sums.shape[0], dtype=np.int64)
    for i in range(matrix.shape[0]):
        group = groups[i]
        if group >= 0 and control_mask[i]:
            sums[group] += matrix[i]
            counts[group] += 1
            last_rows[group] = i
    for group in range(sums.shape[0]):
        if counts[group] == 1:
            sums[group] = matrix[last_rows[group]]
    return counts


@njit(cache=True, parallel=True)
def _subtract_group_means(
    matrix: np.ndarray, groups: np.ndarray, means: np.ndarray, has_control: np.ndarray
) -> np.ndarray:
    """Subtract its group's mean from every row, leaving rows of groups without control unchanged."""
    out = np.zeros(matrix.shape, dtype=np.float64)
    for i in prange(matrix.shape[0]):
        group = groups[i]
        if group < 0:
            continue
        if has_control[group]:
            for j in range(matrix.shape[1]):
                out[i, j] = matrix[i, j] - means[group, j]
        else:
            for j in range(matrix.shape[1]):
                out[i, j] = matrix[i, j]
    return out


def _subtract_control_mean(
    matrix: np.ndarray,
    control_mask: np.ndarray,
    groups: np.ndarray,
    *,
    name: str,
) -> np.ndarray:
    """Return ``matrix`` with the within-group control mean subtracted from every row.

    ``groups`` holds a group code per row, rows coded -1 belong to no group and are set to zero.
    Groups with no control cells are left untouched and a warning is emitted.
    """
    matrix = np.asarray(matrix)
    if matrix.dtype == np.float16:
        matrix = matrix.astype(np.float32)
    sums = np.zeros(
        (int(groups.max(initial=-1)) + 1, matrix.shape[1]), dtype=matrix.dtype if matrix.dtype.kind == "f" else float
    )
    counts = _group_control_sums(matrix, groups, control_mask, sums)
    for _ in range(int(np.count_nonzero(counts == 0))):
        logger.warning(
            f"No control cells found for one group when computing {name!r}; "
            "leaving those rows unchanged (no control subtraction applied)."
        )
    means = (sums.astype(np.float64) / np.maximum(counts, 1)[:, np.newaxis]).astype(sums.dtype)
    return _subtract_group_means(matrix, groups, means, counts > 0)


class PerturbationSpace:
    """Implements various ways of interacting with PerturbationSpaces.

    We differentiate between a cell space and a perturbation space.
    Visually speaking, in cell spaces single data points in an embeddings summarize a cell, whereas in a perturbation space, data points summarize whole perturbations.
    """

    def __init__(self):
        self.control_diff_computed = False

    def compute_control_diff(
        self,
        adata: AnnData,
        *,
        target_col: str = "perturbation",
        group_col: str | None = None,
        reference_key: str = "control",
        layer_key: str | None = None,
        new_layer_key: str = "control_diff",
        embedding_key: str | None = None,
        new_embedding_key: str = "control_diff",
        all_data: bool = False,
        copy: bool = True,
    ) -> AnnData:
        """Subtract mean of the control from the perturbation.

        Args:
            adata: Anndata object of size cells x genes.
            target_col: `.obs` column name that stores the label of the perturbation applied to each cell.
            group_col: `.obs` column name that stores the label of the group of each cell. If None, ignore groups.
            reference_key: The key of the control values.
            layer_key: Key of the AnnData layer to use for computation.
            new_layer_key: the results are stored in the given layer.
            embedding_key: `obsm` key of the AnnData embedding to use for computation.
            new_embedding_key: Results are stored in a new embedding in `obsm` with this key.
            all_data: if True, do the computation in all data representations (X, all layers and all embeddings)
            copy: If True returns a new AnnData; otherwise updates the input AnnData in place.

        Returns:
            Updated AnnData object.

        Examples:
            Example usage with PseudobulkSpace:

            >>> import pertpy as pt
            >>> mdata = pt.ds.papalexi_2021()
            >>> ps = pt.tl.PseudobulkSpace()
            >>> diff_adata = ps.compute_control_diff(mdata["rna"], target_col="gene_target", reference_key="NT")
        """
        if reference_key not in adata.obs[target_col].unique():
            raise ValueError(
                f"Reference key {reference_key} not found in {target_col}. {reference_key} must be in obs column {target_col}."
            )

        if embedding_key is not None and embedding_key not in adata.obsm:
            raise ValueError(f"Embedding key {embedding_key} not found in obsm keys of the anndata.")

        if layer_key is not None and layer_key not in adata.layers:
            raise ValueError(f"Layer {layer_key!r} does not exist in the anndata.")

        if copy:
            adata = adata.copy()

        control_mask = (adata.obs[target_col] == reference_key).to_numpy()
        groups = (
            np.zeros(adata.n_obs, dtype=np.intp)
            if group_col is None
            else pd.factorize(cast_frame(adata.obs)[group_col])[0]
        )

        if layer_key:
            adata.layers[new_layer_key] = _subtract_control_mean(
                to_dense(adata.layers[layer_key]), control_mask, groups, name=new_layer_key
            )

        if embedding_key:
            adata.obsm[new_embedding_key] = _subtract_control_mean(
                cast_dense(adata.obsm[embedding_key]), control_mask, groups, name=new_embedding_key
            )

        if (not layer_key and not embedding_key) or all_data:
            adata.X = _subtract_control_mean(to_dense(adata.X), control_mask, groups, name="X")

        if all_data:
            for local_layer_key in [key for key in adata.layers.keys() if isinstance(key, str)]:  # noqa: SIM118
                if local_layer_key in {layer_key, new_layer_key}:
                    continue
                new_key = local_layer_key + "_control_diff"
                adata.layers[new_key] = _subtract_control_mean(
                    to_dense(adata.layers[local_layer_key]), control_mask, groups, name=new_key
                )

            for local_embedding_key in [key for key in adata.obsm if isinstance(key, str)]:
                if local_embedding_key in {embedding_key, new_embedding_key}:
                    continue
                new_key = local_embedding_key + "_control_diff"
                adata.obsm[new_key] = _subtract_control_mean(
                    cast_dense(adata.obsm[local_embedding_key]), control_mask, groups, name=new_key
                )

        self.control_diff_computed = True

        return adata

    def _combine(
        self,
        adata: AnnData,
        *,
        perturbations: Iterable[str],
        op: Callable[[np.ndarray, np.ndarray], None],
        reference_key: str,
        new_pert_name: str,
        ensure_consistency: bool,
        target_col: str,
    ) -> tuple[AnnData, AnnData] | AnnData:
        """Backend for both ``add`` and ``subtract``.

        ``op`` is applied as ``op(running_total, adata[perturbation].X)`` so callers pick addition or subtraction (or anything else operating in-place on a numpy array).
        """
        perturbations = list(perturbations)
        for perturbation in perturbations:
            if perturbation not in adata.obs_names:
                raise ValueError(
                    f"Perturbation {perturbation} not found in adata.obs_names. {perturbation} must be in adata.obs_names."
                )

        if ensure_consistency:
            adata = self.compute_control_diff(adata, copy=True, all_data=True, target_col=target_col)
        else:
            warnings.warn(
                "Combining perturbations without `ensure_consistency=True` is only well-defined "
                "if the input was already differenced against control "
                "(otherwise perturbation - perturbation != control).",
                stacklevel=3,
            )

        # sc.get.aggregate can leave a `None`-keyed layer behind (the pre-aggregation .X);
        # PseudobulkSpace.compute strips it but defensively re-strip here so callers passing
        # a hand-built AnnData don't crash inside the string ops below.
        layer_keys = [k for k in adata.layers.keys() if isinstance(k, str)]  # noqa: SIM118
        obsm_keys = [k for k in adata.obsm if isinstance(k, str)]
        rename_back = (
            {
                key: key.removesuffix("_control_diff")
                for key in [*layer_keys, *obsm_keys]
                if key.endswith("_control_diff")
            }
            if ensure_consistency
            else {}
        )

        def _running(values: np.ndarray) -> np.ndarray:
            result = values[adata.obs_names.get_loc(reference_key)].astype(float, copy=True)
            for perturbation in perturbations:
                op(result, values[adata.obs_names.get_loc(perturbation)])
            return result

        new_layers: dict[str, np.ndarray] = {}
        for layer_key in layer_keys:
            mat = adata.layers[layer_key]
            new_layers[rename_back.get(layer_key, layer_key)] = np.concatenate(
                (np.asarray(mat), _running(np.asarray(mat))[None, :]), axis=0
            )

        new_obsm: dict[str, np.ndarray] = {}
        for embedding_key in obsm_keys:
            mat = adata.obsm[embedding_key]
            new_obsm[rename_back.get(embedding_key, embedding_key)] = np.concatenate(
                (np.asarray(mat), _running(np.asarray(mat))[None, :]), axis=0
            )

        X = np.asarray(adata.X)
        new_X = np.concatenate((X, _running(X)[None, :]), axis=0)

        new_perturbation = AnnData(X=new_X)
        new_index = adata.obs_names.append(pd.Index([new_pert_name]))
        new_perturbation.obs_names = new_index.tolist()
        new_perturbation.obs = cast_frame(adata.obs).reindex(new_index)

        for key, value in new_layers.items():
            new_perturbation.layers[key] = value
        for key, value in new_obsm.items():
            new_perturbation.obsm[key] = value

        new_perturbation.obs[target_col] = new_perturbation.obs_names.astype("category")

        if ensure_consistency:
            return new_perturbation, adata
        return new_perturbation

    def add(
        self,
        adata: AnnData,
        *,
        perturbations: Iterable[str],
        reference_key: str = "control",
        ensure_consistency: bool = True,
        target_col: str = "perturbation",
    ) -> tuple[AnnData, AnnData] | AnnData:
        """Add perturbations linearly. Assumes input of size n_perts x dimensionality.

        Args:
            adata: Anndata object of size n_perts x dim.
            perturbations: Perturbations to add.
            reference_key: perturbation source from which the perturbation summation starts.
            ensure_consistency: If True, differentiate against control via `compute_control_diff` before combining so that "perturbation - perturbation == control" holds in the resulting space. Set False only if the input has already been differenced.
            target_col: `.obs` column name that stores the label of the perturbation applied to each cell.

        Returns:
            Anndata object of size (n_perts+1) x dim, where the last row is the addition of the specified perturbations.
            If ensure_consistency is True, returns a tuple of (new_perturbation, adata) where adata is the AnnData object provided as input but updated using compute_control_diff.

        Examples:
            Example usage with PseudobulkSpace:

            >>> import pertpy as pt
            >>> mdata = pt.ds.papalexi_2021()
            >>> ps = pt.tl.PseudobulkSpace()
            >>> ps_adata = ps.compute(mdata["rna"], target_col="gene_target", groups_col="gene_target")
            >>> new_perturbation = ps.add(ps_adata, perturbations=["ATF2", "CD86"], reference_key="NT")
        """
        perturbations = list(perturbations)
        new_pert_name = "+".join(perturbations)

        def _iadd(a: np.ndarray, b: np.ndarray) -> None:
            a += b

        return self._combine(
            adata,
            perturbations=perturbations,
            op=_iadd,
            reference_key=reference_key,
            new_pert_name=new_pert_name,
            ensure_consistency=ensure_consistency,
            target_col=target_col,
        )

    def subtract(
        self,
        adata: AnnData,
        *,
        perturbations: Iterable[str],
        reference_key: str = "control",
        ensure_consistency: bool = True,
        target_col: str = "perturbation",
    ) -> tuple[AnnData, AnnData] | AnnData:
        """Subtract perturbations linearly. Assumes input of size n_perts x dimensionality.

        Args:
            adata: Anndata object of size n_perts x dim.
            perturbations: Perturbations to subtract.
            reference_key: Perturbation source from which the perturbation subtraction starts.
            ensure_consistency: If True, differentiate against control via `compute_control_diff` before combining so that "perturbation - perturbation == control" holds in the resulting space. Set False only if the input has already been differenced.
            target_col: `.obs` column name that stores the label of the perturbation applied to each cell.

        Returns:
            Anndata object of size (n_perts+1) x dim, where the last row is the subtraction of the specified perturbations.
            If ensure_consistency is True, returns a tuple of (new_perturbation, adata) where adata is the AnnData object provided as input but updated using compute_control_diff.

        Examples:
            Example usage with PseudobulkSpace:

            >>> import pertpy as pt
            >>> mdata = pt.ds.papalexi_2021()
            >>> ps = pt.tl.PseudobulkSpace()
            >>> ps_adata = ps.compute(mdata["rna"], target_col="gene_target", groups_col="gene_target")
            >>> new_perturbation = ps.subtract(ps_adata, reference_key="ATF2", perturbations=["BRD4", "CUL3"])
        """
        perturbations = list(perturbations)
        new_pert_name = reference_key + "-" + "-".join(perturbations)

        def _isub(a: np.ndarray, b: np.ndarray) -> None:
            a -= b

        return self._combine(
            adata,
            perturbations=perturbations,
            op=_isub,
            reference_key=reference_key,
            new_pert_name=new_pert_name,
            ensure_consistency=ensure_consistency,
            target_col=target_col,
        )

    def label_transfer(
        self,
        adata: AnnData,
        *,
        target_column: str = "perturbation",
        column_uncertainty_score_key: str = "perturbation_transfer_uncertainty",
        target_val: str = "unknown",
        neighbors_key: str = "neighbors",
    ) -> None:
        """Impute missing values in the specified column using KNN imputation in the space defined by `use_rep`.

        Uncertainty is calculated as the entropy of the label distribution in the neighborhood of the target cell.
        In other words, a cell where all neighbors have the same set of labels will have an uncertainty of 0, whereas a cell where all neighbors have many different labels will have high uncertainty.

        Args:
            adata: The AnnData object containing single-cell data.
            target_column: The column name in adata.obs to perform imputation on.
            column_uncertainty_score_key: The column name in adata.obs to store the uncertainty score of the label transfer.
            target_val: The target value to impute.
            neighbors_key: The key in adata.uns where the neighbors are stored.

        Examples:
            >>> import pertpy as pt
            >>> import scanpy as sc
            >>> import numpy as np
            >>> adata = sc.datasets.pbmc68k_reduced()
            >>> # randomly dropout 10% of the data annotations
            >>> adata.obs["perturbation"] = adata.obs["louvain"].astype(str).copy()
            >>> random_cells = np.random.choice(adata.obs.index, int(adata.obs.shape[0] * 0.1), replace=False)
            >>> adata.obs.loc[random_cells, "perturbation"] = "unknown"
            >>> sc.pp.neighbors(adata)
            >>> sc.tl.umap(adata)
            >>> ps = pt.tl.PseudobulkSpace()
            >>> ps.label_transfer(adata)
        """
        if neighbors_key not in adata.uns:
            raise ValueError(f"Key {neighbors_key} not found in adata.uns. Please run `sc.pp.neighbors` first.")

        obs = cast_frame(adata.obs)
        labels = obs[target_column].astype(str)
        target_cells = labels == target_val

        connectivities = sparse.csc_matrix(cast_matrix(adata.obsp[adata.uns[neighbors_key]["connectivities_key"]]))
        # convert labels to an incidence matrix
        unique_labels = labels.drop_duplicates()
        one_hot_encoded_labels = unique_labels.str.get_dummies()
        cell_incidence = sparse.csr_matrix(one_hot_encoded_labels.to_numpy())[
            pd.Index(unique_labels).get_indexer(pd.Index(labels))
        ]
        # convert to distance-weighted neighborhood incidence matrix
        target_connectivities = connectivities.T[np.flatnonzero(target_cells)]
        weighted_label_occurence = pd.DataFrame(
            (target_connectivities @ cell_incidence).toarray(),
            index=adata.obs_names[target_cells.to_numpy()],
            columns=one_hot_encoded_labels.columns,
        ).drop(target_val, axis=1)
        # choose best label for each target cell
        best_labels = weighted_label_occurence.idxmax(axis=1)
        obs[target_column] = labels
        obs.loc[target_cells, target_column] = best_labels

        # calculate uncertainty
        uncertainty = np.zeros(adata.n_obs)
        uncertainty[target_cells] = entropy(weighted_label_occurence, axis=1)
        adata.obs[column_uncertainty_score_key] = uncertainty

    def nearest_perturbations(
        self,
        adata: AnnData,
        perturbation: str,
        *,
        target_col: str = "perturbation",
        n_neighbors: int = 10,
        layer_key: str | None = None,
        embedding_key: str | None = None,
        metric: str = "euclidean",
    ) -> pd.DataFrame:
        """Rank perturbations by their proximity to a query perturbation in a perturbation space.

        Operates on a perturbation-level AnnData (one observation per perturbation), i.e. the output of any ``compute``.
        Useful for discovering perturbations with a similar mechanism of action.
        If ``adata.obsp["distances"]`` is present (as produced by :class:`~pertpy.tools.DistanceSpace`) and no representation is requested explicitly, those precomputed distances are used directly.

        Args:
            adata: Perturbation-level AnnData indexed by perturbation.
            perturbation: The query perturbation to find neighbors for.
            target_col: `.obs` column identifying each perturbation.
            n_neighbors: Number of nearest perturbations to return.
            layer_key: Layer to compute distances from.
            embedding_key: `.obsm` embedding to compute distances from.
            metric: Distance metric passed to :func:`sklearn.metrics.pairwise_distances`.

        Returns:
            DataFrame indexed by perturbation with a ``distance`` column, sorted ascending and excluding the query.

        Examples:
            >>> import pertpy as pt
            >>> adata = pt.ds.norman_2019()
            >>> ps = pt.tl.PseudobulkSpace()
            >>> ps_adata = ps.compute(adata, target_col="perturbation_name")
            >>> neighbors = ps.nearest_perturbations(ps_adata, "CBL+CNN1", target_col="perturbation_name")
        """
        names = (
            adata.obs[target_col].astype(str).to_numpy()
            if target_col in adata.obs
            else adata.obs_names.to_numpy().astype(str)
        )
        matches = np.flatnonzero(names == str(perturbation))
        if matches.size == 0:
            raise ValueError(f"Perturbation {perturbation!r} not found in adata.obs[{target_col!r}].")
        query_idx = int(matches[0])

        if layer_key is None and embedding_key is None and "distances" in adata.obsp:
            distances = np.asarray(adata.obsp["distances"])[query_idx]
        else:
            from sklearn.metrics import pairwise_distances

            coords = _resolve_matrix(adata, layer_key=layer_key, embedding_key=embedding_key)
            distances = pairwise_distances(coords[[query_idx]], coords, metric=metric)[0]

        keep = np.arange(len(names)) != query_idx
        result = pd.DataFrame({"distance": distances[keep]}, index=names[keep])
        return result.sort_values("distance").head(n_neighbors)

    def evaluate_combinations(
        self,
        adata: AnnData,
        *,
        combinations: Iterable[str] | None = None,
        target_col: str = "perturbation",
        reference_key: str = "control",
        metric: Literal["pearson", "cosine", "euclidean"] = "pearson",
        sep: str = "+",
    ) -> pd.DataFrame:
        """Score how well an additive model predicts combination perturbations.

        For every combination ``"A+B"`` whose components ``A`` and ``B`` are each present as single perturbations, the additive prediction ``effect(A) + effect(B)`` is compared against the measured combination effect, where effects are taken relative to ``reference_key``.
        A small distance indicates additive, non-interacting perturbations, whereas a large deviation flags a genetic or pharmacological interaction.

        Args:
            adata: Perturbation-level AnnData indexed by perturbation (one observation per perturbation).
            combinations: Combination names to evaluate. If None, every ``obs_name`` containing ``sep`` whose components are all present as singles is used.
            target_col: `.obs` column identifying each perturbation.
            reference_key: Control perturbation subtracted to obtain effects. If absent, values are used as-is.
            metric: Distance between predicted and measured combination effects.
            sep: Separator between components in combination names.

        Returns:
            DataFrame indexed by combination with ``distance``, ``predicted_magnitude`` and ``measured_magnitude`` columns, sorted by ascending distance.

        Examples:
            >>> import pertpy as pt
            >>> adata = pt.ds.norman_2019()
            >>> ps = pt.tl.PseudobulkSpace()
            >>> ps_adata = ps.compute(adata, target_col="perturbation_name")
            >>> scores = ps.evaluate_combinations(ps_adata, target_col="perturbation_name", reference_key="control")
        """
        names = adata.obs_names.astype(str)
        matrix = np.asarray(adata.X, dtype=float)
        vectors = {name: matrix[i] for i, name in enumerate(names)}

        effects = (
            {name: vec - vectors[reference_key] for name, vec in vectors.items()}
            if reference_key in vectors
            else vectors
        )

        if combinations is None:
            combinations = [n for n in names if sep in n and all(part in vectors for part in n.split(sep))]
        combinations = list(combinations)
        if not combinations:
            raise ValueError("No evaluable combinations found; provide `combinations` explicitly or check `sep`.")

        rows: dict[str, dict[str, float]] = {}
        for combo in combinations:
            if combo not in effects:
                raise ValueError(f"Combination {combo!r} not found in adata.")
            components = combo.split(sep)
            missing = [part for part in components if part not in effects]
            if missing:
                raise ValueError(f"Components {missing} of {combo!r} are not present as single perturbations.")
            predicted = np.sum([effects[part] for part in components], axis=0)
            measured = effects[combo]
            rows[combo] = {
                "distance": _vector_distance(predicted, measured, metric),
                "predicted_magnitude": float(np.linalg.norm(predicted)),
                "measured_magnitude": float(np.linalg.norm(measured)),
            }

        return pd.DataFrame.from_dict(rows, orient="index").sort_values("distance")

    def dose_response(
        self,
        adata: AnnData,
        *,
        target_col: str = "perturbation",
        dose_col: str = "dose",
        reference_key: str = "control",
        metric: Metric = "edistance",
        layer_key: str | None = None,
        embedding_key: str | None = None,
        **kwargs,
    ) -> AnnData:
        """Quantify the effect size of each perturbation as a function of dose.

        For every (perturbation, dose) group the statistical distance to ``reference_key`` is computed in the chosen representation using :class:`~pertpy.tools.Distance`.
        Operates on cell-level data, since distances are defined between groups of cells.

        Args:
            adata: Cell-level AnnData.
            target_col: `.obs` column with the perturbation label.
            dose_col: `.obs` column with the (numeric) dose.
            reference_key: Control perturbation all doses are compared against.
            metric: Distance metric passed to :class:`~pertpy.tools.Distance`.
            layer_key: Layer to compute distances and mean expression from.
            embedding_key: `.obsm` embedding to compute distances from.
            kwargs: Passed to :meth:`~pertpy.tools.Distance.onesided_distances`.

        Returns:
            AnnData with one observation per non-reference (perturbation, dose) group, holding the mean expression in ``X`` and the ``distance`` in `.obs`.

        Examples:
            >>> import pertpy as pt
            >>> adata = pt.ds.srivatsan_2020_sciplex2()
            >>> ps = pt.tl.PseudobulkSpace()
            >>> dose_adata = ps.dose_response(adata, dose_col="dose_value", embedding_key="X_pca")
        """
        for col in (target_col, dose_col):
            if col not in adata.obs:
                raise ValueError(f"Column {col!r} does not exist in the .obs attribute.")
        from pertpy.tools._distances._distances import Distance

        sep = "\x1f"
        obs = cast_frame(adata.obs)
        is_control = (obs[target_col] == reference_key).to_numpy()
        group = obs[target_col].astype(str).str.cat(obs[dose_col].astype(str), sep=sep)
        group = group.mask(is_control, reference_key)
        grouped = adata.copy()
        grouped.obs["_dose_group"] = pd.Categorical(group)

        distance = Distance(metric=metric, layer_key=layer_key, obsm_key=embedding_key)
        dists = distance.onesided_distances(
            grouped, groupby="_dose_group", selected_group=reference_key, show_progressbar=False, **kwargs
        )
        if isinstance(dists, tuple):
            dists = dists[0]

        treated = grouped[~is_control].copy()
        treated.obs["_dose_group"] = treated.obs["_dose_group"].cat.remove_unused_categories()
        dose_adata = sc.get.aggregate(treated, by="_dose_group", func="mean", layer=layer_key)
        dose_adata.X = dose_adata.layers.pop("mean")
        _carry_constant_obs(dose_adata, cast_frame(treated.obs), "_dose_group")
        dose_obs = cast_frame(dose_adata.obs)
        dose_adata.obs["distance"] = dists.reindex(dose_obs["_dose_group"].astype(str)).to_numpy(dtype=float)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            with contextlib.suppress(ValueError, TypeError):
                dose_adata.obs[dose_col] = pd.to_numeric(dose_obs[dose_col].astype(str))
        dose_adata.obs = cast_frame(dose_adata.obs).drop(columns="_dose_group")
        dose_adata.obs_names = dose_adata.obs_names.str.replace(sep, "_")
        order = cast_frame(dose_adata.obs).sort_values([target_col, dose_col]).index
        return dose_adata[order].copy()

    def fit_dose_response(
        self,
        adata: AnnData,
        response: str = "distance",
        *,
        target_col: str = "perturbation",
        dose_col: str = "dose",
        key_added: str | None = None,
        n_jobs: int | None = None,
    ) -> None:
        """Fit a four-parameter Hill curve for each perturbation.

        Perturbations whose curve cannot be fit get a warning and NaN parameters.

        Args:
            adata: AnnData with one observation per dose or replicate, such as the output of :meth:`dose_response`.
            response: `.obs` column or gene in ``var_names`` to fit.
            target_col: `.obs` column identifying the perturbation.
            dose_col: `.obs` column containing non-negative numeric doses.
            key_added: Prefix of the `.obs` columns the results are written to. Defaults to ``response``.
            n_jobs: Number of jobs to distribute the perturbations over, passed to `joblib.Parallel`.
                None means one job, -1 all available cores.

        Returns:
            Adds the fitted response and the per-perturbation ``e0``, ``emax``, ``slope``, ``ec50``, ``ec50_se``, ``r_squared`` and ``ec50_in_range`` to `.obs`, prefixed with ``key_added``.

        Examples:
            >>> import pertpy as pt
            >>> adata = pt.ds.srivatsan_2020_sciplex2()
            >>> ps = pt.tl.PseudobulkSpace()
            >>> dose_adata = ps.dose_response(adata, dose_col="dose_value", embedding_key="X_pca")
            >>> ps.fit_dose_response(dose_adata, dose_col="dose_value")
            >>> ps.fit_dose_response(dose_adata, "CDKN1A", dose_col="dose_value")
        """
        data = sc.get.obs_df(adata, keys=[target_col, dose_col, response])
        doses = data[dose_col].to_numpy(dtype=float)
        responses = data[response].to_numpy(dtype=float)
        if (doses < 0).any():
            raise ValueError("Dose values must be non-negative.")

        labels = data[target_col].to_numpy()
        positions = pd.Series(labels).groupby(labels, sort=False).indices
        perturbations = pd.unique(labels)
        perturbation_rows = [positions.get(p, np.array([], dtype=np.intp)) for p in perturbations]
        n_workers = effective_n_jobs(n_jobs if n_jobs is not None else 1)
        blocks = _block_slices(len(perturbations), n_blocks=len(perturbations) if n_workers == 1 else 4 * n_workers)
        block_fits = _parallelize_with_joblib(
            (
                delayed(_fit_hill_block)(
                    [doses[rows] for rows in perturbation_rows[block]],
                    [responses[rows] for rows in perturbation_rows[block]],
                )
                for block in blocks
            ),
            total=len(blocks),
            n_jobs=n_jobs,
        )

        fitted = np.full(len(data), np.nan)
        records: dict[object, dict[str, float | bool]] = {}
        for perturbation, rows, result in zip(
            perturbations, perturbation_rows, itertools.chain.from_iterable(block_fits), strict=True
        ):
            if isinstance(result, Exception):
                warnings.warn(
                    f"Cannot fit a Hill curve for perturbation {perturbation!r}: {result}", UserWarning, stacklevel=2
                )
                fit: dict[str, float | bool] = dict.fromkeys(
                    ("e0", "emax", "slope", "ec50", "ec50_se", "r_squared"), np.nan
                )
                fit["ec50_in_range"] = False
            else:
                fit = result
                fitted[rows] = _four_parameter_logistic(
                    doses[rows], fit["e0"], fit["emax"], np.log(fit["ec50"]), fit["slope"]
                )
                if np.isnan(fit["ec50_se"]):
                    warnings.warn(
                        f"Cannot estimate the EC50 standard error for perturbation {perturbation!r}. "
                        "Inspect the dose range and fitted curve before interpreting the estimate.",
                        UserWarning,
                        stacklevel=2,
                    )
            records[perturbation] = fit

        prefix = response if key_added is None else key_added
        fits = pd.DataFrame.from_dict(records, orient="index")
        adata.obs[f"{prefix}_fitted"] = fitted
        for col in fits.columns:
            adata.obs[f"{prefix}_{col}"] = fits[col].reindex(labels).to_numpy()

    @_doc_params(common_plot_args=doc_common_plot_args)
    def plot_dose_response(  # pragma: no cover # noqa: D417
        self,
        adata: AnnData,
        response: str = "distance",
        *,
        target_col: str = "perturbation",
        dose_col: str = "dose",
        key_added: str | None = None,
        perturbations: Sequence[str] | None = None,
        ncols: int = 4,
        return_fig: bool = False,
    ) -> Figure | None:
        """Plot the measured responses and fitted Hill curves of each perturbation.

        Args:
            adata: AnnData with one observation per dose or replicate, such as the output of :meth:`dose_response`.
            response: `.obs` column or gene in ``var_names`` to plot.
            target_col: `.obs` column identifying the perturbation.
            dose_col: `.obs` column containing the doses.
            key_added: Prefix passed to :meth:`fit_dose_response`. Defaults to ``response``.
            perturbations: Perturbations to plot. Defaults to all.
            ncols: Number of panels per row.
            {common_plot_args}

        Returns:
            If `return_fig` is `True`, returns the figure, otherwise `None`.

        Examples:
            >>> import pertpy as pt
            >>> adata = pt.ds.srivatsan_2020_sciplex2()
            >>> ps = pt.tl.PseudobulkSpace()
            >>> dose_adata = ps.dose_response(adata, dose_col="dose_value", embedding_key="X_pca")
            >>> ps.fit_dose_response(dose_adata, dose_col="dose_value")
            >>> ps.plot_dose_response(dose_adata, dose_col="dose_value")

        Preview:
            .. image:: /_static/docstring_previews/dose_response.png
        """
        import matplotlib.pyplot as plt

        prefix = response if key_added is None else key_added
        data = sc.get.obs_df(adata, keys=[target_col, dose_col, response])
        obs = cast_frame(adata.obs)
        labels = list(pd.unique(data[target_col]) if perturbations is None else perturbations)
        ncols = min(ncols, len(labels))
        nrows = -(-len(labels) // ncols)
        fig, axes = plt.subplots(nrows, ncols, figsize=(3.5 * ncols, 3 * nrows), squeeze=False, layout="constrained")
        for ax, label in zip(axes.flat, labels, strict=False):
            mask = (data[target_col] == label).to_numpy()
            doses = data.loc[mask, dose_col].to_numpy(dtype=float)
            ax.scatter(doses, data.loc[mask, response], zorder=3)
            if f"{prefix}_ec50" in obs and np.isfinite((fit := obs.loc[mask].iloc[0])[f"{prefix}_ec50"]):
                grid = np.geomspace(doses[doses > 0].min(), doses.max(), 200)
                curve = _four_parameter_logistic(
                    grid,
                    fit[f"{prefix}_e0"],
                    fit[f"{prefix}_emax"],
                    np.log(fit[f"{prefix}_ec50"]),
                    fit[f"{prefix}_slope"],
                )
                ax.plot(grid, curve, color="tab:orange")
                if fit[f"{prefix}_ec50_in_range"]:
                    ax.axvline(fit[f"{prefix}_ec50"], color="0.5", linestyle=":")
            lowest = doses[doses > 0].min()
            ax.set_xscale("symlog", linthresh=lowest)
            ax.set_xlim(0 if (doses == 0).any() else lowest / 2, doses.max() * 2)
            ax.set(title=str(label), xlabel=dose_col, ylabel=response)
        for ax in axes.flat[len(labels) :]:
            ax.set_visible(False)

        if return_fig:
            return fig
        plt.show()
        return None

    def plot_similarity(  # pragma: no cover
        self,
        adata: AnnData,
        *,
        target_col: str = "perturbation",
        layer_key: str | None = None,
        embedding_key: str | None = None,
        metric: str = "euclidean",
        cmap: str = "viridis",
        **kwargs,
    ):
        """Plot a clustered heatmap of pairwise distances between perturbations.

        Uses ``adata.obsp["distances"]`` when present (e.g. from :class:`~pertpy.tools.DistanceSpace`) and otherwise computes pairwise distances in the chosen representation.

        Args:
            adata: Perturbation-level AnnData indexed by perturbation.
            target_col: `.obs` column identifying each perturbation.
            layer_key: Layer to compute distances from.
            embedding_key: `.obsm` embedding to compute distances from.
            metric: Distance metric passed to :func:`sklearn.metrics.pairwise_distances`.
            cmap: Matplotlib colormap.
            kwargs: Passed to :func:`seaborn.clustermap`.

        Returns:
            The grid returned by :func:`seaborn.clustermap`.

        Examples:
            >>> import pertpy as pt
            >>> adata = pt.ds.norman_2019()
            >>> ds = pt.tl.DistanceSpace()
            >>> ds_adata = ds.compute(adata, target_col="perturbation_name", metric="edistance")
            >>> ds.plot_similarity(ds_adata, target_col="perturbation_name")
        """
        import seaborn as sns

        names = (
            adata.obs[target_col].astype(str).to_numpy()
            if target_col in adata.obs
            else adata.obs_names.to_numpy().astype(str)
        )
        if layer_key is None and embedding_key is None and "distances" in adata.obsp:
            distances = np.asarray(adata.obsp["distances"])
        else:
            from sklearn.metrics import pairwise_distances

            coords = _resolve_matrix(adata, layer_key=layer_key, embedding_key=embedding_key)
            distances = pairwise_distances(coords, metric=metric)
        frame = pd.DataFrame(distances, index=names, columns=names)

        return sns.clustermap(frame, cmap=cmap, **kwargs)
