from __future__ import annotations

import warnings
from collections.abc import Mapping, MutableMapping
from contextlib import contextmanager, nullcontext
from copy import copy
from functools import partial, wraps
from importlib.metadata import version
from itertools import product
from types import MappingProxyType
from typing import TYPE_CHECKING, Protocol

import h5py
import numpy as np
import pandas as pd
import zarr
from numcodecs import VLenUTF8
from packaging.version import Version
from scipy import sparse
from zarr.core.dtype import VariableLengthUTF8

import anndata as ad
from anndata import AnnData, Raw
from anndata._core import views
from anndata._core.index import _normalize_indices
from anndata._core.merge import intersect_keys
from anndata._core.sparse_dataset import _CSCDataset, _CSRDataset, sparse_dataset
from anndata._core.storage import _check_x_and_layers_are_2d_on_write
from anndata._io.utils import (
    _check_has_no_slash_key,
    check_key,
    zero_dim_array_as_scalar,
)
from anndata._types import StorageType
from anndata._warnings import OldFormatWarning
from anndata.compat import (
    AwkArray,
    CupyArray,
    CupyCSCMatrix,
    CupyCSRMatrix,
    DaskArray,
    _decode_structured_array,
    _from_fixed_length_strings,
    _read_attr,
    _require_group_write_dataframe,
)

from ..._settings import settings
from ...compat import PANDAS_STRING_ARRAY_TYPES
from ...utils import iter_outer, warn
from .registry import _REGISTRY, IOSpec, read_elem, read_elem_partial

if TYPE_CHECKING:
    from collections.abc import Generator, Iterator
    from os import PathLike
    from typing import Any, Literal

    from numpy import typing as npt
    from numpy.typing import NDArray

    from anndata._types import _ArrayStorageType, _GroupStorageType, _WriteInternal
    from anndata.compat import CSArray, CSMatrix, CupyCSMatrix
    from anndata.typing import AxisStorable, RWAble, _InMemoryArrayOrScalarType

    from .registry import Reader, Writer

####################
# Dask utils       #
####################

try:
    from dask.utils import SerializableLock as Lock
except ImportError:
    from threading import Lock

# to fix https://github.com/dask/distributed/issues/780
GLOBAL_LOCK = Lock()

####################
# Dispatch methods #
####################

# def is_full_slice(idx):
#     if isinstance(idx, tuple)len(idx) == 1:

#     if isinstance(idx, type(None)):
#         return True
#     elif idx is Ellipsis:
#         return True
#     elif isinstance(idx, tuple):
#         for el in idx:
#             if isinstance(el, type(None)):
#                 pass
#             elif isinstance(el, slice):
#                 if el != slice(None):
#                     return False
#             else:
#                 return False
#         return True
#     return False


def zarr_v3_compressor_compat(dataset_kwargs: dict) -> dict:
    """Handle mismatch between our compressor kwarg and :func:`zarr.create_array` in v3's `compressors` arg
    See https://zarr.readthedocs.io/en/stable/api/zarr/create/#zarr.create_array

    Parameters
    ----------
    dataset_kwargs
        The kwarg dict potentially containing "compressor"

    Returns
    -------
        The kwarg dict with "compressor" moved to "compressors" if zarr v3 is in use.
    """
    if "compressor" in dataset_kwargs:
        dataset_kwargs["compressors"] = dataset_kwargs.pop("compressor")
    return dataset_kwargs


@contextmanager
def zarr_v3_sharding(dataset_kwargs: dict, format: Literal[2, 3]) -> Generator[dict]:
    auto_sharding = (
        "shards" not in dataset_kwargs
        and ad.settings.auto_shard_zarr_v3
        and format == 3
    )
    if auto_sharding:
        dataset_kwargs = {**dataset_kwargs, "shards": "auto"}
    # Auto shard sizes are a relatively recent feature
    supports_auto_shard_size = Version(version("zarr")) >= Version("3.1.4")
    has_auto_shard_size = supports_auto_shard_size and isinstance(
        zarr.config.get("array.target_shard_size_bytes"), int
    )
    # 1GB uncompressed shard size seems reasonable.
    # Shards need to generally held completely in memory before writing.
    # Even at a compression ration of 6x, that's still a ~20x improvement on number of files.
    # Users can ovetrride this nonetheless, hence the above checks.
    with (
        zarr.config.set({"array.target_shard_size_bytes": 1_000_000_000})
        if supports_auto_shard_size and not has_auto_shard_size and auto_sharding
        else nullcontext()
    ):
        yield dataset_kwargs


def _to_cpu_mem_wrapper(write_func):
    """
    Wrapper to bring cupy types into cpu memory before writing.

    Ideally we do direct writing at some point.
    """

    def wrapper(
        f,
        k,
        cupy_val: CupyArray | CupyCSMatrix,
        *,
        _writer: Writer,
        dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
    ):
        return write_func(
            f, k, cupy_val.get(), _writer=_writer, dataset_kwargs=dataset_kwargs
        )

    return wrapper


def suppress_autoshard_warning[S: StorageType, T: RWAble](
    func: _WriteInternal[S, T],
) -> _WriteInternal[S, T]:
    @wraps(func)
    def wrapper(
        f: S,
        k: str,
        val: T,
        *,
        _writer: Writer,
        dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
    ):
        with warnings.catch_warnings():
            # Suppress warnings only if the user has opted into autosharding at the top level.
            # If someone provides `shards` explicitly, then they should get the warning.
            if ad.settings.auto_shard_zarr_v3 and "shards" not in dataset_kwargs:
                warnings.filterwarnings(
                    "ignore",
                    r"Automatic shard shape inference is experimental",
                    UserWarning,
                )
            return func(f, k, val, _writer=_writer, dataset_kwargs=dataset_kwargs)

    return wrapper


################################
# Fallbacks / backwards compat #
################################

# Note: there is no need for writing in a backwards compatible format, maybe


@_REGISTRY.register_read(h5py.File, IOSpec("", ""))
@_REGISTRY.register_read(h5py.Group, IOSpec("", ""))
@_REGISTRY.register_read(h5py.Dataset, IOSpec("", ""))
def read_basic(
    elem: h5py.File | h5py.Group | h5py.Dataset, *, _reader: Reader
) -> dict[str, _InMemoryArrayOrScalarType] | npt.NDArray | CSMatrix | CSArray:
    from anndata._io.h5ad import read_dataset

    msg = f"Element '{elem.name}' was written without encoding metadata."
    warn(msg, OldFormatWarning)

    if isinstance(elem, Mapping):
        # Backwards compat sparse arrays
        if "h5sparse_format" in elem.attrs:
            return sparse_dataset(elem).to_memory()
        return {k: _reader.read_elem(v) for k, v in dict(elem).items()}
    elif isinstance(elem, h5py.Dataset):
        return read_dataset(elem)  # TODO: Handle legacy


@_REGISTRY.register_read(zarr.Group, IOSpec("", ""))
@_REGISTRY.register_read(zarr.Array, IOSpec("", ""))
def read_basic_zarr(
    elem: zarr.Group | zarr.Array, *, _reader: Reader
) -> dict[str, _InMemoryArrayOrScalarType] | npt.NDArray | CSMatrix | CSArray:
    from anndata._io.zarr import read_dataset

    msg = f"Element '{elem.name}' was written without encoding metadata."
    warn(msg, OldFormatWarning)
    if isinstance(elem, zarr.Group):
        # Backwards compat sparse arrays
        if "h5sparse_format" in elem.attrs:
            return sparse_dataset(elem).to_memory()
        return {k: _reader.read_elem(v) for k, v in dict(elem).items()}
    elif isinstance(elem, zarr.Array):
        return read_dataset(elem)  # TODO: Handle legacy


# @_REGISTRY.register_read_partial(IOSpec("", ""))
# def read_basic_partial(elem, *, items=None, indices=(slice(None), slice(None))):
#     if isinstance(elem, Mapping):
#         return _read_partial(elem, items=items, indices=indices)
#     elif indices != (slice(None), slice(None)):
#         return elem[indices]
#     else:
#         return elem[()]


###########
# AnnData #
###########


def read_indices(group):
    obs_group = group["obs"]
    obs_idx_elem = obs_group[_read_attr(obs_group.attrs, "_index")]
    obs_idx = read_elem(obs_idx_elem)
    var_group = group["var"]
    var_idx_elem = var_group[_read_attr(var_group.attrs, "_index")]
    var_idx = read_elem(var_idx_elem)
    return obs_idx, var_idx


def read_partial(  # noqa: PLR0913
    pth: PathLike[str] | str,
    *,
    obs_idx=slice(None),
    var_idx=slice(None),
    X=True,
    obs=None,
    var=None,
    obsm=None,
    varm=None,
    obsp=None,
    varp=None,
    layers=None,
    uns=None,
) -> ad.AnnData:
    result = {}
    with h5py.File(pth, "r") as f:
        obs_idx, var_idx = _normalize_indices((obs_idx, var_idx), *read_indices(f))
        result["obs"] = read_elem_partial(
            f["obs"], items=obs, indices=(obs_idx, slice(None))
        )
        result["var"] = read_elem_partial(
            f["var"], items=var, indices=(var_idx, slice(None))
        )
        if X:
            result["X"] = read_elem_partial(f["X"], indices=(obs_idx, var_idx))
        else:
            result["X"] = sparse.csr_matrix((len(result["obs"]), len(result["var"])))
        if "obsm" in f:
            result["obsm"] = _read_partial(
                f["obsm"], items=obsm, indices=(obs_idx, slice(None))
            )
        if "varm" in f:
            result["varm"] = _read_partial(
                f["varm"], items=varm, indices=(var_idx, slice(None))
            )
        if "obsp" in f:
            result["obsp"] = _read_partial(
                f["obsp"], items=obsp, indices=(obs_idx, obs_idx)
            )
        if "varp" in f:
            result["varp"] = _read_partial(
                f["varp"], items=varp, indices=(var_idx, var_idx)
            )
        if "layers" in f:
            result["layers"] = _read_partial(
                f["layers"], items=layers, indices=(obs_idx, var_idx)
            )
        if "uns" in f:
            result["uns"] = _read_partial(f["uns"], items=uns)

    return ad.AnnData(**result)


def _read_partial(group, *, items=None, indices=(slice(None), slice(None))):
    if group is None:
        return None
    keys = intersect_keys((group,)) if items is None else intersect_keys((group, items))
    result = {}
    for k in keys:
        next_items = items.get(k, None) if isinstance(items, Mapping) else None
        result[k] = read_elem_partial(group[k], items=next_items, indices=indices)
    return result


@_REGISTRY.register_write(zarr.Group, AnnData, IOSpec("anndata", "0.1.0"))
@_REGISTRY.register_write(h5py.Group, AnnData, IOSpec("anndata", "0.1.0"))
@suppress_autoshard_warning
def write_anndata(
    f: _GroupStorageType,
    k: str,
    adata: AnnData,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    _check_x_and_layers_are_2d_on_write(adata)
    g = f.require_group(k)
    for sub_key, elem in iter_outer(adata):
        if sub_key == "X" and elem is None:
            continue
        _check_has_no_slash_key(sub_key, elem)
        if sub_key == "layers":
            if None in elem:
                _writer.write_elem(g, "X", elem[None], dataset_kwargs=dataset_kwargs)
            elem = {k: v for k, v in elem.items() if k is not None}
        _writer.write_elem(
            g,
            sub_key,
            dict(elem) if isinstance(elem, MutableMapping) else elem,
            dataset_kwargs=dataset_kwargs,
        )


@_REGISTRY.register_read(h5py.Group, IOSpec("anndata", "0.1.0"))
@_REGISTRY.register_read(h5py.Group, IOSpec("raw", "0.1.0"))
@_REGISTRY.register_read(h5py.File, IOSpec("anndata", "0.1.0"))
@_REGISTRY.register_read(h5py.File, IOSpec("raw", "0.1.0"))
@_REGISTRY.register_read(zarr.Group, IOSpec("anndata", "0.1.0"))
@_REGISTRY.register_read(zarr.Group, IOSpec("raw", "0.1.0"))
def read_anndata(elem: _GroupStorageType | h5py.File, *, _reader: Reader) -> AnnData:
    d = {}
    for k in [
        "X",
        "obs",
        "var",
        "obsm",
        "varm",
        "obsp",
        "varp",
        "layers",
        "uns",
        "raw",
    ]:
        if k in elem:
            d[k] = _reader.read_elem(elem[k])
    # Older / non-conforming files may contain higher-dimensional `X` or
    # `layers`; the on-disk spec forbids that. We don't block reading,
    # but the AnnData setters surface the spec violation as a warning
    # during construction below.
    return AnnData(**d)


@_REGISTRY.register_write(h5py.Group, Raw, IOSpec("raw", "0.1.0"))
@_REGISTRY.register_write(zarr.Group, Raw, IOSpec("raw", "0.1.0"))
@suppress_autoshard_warning
def write_raw(
    f: _GroupStorageType,
    k: str,
    raw: Raw,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    g = f.require_group(k)
    _writer.write_elem(g, "X", raw.X, dataset_kwargs=dataset_kwargs)
    _writer.write_elem(g, "var", raw.var, dataset_kwargs=dataset_kwargs)
    _writer.write_elem(g, "varm", dict(raw.varm), dataset_kwargs=dataset_kwargs)


########
# Null #
########


@_REGISTRY.register_read(h5py.Dataset, IOSpec("null", "0.1.0"))
@_REGISTRY.register_read(zarr.Array, IOSpec("null", "0.1.0"))
def read_null(_elem, _reader) -> None:
    return None


@_REGISTRY.register_write(h5py.Group, type(None), IOSpec("null", "0.1.0"))
def write_null_h5py(f, k, _v, _writer, dataset_kwargs=MappingProxyType({})):
    dataset_kwargs = _remove_scalar_compression_args(dataset_kwargs)
    f.create_dataset(k, data=h5py.Empty("f"), **dataset_kwargs)


@_REGISTRY.register_write(zarr.Group, type(None), IOSpec("null", "0.1.0"))
@suppress_autoshard_warning
def write_null_zarr(f, k, _v, _writer, dataset_kwargs=MappingProxyType({})):
    dataset_kwargs = _remove_scalar_compression_args(dataset_kwargs)
    # zarr has no first-class null dataset
    # TODO: why is this not actually storing the empty info with a f.empty call?
    # It fails complaining that k doesn't exist when updating the attributes.
    f.create_array(k, shape=(), dtype="bool")


############
# Mappings #
############


@_REGISTRY.register_read(h5py.Group, IOSpec("dict", "0.1.0"))
@_REGISTRY.register_read(zarr.Group, IOSpec("dict", "0.1.0"))
def read_mapping(
    elem: _GroupStorageType, *, _reader: Reader
) -> dict[str, AxisStorable]:
    return {k: _reader.read_elem(v) for k, v in dict(elem).items()}


@_REGISTRY.register_write(h5py.Group, dict, IOSpec("dict", "0.1.0"))
@_REGISTRY.register_write(zarr.Group, dict, IOSpec("dict", "0.1.0"))
@suppress_autoshard_warning
def write_mapping(
    f: _GroupStorageType,
    k: str,
    v: dict[str, AxisStorable],
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    g = f.require_group(k)
    for sub_k, sub_v in v.items():
        _writer.write_elem(g, sub_k, sub_v, dataset_kwargs=dataset_kwargs)


##############
# np.ndarray #
##############


@_REGISTRY.register_write(h5py.Group, list, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, list, IOSpec("array", "0.2.0"))
@suppress_autoshard_warning
def write_list(
    f: _GroupStorageType,
    k: str,
    elem: list[AxisStorable],
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    _writer.write_elem(f, k, np.array(elem), dataset_kwargs=dataset_kwargs)


# TODO: Is this the right behavior for MaskedArrays?
# It's in the `AnnData.concatenate` docstring, but should we keep it?
@_REGISTRY.register_write(h5py.Group, views.ArrayView, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(h5py.Group, np.ndarray, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(h5py.Group, np.ma.MaskedArray, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, views.ArrayView, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, np.ndarray, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, np.ma.MaskedArray, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, zarr.Array, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, h5py.Dataset, IOSpec("array", "0.2.0"))
@suppress_autoshard_warning
@zero_dim_array_as_scalar
def write_basic(
    f: _GroupStorageType,
    k: str,
    elem: views.ArrayView | np.ndarray | h5py.Dataset | np.ma.MaskedArray | zarr.Array,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    """Write methods which underlying library handles natively."""
    dataset_kwargs = dict(dataset_kwargs)
    dtype = dataset_kwargs.pop("dtype", elem.dtype)
    if isinstance(f, h5py.Group):
        f.create_dataset(k, data=elem, shape=elem.shape, dtype=dtype, **dataset_kwargs)
    else:
        dataset_kwargs = zarr_v3_compressor_compat(dataset_kwargs)
        with zarr_v3_sharding(
            dataset_kwargs, format=f.metadata.zarr_format
        ) as dataset_kwargs:
            f.create_array(k, shape=elem.shape, dtype=dtype, **dataset_kwargs)
        # see https://github.com/zarr-developers/zarr-python/discussions/2712
        if isinstance(elem, zarr.Array | h5py.Dataset):
            f[k][...] = elem[...]
        else:
            f[k][...] = elem


def _iter_chunks_for_copy(
    elem: _ArrayStorageType, dest: _ArrayStorageType
) -> Iterator[slice | tuple[list[slice]]]:
    """
    Returns an iterator of tuples of slices for copying chunks from `elem` to `dest`.

    * If `dest` has chunks, it will return the chunks of `dest`.
    * If `dest` is not chunked, we write it in ~100MB chunks or 1000 rows, whichever is larger.
    """
    if dest.chunks and hasattr(dest, "iter_chunks"):
        return dest.iter_chunks()
    else:
        shape = elem.shape
        # Number of rows that works out to
        n_rows = max(
            ad.settings.min_rows_for_chunked_h5_copy,
            elem.chunks[0] if elem.chunks is not None else 1,
        )
        return (slice(i, min(i + n_rows, shape[0])) for i in range(0, shape[0], n_rows))


@_REGISTRY.register_write(h5py.Group, h5py.Dataset, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(h5py.Group, zarr.Array, IOSpec("array", "0.2.0"))
def write_chunked_dense_array_to_group(
    f: h5py.Group,
    k: str,
    elem: _ArrayStorageType,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    """Write to a h5py.Dataset in chunks.

    `h5py.Group.create_dataset(..., data: h5py.Dataset)` will load all of `data` into memory
    before writing. Instead, we will write in chunks to avoid this. We don't need to do this for
    zarr since zarr handles this automatically.
    """
    dtype = dataset_kwargs.get("dtype", elem.dtype)
    kwargs = {**dataset_kwargs, "dtype": dtype}
    dest = f.create_dataset(k, shape=elem.shape, **kwargs)

    for chunk in _iter_chunks_for_copy(elem, dest):
        dest[chunk] = elem[chunk]


_REGISTRY.register_write(h5py.Group, CupyArray, IOSpec("array", "0.2.0"))(
    _to_cpu_mem_wrapper(write_basic)
)
_REGISTRY.register_write(zarr.Group, CupyArray, IOSpec("array", "0.2.0"))(
    suppress_autoshard_warning(_to_cpu_mem_wrapper(write_basic))
)


@_REGISTRY.register_write(zarr.Group, views.DaskArrayView, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, DaskArray, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(h5py.Group, views.DaskArrayView, IOSpec("array", "0.2.0"))
@_REGISTRY.register_write(h5py.Group, DaskArray, IOSpec("array", "0.2.0"))
@suppress_autoshard_warning
def write_basic_dask_dask_dense(
    f: zarr.Group | h5py.Group,
    k: str,
    elem: DaskArray,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    import dask.array as da

    dataset_kwargs = dict(dataset_kwargs)
    is_h5 = isinstance(f, h5py.Group)
    if not is_h5:
        dataset_kwargs = zarr_v3_compressor_compat(dataset_kwargs)
    if is_h5:
        g = f.require_dataset(k, shape=elem.shape, dtype=elem.dtype, **dataset_kwargs)
    else:
        with zarr_v3_sharding(
            dataset_kwargs, format=f.metadata.zarr_format
        ) as dataset_kwargs:
            g = f.require_array(k, shape=elem.shape, dtype=elem.dtype, **dataset_kwargs)
    da.store(elem, g, scheduler="threads")


@_REGISTRY.register_read(h5py.Dataset, IOSpec("array", "0.2.0"))
@_REGISTRY.register_read(zarr.Array, IOSpec("array", "0.2.0"))
@_REGISTRY.register_read(zarr.Array, IOSpec("string-array", "0.2.0"))
def read_array(elem: _ArrayStorageType, *, _reader: Reader) -> npt.NDArray:
    return elem[()]


@_REGISTRY.register_read_partial(h5py.Dataset, IOSpec("array", "0.2.0"))
@_REGISTRY.register_read_partial(zarr.Array, IOSpec("string-array", "0.2.0"))
def read_array_partial(elem, *, items=None, indices=(slice(None, None))):
    return elem[indices]


@_REGISTRY.register_read_partial(zarr.Array, IOSpec("array", "0.2.0"))
def read_zarr_array_partial(elem, *, items=None, indices=(slice(None, None))):
    return elem.oindex[indices]


# arrays of strings
@_REGISTRY.register_read(h5py.Dataset, IOSpec("string-array", "0.2.0"))
def read_string_array(d: h5py.Dataset, *, _reader: Reader):
    return read_array(d.asstr(), _reader=_reader)


@_REGISTRY.register_read_partial(h5py.Dataset, IOSpec("string-array", "0.2.0"))
def read_string_array_partial(d, items=None, indices=slice(None)):
    return read_array_partial(d.asstr(), items=items, indices=indices)


@_REGISTRY.register_write(
    h5py.Group, (views.ArrayView, "U"), IOSpec("string-array", "0.2.0")
)
@_REGISTRY.register_write(
    h5py.Group, (views.ArrayView, "O"), IOSpec("string-array", "0.2.0")
)
@_REGISTRY.register_write(
    h5py.Group, (np.ndarray, "U"), IOSpec("string-array", "0.2.0")
)
@_REGISTRY.register_write(
    h5py.Group, (np.ndarray, "O"), IOSpec("string-array", "0.2.0")
)
@_REGISTRY.register_write(
    h5py.Group, (np.ndarray, "T"), IOSpec("string-array", "0.2.0")
)
@zero_dim_array_as_scalar
def write_vlen_string_array(
    f: h5py.Group,
    k: str,
    elem: np.ndarray,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    """Write methods which underlying library handles nativley."""
    str_dtype = h5py.special_dtype(vlen=str)
    f.create_dataset(k, data=elem.astype(str_dtype), dtype=str_dtype, **dataset_kwargs)


@_REGISTRY.register_write(
    zarr.Group, (views.ArrayView, "U"), IOSpec("string-array", "0.2.0")
)
@_REGISTRY.register_write(
    zarr.Group, (views.ArrayView, "O"), IOSpec("string-array", "0.2.0")
)
@_REGISTRY.register_write(
    zarr.Group, (np.ndarray, "U"), IOSpec("string-array", "0.2.0")
)
@_REGISTRY.register_write(
    zarr.Group, (np.ndarray, "O"), IOSpec("string-array", "0.2.0")
)
@_REGISTRY.register_write(
    zarr.Group, (np.ndarray, "T"), IOSpec("string-array", "0.2.0")
)
@suppress_autoshard_warning
@zero_dim_array_as_scalar
def write_vlen_string_array_zarr(
    f: zarr.Group,
    k: str,
    elem: np.ndarray,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    dataset_kwargs = dict(dataset_kwargs)
    dataset_kwargs = zarr_v3_compressor_compat(dataset_kwargs)
    dtype = VariableLengthUTF8()
    filters, fill_value = None, None
    if f.metadata.zarr_format == 2:
        filters, fill_value = [VLenUTF8()], ""
    with zarr_v3_sharding(
        dataset_kwargs, format=f.metadata.zarr_format
    ) as dataset_kwargs:
        f.create_array(
            k,
            shape=elem.shape,
            dtype=dtype,
            filters=filters,
            fill_value=fill_value,
            **dataset_kwargs,
        )
    f[k][:] = elem


###############
# np.recarray #
###############


def _to_hdf5_vlen_strings(value: np.ndarray) -> np.ndarray:
    """This corrects compound dtypes to work with hdf5 files."""
    new_dtype = []
    for dt_name, (dt_type, _) in value.dtype.fields.items():
        if dt_type.kind in {"U", "O"}:
            new_dtype.append((dt_name, h5py.special_dtype(vlen=str)))
        else:
            new_dtype.append((dt_name, dt_type))
    return value.astype(new_dtype)


@_REGISTRY.register_read(h5py.Dataset, IOSpec("rec-array", "0.2.0"))
@_REGISTRY.register_read(zarr.Array, IOSpec("rec-array", "0.2.0"))
def read_recarray(
    d: _ArrayStorageType, *, _reader: Reader
) -> np.recarray | npt.NDArray:
    value = d[()]
    value = _decode_structured_array(
        _from_fixed_length_strings(value), dtype=value.dtype
    )
    return value


@_REGISTRY.register_write(h5py.Group, (np.ndarray, "V"), IOSpec("rec-array", "0.2.0"))
@_REGISTRY.register_write(h5py.Group, np.recarray, IOSpec("rec-array", "0.2.0"))
def write_recarray(
    f: h5py.Group,
    k: str,
    elem: np.ndarray | np.recarray,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    f.create_dataset(k, data=_to_hdf5_vlen_strings(elem), **dataset_kwargs)


@_REGISTRY.register_write(zarr.Group, (np.ndarray, "V"), IOSpec("rec-array", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, np.recarray, IOSpec("rec-array", "0.2.0"))
def write_recarray_zarr(
    f: zarr.Group,
    k: str,
    elem: np.ndarray | np.recarray,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    from anndata.compat import _to_fixed_length_strings

    elem = _to_fixed_length_strings(elem)
    dataset_kwargs = dict(dataset_kwargs)
    dataset_kwargs = zarr_v3_compressor_compat(dataset_kwargs)
    # https://github.com/zarr-developers/zarr-python/issues/3546
    # with zarr_v3_sharding(
    #     dataset_kwargs, format=f.metadata.zarr_format
    # ) as dataset_kwargs:
    f.create_array(k, shape=elem.shape, dtype=elem.dtype, **dataset_kwargs)
    f[k][...] = elem


#################
# Sparse arrays #
#################


def write_sparse_compressed(
    f: _GroupStorageType,
    key: str,
    value: CSMatrix | CSArray,
    *,
    _writer: Writer,
    fmt: Literal["csr", "csc"],
    dataset_kwargs=MappingProxyType({}),
):
    g = f.require_group(key)
    g.attrs["shape"] = value.shape
    dataset_kwargs = dict(dataset_kwargs)
    indptr_dtype = dataset_kwargs.pop("indptr_dtype", value.indptr.dtype)

    # Allow resizing for hdf5
    if isinstance(f, h5py.Group):
        dataset_kwargs = dict(maxshape=(None,), **dataset_kwargs)
    dataset_kwargs = zarr_v3_compressor_compat(dataset_kwargs)

    for attr_name in ["data", "indices", "indptr"]:
        attr = getattr(value, attr_name)
        dtype = indptr_dtype if attr_name == "indptr" else attr.dtype
        if (
            attr_name == "indices"
            and settings.write_csr_csc_indices_with_min_possible_dtype
        ):
            # np.min_scalar_type can return things like np.ulonglong which zarr doesn't understand
            # and I find this clearer as to what the result type is i.e., unsigned or signed.
            # For example `np.iinfo(np.uint16).max + 1` could be either `uint32` or `int32`,
            # and there's nothing in numpy's docs disallowing this output to change.
            if (minor_axis_size := value.shape[value.format == "csr"]) <= np.iinfo(
                np.uint8
            ).max:
                dtype = np.dtype("uint8")
            elif minor_axis_size <= np.iinfo(np.uint16).max:
                dtype = np.dtype("uint16")
            elif minor_axis_size <= np.iinfo(np.uint32).max:
                dtype = np.dtype("uint32")
            elif minor_axis_size <= np.iinfo(np.uint64).max:
                dtype = np.dtype("uint64")
        if isinstance(f, h5py.Group):
            g.create_dataset(
                attr_name, data=attr, shape=attr.shape, dtype=dtype, **dataset_kwargs
            )
        else:
            with zarr_v3_sharding(
                dataset_kwargs, format=f.metadata.zarr_format
            ) as dataset_kwargs_local:
                arr = g.create_array(
                    attr_name, shape=attr.shape, dtype=dtype, **dataset_kwargs_local
                )
            # see https://github.com/zarr-developers/zarr-python/discussions/2712
            arr[...] = attr[...]


write_csr, write_csc = (
    suppress_autoshard_warning(partial(write_sparse_compressed, fmt=fmt))
    for fmt in ["csr", "csc"]
)

for store_type, (cls, spec, func) in product(
    (h5py.Group, zarr.Group),
    [
        # spmatrix
        (sparse.csr_matrix, IOSpec("csr_matrix", "0.1.0"), write_csr),
        (views.SparseCSRMatrixView, IOSpec("csr_matrix", "0.1.0"), write_csr),
        (sparse.csc_matrix, IOSpec("csc_matrix", "0.1.0"), write_csc),
        (views.SparseCSCMatrixView, IOSpec("csc_matrix", "0.1.0"), write_csc),
        # sparray
        (sparse.csr_array, IOSpec("csr_matrix", "0.1.0"), write_csr),
        (views.SparseCSRArrayView, IOSpec("csr_matrix", "0.1.0"), write_csr),
        (sparse.csc_array, IOSpec("csc_matrix", "0.1.0"), write_csc),
        (views.SparseCSCArrayView, IOSpec("csc_matrix", "0.1.0"), write_csc),
        # cupy spmatrix
        (CupyCSRMatrix, IOSpec("csr_matrix", "0.1.0"), _to_cpu_mem_wrapper(write_csr)),
        (
            views.CupySparseCSRView,
            IOSpec("csr_matrix", "0.1.0"),
            _to_cpu_mem_wrapper(write_csr),
        ),
        (CupyCSCMatrix, IOSpec("csc_matrix", "0.1.0"), _to_cpu_mem_wrapper(write_csc)),
        (
            views.CupySparseCSCView,
            IOSpec("csc_matrix", "0.1.0"),
            _to_cpu_mem_wrapper(write_csc),
        ),
    ],
):
    _REGISTRY.register_write(store_type, cls, spec)(func)


@_REGISTRY.register_write(h5py.Group, _CSRDataset, IOSpec("csr_matrix", "0.1.0"))
@_REGISTRY.register_write(h5py.Group, _CSCDataset, IOSpec("csc_matrix", "0.1.0"))
@_REGISTRY.register_write(zarr.Group, _CSRDataset, IOSpec("csr_matrix", "0.1.0"))
@_REGISTRY.register_write(zarr.Group, _CSCDataset, IOSpec("csc_matrix", "0.1.0"))
@suppress_autoshard_warning
def write_sparse_dataset(
    f: _GroupStorageType,
    k: str,
    elem: _CSCDataset | _CSRDataset,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    write_sparse_compressed(
        f,
        k,
        elem._to_backed(),
        _writer=_writer,
        fmt=elem.format,
        dataset_kwargs=dataset_kwargs,
    )


def write_cupy_dask(f, k, elem, _writer, dataset_kwargs=MappingProxyType({})):
    _writer.write_elem(
        f,
        k,
        elem.map_blocks(lambda x: x.get(), dtype=elem.dtype, meta=elem._meta.get()),
        dataset_kwargs=dataset_kwargs,
    )


def write_dask_sparse(
    f: _GroupStorageType,
    k: str,
    elem: DaskArray,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    sparse_format = elem._meta.format

    def as_int64_indices(x):
        x.indptr = x.indptr.astype(np.int64, copy=False)
        x.indices = x.indices.astype(np.int64, copy=False)
        return x

    if sparse_format == "csr":
        axis = 0
    elif sparse_format == "csc":
        axis = 1
    else:
        msg = f"Cannot write dask sparse arrays with format {sparse_format}"
        raise NotImplementedError(msg)

    def chunk_slice(start: int, stop: int) -> tuple[slice | None, slice | None]:
        result = [slice(None), slice(None)]
        result[axis] = slice(start, stop)
        return tuple(result)

    axis_chunks = elem.chunks[axis]
    chunk_start = 0
    chunk_stop = axis_chunks[0]

    _writer.write_elem(
        f,
        k,
        as_int64_indices(elem[chunk_slice(chunk_start, chunk_stop)].compute()),
        dataset_kwargs=dataset_kwargs,
    )

    disk_mtx = sparse_dataset(f[k])

    for chunk_size in axis_chunks[1:]:
        chunk_start = chunk_stop
        chunk_stop += chunk_size

        disk_mtx.append(elem[chunk_slice(chunk_start, chunk_stop)].compute())


for array_type, group_type in product(
    [DaskArray, views.DaskArrayView], [h5py.Group, zarr.Group]
):
    for cupy_array_type, spec in [
        (CupyArray, IOSpec("array", "0.2.0")),
        (CupyCSCMatrix, IOSpec("csc_matrix", "0.1.0")),
        (CupyCSRMatrix, IOSpec("csr_matrix", "0.1.0")),
    ]:
        _REGISTRY.register_write(group_type, (array_type, cupy_array_type), spec)(
            write_cupy_dask
        )
    for scipy_sparse_type, spec in [
        (sparse.csr_matrix, IOSpec("csr_matrix", "0.1.0")),
        (sparse.csc_matrix, IOSpec("csc_matrix", "0.1.0")),
        (sparse.csr_array, IOSpec("csr_matrix", "0.1.0")),
        (sparse.csc_array, IOSpec("csc_matrix", "0.1.0")),
    ]:
        _REGISTRY.register_write(group_type, (array_type, scipy_sparse_type), spec)(
            write_dask_sparse
        )


@_REGISTRY.register_read(h5py.Group, IOSpec("csc_matrix", "0.1.0"))
@_REGISTRY.register_read(h5py.Group, IOSpec("csr_matrix", "0.1.0"))
@_REGISTRY.register_read(zarr.Group, IOSpec("csc_matrix", "0.1.0"))
@_REGISTRY.register_read(zarr.Group, IOSpec("csr_matrix", "0.1.0"))
def read_sparse(elem: _GroupStorageType, *, _reader: Reader) -> CSMatrix | CSArray:
    return sparse_dataset(elem).to_memory()


@_REGISTRY.register_read_partial(h5py.Group, IOSpec("csc_matrix", "0.1.0"))
@_REGISTRY.register_read_partial(h5py.Group, IOSpec("csr_matrix", "0.1.0"))
@_REGISTRY.register_read_partial(zarr.Group, IOSpec("csc_matrix", "0.1.0"))
@_REGISTRY.register_read_partial(zarr.Group, IOSpec("csr_matrix", "0.1.0"))
def read_sparse_partial(elem, *, items=None, indices=(slice(None), slice(None))):
    return sparse_dataset(elem)[indices]


#################
# Awkward array #
#################


@_REGISTRY.register_write(h5py.Group, AwkArray, IOSpec("awkward-array", "0.1.0"))
@_REGISTRY.register_write(zarr.Group, AwkArray, IOSpec("awkward-array", "0.1.0"))
@_REGISTRY.register_write(
    h5py.Group, views.AwkwardArrayView, IOSpec("awkward-array", "0.1.0")
)
@_REGISTRY.register_write(
    zarr.Group, views.AwkwardArrayView, IOSpec("awkward-array", "0.1.0")
)
@suppress_autoshard_warning
def write_awkward(
    f: _GroupStorageType,
    k: str,
    v: views.AwkwardArrayView | AwkArray,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    from anndata.compat import awkward as ak

    group = f.require_group(k)
    del k
    if isinstance(v, views.AwkwardArrayView):
        # copy to remove the view attributes
        v = copy(v)
    form, length, container = ak.to_buffers(ak.to_packed(v))
    group.attrs["length"] = length
    group.attrs["form"] = form.to_json()
    for k, v in container.items():
        _writer.write_elem(group, k, v, dataset_kwargs=dataset_kwargs)


@_REGISTRY.register_read(h5py.Group, IOSpec("awkward-array", "0.1.0"))
@_REGISTRY.register_read(zarr.Group, IOSpec("awkward-array", "0.1.0"))
def read_awkward(elem: _GroupStorageType, *, _reader: Reader) -> AwkArray:
    from anndata.compat import awkward as ak

    form = _read_attr(elem.attrs, "form")
    length = _read_attr(elem.attrs, "length")
    container = {k: _reader.read_elem(elem[k]) for k in elem}

    return ak.from_buffers(form, int(length), container)


##############
# DataFrames #
##############


@_REGISTRY.register_write(h5py.Group, views.DataFrameView, IOSpec("dataframe", "0.2.0"))
@_REGISTRY.register_write(h5py.Group, pd.DataFrame, IOSpec("dataframe", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, views.DataFrameView, IOSpec("dataframe", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, pd.DataFrame, IOSpec("dataframe", "0.2.0"))
@suppress_autoshard_warning
def write_dataframe(
    f: _GroupStorageType,
    key: str,
    df: views.DataFrameView | pd.DataFrame,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    # Check arguments
    for reserved in ("_index",):
        if reserved in df.columns:
            msg = f"{reserved!r} is a reserved name for dataframe columns."
            raise ValueError(msg)
    group = _require_group_write_dataframe(f, key, df)
    if not df.columns.is_unique:
        duplicates = list(df.columns[df.columns.duplicated()])
        msg = f"Found repeated column names: {duplicates}. Column names must be unique."
        raise ValueError(msg)
    col_names = [check_key(c) for c in df.columns]
    group.attrs["column-order"] = col_names

    if df.index.name is not None:
        if df.index.name in col_names and not pd.Series(
            df.index, index=df.index
        ).equals(df[df.index.name]):
            msg = (
                f"DataFrame.index.name ({df.index.name!r}) is also used by a column "
                "whose values are different. This is not supported. Please make sure "
                "the values are the same, or use a different name."
            )
            raise ValueError(msg)
        index_name = df.index.name
    else:
        index_name = "_index"
    group.attrs["_index"] = check_key(index_name)

    # ._values is "the best" array representation. It's the true array backing the
    # object, where `.values` is always a np.ndarray and .array is always a pandas
    # array.
    _writer.write_elem(
        group, index_name, df.index._values, dataset_kwargs=dataset_kwargs
    )
    for colname, series in df.items():
        # TODO: this should write the "true" representation of the series (i.e. the underlying array or ndarray depending)
        _writer.write_elem(
            group, colname, series._values, dataset_kwargs=dataset_kwargs
        )


@_REGISTRY.register_read(h5py.Group, IOSpec("dataframe", "0.2.0"))
@_REGISTRY.register_read(zarr.Group, IOSpec("dataframe", "0.2.0"))
def read_dataframe(elem: _GroupStorageType, *, _reader: Reader) -> pd.DataFrame:
    columns = list(_read_attr(elem.attrs, "column-order"))
    idx_key = _read_attr(elem.attrs, "_index")
    df = pd.DataFrame(
        {k: _reader.read_elem(elem[k]) for k in columns},
        index=_reader.read_elem(elem[idx_key]),
        columns=columns if columns else None,
    )
    if idx_key != "_index":
        df.index.name = idx_key
    return df


# TODO: Figure out what indices is allowed to be at each element
@_REGISTRY.register_read_partial(h5py.Group, IOSpec("dataframe", "0.2.0"))
@_REGISTRY.register_read_partial(zarr.Group, IOSpec("dataframe", "0.2.0"))
def read_dataframe_partial(
    elem, *, items=None, indices=(slice(None, None), slice(None, None))
):
    if items is not None:
        columns = [
            col for col in _read_attr(elem.attrs, "column-order") if col in items
        ]
    else:
        columns = list(_read_attr(elem.attrs, "column-order"))
    idx_key = _read_attr(elem.attrs, "_index")
    df = pd.DataFrame(
        {k: read_elem_partial(elem[k], indices=indices[0]) for k in columns},
        index=read_elem_partial(elem[idx_key], indices=indices[0]),
        columns=columns if columns else None,
    )
    if idx_key != "_index":
        df.index.name = idx_key
    return df


# Backwards compat dataframe reading


@_REGISTRY.register_read(h5py.Group, IOSpec("dataframe", "0.1.0"))
@_REGISTRY.register_read(zarr.Group, IOSpec("dataframe", "0.1.0"))
def read_dataframe_0_1_0(elem: _GroupStorageType, *, _reader: Reader) -> pd.DataFrame:
    columns = _read_attr(elem.attrs, "column-order")
    idx_key = _read_attr(elem.attrs, "_index")
    df = pd.DataFrame(
        {k: read_series(elem[k]) for k in columns},
        index=read_series(elem[idx_key]),
        columns=columns if len(columns) else None,
    )
    if idx_key != "_index":
        df.index.name = idx_key
    return df


def read_series(dataset: h5py.Dataset) -> np.ndarray | pd.Categorical:
    # For reading older dataframes
    if "categories" in dataset.attrs:
        if isinstance(dataset, zarr.Array):
            parent_name = dataset.name.rstrip(dataset.basename).strip("/")
            parent = zarr.open(dataset.store, mode="r")[parent_name]
        else:
            parent = dataset.parent
        categories_dset = parent[_read_attr(dataset.attrs, "categories")]
        categories = read_elem(categories_dset)
        ordered = bool(_read_attr(categories_dset.attrs, "ordered", default=False))
        return pd.Categorical.from_codes(
            read_elem(dataset), categories, ordered=ordered
        )
    else:
        return read_elem(dataset)


@_REGISTRY.register_read_partial(h5py.Group, IOSpec("dataframe", "0.1.0"))
@_REGISTRY.register_read_partial(zarr.Group, IOSpec("dataframe", "0.1.0"))
def read_partial_dataframe_0_1_0(
    elem, *, items=None, indices=(slice(None), slice(None))
):
    items = slice(None) if items is None else list(items)
    return read_elem(elem)[items].iloc[indices[0]]


###############
# Categorical #
###############


@_REGISTRY.register_write(h5py.Group, pd.Categorical, IOSpec("categorical", "0.2.0"))
@_REGISTRY.register_write(zarr.Group, pd.Categorical, IOSpec("categorical", "0.2.0"))
@suppress_autoshard_warning
def write_categorical(
    f: _GroupStorageType,
    k: str,
    v: pd.Categorical,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    g = f.require_group(k)
    g.attrs["ordered"] = bool(v.ordered)

    _writer.write_elem(g, "codes", v.codes, dataset_kwargs=dataset_kwargs)
    _writer.write_elem(
        g,
        "categories",
        v.categories.to_numpy(),
        dataset_kwargs=dataset_kwargs,
    )


@_REGISTRY.register_read(h5py.Group, IOSpec("categorical", "0.2.0"))
@_REGISTRY.register_read(zarr.Group, IOSpec("categorical", "0.2.0"))
def read_categorical(elem: _GroupStorageType, *, _reader: Reader) -> pd.Categorical:
    return pd.Categorical.from_codes(
        codes=_reader.read_elem(elem["codes"]),
        categories=_reader.read_elem(elem["categories"]),
        ordered=bool(_read_attr(elem.attrs, "ordered")),
    )


@_REGISTRY.register_read_partial(h5py.Group, IOSpec("categorical", "0.2.0"))
@_REGISTRY.register_read_partial(zarr.Group, IOSpec("categorical", "0.2.0"))
def read_partial_categorical(elem, *, items=None, indices=(slice(None),)):
    return pd.Categorical.from_codes(
        codes=read_elem_partial(elem["codes"], indices=indices),
        categories=read_elem(elem["categories"]),
        ordered=bool(_read_attr(elem.attrs, "ordered")),
    )


####################
# Pandas nullables #
####################


@_REGISTRY.register_write(
    h5py.Group, pd.arrays.IntegerArray, IOSpec("nullable-integer", "0.1.0")
)
@_REGISTRY.register_write(
    zarr.Group, pd.arrays.IntegerArray, IOSpec("nullable-integer", "0.1.0")
)
@_REGISTRY.register_write(
    h5py.Group, pd.arrays.BooleanArray, IOSpec("nullable-boolean", "0.1.0")
)
@_REGISTRY.register_write(
    zarr.Group, pd.arrays.BooleanArray, IOSpec("nullable-boolean", "0.1.0")
)
def write_nullable(
    f: _GroupStorageType,
    k: str,
    v: pd.arrays.IntegerArray
    | pd.arrays.BooleanArray
    | pd.arrays.StringArray
    | pd.arrays.ArrowStringArray,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
) -> None:
    if isinstance(v, pd.arrays.StringArray | pd.arrays.ArrowStringArray):
        # if explicitly set to `False`, we try writing them as non-nullable string array
        if settings.allow_write_nullable_strings is False:
            if v.isna().any():
                msg = (
                    "Cannot write `pd.arrays.[Arrow]StringArray` with missing values "
                    "when `anndata.settings.allow_write_nullable_strings` is set to False. "
                    "Opt-in to writing these arrays by toggling it to True or remove missing values."
                )
                raise ValueError(msg)
            # This works since there are no missing values. Otherwise, we’d need to be very careful.
            # TODO: check if the cost of creating a numpy "T" string array here would amortize when writing
            _writer.write_elem(f, k, np.asarray(v), dataset_kwargs=dataset_kwargs)
            return

        # if implicitly set to `False`, we error out
        if (
            settings.allow_write_nullable_strings is None
            and not pd.options.future.infer_string
        ):
            msg = (
                "`anndata.settings.allow_write_nullable_strings` is None and "
                "`pd.options.future.infer_string` is False. "
                "Opt-in to writing these arrays by toggling either setting to True, "
                "or make `anndata` attempt to write the non-nullable format supported by "
                "anndata < 0.11 by setting `anndata.settings.allow_write_nullable_strings` to False."
            )
            raise RuntimeError(msg)

    g = f.require_group(k)
    if isinstance(v, pd.arrays.StringArray | pd.arrays.ArrowStringArray):
        if v.dtype.na_value is pd.NA:
            g.attrs["na-value"] = "NA"
        elif np.isnan(v.dtype.na_value):
            g.attrs["na-value"] = "NaN"
        else:
            msg = f"Cannot write {v.dtype.na_value} as na_value for pandas StringArray"
            raise ValueError(msg)
    values = (
        v.to_numpy(na_value="")
        if isinstance(v, pd.arrays.StringArray | pd.arrays.ArrowStringArray)
        else v.to_numpy(na_value=0, dtype=v.dtype.numpy_dtype)
    )
    _writer.write_elem(g, "values", values, dataset_kwargs=dataset_kwargs)
    _writer.write_elem(g, "mask", v.isna(), dataset_kwargs=dataset_kwargs)


for store_type, array_type in product(
    [h5py.Group, zarr.Group], PANDAS_STRING_ARRAY_TYPES
):
    _REGISTRY.register_write(
        store_type, array_type, IOSpec("nullable-string-array", "0.1.0")
    )(write_nullable)


class _BaseMaskedArray(Protocol):
    def __call__(
        self, values: NDArray[np.number], /, *, mask: NDArray[np.bool_]
    ) -> pd.api.extensions.ExtensionArray: ...


def _read_nullable(
    elem: _GroupStorageType, *, _reader: Reader, array_type: _BaseMaskedArray
) -> pd.api.extensions.ExtensionArray:
    return array_type(
        _reader.read_elem(elem["values"]),
        mask=_reader.read_elem(elem["mask"]),
    )


_REGISTRY.register_read(h5py.Group, IOSpec("nullable-integer", "0.1.0"))(
    read_nullable_integer := partial(_read_nullable, array_type=pd.arrays.IntegerArray)
)
_REGISTRY.register_read(zarr.Group, IOSpec("nullable-integer", "0.1.0"))(
    read_nullable_integer
)

_REGISTRY.register_read(h5py.Group, IOSpec("nullable-boolean", "0.1.0"))(
    read_nullable_boolean := partial(_read_nullable, array_type=pd.arrays.BooleanArray)
)
_REGISTRY.register_read(zarr.Group, IOSpec("nullable-boolean", "0.1.0"))(
    read_nullable_boolean
)


@_REGISTRY.register_read(h5py.Group, IOSpec("nullable-string-array", "0.1.0"))
@_REGISTRY.register_read(zarr.Group, IOSpec("nullable-string-array", "0.1.0"))
def _read_nullable_string(
    elem: _GroupStorageType, *, _reader: Reader
) -> pd.api.extensions.ExtensionArray:
    values = _reader.read_elem(elem["values"])
    mask = _reader.read_elem(elem["mask"])
    dtype = pd.StringDtype(
        na_value=np.nan
        if _read_attr(elem.attrs, "na-value", default="NA") == "NaN"
        else pd.NA
    )

    arr = pd.array(
        values.astype(np.dtypes.StringDType(na_object=dtype.na_value)),  # TODO: why?
        dtype=dtype,
    )
    arr[mask] = pd.NA
    return arr


###########
# Scalars #
###########


@_REGISTRY.register_read(h5py.Dataset, IOSpec("numeric-scalar", "0.2.0"))
@_REGISTRY.register_read(zarr.Array, IOSpec("numeric-scalar", "0.2.0"))
def read_scalar(elem: _ArrayStorageType, *, _reader: Reader) -> np.number:
    # TODO: `item` ensures the return is in fact a scalar (needed after zarr v3 which now returns a 1 elem array)
    # https://github.com/zarr-developers/zarr-python/issues/2713
    return elem[()].item()


def _remove_scalar_compression_args(dataset_kwargs: Mapping[str, Any]) -> dict:
    # Can’t compress scalars, error is thrown
    dataset_kwargs = dict(dataset_kwargs)
    for arg in (
        "compression",
        "compression_opts",
        "chunks",
        "shuffle",
        "fletcher32",
        "scaleoffset",
        "compressor",
    ):
        dataset_kwargs.pop(arg, None)
    return dataset_kwargs


def write_scalar_zarr(
    f: zarr.Group,
    key: str,
    value,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    # these args are ignored in v2: https://zarr.readthedocs.io/en/v2.18.4/api/hierarchy.html#zarr.hierarchy.Group.create_dataset
    # and error out in v3
    dataset_kwargs = _remove_scalar_compression_args(dataset_kwargs)

    match f.metadata.zarr_format, value:
        case 2, str():
            filters, dtype, fill_value = [VLenUTF8()], VariableLengthUTF8(), ""
        case 3, str():
            filters, dtype, fill_value = None, VariableLengthUTF8(), None
        case _, _:
            filters, dtype, fill_value = None, np.array(value).dtype, None
    a = f.create_array(
        key,
        shape=(),
        dtype=dtype,
        filters=filters,
        fill_value=fill_value,
        **dataset_kwargs,
    )
    a[...] = np.array(value)


def write_hdf5_scalar(
    f: h5py.Group,
    key: str,
    value,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any] = MappingProxyType({}),
):
    # Can’t compress scalars, error is thrown
    dataset_kwargs = _remove_scalar_compression_args(dataset_kwargs)
    f.create_dataset(key, data=np.array(value), **dataset_kwargs)


for numeric_scalar_type in [
    *(bool, np.bool_),
    *(np.uint8, np.uint16, np.uint32, np.uint64),
    *(int, np.int8, np.int16, np.int32, np.int64),
    *(float, *np.floating.__subclasses__()),
    *np.complexfloating.__subclasses__(),
]:
    _REGISTRY.register_write(
        h5py.Group, numeric_scalar_type, IOSpec("numeric-scalar", "0.2.0")
    )(write_hdf5_scalar)
    _REGISTRY.register_write(
        zarr.Group, numeric_scalar_type, IOSpec("numeric-scalar", "0.2.0")
    )(write_scalar_zarr)

_REGISTRY.register_write(zarr.Group, str, IOSpec("string", "0.2.0"))(write_scalar_zarr)
_REGISTRY.register_write(zarr.Group, np.str_, IOSpec("string", "0.2.0"))(
    write_scalar_zarr
)


@_REGISTRY.register_read(h5py.Dataset, IOSpec("string", "0.2.0"))
def read_hdf5_string(elem: h5py.Dataset, *, _reader: Reader) -> str:
    return elem.asstr()[()]


@_REGISTRY.register_read(zarr.Array, IOSpec("string", "0.2.0"))
def read_zarr_string(elem: zarr.Array, *, _reader: Reader) -> str:
    return str(elem[()])


_REGISTRY.register_read(h5py.Dataset, IOSpec("bytes", "0.2.0"))(read_scalar)
_REGISTRY.register_read(zarr.Array, IOSpec("bytes", "0.2.0"))(read_scalar)


@_REGISTRY.register_write(h5py.Group, np.str_, IOSpec("string", "0.2.0"))
@_REGISTRY.register_write(h5py.Group, str, IOSpec("string", "0.2.0"))
def write_string(
    f: h5py.Group,
    k: str,
    v: np.str_ | str,
    *,
    _writer: Writer,
    dataset_kwargs: Mapping[str, Any],
):
    dataset_kwargs = dict(dataset_kwargs)
    dataset_kwargs.pop("compression", None)
    dataset_kwargs.pop("compression_opts", None)
    f.create_dataset(
        k, data=np.array(v, dtype=h5py.string_dtype(encoding="utf-8")), **dataset_kwargs
    )


# @_REGISTRY.register_write(np.bytes_, IOSpec("bytes", "0.2.0"))
# @_REGISTRY.register_write(bytes, IOSpec("bytes", "0.2.0"))
# def write_string(f, k, v, dataset_kwargs):
#     if "compression" in dataset_kwargs:
#         dataset_kwargs = dict(dataset_kwargs)
#         dataset_kwargs.pop("compression")
#     f.create_dataset(k, data=np.array(v), **dataset_kwargs)
