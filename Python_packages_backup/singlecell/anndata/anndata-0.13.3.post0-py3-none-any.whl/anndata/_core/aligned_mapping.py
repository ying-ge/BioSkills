from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import MutableMapping, Sequence
from copy import copy
from dataclasses import dataclass
from itertools import chain
from types import NoneType
from typing import TYPE_CHECKING

import h5py
import numpy as np
import pandas as pd
from scverse_misc import Deprecation, deprecated

from .._warnings import ExperimentalFeatureWarning, ImplicitModificationWarning
from ..compat import AwkArray, CSArray, CSMatrix, CupyArray, XDataset
from ..utils import (
    axis_len,
    convert_to_dict,
    deprecation_msg,
    raise_value_error_if_multiindex_columns,
    warn,
    warn_once,
)
from .access import ElementRef
from .index import _subset
from .storage import _non_2d_message, coerce_array
from .views import as_view, view_update
from .xarray import Dataset2D

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Iterator, Mapping
    from typing import ClassVar, Literal, Self

    from .anndata import AnnData


OneDIdx = Sequence[int] | Sequence[bool] | slice
TwoDIdx = tuple[OneDIdx, OneDIdx]
# TODO: pd.DataFrame only allowed in AxisArrays?
Value = pd.DataFrame | CSMatrix | CSArray | np.ndarray


class AlignedMappingBase[I: (OneDIdx, TwoDIdx), K: (str, str | None)](
    MutableMapping[K, Value], ABC
):
    """\
    An abstract base class for Mappings containing array-like values aligned
    to either one or both AnnData axes.
    """

    _allow_df: ClassVar[bool]
    """If this mapping supports heterogeneous DataFrames"""

    _view_class: ClassVar[type[AlignedView]]
    """The view class for this aligned mapping."""

    _actual_class: ClassVar[type[AlignedActual]]
    """The actual class (which has it’s own data) for this aligned mapping."""

    _parent: AnnData  # technically also can be Raw for .varm
    """The parent object that this mapping is aligned to."""

    def __repr__(self) -> str:
        return f"{type(self).__name__} with keys: {', '.join(map(repr, self.keys()))}"

    def _ipython_key_completions_(self) -> list[K]:
        return list(self.keys())

    def _validate_value(self, val: Value, key: K) -> Value:
        """Raises an error if value is invalid"""
        if isinstance(val, AwkArray):
            msg = (
                "Support for Awkward Arrays is currently experimental. "
                "Behavior may change in the future. Please report any issues you may encounter!"
            )
            warn_once(msg, ExperimentalFeatureWarning)
        elif isinstance(val, np.ndarray | CupyArray) and len(val.shape) == 1:
            val = val.reshape((val.shape[0], 1))
        elif isinstance(val, XDataset):
            val = Dataset2D(val)
        for i, axis in enumerate(self.axes):
            if self.parent.shape[axis] == axis_len(val, i):
                continue
            right_shape = tuple(self.parent.shape[a] for a in self.axes)
            actual_shape = tuple(axis_len(val, a) for a, _ in enumerate(self.axes))
            if actual_shape[i] is None and isinstance(val, AwkArray):
                dim = ("obs", "var")[i]
                msg = (
                    f"The AwkwardArray is of variable length in dimension {dim}.",
                    f"Try ak.to_regular(array, {i}) before including the array in AnnData",
                )
            else:
                dims = tuple(("obs", "var")[ax] for ax in self.axes)
                msg = (
                    f"Value passed for key {key!r} is of incorrect shape. "
                    f"Values of {self.attrname} must match dimensions {dims} of parent. "
                    f"Value had shape {actual_shape} while it should have had {right_shape}."
                )
            raise ValueError(msg)
        name = f"{self.attrname.title().rstrip('s')} {key!r}"
        return coerce_array(val, name=name, allow_df=self._allow_df)

    @property
    @abstractmethod
    def attrname(self) -> str:
        """What attr for the AnnData is this?"""

    @property
    @abstractmethod
    def axes(self) -> tuple[Literal[0, 1], ...]:
        """Which axes of the parent is this aligned to?"""

    @property
    @abstractmethod
    def is_view(self) -> bool: ...

    @property
    def parent(self) -> AnnData:
        return self._parent

    def copy(self) -> dict[K, Value]:
        # Shallow copy for awkward array since their buffers are immutable
        return {
            k: copy(v) if isinstance(v, AwkArray | NoneType) else v.copy()
            for k, v in self.items()
        }

    def _view(self, parent: AnnData, subset_idx: I) -> AlignedView[Self, I, K]:
        """Returns a subset copy-on-write view of the object."""
        return self._view_class(self, parent, subset_idx)

    @deprecated(Deprecation("0.10.2", deprecation_msg("as_dict", "dict(obj)")))
    def as_dict(self) -> dict:
        return dict(self)


class AlignedView[P: AlignedMappingBase, I: (OneDIdx, TwoDIdx), K: (str, str | None)](
    AlignedMappingBase[I, K]
):
    is_view: ClassVar[Literal[True]] = True

    # override docstring
    parent: AnnData
    """Reference to parent AnnData view"""

    attrname: str
    """What attribute in the parent is this?"""

    parent_mapping: P
    """The object this is a view of."""

    subset_idx: I
    """The subset of the parent to view."""

    def __init__(self, parent_mapping: P, parent_view: AnnData, subset_idx: I) -> None:
        self.parent_mapping = parent_mapping
        self._parent = parent_view
        self.subset_idx = subset_idx
        if hasattr(parent_mapping, "_axis"):
            # LayersBase has no _axis, the rest does
            self._axis = parent_mapping._axis  # type: ignore

    def __getitem__(self, key: K) -> Value:
        if self.parent_mapping[key] is None:
            return None
        return as_view(
            _subset(self.parent_mapping[key], self.subset_idx),
            ElementRef(self.parent, self.attrname, (key,)),
        )

    def __setitem__(self, key: K, value: Value) -> None:
        value = self._validate_value(value, key)  # Validate before mutating
        msg = (
            f"Setting element `.{self.attrname}['{key}']` of view, "
            "initializing view as actual."
        )
        warn(msg, ImplicitModificationWarning)
        with view_update(self.parent, self.attrname, ()) as new_mapping:
            if value is None:
                del new_mapping[key]
            else:
                new_mapping[key] = value

    def __delitem__(self, key: K) -> None:
        if key not in self:
            msg = f"{key!r} not found in view of {self.attrname}"
            raise KeyError(msg)  # Make sure it exists before bothering with a copy
        if not (key is None and self.attrname == "layers"):
            msg = (
                f"Removing element `.{self.attrname}['{key}']` of view, "
                "initializing view as actual."
            )
            warn(msg, ImplicitModificationWarning)
        with view_update(self.parent, self.attrname, ()) as new_mapping:
            del new_mapping[key]

    def __contains__(self, key: K) -> bool:
        return key in self.parent_mapping

    def __iter__(self) -> Iterator[K]:
        return iter(self.parent_mapping)

    def __len__(self) -> int:
        return len(self.parent_mapping)


class AlignedActual[I: (OneDIdx, TwoDIdx), K: (str, str | None)](
    AlignedMappingBase[I, K]
):
    is_view: ClassVar[Literal[False]] = False

    _data: MutableMapping[K, Value]
    """Underlying mapping to the data"""

    def __init__(
        self, parent: AnnData, *, store: MutableMapping[K, Value], validate: bool = True
    ):
        self._parent = parent
        self._data = store
        for k, v in self._data.items():
            if v is None:
                continue
            self._data[k] = self._validate_value(v, k) if validate else v

    def __getitem__(self, key: K) -> Value:
        return self._data[key]

    def __setitem__(self, key: K, value: Value):
        if value is not None:
            value = self._validate_value(value, key)
        if key is None and value is None:
            del self[key]
        else:
            self._data[key] = value

    def __contains__(self, key: K) -> bool:
        return key in self._data

    def __delitem__(self, key: K):
        if key is None:
            self._data.pop(key, None)
        else:
            del self._data[key]

    def __iter__(self) -> Iterator[K]:
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)


class AxisArraysBase(AlignedMappingBase[OneDIdx, str]):
    """\
    Mapping of key→array-like,
    where array-like is aligned to an axis of parent AnnData.
    """

    _allow_df: ClassVar = True
    _dimnames: ClassVar = ("obs", "var")

    _axis: Literal[0, 1]

    @property
    def attrname(self) -> str:
        return f"{self.dim}m"

    @property
    def axes(self) -> tuple[Literal[0, 1]]:
        """Axes of the parent this is aligned to"""
        return (self._axis,)

    @property
    def dim(self) -> str:
        """Name of the dimension this aligned to."""
        return self._dimnames[self._axis]

    def to_df(self) -> pd.DataFrame:
        """Convert to pandas dataframe."""
        df = pd.DataFrame(index=self.dim_names)
        for key in self.keys():
            value = self[key]
            for icolumn, column in enumerate(value.T):
                df[f"{key}{icolumn + 1}"] = column
        return df

    def _validate_value(self, val: Value, key: str) -> Value:
        if isinstance(val, pd.DataFrame):
            raise_value_error_if_multiindex_columns(val, f"{self.attrname}[{key!r}]")
            if not val.index.equals(self.dim_names):
                # Could probably also re-order index if it’s contained
                try:
                    pd.testing.assert_index_equal(val.index, self.dim_names)
                except AssertionError as e:
                    msg = f"value.index does not match parent’s {self.dim} names:\n{e}"
                    raise ValueError(msg) from None
                else:
                    msg = "Index.equals and pd.testing.assert_index_equal disagree"
                    raise AssertionError(msg)
            val.index.name = (
                self.dim_names.name
            )  # this is consistent with AnnData.obsm.setter and AnnData.varm.setter
        return super()._validate_value(val, key)

    @property
    def dim_names(self) -> pd.Index:
        return (self.parent.obs_names, self.parent.var_names)[self._axis]


class AxisArrays(AlignedActual[OneDIdx, str], AxisArraysBase):
    def __init__(
        self,
        parent: AnnData,
        *,
        axis: Literal[0, 1],
        store: MutableMapping[str, Value] | AxisArraysBase,
        validate: bool = True,
    ):
        if axis not in {0, 1}:
            raise ValueError()
        self._axis = axis
        super().__init__(parent, store=store, validate=validate)


class AxisArraysView(AlignedView[AxisArraysBase, OneDIdx, str], AxisArraysBase):
    pass


AxisArraysBase._view_class = AxisArraysView
AxisArraysBase._actual_class = AxisArrays


class LayersBase(AlignedMappingBase[TwoDIdx, str | None]):
    """\
    Mapping of key: array-like, where array-like is aligned to both axes of the
    parent anndata.
    """

    _allow_df: ClassVar = False
    attrname: ClassVar[Literal["layers"]] = "layers"
    axes: ClassVar[tuple[Literal[0], Literal[1]]] = (0, 1)

    isbacked: bool

    def __bool__(self) -> bool:
        return not self.keys() <= {None}

    def clear(self, *, keep_x: bool | None = None) -> None:
        """Remove all layers.

        Parameters
        ----------
        keep_x
            Whether to keep `.X` (stored under the `None` key).
            The default (`None`) keeps ``.X`` and warns that a future
            release may drop it by default - use this parameter explicitly to silence the warning.
        """
        if keep_x is None:
            warn(
                "`.layers.clear()` currently keeps `.X` (stored under the "
                "`None` key), but a future release may drop it. Pass "
                "`keep_x=True` to keep `.X` or `keep_x=False` to drop it "
                "and silence this warning.",
                FutureWarning,
            )
            keep_x = True
        for key in [k for k in self if not (keep_x and k is None)]:
            del self[key]

    def _validate_value(self, val: Value, key: str | None) -> Value:
        """Warn if storing ``val`` under ``key`` would violate the on-disk spec.

        Called from the explicit write paths (``__setitem__`` and the
        :class:`AlignedMappingProperty` full-reassign hook) only; we do
        *not* warn from :meth:`_validate_value` because that runs on
        every property access via :meth:`AlignedActual.__init__`.

        The ``key=None`` slot mirrors ``AnnData.X`` and is reported by
        the ``X`` setter itself (with the better name "X").
        """
        if key is not None and (msg := _non_2d_message(val, name=f"Layer {key!r}")):
            warn(msg, UserWarning)
        return super()._validate_value(val, key)


class Layers(AlignedActual[TwoDIdx, str | None], LayersBase):
    def __init__(
        self,
        parent: AnnData,
        *,
        store: MutableMapping[str | None, Value],
        validate: bool = True,
    ):
        super().__init__(parent, store=store, validate=validate)
        self.isbacked = None not in self._data and self.parent.filename is not None

    def __getitem__(self, key: str | None) -> Value:
        if key is None and self.isbacked:
            if not self.parent.file.is_open:
                self.parent.file.open()
            X = self.parent.file["X"]
            if isinstance(X, h5py.Group):
                from ..io import sparse_dataset

                X = sparse_dataset(X)
            return X
        return super().__getitem__(key)

    def __iter__(self) -> str | None:
        keys_iter = super().__iter__()
        if self.isbacked:
            yield from chain([None], keys_iter)
        yield from keys_iter

    def __len__(self) -> int:
        data_length = super().__len__()
        if self.isbacked:
            return data_length + 1
        return data_length

    def __contains__(self, key: str | None) -> bool:
        if key is None and self.isbacked:
            return True
        return super().__contains__(key)


class LayersView(AlignedView[LayersBase, TwoDIdx, str | None], LayersBase):
    def __init__(
        self, parent_mapping: LayersBase, parent_view: AnnData, subset_idx: TwoDIdx
    ) -> None:
        super().__init__(parent_mapping, parent_view, subset_idx)
        self.isbacked = parent_mapping.isbacked


LayersBase._view_class = LayersView
LayersBase._actual_class = Layers


class PairwiseArraysBase(AlignedMappingBase[OneDIdx, str]):
    """\
    Mapping of key: array-like, where both axes of array-like are aligned to
    one axis of the parent anndata.
    """

    _allow_df: ClassVar = False
    _dimnames: ClassVar = ("obs", "var")

    _axis: Literal[0, 1]

    @property
    def attrname(self) -> str:
        return f"{self.dim}p"

    @property
    def axes(self) -> tuple[Literal[0], Literal[0]] | tuple[Literal[1], Literal[1]]:
        """Axes of the parent this is aligned to"""
        return self._axis, self._axis  # type: ignore

    @property
    def dim(self) -> str:
        """Name of the dimension this aligned to."""
        return self._dimnames[self._axis]


class PairwiseArrays(AlignedActual[OneDIdx, str], PairwiseArraysBase):
    def __init__(
        self,
        parent: AnnData,
        *,
        axis: Literal[0, 1],
        store: MutableMapping[str, Value],
        validate: bool = True,
    ):
        if axis not in {0, 1}:
            raise ValueError()
        self._axis = axis
        super().__init__(parent, store=store, validate=validate)


class PairwiseArraysView(
    AlignedView[PairwiseArraysBase, OneDIdx, str], PairwiseArraysBase
):
    pass


PairwiseArraysBase._view_class = PairwiseArraysView
PairwiseArraysBase._actual_class = PairwiseArrays


type AlignedMapping = (
    AxisArrays
    | AxisArraysView
    | Layers
    | LayersView
    | PairwiseArrays
    | PairwiseArraysView
)
"""Pair of types to be aligned."""


@dataclass
class AlignedMappingProperty[T: AlignedMapping, K: (str, str | None)](property):
    """A :class:`property` that creates an ephemeral AlignedMapping.

    The actual data is stored as `f'_{self.name}'` in the parent object.
    """

    cls: type[T]
    """Concrete type that will be constructed."""
    axis: Literal[0, 1] | None = None
    """Axis of the parent to align to."""
    name: str | None = None
    """Name of the attribute in the parent object."""

    def construct(
        self, obj: AnnData, *, store: MutableMapping[K, Value], validate: bool = True
    ) -> T:
        if self.axis is None:
            return self.cls(obj, store=store, validate=validate)
        return self.cls(obj, axis=self.axis, store=store, validate=validate)

    @property
    def fget(self) -> Callable[[], None]:
        """Fake fget for sphinx-autodoc-typehints."""

        def fake(): ...

        fake.__annotations__ = {"return": self.cls._actual_class | self.cls._view_class}
        return fake

    def __set_name__(self, owner: AnnData, name: str):
        self.name = name

    def __get__(self, obj: AnnData | None, objtype: type | None = None) -> T:
        if obj is None:
            # When accessed from the class, e.g. via `AnnData.obs`,
            # this needs to return a `property` instance, e.g. for Sphinx
            return self  # type: ignore
        if not obj.is_view:
            # all stores are created through `.__set__`, so no need to double-validate.
            return self.construct(
                obj, store=getattr(obj, f"_{self.name}"), validate=False
            )
        parent_anndata = obj._adata_ref
        idxs = (obj._oidx, obj._vidx)
        parent: AlignedMapping = getattr(parent_anndata, self.name)
        return parent._view(obj, tuple(idxs[ax] for ax in parent.axes))

    def __set__(
        self, obj: AnnData, value: Mapping[K, Value] | Iterable[tuple[K, Value]] | None
    ) -> None:
        value = convert_to_dict(value)
        _ = self.construct(obj, store=value)  # Validate and convert arrays in `value`
        if obj.is_view:
            obj._init_as_actual(obj.copy())
        prev = getattr(obj, f"_{self.name}", None)
        if issubclass(self.cls, LayersBase):
            if None in value:
                if value[None] is None:
                    value = {k: v for k, v in value.items() if k is not None}
            elif prev is not None and (x := prev.get(None)) is not None:
                warn(
                    "Assigning to `.layers` without a `None` key currently "
                    "preserves `.X` (stored under the `None` key), but a "
                    "future release may drop it. Include `.X` explicitly as "
                    "`{None: adata.X, ...}` to keep it, or `{None: None, ...}` "
                    "to drop it and silence this warning.",
                    FutureWarning,
                )
                value = {**value, None: x}
        setattr(obj, f"_{self.name}", value)

    def __delete__(self, obj: AnnData) -> None:
        if issubclass(self.cls, LayersBase) and (
            (x := getattr(obj, self.name).get(None)) is not None
        ):
            warn(
                "`del adata.layers` currently keeps `.X` (stored under the "
                "`None` key), but a future release may drop it. Use "
                "`adata.layers.clear(keep_x=True)` to keep `.X` or "
                "`adata.layers.clear(keep_x=False)` to drop it and silence "
                "this warning.",
                FutureWarning,
            )
            # Reassign with `.X` prevents another, less-helpful warning
            setattr(obj, self.name, {None: x})
            return
        setattr(obj, self.name, {})
