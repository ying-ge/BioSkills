from __future__ import annotations

from collections.abc import Iterable, Sequence
from enum import Enum
from functools import singledispatch, wraps
from itertools import repeat
from typing import TYPE_CHECKING, Literal, NamedTuple, cast, overload

import h5py
import numpy as np
import pandas as pd
from scipy.sparse import issparse

from anndata.types import SupportsArrayApiBase

from .._settings import settings
from ..compat import (
    AwkArray,
    CSArray,
    CSMatrix,
    DaskArray,
    IndexManager,
    XDataArray,
    has_xp_base,
)
from .xarray import Dataset2D

if TYPE_CHECKING:
    from collections.abc import Callable

    from numpy.typing import NDArray

    from anndata.typing import Index1D

    from ..acc import Array
    from ..typing import Index, _Index1DNorm
    from .anndata import AnnData
    from .raw import Raw


__all__ = [
    "_ensure_numpy_idx",
    "_fix_slice_bounds",
    "_get_vector_ambiguous",
    "_normalize_indices",
    "_safe_fancy_index_h5py",
    "_subset",
    "array_api_ix",
    "make_slice",
    "unpack_index",
]


def _normalize_indices(
    index: Index[IndexManager], names0: pd.Index, names1: pd.Index
) -> tuple[
    _Index1DNorm | int | np.integer, _Index1DNorm | int | np.integer | pd.MultiIndex
]:
    # deal with tuples of length 1
    if isinstance(index, tuple) and len(index) == 1:
        index = index[0]
    ax0, ax1 = unpack_index(index)
    ax0 = _normalize_index(ax0, names0)
    ax1 = _normalize_index(ax1, names1)
    return ax0, ax1


ArrayApiDtype = Literal["real floating", "signed integer", "unsigned integer", "bool"]
DtypeKind = Literal["f", "i", "u", "b"]


class _XrDtV(NamedTuple):
    type: type[np.generic]
    array_api_str: ArrayApiDtype
    kind: DtypeKind

    def __call__(
        self,
        indexer: SupportsArrayApiBase | pd.api.extensions.ExtensionArray | np.matrix,
    ) -> bool:
        return (
            has_xp_base(indexer)
            and indexer.__array_namespace__().isdtype(indexer.dtype, self.array_api_str)
        ) or (
            isinstance(indexer, pd.api.extensions.ExtensionArray)
            and (
                issubclass(indexer.dtype.type, self.type)
                or indexer.dtype.kind == self.kind
            )
        )


class XArrayDtype(_XrDtV, Enum):
    Float = (np.floating, "real floating", "f")
    SignedInt = (np.signedinteger, "signed integer", "i")
    UnsignedInt = (np.unsignedinteger, "unsigned integer", "u")
    Bool = (np.bool, "bool", "b")


@singledispatch
def _gen_anndata_index(
    indexer: Index1D, index: pd.Index
) -> _Index1DNorm | int | np.integer | SupportsArrayApiBase:
    msg = f"Unknown indexer {indexer!r} of type {type(indexer)}"
    raise IndexError(msg)


@_gen_anndata_index.register(slice)
def _from_slice(indexer: slice, index: pd.Index) -> slice:
    def name_idx(i):
        if isinstance(i, str):
            i = index.get_loc(i)
        return i

    start = name_idx(indexer.start)
    stop = name_idx(indexer.stop)
    # string slices can only be inclusive, so +1 in that case
    if isinstance(indexer.stop, str):
        stop = None if stop is None else stop + 1
    step = indexer.step
    return slice(start, stop, step)


@_gen_anndata_index.register(np.integer | int)
def _from_int(indexer: np.integer | int, index: pd.Index) -> np.integer | int:
    return indexer


@_gen_anndata_index.register(str)
def _from_str(indexer: str, index: pd.Index) -> int:
    return index.get_loc(indexer)


@_gen_anndata_index.register(XDataArray)
def _from_xarray(indexer: XDataArray, index: pd.Index) -> np.ndarray:
    if isinstance(indexer.data, DaskArray):
        return indexer.data.compute()
    return indexer.data


@_gen_anndata_index.register(CSMatrix | CSArray)
def _from_sparse(
    indexer: CSMatrix | CSArray,
    index: pd.Index,
) -> SupportsArrayApiBase:
    indexer = indexer.toarray()
    return _gen_anndata_index(indexer, index)


@_gen_anndata_index.register(Sequence)
def _from_sequence(
    indexer: Sequence,
    index: pd.Index,
) -> SupportsArrayApiBase:
    indexer: np.ndarray = np.array(indexer)
    if len(indexer) == 0:
        indexer = indexer.astype(int)
    return _gen_anndata_index(indexer, index)


@_gen_anndata_index.register(
    SupportsArrayApiBase | pd.api.extensions.ExtensionArray | np.matrix | pd.MultiIndex
)
def _from_array(
    indexer: SupportsArrayApiBase
    | pd.api.extensions.ExtensionArray
    | np.matrix
    | pd.MultiIndex,
    index: pd.Index,
) -> SupportsArrayApiBase:
    # convert to the 1D if it's accidentally 2D column/row vector
    # convert sparse into dense arrays if needed
    use_xp = has_xp_base(indexer)
    # MultiIndex objects are not turned into arrays in _normalize_index
    is_pandas = isinstance(
        indexer,
        pd.api.extensions.ExtensionArray | pd.MultiIndex,
    )
    xp = indexer.__array_namespace__() if use_xp else np
    if indexer.shape == (index.shape[0], 1) or indexer.shape == (1, index.shape[0]):
        indexer = xp.ravel(indexer)
    # https://github.com/numpy/numpy/issues/27545
    is_numpy_string = indexer.dtype == np.dtypes.StringDType()
    if not is_numpy_string or is_pandas:
        # if it is a float array or something along those lines, convert it to integers
        if XArrayDtype.Float(indexer):
            indexer_int = xp.astype(indexer, xp.int64)
            if xp.all((indexer - indexer_int) != 0):
                msg = f"Indexer {indexer!r} has floating point values."
                raise IndexError(msg)
            return indexer_int
        if XArrayDtype.SignedInt(indexer) or XArrayDtype.UnsignedInt(indexer):
            # Might not work for range indexes
            return np.asarray(indexer) if is_pandas else indexer
        if XArrayDtype.Bool(indexer):
            if indexer.shape != index.shape:
                msg = (
                    f"Boolean index does not match AnnData’s shape along this "
                    f"dimension. Boolean index has shape {indexer.shape} while "
                    f"AnnData index has shape {index.shape}."
                )
                raise IndexError(msg)
            return np.asarray(indexer) if is_pandas else indexer
        if not isinstance(indexer, np.ndarray) and has_xp_base(indexer):
            msg = f"indexer is array-api compatible but has unsupported dtype: {indexer.dtype}"
            raise ValueError(msg)
    positions = index.get_indexer(indexer)  # indexer should be string array
    if xp.any(positions < 0):
        not_found = indexer[positions < 0]
        msg = (
            f"Values {list(not_found)}, from {list(indexer)}, "
            "are not valid obs/ var names or indices."
        )
        raise KeyError(msg)
    return positions  # np.ndarray[int]


def _normalize_index(
    indexer: Index1D[IndexManager], index: pd.Index
) -> _Index1DNorm | int | np.integer | SupportsArrayApiBase | pd.MultiIndex:

    if isinstance(indexer, pd.Index | pd.Series) and (
        not isinstance(indexer, pd.MultiIndex) or settings.restrict_index_types
    ):
        indexer = indexer.array
    if isinstance(indexer, IndexManager):
        indexer = indexer.get_default()

    return _gen_anndata_index(indexer, index)


def _fix_slice_bounds[A: int, Z: int, S: int](
    s: slice[A | None, Z | None, S | None], length: int
) -> slice[A, Z, S]:
    """The slice will be clipped to length, and the step won't be None.

    E.g. infer None valued attributes.
    """
    step = s.step if s.step is not None else 1

    # slice constructor would have errored if step was 0
    if step > 0:
        start = s.start if s.start is not None else 0
        stop = s.stop if s.stop is not None else length
    elif step < 0:
        # Reverse
        start = s.start if s.start is not None else length
        stop = s.stop if s.stop is not None else 0
    else:
        msg = "step must be non-zero"
        raise AssertionError(msg)

    return slice(start, stop, step)


def unpack_index[M: IndexManager](index: Index[M]) -> tuple[Index1D[M], Index1D[M]]:
    if not isinstance(index, tuple):
        if index is Ellipsis:
            index = slice(None)
        return index, slice(None)
    num_ellipsis = sum(i is Ellipsis for i in index)
    if num_ellipsis > 1:
        msg = "an index can only have a single ellipsis ('...')"
        raise IndexError(msg)
    # If index has Ellipsis, filter it out (and if not, error)
    if len(index) > 2:
        if not num_ellipsis:
            msg = "Received a length 3 index without an ellipsis"
            raise IndexError(msg)
        index = tuple(i for i in index if i is not Ellipsis)
        return index
    # If index has Ellipsis, replace it with slice
    if len(index) == 2:
        index = tuple(slice(None) if i is Ellipsis else i for i in index)
        return index
    if len(index) == 1:
        index = index[0]
        if index is Ellipsis:
            index = slice(None)
        return index, slice(None)
    msg = "invalid number of indices"
    raise IndexError(msg)


def _index_manager_to_numpy_idx_in_tuple(
    subset_idx: tuple[_Index1DNorm]
    | tuple[_Index1DNorm[IndexManager], _Index1DNorm[IndexManager]],
) -> tuple[_Index1DNorm] | tuple[_Index1DNorm, _Index1DNorm]:
    """Convert IndexManager instances to numpy arrays in a tuple of indices."""
    return tuple(
        np.asarray(idx) if isinstance(idx, IndexManager) else idx for idx in subset_idx
    )


def _ensure_numpy_idx[T, R](
    func: Callable[[T, tuple[_Index1DNorm] | tuple[_Index1DNorm, _Index1DNorm]], R],
) -> Callable[
    [
        T,
        tuple[_Index1DNorm[IndexManager]]
        | tuple[_Index1DNorm[IndexManager], _Index1DNorm[IndexManager]],
    ],
    R,
]:
    """Convert IndexManager instances to numpy arrays in a tuple of indices."""

    @wraps(func)
    def _ensure(
        a: T,
        subset_idx: tuple[_Index1DNorm[IndexManager]]
        | tuple[_Index1DNorm[IndexManager], _Index1DNorm[IndexManager]],
    ) -> R:
        return func(
            a,
            _index_manager_to_numpy_idx_in_tuple(subset_idx),
        )

    return _ensure


def array_api_ix(*args: SupportsArrayApiBase) -> tuple[SupportsArrayApiBase, ...]:
    """Construct an open mesh from multiple sequences.

    Vendored version of `numpy.ix_` for the array-api.

    For each sequence `args[i]`, it returns an array with `.ndim == len(args)`,
    `.size == .shape[i] == len(args[i])` (i.e. `shape[…] == 1` for each other dimension)
    """
    out = []
    n_dims = len(args)
    for k, new in enumerate(args):
        xp = new.__array_namespace__()
        if new.ndim != 1:  # pragma: no cover
            msg = "Cross index must be 1 dimensional"
            raise ValueError(msg)
        if xp.isdtype(new.dtype, "bool"):
            (new,) = new.nonzero()
        new = new.reshape((1,) * k + (new.size,) + (1,) * (n_dims - k - 1))
        out.append(new)
    return tuple(out)


def _prepare_array_api_idx(
    a: SupportsArrayApiBase,
    subset_idx: tuple[_Index1DNorm[IndexManager]]
    | tuple[_Index1DNorm[IndexManager], _Index1DNorm[IndexManager]],
) -> tuple[slice | SupportsArrayApiBase, ...]:
    """Prepare indices for array-api compatible subsetting."""
    xp = a.__array_namespace__()

    def get_idx(idx):
        if isinstance(idx, IndexManager):
            return idx.get_for_array(a)
        elif isinstance(idx, slice) or has_xp_base(idx):
            return idx
        else:  # pragma: no cover
            # Convert numpy/list to array-api array on the target device
            # In theory should be unreachable so this is a last resort since xp.asarray is pretty undefined.
            return xp.asarray(idx, device=a.device)

    maybe_array_api_idxs = tuple(get_idx(idx) for idx in subset_idx)
    if all(isinstance(x, type(a)) for x in maybe_array_api_idxs):
        return array_api_ix(*maybe_array_api_idxs)

    return maybe_array_api_idxs


@singledispatch
def _subset[
    T: np.ndarray
    | pd.DataFrame
    | SupportsArrayApiBase
    | DaskArray
    | CSArray
    | CSMatrix
    | Dataset2D
](
    a: T,
    subset_idx: tuple[_Index1DNorm[IndexManager]]
    | tuple[_Index1DNorm[IndexManager], _Index1DNorm[IndexManager]],
) -> T | np.ndarray:
    """Select a subset of array `a` using the given indices.

    For numpy arrays with array indices (not slices), this uses np.ix_ for
    coordinate-based indexing. For array-api arrays, it uses device-aware
    indexing with IndexManager support.
    """
    # Check if this is an array-api array (not numpy)
    if has_xp_base(a) and not isinstance(a, np.ndarray):
        # Use array-api aware indexing
        subset_idx = _prepare_array_api_idx(a, subset_idx)
        return a[subset_idx]

    # For numpy arrays and other types, ensure we have numpy indices
    subset_idx = _index_manager_to_numpy_idx_in_tuple(subset_idx)

    # Select as combination of indexes, not coordinates
    # Correcting for indexing behaviour of np.ndarray
    if all(isinstance(x, Iterable) for x in subset_idx):
        subset_idx = np.ix_(*subset_idx)
    return a[subset_idx]


@_subset.register(DaskArray)
@_ensure_numpy_idx
def _subset_dask(
    a: DaskArray, subset_idx: tuple[_Index1DNorm] | tuple[_Index1DNorm, _Index1DNorm]
) -> DaskArray:
    if len(subset_idx) > 1 and all(isinstance(x, Iterable) for x in subset_idx):
        if issparse(a._meta) and a._meta.format == "csc":
            return a[:, subset_idx[1]][subset_idx[0], :]
        return a[subset_idx[0], :][:, subset_idx[1]]
    return a[subset_idx]


@_subset.register(CSMatrix)
@_subset.register(CSArray)
@_ensure_numpy_idx
def _subset_sparse[T: CSMatrix | CSArray](
    a: T, subset_idx: tuple[_Index1DNorm] | tuple[_Index1DNorm, _Index1DNorm]
) -> T:
    # Correcting for indexing behaviour of sparse.spmatrix
    if len(subset_idx) > 1 and all(isinstance(x, Iterable) for x in subset_idx):
        first_idx = subset_idx[0]
        if issubclass(first_idx.dtype.type, np.bool_):
            first_idx = np.flatnonzero(first_idx)
        subset_idx = (first_idx.reshape(-1, 1), *subset_idx[1:])
    return a[subset_idx]


@_subset.register(pd.DataFrame)
@_subset.register(Dataset2D)
@_ensure_numpy_idx
def _subset_df[T: pd.DataFrame | Dataset2D](
    df: T, subset_idx: tuple[_Index1DNorm] | tuple[_Index1DNorm, _Index1DNorm]
) -> T:
    return df.iloc[subset_idx]


@_subset.register(AwkArray)
@_ensure_numpy_idx
def _subset_awkarray(
    a: AwkArray, subset_idx: tuple[_Index1DNorm] | tuple[_Index1DNorm, _Index1DNorm]
) -> AwkArray:
    if all(isinstance(x, Iterable) for x in subset_idx):
        subset_idx = np.ix_(*subset_idx)
    return a[subset_idx]


# Registration for SparseDataset occurs in sparse_dataset.py
@_subset.register(h5py.Dataset)
@_ensure_numpy_idx
def _subset_dataset(
    d: h5py.Dataset, subset_idx: tuple[_Index1DNorm] | tuple[_Index1DNorm, _Index1DNorm]
) -> np.ndarray:
    order: tuple[NDArray[np.integer] | slice, ...]
    inv_order: tuple[NDArray[np.integer] | slice, ...]
    order, inv_order = zip(*map(_index_order_and_inverse, subset_idx), strict=True)
    # check for duplicates or multi-dimensional fancy indexing
    array_dims = [i for i in order if isinstance(i, np.ndarray)]
    has_duplicates = any(len(np.unique(i)) != len(i) for i in array_dims)
    # Use safe indexing if there are duplicates OR multiple array dimensions
    # (h5py doesn't support multi-dimensional fancy indexing natively)
    if has_duplicates or len(array_dims) > 1:
        # For multi-dimensional indexing, bypass the sorting logic and use original indices
        return _safe_fancy_index_h5py(d, subset_idx)
    # from hdf5, then to real order
    return d[order][inv_order]


@overload
def _index_order_and_inverse(
    axis_idx: NDArray[np.integer] | NDArray[np.bool_],
) -> tuple[NDArray[np.integer], NDArray[np.integer]]: ...
@overload
def _index_order_and_inverse(axis_idx: slice) -> tuple[slice, slice]: ...
def _index_order_and_inverse(
    axis_idx: _Index1DNorm,
) -> tuple[_Index1DNorm, NDArray[np.integer] | slice]:
    """Order and get inverse index array."""
    if not isinstance(axis_idx, np.ndarray):
        return axis_idx, slice(None)
    if axis_idx.dtype == bool:
        axis_idx = np.flatnonzero(axis_idx)
    order = np.argsort(axis_idx)
    return axis_idx[order], np.argsort(order)


@overload
def _process_index_for_h5py(
    idx: NDArray[np.integer] | NDArray[np.bool_],
) -> tuple[NDArray[np.integer], NDArray[np.integer]]: ...
@overload
def _process_index_for_h5py(idx: slice) -> tuple[slice, None]: ...
def _process_index_for_h5py(
    idx: _Index1DNorm,
) -> tuple[_Index1DNorm, NDArray[np.integer] | None]:
    """Process a single index for h5py compatibility, handling sorting and duplicates."""
    if not isinstance(idx, np.ndarray):
        # Not an array (slice, integer, list) - no special processing needed
        return idx, None

    if idx.dtype == bool:
        idx = np.flatnonzero(idx)

    # For h5py fancy indexing, we need sorted indices
    # But we also need to track how to reverse the sorting
    unique, inverse = np.unique(idx, return_inverse=True)
    return (
        # Has duplicates - use unique + inverse mapping approach
        (unique, inverse)
        if len(unique) != len(idx)
        # No duplicates - just sort and track reverse mapping
        else _index_order_and_inverse(idx)
    )


def _safe_fancy_index_h5py(
    dataset: h5py.Dataset,
    subset_idx: tuple[_Index1DNorm] | tuple[_Index1DNorm, _Index1DNorm],
) -> h5py.Dataset:
    # Handle multi-dimensional indexing of h5py dataset
    # This avoids h5py's limitation with multi-dimensional fancy indexing
    # without loading the entire dataset into memory

    # Convert boolean arrays to integer arrays and handle sorting for h5py
    processed_indices: tuple[NDArray[np.integer] | slice, ...]
    reverse_indices: tuple[NDArray[np.integer] | None, ...]
    processed_indices, reverse_indices = zip(
        *map(_process_index_for_h5py, subset_idx), strict=True
    )

    # First find the index that reduces the size of the dataset the most
    i_min = np.argmin([
        _get_index_size(inds, dataset.shape[i]) / dataset.shape[i]
        for i, inds in enumerate(processed_indices)
    ])

    # Apply the most selective index first to h5py dataset
    first_index = [slice(None)] * len(processed_indices)
    first_index[i_min] = processed_indices[i_min]
    in_memory_array = cast("np.ndarray", dataset[tuple(first_index)])

    # Apply remaining indices to the numpy array
    remaining_indices = list(processed_indices)
    remaining_indices[i_min] = slice(None)  # Already applied
    result = in_memory_array[tuple(remaining_indices)]

    # Now apply reverse mappings to get the original order
    for dim, reverse_map in enumerate(reverse_indices):
        if reverse_map is not None:
            result = result.take(reverse_map, axis=dim)

    return result


def _get_index_size(idx: _Index1DNorm, dim_size: int) -> int:
    """Get size for any index type."""
    if isinstance(idx, slice):
        return len(range(*idx.indices(dim_size)))
    elif isinstance(idx, int):
        return 1
    else:  # For other types, try to get length
        return len(idx)


def make_slice(idx, dimidx: int, n: int = 2) -> tuple[slice, ...]:
    mut = list(repeat(slice(None), n))
    mut[dimidx] = idx
    return tuple(mut)


def _get_vector_ambiguous(
    adata: AnnData | Raw, k: str, dim: Literal["obs", "var"], layer: str | None = None
) -> Array:
    from ..acc import A

    idxdim = "var" if dim == "obs" else "obs"
    match (k in getattr(adata, dim), k in getattr(adata, f"{idxdim}_names")):
        case True, True:
            msg = f"Key {k} could be found in both .{idxdim}_names and .{dim}.columns"
            raise ValueError(msg)
        case False, False:
            msg = f"Could not find key {k} in .{idxdim}_names or .{dim}.columns."
            raise KeyError(msg)
        case True, False:
            ref = (A.obs if dim == "obs" else A.var)[k]
        case False, True:
            acc = A.layers[layer]
            ref = acc[k, :] if idxdim == "obs" else acc[:, k]
    return adata[ref]
