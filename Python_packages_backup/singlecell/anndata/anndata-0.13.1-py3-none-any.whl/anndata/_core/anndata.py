"""\
Main class and helper functions.
"""

from __future__ import annotations

from collections import OrderedDict, defaultdict
from collections.abc import Mapping, MutableMapping, Sequence
from copy import copy, deepcopy
from functools import singledispatchmethod
from pathlib import Path
from textwrap import dedent
from typing import TYPE_CHECKING, cast, overload

import h5py
import numpy as np
import pandas as pd
from natsort import natsorted
from pandas.api.types import infer_dtype
from scipy.sparse import issparse
from scverse_misc import Deprecation, deprecated

from anndata._core.access import ElementRef
from anndata._core.sparse_dataset import sparse_dataset
from anndata.types import SupportsArrayApiBase

from .. import utils
from .._settings import settings
from .._warnings import ImplicitModificationWarning
from ..compat import (
    AwkArray,
    CSArray,
    IndexManager,
    XDataset,
    ZarrArray,
    _move_adj_mtx,
    has_xp,
    old_positionals,
    pandas_as_str,
)
from ..logging import anndata_logger as logger
from ..utils import (
    axis_len,
    deprecation_msg,
    ensure_df_homogeneous,
    get_union_members,
    iter_outer,
    raise_value_error_if_multiindex_columns,
    set_module,
    warn,
)
from .aligned_df import _gen_dataframe
from .aligned_mapping import AlignedMappingProperty, AxisArrays, Layers, PairwiseArrays
from .file_backing import AnnDataFileManager, to_memory
from .index import _get_vector_ambiguous, _normalize_indices, _subset
from .raw import Raw
from .sparse_dataset import BaseCompressedSparseDataset
from .storage import _non_2d_message, coerce_array
from .views import DictView, _resolve_idxs, as_view
from .xarray import Dataset2D

if TYPE_CHECKING:
    from collections.abc import Iterable
    from os import PathLike
    from typing import Any, ClassVar, Literal

    from scipy import sparse
    from zarr.storage import StoreLike

    from anndata._types import AnnDataElem
    from anndata.typing import RWAble

    from .._types import ReduceFunc
    from ..acc import (
        AdRef,
        Array,
        DataFrameLike,
        FullArray,
        GraphAcc,
        LayerAcc,
        MapAcc,
        MetaAcc,
        MultiAcc,
        RefAcc,
    )
    from ..compat import CSArray, CSMatrix
    from ..typing import AxisStorable, Index, Index1D, _Index1DNorm, _XDataType
    from .aligned_mapping import AxisArraysView, LayersView, PairwiseArraysView


@set_module("anndata")
class AnnData:  # noqa: PLW1641
    """\
    An annotated data matrix.

    .. figure:: ../_static/img/anndata_schema.svg
       :width: 260px
       :align: right
       :class: dark-light

    :class:`~anndata.AnnData` stores a data matrix :attr:`X` together with annotations
    of observations :attr:`obs` (:attr:`obsm`, :attr:`obsp`),
    variables :attr:`var` (:attr:`varm`, :attr:`varp`),
    and unstructured annotations :attr:`uns`.

    An :class:`~anndata.AnnData` object `adata` can be sliced like a
    :class:`~pandas.DataFrame`,
    for instance `adata_subset = adata[:, list_of_variable_names]`.
    :class:`~anndata.AnnData`’s basic structure is similar to R’s ExpressionSet
    [Huber15]_. If setting an `.h5ad`-formatted HDF5 backing file `.filename`,
    data remains on the disk but is automatically loaded into memory if needed.

    Parameters
    ----------
    X
        A #observations × #variables data matrix. A view of the data is used if the
        data type matches, otherwise, a copy is made.
    obs
        Key-indexed one-dimensional observations annotation of length #observations.
    var
        Key-indexed one-dimensional variables annotation of length #variables.
    uns
        Key-indexed unstructured annotation.
    obsm
        Key-indexed multi-dimensional observations annotation of length #observations.
        If passing a :class:`~numpy.ndarray`, it needs to have a structured datatype.
    varm
        Key-indexed multi-dimensional variables annotation of length #variables.
        If passing a :class:`~numpy.ndarray`, it needs to have a structured datatype.
    layers
        Key-indexed multi-dimensional arrays aligned to dimensions of `X`.
    shape
        Shape tuple (#observations, #variables). Can only be provided if `X` is `None`.
    filename
        Name of backing file. See :class:`h5py.File`.
    filemode
        Open mode of backing file. See :class:`h5py.File`.

    See Also
    --------
    io.read_h5ad
    io.read_csv
    io.read_excel
    io.read_hdf
    io.read_zarr
    io.read_mtx
    io.read_text
    io.read_umi_tools

    Notes
    -----
    :class:`~anndata.AnnData` stores observations (samples) of variables/features
    in the rows of a matrix.
    This is the convention of the modern classics of statistics [Hastie09]_
    and machine learning [Murphy12]_,
    the convention of dataframes both in R and Python and the established statistics
    and machine learning packages in Python (statsmodels_, scikit-learn_).

    Single dimensional annotations of the observation and variables are stored
    in the :attr:`obs` and :attr:`var` attributes as :class:`~pandas.DataFrame`\\ s.
    This is intended for metrics calculated over their axes.
    Multi-dimensional annotations are stored in :attr:`obsm` and :attr:`varm`,
    which are aligned to the objects observation and variable dimensions respectively.
    Square matrices representing graphs are stored in :attr:`obsp` and :attr:`varp`,
    with both of their own dimensions aligned to their associated axis.
    Additional measurements across both observations and variables are stored in
    :attr:`layers`.

    Indexing into an AnnData object can be performed by relative position
    with numeric indices (like pandas’ :meth:`~pandas.DataFrame.iloc`),
    or by labels (like :meth:`~pandas.DataFrame.loc`).
    To avoid ambiguity with numeric indexing into observations or variables,
    indexes of the AnnData object are converted to strings by the constructor.

    Subsetting an AnnData object by indexing into it will also subset its elements
    according to the dimensions they were aligned to.
    This means an operation like `adata[list_of_obs, :]` will also subset :attr:`obs`,
    :attr:`obsm`, and :attr:`layers`.

    Subsetting an AnnData object returns a view into the original object,
    meaning very little additional memory is used upon subsetting.
    This is achieved lazily, meaning that the constituent arrays are subset on access.
    Copying a view causes an equivalent “real” AnnData object to be generated.
    Attempting to modify a view (at any attribute except X) is handled
    in a copy-on-modify manner, meaning the object is initialized in place.
    Here’s an example::

        batch1 = adata[adata.obs["batch"] == "batch1", :]
        batch1.obs["value"] = 0  # This makes batch1 a “real” AnnData object

    At the end of this snippet: `adata` was not modified,
    and `batch1` is its own AnnData object with its own data.

    Similar to Bioconductor’s `ExpressionSet` and :mod:`scipy.sparse` matrices,
    subsetting an AnnData object retains the dimensionality of its constituent arrays.
    Therefore, unlike with the classes exposed by :mod:`pandas`, :mod:`numpy`,
    and `xarray`, there is no concept of a one dimensional AnnData object.
    AnnDatas always have two inherent dimensions, :attr:`obs` and :attr:`var`.
    Additionally, maintaining the dimensionality of the AnnData object allows for
    consistent handling of :mod:`scipy.sparse` matrices and :mod:`numpy` arrays.

    .. _statsmodels: http://www.statsmodels.org/stable/index.html
    .. _scikit-learn: http://scikit-learn.org/
    """

    _DONT_HIDE_DEPRECATED: ClassVar = {"concatenate"}

    _BACKED_ATTRS: ClassVar[list[str]] = ["X", "raw.X"]

    # backwards compat
    _H5_ALIASES: ClassVar[dict[str, set[str]]] = dict(
        X={"X", "_X", "data", "_data"},
        obs={"obs", "_obs", "smp", "_smp"},
        var={"var", "_var"},
        uns={"uns"},
        obsm={"obsm", "_obsm", "smpm", "_smpm"},
        varm={"varm", "_varm"},
        layers={"layers", "_layers"},
    )

    _H5_ALIASES_NAMES: ClassVar[dict[str, set[str]]] = dict(
        obs={"obs_names", "smp_names", "row_names", "index"},
        var={"var_names", "col_names", "index"},
    )

    _accessors: ClassVar[set[str]] = set()

    # view attributes
    _adata_ref: AnnData | None
    _oidx: _Index1DNorm[IndexManager] | None
    _vidx: _Index1DNorm[IndexManager] | None

    @old_positionals(
        "obsm",
        "varm",
        "layers",
        "raw",
        "dtype",
        "shape",
        "filename",
        "filemode",
        "asview",
    )
    def __init__(  # noqa: PLR0913
        self,
        X: _XDataType | pd.DataFrame | None = None,
        obs: pd.DataFrame | Mapping[str, Iterable[Any]] | None = None,
        var: pd.DataFrame | Mapping[str, Iterable[Any]] | None = None,
        uns: Mapping[str, Any] | None = None,
        *,
        obsm: np.ndarray | Mapping[str, Sequence[Any]] | None = None,
        varm: np.ndarray | Mapping[str, Sequence[Any]] | None = None,
        layers: Mapping[str, _XDataType] | None = None,
        raw: Mapping[str, Any] | None = None,
        shape: tuple[int, int] | None = None,
        filename: PathLike[str] | str | None = None,
        filemode: Literal["r", "r+"] | None = None,
        asview: bool = False,
        obsp: np.ndarray | Mapping[str, Sequence[Any]] | None = None,
        varp: np.ndarray | Mapping[str, Sequence[Any]] | None = None,
        oidx: _Index1DNorm | int | np.integer | None = None,
        vidx: _Index1DNorm | int | np.integer | None = None,
    ):
        # check for any multi-indices that aren’t later checked in coerce_array
        for attr, key in [(obs, "obs"), (var, "var"), (X, "X")]:
            if isinstance(attr, pd.DataFrame):
                raise_value_error_if_multiindex_columns(attr, key)
        if asview:
            if not isinstance(X, AnnData):
                msg = "`X` has to be an AnnData object."
                raise ValueError(msg)
            assert oidx is not None
            assert vidx is not None
            self._init_as_view(X, oidx, vidx)
        else:
            self._init_as_actual(
                X=X,
                obs=obs,
                var=var,
                uns=uns,
                obsm=obsm,
                varm=varm,
                raw=raw,
                layers=layers,
                shape=shape,
                obsp=obsp,
                varp=varp,
                filename=filename,
                filemode=filemode,
            )

    def _init_as_view(
        self,
        adata_ref: AnnData,
        oidx: _Index1DNorm | int | np.integer,
        vidx: _Index1DNorm | int | np.integer,
    ):
        self._is_view = True
        if isinstance(oidx, int | np.integer):
            if not (-adata_ref.n_obs <= oidx < adata_ref.n_obs):
                msg = f"Observation index `{oidx}` is out of range."
                raise IndexError(msg)
            oidx += adata_ref.n_obs * (oidx < 0)
            oidx = slice(oidx, oidx + 1, 1)
        if isinstance(vidx, int | np.integer):
            if not (-adata_ref.n_vars <= vidx < adata_ref.n_vars):
                msg = f"Variable index `{vidx}` is out of range."
                raise IndexError(msg)
            vidx += adata_ref.n_vars * (vidx < 0)
            vidx = slice(vidx, vidx + 1, 1)
        if adata_ref.is_view:
            assert adata_ref._adata_ref is not None
            assert adata_ref._oidx is not None
            assert adata_ref._vidx is not None
            prev_oidx, prev_vidx = adata_ref._oidx, adata_ref._vidx
            adata_ref = adata_ref._adata_ref
            oidx, vidx = _resolve_idxs((prev_oidx, prev_vidx), (oidx, vidx), adata_ref)
        for axis, idx in [("o", oidx), ("v", vidx)]:
            setattr(
                self,
                f"_{axis}idx",
                IndexManager.from_array(idx) if has_xp(idx) else idx,
            )

        # self._adata_ref is never a view
        self._adata_ref = adata_ref
        # the file is the same as of the reference object
        self.file = adata_ref.file

        # views on attributes of adata_ref
        var_sub = adata_ref.var.iloc[
            np.array(self._vidx) if isinstance(self._vidx, IndexManager) else self._vidx
        ]
        obs_sub = adata_ref.obs.iloc[
            np.array(self._oidx) if isinstance(self._oidx, IndexManager) else self._oidx
        ]
        # fix categories
        uns = copy(adata_ref._uns)
        if settings.remove_unused_categories:
            self._remove_unused_categories(adata_ref.obs, obs_sub, uns)
            self._remove_unused_categories(adata_ref.var, var_sub, uns)
        # set attributes
        self._obs = as_view(obs_sub, view_args=(self, "obs"))
        self._var = as_view(var_sub, view_args=(self, "var"))
        self._uns = uns

        # set raw, easy, as it’s immutable anyways...
        if adata_ref._raw is not None:
            # slicing along variables axis is ignored
            self._raw = adata_ref.raw[self, oidx]
        else:
            self._raw = None

    def _init_as_actual(  # noqa: PLR0912, PLR0913, PLR0915
        self,
        X=None,
        *,
        obs=None,
        var=None,
        uns=None,
        obsm=None,
        varm=None,
        varp=None,
        obsp=None,
        raw=None,
        layers=None,
        shape=None,
        filename=None,
        filemode=None,
    ):
        # view attributes
        self._is_view = False
        self._adata_ref = None
        self._oidx = None
        self._vidx = None

        # ----------------------------------------------------------------------
        # various ways of initializing the data
        # ----------------------------------------------------------------------

        # If X is a data frame, we store its indices for verification
        x_indices = []

        # init from file
        if filename is not None:
            fileobj, filename = (
                (filename, None)
                if isinstance(filename, h5py.File)
                else (None, filename)
            )
            self.file = AnnDataFileManager(self, filename, filemode, fileobj)
        else:
            self.file = AnnDataFileManager(self, None)

            # init from AnnData
            if isinstance(X, AnnData):
                if any((obs, var, uns, obsm, varm, obsp, varp)):
                    msg = "If `X` is a dict no further arguments must be provided."
                    raise ValueError(msg)
                obs, var, uns, obsm, varm, obsp, varp, layers, raw = (
                    X.obs,
                    X.var,
                    X.uns,
                    X.obsm,
                    X.varm,
                    X.obsp,
                    X.varp,
                    X.layers,
                    X.raw,
                )
                X = X.layers.get(None)

            if layers is not None and None in layers:
                if X is not None and X is not layers[None]:
                    msg = (
                        "If you provide `layers[None]` and `X`, they must be identical."
                    )
                    raise ValueError(msg)
                X = layers[None]

            # init from DataFrame
            elif isinstance(X, pd.DataFrame):
                # to verify index matching, we wait until obs and var are DataFrames
                if obs is None:
                    obs = pd.DataFrame(index=X.index)
                elif not isinstance(X.index, pd.RangeIndex):
                    x_indices.append((
                        "obs",
                        "index",
                        pandas_as_str(X.index)
                        if settings.restrict_index_types
                        else X.index,
                    ))
                if var is None:
                    var = pd.DataFrame(index=X.columns)
                elif not isinstance(X.columns, pd.RangeIndex):
                    x_indices.append(("var", "columns", pandas_as_str(X.columns)))
                X = ensure_df_homogeneous(X, "X")

        # ----------------------------------------------------------------------
        # actually process the data
        # ----------------------------------------------------------------------

        # check data type of X
        if X is not None:
            X = coerce_array(X, name="X")
            if shape is not None:
                msg = "`shape` needs to be `None` if `X` is not `None`."
                raise ValueError(msg)
            # data matrix and shape
            n_obs, n_vars = X.shape[:2]
            source = "X"
        else:
            n_obs, n_vars = (
                shape
                if shape is not None
                else _infer_shape(
                    obs, var, obsm=obsm, varm=varm, layers=layers, obsp=obsp, varp=varp
                )
            )
            source = "shape"

        # annotations
        self._obs = _gen_dataframe(
            obs, ["obs_names", "row_names"], source=source, attr="obs", length=n_obs
        )
        self._var = _gen_dataframe(
            var, ["var_names", "col_names"], source=source, attr="var", length=n_vars
        )

        # now we can verify if indices match!
        for attr_name, x_name, idx in x_indices:
            attr = getattr(self, attr_name)
            if isinstance(attr.index, pd.RangeIndex):
                attr.index = idx
            elif not idx.equals(attr.index):
                msg = f"Index of {attr_name} must match {x_name} of X."
                raise ValueError(msg)

        # unstructured annotations
        self.uns = uns or OrderedDict()

        # aligned mappings go through `AlignedMappingProperty.__set__`, which validates and coerces
        # (`layers` is done a bit farther down in the same way)
        self.obsm = obsm
        self.varm = varm

        self.obsp = obsp
        self.varp = varp

        # Backwards compat for connectivities matrices in uns["neighbors"]
        _move_adj_mtx({"uns": self._uns, "obsp": self._obsp})
        self._check_dimensions()
        if settings.check_uniqueness:
            self._check_uniqueness()

        if self.filename:
            assert not isinstance(raw, Raw), (
                "got raw from other adata but also filename?"
            )
            if {"raw", "raw.X"} & set(self.file):
                raw = dict(X=None, **raw)

        # clean up old formats
        self._clean_up_old_format(uns)

        # layers
        self.layers = layers
        if X is not None:
            self.X = X
        if not raw:
            self._raw = None
        elif isinstance(raw, Mapping):
            self._raw = Raw(self, **raw)
        else:  # is a Raw from another AnnData
            self._raw = Raw(self, raw.X, raw.var, raw.varm)

    @old_positionals("show_stratified", "with_disk")
    def __sizeof__(
        self, *, show_stratified: bool = False, with_disk: bool = False
    ) -> int:
        def cs_to_bytes(X: CSArray | CSMatrix) -> int:
            return int(X.data.nbytes + X.indptr.nbytes + X.indices.nbytes)

        def get_size(X: RWAble) -> int:
            if isinstance(X, h5py.Dataset) and with_disk:
                return int(np.array(X.shape).prod() * X.dtype.itemsize)
            elif isinstance(X, BaseCompressedSparseDataset) and with_disk:
                return cs_to_bytes(X._to_backed())
            elif issparse(X):
                return cs_to_bytes(X)
            elif isinstance(X, dict | MutableMapping):
                return sum(get_size(v) for v in X.values())
            else:
                return X.__sizeof__()

        def fold_size(
            elem: _XDataType | AxisStorable | pd.DataFrame | XDataset,
            *,
            accumulate: dict[str, int],
            attr_name: str | None,  # TODO: type
        ):
            if elem is None:
                size = 0
            elif elem is self.raw:
                size = (
                    get_size(elem.X)
                    + get_size(elem.var)
                    + sum(get_size(v) for v in elem.varm.values())
                )
            else:
                size = get_size(elem)
            accumulate[attr_name] = size
            if size > 0 and show_stratified:
                from tqdm import tqdm

                print(f"Size of {attr_name}: {tqdm.format_sizeof(size, 'B')}")
            return accumulate

        return sum(self._reduce(fold_size, init=defaultdict(int)).values())

    def _gen_repr(self, n_obs, n_vars) -> str:
        backed_at = f" backed at {str(self.filename)!r}" if self.isbacked else ""
        descr = f"AnnData object with n_obs × n_vars = {n_obs} × {n_vars}{backed_at}"
        for attr_name, elem in iter_outer(self):
            if attr_name not in {"raw", "X"}:
                keys = elem.keys()
                if len(keys) > 0:
                    descr += f"\n    {attr_name}: {str(list(keys))[1:-1]}"
        return descr

    def __repr__(self) -> str:
        if self.is_view:
            return "View of " + self._gen_repr(self.n_obs, self.n_vars)
        else:
            return self._gen_repr(self.n_obs, self.n_vars)

    def __eq__(self, other):
        """Equality testing"""
        msg = (
            "Equality comparisons are not supported for AnnData objects, "
            "instead compare the desired attributes."
        )
        raise NotImplementedError(msg)

    @property
    def shape(self) -> tuple[int, int]:
        """Shape of data matrix (:attr:`n_obs`, :attr:`n_vars`)."""
        return self.n_obs, self.n_vars

    @property
    def X(self) -> _XDataType | None:
        """Data matrix of shape :attr:`n_obs` × :attr:`n_vars`."""
        if self.isbacked:
            if not self.file.is_open:
                self.file.open()
            X = self.file["X"]
            if isinstance(X, h5py.Group):
                X = sparse_dataset(X)
            # This is so that we can index into a backed dense dataset with
            # indices that aren’t strictly increasing
            if self.is_view:
                return _subset(X, (self._oidx, self._vidx))
            return X
        elif self.is_view and self._adata_ref.X is None:
            return None
        elif self.is_view:
            return as_view(
                _subset(self._adata_ref.X, (self._oidx, self._vidx)),
                ElementRef(self, "X"),
            )
        return self.layers.get(None)

    @X.setter
    def X(self, value: _XDataType | None) -> None:
        value = (
            coerce_array(value, name="X", allow_array_like=True)
            if value is not None
            else None
        )
        if np.isscalar(value) and value is not None:
            msg = "The ability to set X with a scalar value will be removed in the future.  Initializing as an `np.array` with the shape of the current view."
            warn(msg, FutureWarning)
            value = np.full(self.shape, fill_value=value)
        if hasattr(value, "shape") and value.shape[:2] != self.shape:
            if len(value.shape) > 2:
                msg = (
                    f"Cannot set `X` from an array of shape {tuple(value.shape)}: "
                    f"its leading two dimensions {tuple(value.shape[:2])} do not "
                    f"match the AnnData shape {tuple(self.shape)}. Automatic "
                    f"reshaping is only supported for 2-D inputs."
                )
                raise ValueError(msg)
            msg = "Automatic reshaping when setting X will be removed in the future."
            warn(msg, FutureWarning)
            value = value.reshape(self.shape)
        if (spec_msg := _non_2d_message(value, name="X")) is not None:
            # In-memory higher-than-2-D `X` is allowed, but the on-disk
            # AnnData spec is strict; flag it so users know early.
            warn(spec_msg, UserWarning)
        can_set_direct_if_not_none = (
            value is None
            or (hasattr(value, "shape") and (self.shape == value.shape[:2]))
            or (self.n_vars == 1 and self.n_obs == len(value))
            or (self.n_obs == 1 and self.n_vars == len(value))
        )
        if not can_set_direct_if_not_none:
            msg = f"Data matrix has wrong shape {value.shape}, need to be {self.shape}."
            raise ValueError(msg)
        if self.is_view:
            msg = "Setting element `.X` of view, initializing view as actual."
            warn(msg, ImplicitModificationWarning)
            self._init_as_actual(self._copy(X=value))
            return
        if value is not None:
            self.layers[None] = value
        else:
            self.layers.pop(None, None)

    @X.deleter
    def X(self) -> None:
        self.X = None

    layers: AlignedMappingProperty[Layers | LayersView, str | None] = (
        AlignedMappingProperty(Layers)
    )
    """\
    Dictionary-like object with values of the same dimensions as :attr:`X`.

    Layers in AnnData are inspired by loompy’s :ref:`loomlayers`.

    Return the layer named `"unspliced"`::

        adata.layers["unspliced"]

    Create or replace the `"spliced"` layer::

        adata.layers["spliced"] = ...

    Assign the 10th column of layer `"spliced"` to the variable a::

        a = adata.layers["spliced"][:, 10]

    Delete the `"spliced"` layer::

        del adata.layers["spliced"]

    Return layers’ names::

        adata.layers.keys()
    """

    @property
    def raw(self) -> Raw:
        """\
        Store raw version of :attr:`X` and :attr:`var` as `.raw.X` and `.raw.var`.

        The :attr:`raw` attribute is initialized with the current content
        of an object by setting::

            adata.raw = adata.copy()

        Its content can be deleted::

            adata.raw = None
            # or
            del adata.raw

        Upon slicing an AnnData object along the obs (row) axis, :attr:`raw`
        is also sliced. Slicing an AnnData object along the vars (columns) axis
        leaves :attr:`raw` unaffected. Note that you can call::

             adata.raw[:, 'orig_variable_name'].X

        to retrieve the data associated with a variable that might have been
        filtered out or "compressed away" in :attr:`X`.
        """
        return self._raw

    @raw.setter
    def raw(self, value: AnnData) -> None:
        if value is None:
            del self.raw
            return
        if not isinstance(value, AnnData):
            msg = "Can only init raw attribute with an AnnData object."
            raise ValueError(msg)
        raw = Raw(self, X=value.X, var=value.var, varm=value.varm)
        if self.is_view:
            self._init_as_actual(self.copy())
        self._raw = raw

    @raw.deleter
    def raw(self) -> None:
        if self.is_view:
            self._init_as_actual(self.copy())
        self._raw = None

    @property
    def n_obs(self) -> int:
        """Number of observations."""
        return len(self.obs_names)

    @property
    def n_vars(self) -> int:
        """Number of variables/features."""
        return len(self.var_names)

    def _set_dim_df(self, value: pd.DataFrame | XDataset, attr: Literal["obs", "var"]):
        value = _gen_dataframe(
            value,
            [f"{attr}_names", f"{'row' if attr == 'obs' else 'col'}_names"],
            source="shape",
            attr=attr,
            length=self.n_obs if attr == "obs" else self.n_vars,
        )
        raise_value_error_if_multiindex_columns(value, attr)
        value_idx = self._prep_dim_index(value.index, attr)
        if self.is_view:
            self._init_as_actual(self.copy())
        setattr(self, f"_{attr}", value)
        self._set_dim_index(value_idx, attr)
        if not len(value.columns):
            value.columns = value.columns.astype(str)

    def _prep_dim_index(self, value, attr: str) -> pd.Index:
        """Prepares index to be uses as obs_names or var_names for AnnData object.AssertionError

        If a pd.Index is passed, this will use a reference, otherwise a new index object is created.
        """
        if self.shape[attr == "var"] != len(value):
            msg = f"Length of passed value for {attr}_names is {len(value)}, but this AnnData has shape: {self.shape}"
            raise ValueError(msg)
        if (
            settings.restrict_index_types
            and isinstance(value, pd.Index)
            and not isinstance(value.name, str | type(None))
        ):
            msg = (
                f"AnnData expects .{attr}.index.name to be a string or None, "
                f"but you passed a name of type {type(value.name).__name__!r}"
            )
            raise ValueError(msg)
        else:
            value = (
                value if isinstance(value, pd.Index) else pandas_as_str(pd.Index(value))
            )
            if not isinstance(value.name, str | type(None)):
                value.name = None
        if (
            settings.restrict_index_types
            and len(value) > 0
            and not isinstance(value, pd.RangeIndex)
            and infer_dtype(value) not in {"string", "bytes"}
        ):
            sample = list(value[: min(len(value), 5)])
            msg = dedent(
                f"""
                AnnData expects .{attr}.index to contain strings, but got values like:
                    {sample}

                    Inferred to be: {infer_dtype(value)}
                """
            )
            warn(msg, UserWarning)
        return value

    def _set_dim_index(self, value: pd.Index, attr: str):
        # Assumes _prep_dim_index has been run
        if self.is_view:
            self._init_as_actual(self.copy())
        getattr(self, attr).index = value
        for v in getattr(self, f"_{attr}m").values():
            if isinstance(v, pd.DataFrame):
                v.index = value

    @property
    def obs(self) -> pd.DataFrame | Dataset2D:
        """One-dimensional annotation of observations (`pd.DataFrame`)."""
        return self._obs

    @obs.setter
    def obs(self, value: pd.DataFrame | XDataset):
        self._set_dim_df(value, "obs")

    @obs.deleter
    def obs(self):
        self.obs = pd.DataFrame({}, index=self.obs_names)

    @property
    def obs_names(self) -> pd.Index:
        """Names of observations (alias for `.obs.index`)."""
        return self.obs.index

    @obs_names.setter
    def obs_names(self, names: Sequence[str]):
        names = self._prep_dim_index(names, "obs")
        self._set_dim_index(names, "obs")

    @property
    def var(self) -> pd.DataFrame | Dataset2D:
        """One-dimensional annotation of variables/ features (`pd.DataFrame`)."""
        return self._var

    @var.setter
    def var(self, value: pd.DataFrame | XDataset):
        self._set_dim_df(value, "var")

    @var.deleter
    def var(self):
        self.var = pd.DataFrame({}, index=self.var_names)

    @property
    def var_names(self) -> pd.Index:
        """Names of variables (alias for `.var.index`)."""
        return self.var.index

    @var_names.setter
    def var_names(self, names: Sequence[str]):
        names = self._prep_dim_index(names, "var")
        self._set_dim_index(names, "var")

    @property
    def uns(self) -> MutableMapping:
        """Unstructured annotation (ordered dictionary)."""
        uns = self._uns
        if self.is_view:
            uns = DictView(uns, view_args=(self, "_uns"))
        return uns

    @uns.setter
    def uns(self, value: MutableMapping):
        if not isinstance(value, MutableMapping):
            msg = "Only mutable mapping types (e.g. dict) are allowed for `.uns`."
            raise ValueError(msg)
        if isinstance(value, DictView):
            value = value.copy()
        if self.is_view:
            self._init_as_actual(self.copy())
        self._uns = value

    @uns.deleter
    def uns(self):
        self.uns = OrderedDict()

    obsm: AlignedMappingProperty[AxisArrays | AxisArraysView, str] = (
        AlignedMappingProperty(AxisArrays, 0)
    )
    """\
    Multi-dimensional annotation of observations
    (mutable structured :class:`~numpy.ndarray`).

    Stores for each key a two or higher-dimensional :class:`~numpy.ndarray`
    of length `n_obs`.
    Is sliced with `data` and `obs` but behaves otherwise like a :term:`mapping`.
    """

    varm: AlignedMappingProperty[AxisArrays | AxisArraysView, str] = (
        AlignedMappingProperty(AxisArrays, 1)
    )
    """\
    Multi-dimensional annotation of variables/features
    (mutable structured :class:`~numpy.ndarray`).

    Stores for each key a two or higher-dimensional :class:`~numpy.ndarray`
    of length `n_vars`.
    Is sliced with `data` and `var` but behaves otherwise like a :term:`mapping`.
    """

    obsp: AlignedMappingProperty[PairwiseArrays | PairwiseArraysView, str] = (
        AlignedMappingProperty(PairwiseArrays, 0)
    )
    """\
    Pairwise annotation of observations,
    a mutable mapping with array-like values.

    Stores for each key a two or higher-dimensional :class:`~numpy.ndarray`
    whose first two dimensions are of length `n_obs`.
    Is sliced with `data` and `obs` but behaves otherwise like a :term:`mapping`.
    """

    varp: AlignedMappingProperty[PairwiseArrays | PairwiseArraysView, str] = (
        AlignedMappingProperty(PairwiseArrays, 1)
    )
    """\
    Pairwise annotation of variables/features,
    a mutable mapping with array-like values.

    Stores for each key a two or higher-dimensional :class:`~numpy.ndarray`
    whose first two dimensions are of length `n_var`.
    Is sliced with `data` and `var` but behaves otherwise like a :term:`mapping`.
    """

    @deprecated(
        Deprecation(
            "0.12.3",
            deprecation_msg(
                *("obs_keys", "obs"),
                "(e.g. `k in adata.obs` or `str(adata.obs.columns.tolist())`)",
            ),
        )
    )
    def obs_keys(self) -> list[str]:
        """List keys of observation annotation :attr:`obs`."""
        return self._obs.keys().tolist()

    @deprecated(
        Deprecation(
            "0.12.3",
            deprecation_msg(
                *("var_keys", "var"),
                "(e.g. `k in adata.var` or `str(adata.var.columns.tolist())`)",
            ),
        )
    )
    def var_keys(self) -> list[str]:
        """List keys of variable annotation :attr:`var`."""
        return self._var.keys().tolist()

    @deprecated(
        Deprecation(
            "0.12.3",
            deprecation_msg(
                *("obsm_keys", "obsm"),
                "(e.g. `k in adata.obsm` or `adata.obsm.keys() | {'u'}`)",
            ),
        )
    )
    def obsm_keys(self) -> list[str]:
        """List keys of observation annotation :attr:`obsm`."""
        return list(self.obsm.keys())

    @deprecated(
        Deprecation(
            "0.12.3",
            deprecation_msg(
                *("varm_keys", "varm"),
                "(e.g. `k in adata.varm` or `adata.varm.keys() | {'u'}`)",
            ),
        )
    )
    def varm_keys(self) -> list[str]:
        """List keys of variable annotation :attr:`varm`."""
        return list(self.varm.keys())

    @deprecated(
        Deprecation(
            "0.13",
            deprecation_msg(
                "uns_keys", "uns", "(e.g. `k in adata.uns` or `sorted(adata.uns)`)"
            ),
        )
    )
    def uns_keys(self) -> list[str]:
        """List keys of unstructured annotation."""
        return sorted(self._uns.keys())

    @property
    def isbacked(self) -> bool:
        """`True` if object is backed on disk, `False` otherwise."""
        return self.layers.isbacked

    @property
    def is_view(self) -> bool:
        """`True` if object is view of another AnnData object, `False` otherwise."""
        return self._is_view

    @property
    def filename(self) -> Path | None:
        """\
        Change to backing mode by setting the filename of a `.h5ad` file.

        - Setting the filename writes the stored data to disk.
        - Setting the filename when the filename was previously another name
          moves the backing file from the previous file to the new file.
          If you want to copy the previous file, use `copy(filename='new_filename')`.
        """
        return self.file.filename

    @filename.setter
    def filename(self, filename: PathLike[str] | str | None):
        # convert early for later comparison
        filename = None if filename is None else Path(filename)
        # change from backing-mode back to full loading into memory
        if filename is None:
            if self.filename is not None:
                self.file._to_memory_mode()
            else:
                # both filename and self.filename are None
                # do nothing
                return
        else:
            if self.filename is not None:
                if self.filename != filename:
                    # write the content of self to the old file
                    # and close the file
                    self.write()
                    self.filename.rename(filename)
                else:
                    # do nothing
                    return
            else:
                # change from memory to backing-mode
                # write the content of self to disk
                as_dense = ("X", "raw/X") if self.raw is not None else ("X",)
                self.write(filename, as_dense=as_dense)
            # open new file for accessing
            self.file.open(filename, "r+")
            # As the data is stored on disk, we can safely set remove it.
            # Setting `X` to `None` now would raise an error because `self.isbacked`.
            self.layers.pop(None, None)

    def _set_backed(self, attr, value):
        from .._io.utils import write_attribute

        write_attribute(self.file._file, attr, value)

    def _normalize_indices(
        self, index: Index
    ) -> tuple[_Index1DNorm | int | np.integer, _Index1DNorm | int | np.integer]:
        return _normalize_indices(index, self.obs_names, self.var_names)

    @overload
    def __getitem__(self, index: MetaAcc) -> DataFrameLike: ...
    @overload
    def __getitem__(self, index: MultiAcc) -> FullArray: ...
    @overload
    def __getitem__(self, index: LayerAcc | GraphAcc) -> _XDataType: ...
    @overload
    def __getitem__(self, index: AdRef) -> Array: ...
    @overload
    def __getitem__(self, index: Index) -> AnnData: ...
    def __getitem__(self, index: Index | AdRef) -> AnnData | Array | FullArray:
        """Slice AnnData object or retrieve an array using an :class:`~anndata.acc.AdRef`."""
        from ..acc import AdRef, MapAcc, RefAcc

        if isinstance(index, AdRef):
            return index.acc.get(self, index.idx)
        elif isinstance(index, RefAcc):
            return index.get(self)
        elif isinstance(index, MapAcc):
            msg = f"Cannot index with {index} because this is not a path to an array-like structure."
            raise IndexError(msg)

        oidx, vidx = self._normalize_indices(index)
        return AnnData(self, oidx=oidx, vidx=vidx, asview=True)

    @singledispatchmethod
    @staticmethod
    def _remove_unused_categories(
        df_full: pd.DataFrame, df_sub: pd.DataFrame, uns: dict[str, Any]
    ):
        for k in df_full:
            if not isinstance(df_full[k].dtype, pd.CategoricalDtype):
                continue
            all_categories = df_full[k].cat.categories
            # TODO: this mode is going away
            with pd.option_context("mode.chained_assignment", None):
                df_sub[k] = df_sub[k].cat.remove_unused_categories()
            # also correct the colors...
            color_key = f"{k}_colors"
            if color_key not in uns:
                continue
            color_vec = uns[color_key]
            if np.array(color_vec).ndim == 0:
                # Make 0D arrays into 1D ones
                uns[color_key] = np.array(color_vec)[(None,)]
            elif len(color_vec) != len(all_categories):
                # Reset colors
                del uns[color_key]
            else:
                idx = np.where(np.isin(all_categories, df_sub[k].cat.categories))[0]
                uns[color_key] = np.array(color_vec)[(idx,)]

    def rename_categories(self, key: str, categories: Sequence[Any]):
        """\
        Rename categories of annotation `key` in :attr:`obs`, :attr:`var`,
        and :attr:`uns`.

        Only supports passing a list/array-like `categories` argument.

        Besides calling `self.obs[key].cat.categories = categories` –
        similar for :attr:`var` - this also renames categories in unstructured
        annotation that uses the categorical annotation `key`.

        Parameters
        ----------
        key
             Key for observations or variables annotation.
        categories
             New categories, the same number as the old categories.
        """
        if isinstance(categories, Mapping):
            msg = "Only list-like `categories` is supported."
            raise ValueError(msg)
        if key in self.obs:
            old_categories = self.obs[key].cat.categories.tolist()
            self.obs[key] = self.obs[key].cat.rename_categories(categories)
        elif key in self.var:
            old_categories = self.var[key].cat.categories.tolist()
            self.var[key] = self.var[key].cat.rename_categories(categories)
        else:
            msg = f"{key} is neither in `.obs` nor in `.var`."
            raise ValueError(msg)
        # this is not a good solution
        # but depends on the scanpy conventions for storing the categorical key
        # as `groupby` in the `params` slot
        for k1, v1 in self.uns.items():
            if not (
                isinstance(v1, Mapping)
                and "params" in v1
                and "groupby" in v1["params"]
                and v1["params"]["groupby"] == key
            ):
                continue
            for k2, v2 in v1.items():
                # picks out the recarrays that are named according to the old
                # categories
                if isinstance(v2, np.ndarray) and v2.dtype.names is not None:
                    if list(v2.dtype.names) == old_categories:
                        self.uns[k1][k2].dtype.names = categories
                    else:
                        logger.warning(
                            f"Omitting {k1}/{k2} as old categories do not match."
                        )

    def strings_to_categoricals(self, df: pd.DataFrame | None = None):
        """\
        Transform string annotations to categoricals.

        Only affects string annotations that lead to less categories than the
        total number of observations.

        Params
        ------
        df
            If `df` is `None`, modifies both :attr:`obs` and :attr:`var`,
            otherwise modifies `df` inplace.

        Notes
        -----
        Turns the view of an :class:`~anndata.AnnData` into an actual
        :class:`~anndata.AnnData`.
        """
        dont_modify = False  # only necessary for backed views
        if df is None:
            dfs = [self.obs, self.var]
            if self.is_view and self.isbacked:
                dont_modify = True
        else:
            dfs = [df]
        del df

        for df in dfs:
            string_cols = [
                key for key in df.columns if infer_dtype(df[key]) == "string"
            ]
            for key in string_cols:
                c = pd.Categorical(df[key])
                # TODO: We should only check if non-null values are unique, but
                # this would break cases where string columns with nulls could
                # be written as categorical, but not as string.
                # Possible solution: https://github.com/scverse/anndata/issues/504
                if len(c.categories) >= len(c):
                    continue
                # Ideally this could be done inplace
                sorted_categories = natsorted(c.categories)
                if not np.array_equal(c.categories, sorted_categories):
                    c = c.reorder_categories(sorted_categories)
                if dont_modify:
                    msg = (
                        "Please call `.strings_to_categoricals()` on full "
                        "AnnData, not on this view. You might encounter this"
                        "error message while copying or writing to disk."
                    )
                    raise RuntimeError(msg)
                df[key] = c
                logger.info(f"... storing {key!r} as categorical")

    _sanitize = strings_to_categoricals  # backwards compat

    def _inplace_subset_var(self, index: Index1D):
        """\
        Inplace subsetting along variables dimension.

        Same as `adata = adata[:, index]`, but inplace.
        """
        adata_subset = self[:, index].copy()

        self._init_as_actual(adata_subset)

    def _inplace_subset_obs(self, index: Index1D):
        """\
        Inplace subsetting along variables dimension.

        Same as `adata = adata[index, :]`, but inplace.
        """
        adata_subset = self[index].copy()

        self._init_as_actual(adata_subset)

    def __len__(self) -> int:
        return self.shape[0]

    def transpose(self) -> AnnData:
        """\
        Transpose whole object.

        Data matrix is transposed, observations and variables are interchanged.
        Ignores `.raw`.
        """
        from anndata.compat import _safe_transpose

        if self.is_view:
            msg = (
                "You’re trying to transpose a view of an `AnnData`, "
                "which is currently not implemented. Call `.copy()` before transposing."
            )
            raise ValueError(msg)
        if any(
            isinstance(elem, ZarrArray | BaseCompressedSparseDataset | h5py.Dataset)
            for elem in (self.X, *self.layers.values())
        ):
            msg = "Cannot transpose anndata object that has raw zarr arrays or h5py arrays backing X or layers"
            raise ValueError(msg)

        return AnnData(
            layers={k: _safe_transpose(v) for k, v in self.layers.items()},
            obs=self.var,
            var=self.obs,
            uns=self._uns,
            obsm=self.varm,
            varm=self.obsm,
            obsp=self.varp,
            varp=self.obsp,
            filename=self.filename,
        )

    T = property(transpose)

    def to_df(self, layer: str | None = None) -> pd.DataFrame:
        """\
        Generate shallow :class:`~pandas.DataFrame`.

        The data matrix :attr:`X` is returned as
        :class:`~pandas.DataFrame`, where :attr:`obs_names` initializes the
        index, and :attr:`var_names` the columns.

        * No annotations are maintained in the returned object.
        * The data matrix is densified in case it is sparse.

        Params
        ------
        layer
            Key for `.layers`.

        Returns
        -------
        Pandas DataFrame of specified data matrix.
        """
        if layer is not None:
            X = self.layers[layer]
        elif not self._has_X():
            msg = "X is None, cannot convert to dataframe."
            raise ValueError(msg)
        else:
            X = self.X
        if issparse(X):
            X = X.toarray()
        return pd.DataFrame(X, index=self.obs_names, columns=self.var_names)

    @deprecated(
        Deprecation(
            "0.13",
            deprecation_msg(
                "obs_vector",
                "anndata.acc.A",
                "E.g. `vec = adata[A.obs['foo']]` or `vec = adata[A.layers['l']['bar', :]]`",
            ),
        )
    )
    def obs_vector(self, k: str, /, *, layer: str | None = None) -> np.ndarray:
        """\
        Convenience function for returning a 1 dimensional ndarray of values from :attr:`X`, :attr:`layers`\\ `[k]`, or :attr:`obs`.

        Made for convenience, not performance.
        Intentionally permissive about arguments, for easy iterative use.

        Params
        ------
        k
            Key to use. Should be in :attr:`var_names` or :attr:`obs`\\ `.columns`.
        layer
            What layer values should be returned from. If `None`, :attr:`X` is used.

        Returns
        -------
        A one dimensional ndarray, with values for each obs in the same order
        as :attr:`obs_names`.
        """
        return _get_vector_ambiguous(self, k, "obs", layer=layer)

    @deprecated(
        Deprecation(
            "0.13",
            deprecation_msg(
                "var_vector",
                "anndata.acc.A",
                "E.g. `vec = adata[A.var['foo']]` or `vec = adata[A.layers['l'][:, 'bar']]`",
            ),
        )
    )
    def var_vector(self, k: str, /, *, layer: str | None = None) -> np.ndarray:
        """\
        Convenience function for returning a 1 dimensional ndarray of values from :attr:`X`, :attr:`layers`\\ `[k]`, or :attr:`obs`.

        Made for convenience, not performance. Intentionally permissive about
        arguments, for easy iterative use.

        Params
        ------
        k
            Key to use. Should be in :attr:`obs_names` or :attr:`var`\\ `.columns`.
        layer
            What layer values should be returned from. If `None`, :attr:`X` is used.

        Returns
        -------
        A one dimensional ndarray, with values for each var in the same order
        as :attr:`var_names`.
        """
        return _get_vector_ambiguous(self, k, "var", layer=layer)

    def _copy(
        self, *, X: _XDataType | None | Literal["no_set_X"] = "no_set_X"
    ) -> AnnData:
        from ..typing import _XDataType

        new = {}
        for key, elem in iter_outer(self):
            if elem is not None:
                elem = elem.copy()
            new[key] = elem
            if key == "layers" and isinstance(
                X, (*get_union_members(_XDataType), type(None))
            ):
                new[key][None] = X
        new["uns"] = deepcopy(self._uns)
        if self.raw is not None:
            new["raw"] = self.raw.copy()
        return AnnData(**new)

    @old_positionals("copy")
    def to_memory(self, *, copy: bool = False) -> AnnData:
        """Return a new AnnData object with all non-in-memory arrays loaded into memory.

        Params
        ------
        copy
            Whether the arrays that are already in-memory should be copied.

        Example
        -------

        .. code:: python

            import anndata
            backed = anndata.io.read_h5ad("file.h5ad", backed="r")
            mem = backed[backed.obs["cluster"] == "a", :].to_memory()
        """
        new = {}
        for attr_name, attr in iter_outer(self):
            if attr is not None:
                if attr is self.raw:
                    new["raw"] = {
                        "X": to_memory(self.raw.X, copy=copy),
                        "var": to_memory(self.raw.var, copy=copy),
                        "varm": to_memory(self.raw.varm, copy=copy),
                    }
                else:
                    new[attr_name] = to_memory(attr, copy=copy)
        return AnnData(**new)

    def _has_raw_zarr_or_h5_array(self) -> bool:
        def predicate(
            elem: RWAble,
            *,
            accumulate: bool,
            attr_name: AnnDataElem | None = None,
        ):
            if isinstance(elem, MutableMapping):
                return accumulate or any(
                    isinstance(
                        v, ZarrArray | BaseCompressedSparseDataset | h5py.Dataset
                    )
                    for v in elem.values()
                )
            return accumulate or isinstance(
                elem, ZarrArray | BaseCompressedSparseDataset | h5py.Dataset
            )

        return self._reduce(predicate, init=False)

    def copy(self, filename: PathLike[str] | str | None = None) -> AnnData:
        """Full copy, optionally on disk."""
        if not self.isbacked:
            if self._has_raw_zarr_or_h5_array():
                msg = "Copy is not implemented for anndatas which have backing raw h5 (not in backed mode) or zarr arrays"
                raise NotImplementedError(msg)
            return self._copy()
        else:
            from ..io import read_h5ad, write_h5ad

            if filename is None:
                msg = (
                    "To copy an AnnData object in backed mode, "
                    "pass a filename: `.copy(filename='myfilename.h5ad')`. "
                    "To load the object into memory, use `.to_memory()`."
                )
                raise ValueError(msg)
            mode = self.file._filemode
            write_h5ad(filename, self)
            return read_h5ad(filename, backed=mode)

    def _reduce[T](
        self,
        func: ReduceFunc[T],
        *,
        init: T,
    ) -> T:
        """Accumulate a value starting from init by iterating over the parent "elems"of the AnnData object i.e., raw, obs, varp etc.

        Parameters
        ----------
        func
            The function that performs the accumulation.
        init
            The starting value

        Returns
        -------
            An accumulated value
        """
        accumulate = init
        for attr_name, attr in iter_outer(self):
            accumulate = func(attr, accumulate=accumulate, attr_name=attr_name)
        return accumulate

    def unwriteable(self, *, store_type: Literal["h5", "zarr"] | None = None) -> bool:
        """Whether or not an `AnnData` object can be written to disk for a given store type.

        Parameters
        ----------
        store_type
            Which backing store - `None` indicates that it can be writeable to either.

        Returns
        -------
            Whether or not this object is writeable.
            While the return type may change to include richer output about which elements cannot be written,
            this new type's evaluation as a boolean will not change from the current behavior i.e.,
            `bool(adata.unwriteable())` will always evaluate the same.
        """

        if _non_2d_message(self.X, name="X") is not None:
            return True
        for value in self.layers.values():
            if _non_2d_message(value, name="layer") is not None:
                return True

        from anndata._io.specs.registry import _REGISTRY

        writeable_elems = {
            src_type
            for (dest_type, src_type, __) in _REGISTRY.write
            if store_type is None or store_type in dest_type.__module__
        }

        def predicate(  # noqa: PLR0911
            elem: RWAble,
            *,
            accumulate: bool,
            attr_name: AnnDataElem | None = None,
        ):
            if elem is None:
                return accumulate
            if isinstance(elem, AnnData):
                return accumulate or elem.unwriteable(store_type=store_type)
            if isinstance(elem, pd.Categorical):
                return accumulate or predicate(elem.categories, accumulate=accumulate)
            if isinstance(elem, pd.Series | pd.Index):
                # matches behavior in methods.py
                return accumulate or predicate(elem._values, accumulate=accumulate)
            if isinstance(elem, AwkArray):
                import awkward as ak

                container = ak.to_buffers(ak.to_packed(elem))
                return accumulate or any(
                    predicate(v, accumulate=accumulate) for v in container[2].values()
                )
            if attr_name == "raw":
                return (
                    accumulate
                    or any(
                        predicate(e[attr], accumulate=accumulate)
                        for e in [elem.var, elem.varm]
                        for attr in e
                    )
                    or predicate(elem.X, accumulate=accumulate)
                )
            if attr_name in {
                "obs",
                "obsm",
                "varm",
                "var",
                "layers",
                "varp",
                "obsp",
                "uns",
            } or isinstance(elem, pd.DataFrame | XDataset | MutableMapping):
                accumulate = accumulate or any(
                    predicate(elem[k], accumulate=accumulate) for k in elem
                )
                if isinstance(elem, pd.DataFrame):
                    return accumulate or predicate(elem.index, accumulate=accumulate)
                return accumulate
            return (
                (accumulate or type(elem) not in writeable_elems)
                if not isinstance(elem, SupportsArrayApiBase)
                else accumulate
            )

        return self._reduce(predicate, init=False)

    def var_names_make_unique(self, join: str = "-") -> None:
        # Important to go through the setter so obsm dataframes are updated too
        self.var_names = utils.make_index_unique(self.var.index, join)

    var_names_make_unique.__doc__ = utils.make_index_unique.__doc__

    def obs_names_make_unique(self, join: str = "-") -> None:
        # Important to go through the setter so obsm dataframes are updated too
        self.obs_names = utils.make_index_unique(self.obs.index, join)

    obs_names_make_unique.__doc__ = utils.make_index_unique.__doc__

    def _check_uniqueness(self) -> None:
        if (
            settings.restrict_index_types
            and self.obs.index[~self.obs.index.isna()].has_duplicates
        ):
            utils.warn_names_duplicates("obs")
        if (
            settings.restrict_index_types
            and self.var.index[~self.var.index.isna()].has_duplicates
        ):
            utils.warn_names_duplicates("var")

    def __contains__(self, key: AdRef | RefAcc | MapAcc) -> bool:
        """Check if array is in AnnData.

        When passed a :class:`~anndata.acc.MapAcc`,
        it will check if the referenced map has any entries,
        e.g. `A.obsm in adata` will return `True` if `adata.obsm` is not empty.
        """
        from ..acc import AdRef, GraphMapAcc, LayerMapAcc, MapAcc, MultiMapAcc, RefAcc

        match key:
            case LayerMapAcc():
                return bool(self.layers)
            case MultiMapAcc():
                return bool(getattr(self, f"{key.dim}m"))
            case GraphMapAcc():
                return bool(getattr(self, f"{key.dim}p"))
            case MapAcc():  # to check MapAccs, we need to know the attribute name
                msg = f"Unknown MapAcc subclass {type(key)}."
                raise TypeError(msg)
            case RefAcc():
                return key.isin(self)
            case AdRef():
                return key.acc.isin(self, key.idx)
            case _:
                msg = f"Unexpected key {key!r} is not a valid reference (`anndata.acc.*`)."
                raise TypeError(msg)

    def _check_dimensions(self, key=None):
        key = {"obsm", "varm"} if key is None else {key}
        if "obsm" in key and (
            not all(axis_len(o, 0) == self.n_obs for o in self.obsm.values())
            and len(self.obsm.dim_names) != self.n_obs
        ):
            msg = (
                "Observations annot. `obsm` must have number of rows of `X`"
                f" ({self.n_obs}), but has {len(self.obsm)} rows."
            )
            raise ValueError(msg)
        if "varm" in key and (
            not all(axis_len(v, 0) == self.n_vars for v in self.varm.values())
            and len(self.varm.dim_names) != self.n_vars
        ):
            msg = (
                "Variables annot. `varm` must have number of columns of `X`"
                f" ({self.n_vars}), but has {len(self.varm)} rows."
            )
            raise ValueError(msg)

    @old_positionals("compression", "compression_opts", "as_dense")
    def write_h5ad(
        self,
        filename: PathLike[str] | str | None = None,
        *,
        convert_strings_to_categoricals: bool = True,
        compression: Literal["gzip", "lzf"] | None = None,
        compression_opts: int | Any = None,
        as_dense: Sequence[str] = (),
    ):
        """\
        Write `.h5ad`-formatted hdf5 file.

        .. note::
           Setting compression to `'gzip'` can save disk space
           but will slow down writing and subsequent reading.
           Prior to v0.6.16, this was the default for parameter `compression`.

        Generally, if you have sparse data that are stored as a dense matrix,
        you can dramatically improve performance and reduce disk space
        by converting to a :class:`~scipy.sparse.csr_matrix`::

            from scipy.sparse import csr_matrix
            adata.X = csr_matrix(adata.X)

        Parameters
        ----------
        filename
            Filename of data file. Defaults to backing file.
        convert_strings_to_categoricals
            Convert string columns to categorical.
        compression
            For [`lzf`, `gzip`], see the h5py :ref:`dataset_compression`.

            Alternative compression filters such as `zstd` can be passed
            from the :doc:`hdf5plugin <hdf5plugin:usage>` library.
            Experimental.

            Usage example::

                import hdf5plugin
                adata.write_h5ad(
                    filename,
                    compression=hdf5plugin.FILTERS["zstd"]
                )

            .. note::
                Datasets written with hdf5plugin-provided compressors
                cannot be opened without first loading the hdf5plugin
                library using `import hdf5plugin`. When using alternative
                compression filters such as `zstd`, consider writing to
                `zarr` format instead of `h5ad`, as the `zarr` library
                provides a more transparent compression pipeline.

        compression_opts
            For [`lzf`, `gzip`], see the h5py :ref:`dataset_compression`.

            Alternative compression filters such as `zstd` can be configured
            using helpers from the :doc:`hdf5plugin <hdf5plugin:usage>`
            library. Experimental.

            Usage example (setting `zstd` compression level to 5)::

                import hdf5plugin
                adata.write_h5ad(
                    filename,
                    compression=hdf5plugin.FILTERS["zstd"],
                    compression_opts=hdf5plugin.Zstd(clevel=5).filter_options
                )

        as_dense
            Sparse arrays in AnnData object to write as dense. Currently only
            supports `X` and `raw/X`.
        """
        from ..io import write_h5ad

        if filename is None and not self.isbacked:
            msg = "Provide a filename!"
            raise ValueError(msg)
        if filename is None:
            filename = self.filename

        write_h5ad(
            Path(filename),
            self,
            convert_strings_to_categoricals=convert_strings_to_categoricals,
            compression=compression,
            compression_opts=compression_opts,
            as_dense=as_dense,
        )
        # Only reset the filename if the AnnData object now points to a complete new copy
        if self.isbacked and not self.is_view:
            self.file.filename = filename

    write = write_h5ad  # a shortcut and backwards compat

    @old_positionals("skip_data", "sep")
    def write_csvs(
        self, dirname: PathLike[str] | str, *, skip_data: bool = True, sep: str = ","
    ):
        """\
        Write annotation to `.csv` files.

        It is not possible to recover the full :class:`~anndata.AnnData` from
        these files. Use :meth:`write` for this.

        Parameters
        ----------
        dirname
            Name of directory to which to export.
        skip_data
             Skip the data matrix :attr:`X`.
        sep
             Separator for the data.
        """
        from ..io import write_csvs

        write_csvs(dirname, self, skip_data=skip_data, sep=sep)

    @deprecated(
        Deprecation(
            "0.13",
            "Deprecated in favor of other formats, e.g. `write_h5ad`. "
            "Loom isn’t well-maintained and supports only a subset of anndata features.",
        )
    )
    @old_positionals("write_obsm_varm")
    def write_loom(
        self, filename: PathLike[str] | str, *, write_obsm_varm: bool = False
    ):
        """\
        Write `.loom`-formatted hdf5 file.

        Parameters
        ----------
        filename
            The filename.
        """
        from ..io import write_loom

        write_loom(filename, self, write_obsm_varm=write_obsm_varm)

    @old_positionals("chunks")
    def write_zarr(
        self,
        store: StoreLike,
        *,
        chunks: tuple[int, ...] | None = None,
        convert_strings_to_categoricals: bool = True,
        consolidate_metadata: bool = True,
    ):
        """\
        Write a hierarchical Zarr array store.

        Parameters
        ----------
        store
            The filename, a :class:`~typing.MutableMapping`, or a Zarr storage class.
        chunks
            Chunk shape.
        convert_strings_to_categoricals
            Convert string columns to categorical.
        consolidate_metadata
            Whether to consolidate the metadata of the store after writing.
        """
        from ..io import write_zarr

        # TODO: What is a bool for chunks supposed to do?
        if isinstance(chunks, bool):
            msg = (
                "Passing `write_zarr(adata, chunks=True)` is no longer supported. "
                "Please pass `write_zarr(adata)` instead."
            )
            raise ValueError(msg)
        write_zarr(
            store,
            self,
            chunks=chunks,
            convert_strings_to_categoricals=convert_strings_to_categoricals,
            consolidate_metadata=consolidate_metadata,
        )

    def chunked_X(self, chunk_size: int | None = None):
        """\
        Return an iterator over the rows of the data matrix :attr:`X`.

        Parameters
        ----------
        chunk_size
            Row size of a single chunk.
        """
        if chunk_size is None:
            # Should be some adaptive code
            chunk_size = 6000
        start = 0
        n = self.n_obs
        for _ in range(int(n // chunk_size)):
            end = start + chunk_size
            yield (self.X[start:end], start, end)
            start = end
        if start < n:
            yield (self.X[start:n], start, n)

    @old_positionals("replace")
    def chunk_X(
        self,
        select: int | Sequence[int] | np.ndarray = 1000,
        *,
        replace: bool = True,
    ):
        """\
        Return a chunk of the data matrix :attr:`X` with random or specified indices.

        Parameters
        ----------
        select
            Depending on the type:

            :class:`int`
                A random chunk with `select` rows will be returned.
            :term:`sequence` (e.g. a list, tuple or numpy array) of :class:`int`
                A chunk with these indices will be returned.

        replace
            If `select` is an integer then `True` means random sampling of
            indices with replacement, `False` without replacement.
        """
        if isinstance(select, int):
            select = select if select < self.n_obs else self.n_obs
            choice = np.random.choice(self.n_obs, select, replace)
        elif isinstance(select, np.ndarray | Sequence):
            choice = np.asarray(select)
        else:
            msg = "select should be int or array"
            raise ValueError(msg)

        reverse = None
        if self.isbacked:
            # h5py can only slice with a sorted list of unique index values
            # so random batch with indices [2, 2, 5, 3, 8, 10, 8] will fail
            # this fixes the problem
            indices, reverse = np.unique(choice, return_inverse=True)
            selection = self.X[indices.tolist()]
        else:
            selection = self.X[choice]

        selection = selection.toarray() if issparse(selection) else selection
        return selection if reverse is None else selection[reverse]

    def _has_X(self) -> bool:
        """
        Check if X is None.

        This is more efficient than trying `adata.X is None` for views, since creating
        views (at least anndata's kind) can be expensive.
        """
        if not self.is_view:
            return self.X is not None
        else:
            return self._adata_ref.X is not None

    # --------------------------------------------------------------------------
    # all of the following is for backwards compat
    # --------------------------------------------------------------------------

    @property
    @deprecated(Deprecation("0.7.2", deprecation_msg("isview", "is_view")))
    def isview(self) -> bool:
        """Whether or not this object is a view."""
        return self.is_view

    def _clean_up_old_format(self, uns):
        # multicolumn keys
        # all of the rest is only for backwards compat
        for bases in [["obs", "smp"], ["var"]]:
            axis = bases[0]
            for k in [f"{p}{base}_keys_multicol" for p in ["", "_"] for base in bases]:
                if uns and k in uns:
                    keys = list(uns[k])
                    del uns[k]
                    break
            else:
                keys = []
            # now, for compat, fill the old multicolumn entries into obsm and varm
            # and remove them from obs and var
            m_attr = getattr(self, f"_{axis}m")
            for key in keys:
                m_attr[key] = self._get_and_delete_multicol_field(axis, key)

    def _get_and_delete_multicol_field(self, a, key_multicol):
        keys = [k for k in getattr(self, a).columns if k.startswith(key_multicol)]
        values = getattr(self, a)[keys].values
        getattr(self, a).drop(keys, axis=1, inplace=True)
        return values


@AnnData._remove_unused_categories.register(Dataset2D)
@staticmethod
def _remove_unused_categories_xr(
    df_full: Dataset2D, df_sub: Dataset2D, uns: dict[str, Any]
):
    pass  # this is handled automatically by the categorical arrays themselves i.e., they dedup upon access.


def _check_2d_shape(X):
    """\
    Check shape of array or sparse matrix.

    Assure that X is always 2D: Unlike numpy we always deal with 2D arrays.
    """
    if X.dtype.names is None and len(X.shape) != 2:
        msg = f"X needs to be 2-dimensional, not {len(X.shape)}-dimensional."
        raise ValueError(msg)


def _infer_shape_for_axis(
    xxx: pd.DataFrame | Mapping[str, Iterable[Any]] | None,
    xxxm: np.ndarray | Mapping[str, Sequence[Any]] | None,
    layers: Mapping[str, np.ndarray | sparse.spmatrix] | None,
    xxxp: np.ndarray | Mapping[str, Sequence[Any]] | None,
    axis: Literal[0, 1],
) -> int | None:
    for elem in [xxx, xxxm, xxxp]:
        if elem is not None and hasattr(elem, "shape"):
            return elem.shape[0]
    for elem, id in zip([layers, xxxm, xxxp], ["layers", "xxxm", "xxxp"], strict=True):
        if elem is not None:
            elem = cast("Mapping", elem)
            for sub_elem in elem.values():
                if hasattr(sub_elem, "shape"):
                    size = cast("int", sub_elem.shape[axis if id == "layers" else 0])
                    return size
    return None


def _infer_shape(
    obs: pd.DataFrame | Mapping[str, Iterable[Any]] | None = None,
    var: pd.DataFrame | Mapping[str, Iterable[Any]] | None = None,
    *,
    obsm: np.ndarray | Mapping[str, Sequence[Any]] | None = None,
    varm: np.ndarray | Mapping[str, Sequence[Any]] | None = None,
    layers: Mapping[str, np.ndarray | sparse.spmatrix] | None = None,
    obsp: np.ndarray | Mapping[str, Sequence[Any]] | None = None,
    varp: np.ndarray | Mapping[str, Sequence[Any]] | None = None,
):
    return (
        _infer_shape_for_axis(obs, obsm, layers, obsp, 0),
        _infer_shape_for_axis(var, varm, layers, varp, 1),
    )
