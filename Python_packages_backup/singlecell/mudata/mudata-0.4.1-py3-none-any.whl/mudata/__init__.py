"""Multimodal datasets"""

from contextlib import suppress

from anndata import AnnData
from scverse_misc import ExtensionNamespace
from scverse_misc import make_register_namespace_decorator as _make_register_namespace_decorator

from ._core import utils
from ._core.io import (
    read,
    read_anndata,
    read_h5ad,
    read_h5mu,
    read_zarr,
    write,
    write_anndata,
    write_h5ad,
    write_h5mu,
    write_zarr,
)
from ._core.merge import concat
from ._core.mudata import MuData
from ._core.settings import settings
from ._core.to_ import to_anndata, to_mudata
from ._version import __version__, __version_tuple__

# file format versions
__anndataversion__ = "0.1.0"
__mudataversion__ = "0.1.0"

register_mudata_namespace = _make_register_namespace_decorator(MuData, "mdata")

__all__ = [
    "__version__",
    "MuData",
    "AnnData",
    "utils",
    "settings",
    "to_anndata",
    "to_mudata",
    "concat",
    "read",
    "read_h5ad",
    "read_anndata",
    "read_h5mu",
    "read_zarr",
    "write",
    "write_h5ad",
    "write_anndata",
    "write_h5mu",
    "write_zarr",
    "register_mudata_namespace",
    "ExtensionNamespace",
]

with suppress(ImportError):
    from . import acc

    __all__.append("acc")
