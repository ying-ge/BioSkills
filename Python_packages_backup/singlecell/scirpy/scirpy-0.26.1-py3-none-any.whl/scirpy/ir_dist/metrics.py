import abc
import itertools
from collections.abc import Sequence
from typing import Literal

import joblib
import matplotlib.pyplot as plt
import numba as nb
import numpy as np
import scipy.sparse
import scipy.spatial
from Levenshtein import distance as levenshtein_dist
from scanpy import logging
from scipy.sparse import coo_matrix, csr_matrix
from scverse_misc import Deprecation, deprecated, deprecated_arg

from scirpy.util import _doc_params, _get_usable_cpus, _parallelize_with_joblib

from ._substitution_matrices import (
    AA_ALPHABET_WITH_AMBIGUOUS,
    AA_ALPHABET_WITH_UNKNOWN,
    BLOSUM62,
    CANONICAL_AA_ALPHABET,
    TCRBLOSUM_ALPHA,
    TCRBLOSUM_BETA,
    _map_matrix_to_alphabet,
    _substitution_to_distance_matrix,
)

#: Deprecation of the object-level `block_size` parameter, shared by all `ParallelDistanceCalculator`s.
_deprecation_block_size = Deprecation(
    "0.15.0", "The block size is now set in the `calc_dist_mat` function instead of the object level."
)

_doc_params_parallel_distance_calculator = """\
n_jobs
    Number of jobs to use for the pairwise distance calculation, passed to
    :class:`joblib.Parallel`. If -1, use all CPUs (only for ParallelDistanceCalculators).
    Via the :class:`joblib.parallel_config` context manager, another backend (e.g. `dask`)
    can be selected.
block_size
    Deprecated since v0.15.0. This is now set in `calc_dist_mat` and ignored here.
"""


_doc_dist_mat = """\
Calculates the full pairwise distance matrix.

.. important::
  * Distances are offset by 1 to allow efficient use of sparse matrices
    (:math:`d' = d+1`).
  * That means, a `distance > cutoff` is represented as `0`, a `distance == 0`
    is represented as `1`, a `distance == 1` is represented as `2` and so on.
  * Only returns distances `<= cutoff`. Larger distances are eliminated
    from the sparse matrix.
  * Distances are non-negative.

"""


class DistanceCalculator(abc.ABC):
    """\
    Abstract base class for a :term:`CDR3`-sequence distance calculator.

    Parameters
    ----------
    cutoff:
        Distances > cutoff will be eliminated to make efficient use of sparse matrices.
        If None, the default cutoff shall be used.

    """

    #: The sparse matrix dtype. Defaults to uint8, constraining the max distance to 255.
    DTYPE = "uint8"

    def __init__(self, cutoff: int | None):
        if cutoff > 255:
            raise ValueError("Using a cutoff > 255 is not possible due to the `uint8` dtype used")
        self.cutoff = cutoff

    @_doc_params(dist_mat=_doc_dist_mat)
    @abc.abstractmethod
    def calc_dist_mat(self, seqs: Sequence[str], seqs2: Sequence[str] | None = None) -> csr_matrix:
        """\
        Calculate pairwise distance matrix of all sequences in `seqs` and `seqs2`.

        When `seqs2` is omitted, computes the pairwise distance of `seqs` against
        itself.

        {dist_mat}

        Parameters
        ----------
        seqs
            array containing CDR3 sequences. Must not contain duplicates.
        seqs2
            second array containing CDR3 sequences. Must not contain
            duplicates either.

        Returns
        -------
        Sparse pairwise distance matrix.
        """

    @staticmethod
    def squarify(triangular_matrix: csr_matrix) -> csr_matrix:
        """Mirror a triangular matrix at the diagonal to make it a square matrix.

        The input matrix *must* be upper triangular to begin with, otherwise
        the results will be incorrect. No guard rails!
        """
        assert triangular_matrix.shape[0] == triangular_matrix.shape[1], "needs to be square matrix"
        # The matrix is already upper diagonal. Use the transpose method, see
        # https://stackoverflow.com/a/58806735/2340703.
        return triangular_matrix + triangular_matrix.T - scipy.sparse.diags(triangular_matrix.diagonal())


@_doc_params(params=_doc_params_parallel_distance_calculator)
class ParallelDistanceCalculator(DistanceCalculator):
    """
    Abstract base class for a DistanceCalculator that computes distances in parallel.

    It does so in a blockwise fashion. The function computing distances
    for a single block needs to be overriden.

    Parameters
    ----------
    {params}
    """

    @deprecated_arg("block_size", _deprecation_block_size)
    def __init__(
        self,
        cutoff: int,
        *,
        n_jobs: int = -1,
        block_size: int | None = None,
    ):
        super().__init__(cutoff)
        self.n_jobs = n_jobs

    @abc.abstractmethod
    def _compute_block(
        self,
        seqs1: Sequence[str],
        seqs2: Sequence[str] | None,
        origin: tuple[int, int],
    ) -> tuple[int, int, int]:
        """Compute the distances for a block of the matrix

        Parameters
        ----------
        seqs1
            array containing sequences
        seqs2
            other array containing sequences. If `None` compute the square matrix
            of `seqs1` and iterator over the upper triangle including the diagonal only.
        origin
            row, col coordinates of the origin of the block.

        Returns
        -------
        List of (distance, row, col) tuples for all elements with distance != 0.
        row, col must be the coordinates in the final matrix (they can be derived using
        `origin`). Can't be a generator because this needs to be picklable.
        """

    @staticmethod
    def _block_iter(
        seqs1: Sequence[str],
        seqs2: Sequence[str] | None = None,
        block_size: int | None = 50,
    ) -> tuple[Sequence[str], Sequence[str] | None, tuple[int, int]]:
        """Iterate over sequences in blocks.

        Parameters
        ----------
        seqs1
            array containing (unique) sequences
        seqs2
            array containing other sequences. If `None` compute
            the square matrix of `seqs1` and iterate over the upper triangle (including
            the diagonal) only.
        block_size
            side length of a block (will have `block_size ** 2` elements.)

        Yields
        ------
        seqs1
            subset of length `block_size` of seqs1
        seqs2
            subset of length `block_size` of seqs2. If seqs2 is None, this will
            be `None` if the block is on the diagonal, or a subset of seqs1 otherwise.
        origin
            (row, col) coordinates of the origin of the block.
        """
        square_mat = seqs2 is None
        if square_mat:
            seqs2 = seqs1
        for row in range(0, len(seqs1), block_size):
            start_col = row if square_mat else 0
            for col in range(start_col, len(seqs2), block_size):
                if row == col and square_mat:
                    # block on the diagonal.
                    # yield None for seqs2 to indicate that we only want the upper
                    # diagonal.
                    yield seqs1[row : row + block_size], None, (row, row)
                else:
                    yield seqs1[row : row + block_size], seqs2[col : col + block_size], (row, col)

    def calc_dist_mat(
        self, seqs: Sequence[str], seqs2: Sequence[str] | None = None, *, block_size: int | None = None
    ) -> csr_matrix:
        """Calculate the distance matrix.

        See :meth:`DistanceCalculator.calc_dist_mat`.

        Parameters
        ----------
        seqs
            array containing CDR3 sequences. Must not contain duplicates.
        seqs2
            second array containing CDR3 sequences. Must not contain
            duplicates either.
        block_size
            The width of a block that's sent to a worker. A block contains
            `block_size ** 2` elements. If `None` the block
            size is determined automatically based on the problem size.



        Returns
        -------
        Sparse pairwise distance matrix.
        """
        problem_size = len(seqs) * len(seqs2) if seqs2 is not None else len(seqs) ** 2
        # dynamicall adjust the block size such that there are ~1000 blocks within a range of 50 and 5000
        block_size = int(np.ceil(min(max(np.sqrt(problem_size / 1000), 50), 5000)))
        logging.info(f"block size set to {block_size}")

        # precompute blocks as list to have total number of blocks for progressbar
        blocks = list(self._block_iter(seqs, seqs2, block_size=block_size))

        block_results = _parallelize_with_joblib(
            (joblib.delayed(self._compute_block)(*block) for block in blocks), total=len(blocks), n_jobs=self.n_jobs
        )

        try:
            dists, rows, cols = zip(*itertools.chain(*block_results), strict=False)
        except ValueError:
            # happens when there is no match at all
            dists, rows, cols = (), (), ()

        shape = (len(seqs), len(seqs2)) if seqs2 is not None else (len(seqs), len(seqs))
        score_mat = scipy.sparse.coo_matrix((dists, (rows, cols)), dtype=self.DTYPE, shape=shape)
        score_mat.eliminate_zeros()
        score_mat = score_mat.tocsr()

        if seqs2 is None:
            score_mat = self.squarify(score_mat)

        return score_mat


class IdentityDistanceCalculator(DistanceCalculator):
    """\
    Calculates the Identity-distance between :term:`CDR3` sequences.

    The identity distance is defined as
        * `0`, if sequences are identical
        * `1`, if sequences are not identical.

    Choosing a cutoff:
        For this DistanceCalculator, per definition, the cutoff = 0.
        The `cutoff` argument is ignored.

    Parameters
    ----------
    cutoff
        Will eleminate distances > cutoff to make efficient
        use of sparse matrices. For the IdentityDistanceCalculator this argument
        will be ignored and is always 0.
    """

    def __init__(self, cutoff: int = 0):
        cutoff = 0
        super().__init__(cutoff)

    def calc_dist_mat(self, seqs: np.ndarray, seqs2: np.ndarray = None) -> csr_matrix:
        """In this case, the offseted distance matrix is the identity matrix.

        More details: :meth:`DistanceCalculator.calc_dist_mat`
        """
        if seqs2 is None:
            # In this case, the offsetted distance matrix is the identity matrix
            return scipy.sparse.identity(len(seqs), dtype=self.DTYPE, format="csr")
        else:
            cols_by_seq = {}
            for i2, s2 in enumerate(seqs2):
                cols_by_seq.setdefault(s2, []).append(i2)

            row = []
            col = []
            for i1, s1 in enumerate(seqs):
                matching_cols = cols_by_seq.get(s1)
                if matching_cols is not None:
                    row.extend([i1] * len(matching_cols))
                    col.extend(matching_cols)

            d = np.ones(len(row), dtype=self.DTYPE)
            return coo_matrix((d, (row, col)), dtype=self.DTYPE, shape=(len(seqs), len(seqs2))).tocsr()


@_doc_params(params=_doc_params_parallel_distance_calculator)
class LevenshteinDistanceCalculator(ParallelDistanceCalculator):
    """\
    Calculates the Levenshtein edit-distance between sequences.

    The edit distance is the total number of deletion, addition and modification
    events.

    This class relies on `Python-levenshtein <https://github.com/ztane/python-Levenshtein>`_
    to calculate the distances.

    Choosing a cutoff:
        Each modification stands for a deletion, addition or modification event.
        While lacking empirical data, it seems unlikely that CDR3 sequences with more
        than two modifications still recognize the same antigen.

    Parameters
    ----------
    cutoff
        Will eleminate distances > cutoff to make efficient
        use of sparse matrices. The default cutoff is `2`.
    {params}
    """

    def __init__(self, cutoff: int = 2, **kwargs):
        super().__init__(cutoff, **kwargs)

    def _compute_block(self, seqs1, seqs2, origin):
        origin_row, origin_col = origin
        if seqs2 is not None:
            # compute the full matrix
            coord_iterator = itertools.product(enumerate(seqs1), enumerate(seqs2))
        else:
            # compute only upper triangle in this case
            coord_iterator = itertools.combinations_with_replacement(enumerate(seqs1), r=2)

        result = []
        for (row, s1), (col, s2) in coord_iterator:
            d = levenshtein_dist(s1, s2)
            if d <= self.cutoff:
                result.append((d + 1, origin_row + row, origin_col + col))

        return result


def _seqs2mat(
    seqs: Sequence[str], alphabet: str = AA_ALPHABET_WITH_AMBIGUOUS, max_len: None | int = None
) -> tuple[np.ndarray, np.ndarray]:
    """Convert a collection of gene sequences into a
    numpy matrix of integers for fast comparison.

    Parameters
    ----------
    seqs:
        Sequence of strings

    Returns
    -------
    mat:
        matrix with gene sequences encoded as integers
    L:
        vector with length values of the gene sequences in the matrix

    Examples
    --------
    >>> seqs2mat(["CAT", "HAT"])
    array([[ 4,  0, 16],
        [ 8,  0, 16]], dtype=int8)

    Notes
    -----
    Requires all seqs to have the same length, therefore shorter sequences
    are filled up with -1 entries at the end.
    """
    if max_len is None:
        max_len = np.max([len(s) for s in seqs])
    mat = -1 * np.ones((len(seqs), max_len), dtype=np.int8)
    L = np.zeros(len(seqs), dtype=np.int8 if max_len <= np.iinfo(np.int8).max else np.int16)
    for si, s in enumerate(seqs):
        L[si] = min(len(s), max_len)
        for aai in range(max_len):
            if aai >= len(s):
                break
            try:
                mat[si, aai] = alphabet.index(s[aai])
            except ValueError:
                # Unknown symbols given value for last column/row of matrix
                mat[si, aai] = len(alphabet)
    return mat, L


class _MetricDistanceCalculator(abc.ABC):
    """
    Abstract base class for distance calculator classes that computes parwise distances between
    gene sequences in parallel based on a certain distance metric.

    The result is a (scipy) compressed sparse row distance matrix.
    Derived classes just need to implement the method _metric_mat (see method comments for more details).

    The code of this class is based on `pwseqdist <https://github.com/agartland/pwseqdist/blob/master/pwseqdist>`_.
    Reused under MIT license, Copyright (c) 2020 Andrew Fiore-Gartland.

    Parameters
    ----------
    n_jobs:
        Number of threads per process to use for the pairwise distance calculation
    n_blocks:
        Overall number of blocks given to the workers (processes)
    histogram:
        Determines whether a nearest neighbor histogram should be created
    """

    def __init__(self, n_jobs: int = -1, n_blocks: int = 1, histogram: bool = False):
        super().__init__()
        self.n_jobs = n_jobs
        self.n_blocks = n_blocks
        self.histogram = histogram

    @abc.abstractmethod
    def _metric_mat(
        self,
        *,
        seqs: Sequence[str],
        seqs2: Sequence[str],
        is_symmetric: bool = False,
        start_column: int = 0,
    ) -> tuple[list[np.ndarray], list[np.ndarray], np.ndarray, np.ndarray]:
        """
        Abstract method that should be implemented by the derived class in a way such that it computes the pairwise distances
        for gene sequences in seqs and seqs2 based on a certain distance metric. The result should be a distance matrix
        that is returned in the form of the data, indices and intptr arrays of a (scipy) compressed sparse row matrix.

        In case that a nearest neighbour histogram should be created later, the minimum value per row is returned.

        If this function is used to compute a block of a bigger result matrix, is_symmetric and start_column
        can be used to only compute the part of the block that would be part of the upper triangular matrix of the
        result matrix.

        Parameters
        ----------
        seqs/2:
            A python sequence of strings representing gene sequences
        is_symmetric:
            Determines whether the final result matrix is symmetric, assuming that this function is
            only used to compute a block of a bigger result matrix
        start_column:
            Determines at which column the calculation should be started. This is only used if this function is
            used to compute a block of a bigger result matrix that is symmetric

        Returns
        -------
        data_rows:
            List with arrays containing the non-zero data values of the result matrix per row,
            needed to create the final scipy CSR result matrix later
        indices_rows:
            List with arrays containing the non-zero entry column indeces of the result matrix per row,
            needed to create the final scipy CSR result matrix later
        row_element_counts:
            Array with integers that indicate the amount of non-zero values of the result matrix per row,
            needed to create the final scipy CSR result matrix later
        row_mins:
            Array containing the minimum distance per row, ignoring equal sequences and ignoring the cutoff.
            Contains None if the computation of row_mins is not implemented. Used to create a nearest neighbor
            histogram later. Is empty if the histogram should not be created.
        """
        pass

    def _make_histogram(self, row_mins: np.ndarray):
        """Subclass should override this method if the creation of a nearest neighbor histogram is implemented."""
        raise NotImplementedError("Creating a histogram is not implemented for this metric")

    def _calc_dist_mat_block(
        self,
        seqs: Sequence[str],
        seqs2: Sequence[str],
        is_symmetric: bool = False,
        start_column: int = 0,
    ) -> tuple[csr_matrix, np.ndarray]:
        """Computes a block of the final distance matrix and returns it as CSR matrix. Also computes
        the minimum distance per row, for which equal sequences and the cutoff are ignored.
        If the final result matrix that consists of all blocks together is symmetric, only the part
        of the block that would contribute to the upper triangular matrix of the final result will be computed.
        """
        if len(seqs) == 0 or len(seqs2) == 0:
            return csr_matrix((len(seqs), len(seqs2))), np.array([None])

        data_rows, indices_rows, row_element_counts, row_mins = self._metric_mat(
            seqs=seqs,
            seqs2=seqs2,
            is_symmetric=is_symmetric,
            start_column=start_column,
        )

        indptr = np.zeros(row_element_counts.shape[0] + 1)
        indptr[1:] = np.cumsum(row_element_counts)
        data, indices = np.concatenate(data_rows), np.concatenate(indices_rows)
        sparse_distance_matrix = csr_matrix((data, indices, indptr), shape=(len(seqs), len(seqs2)))
        return sparse_distance_matrix, row_mins

    def _validate_seqs(self, seqs: Sequence[str], seqs2: Sequence[str]) -> None:
        """Hook for metric-specific input checks before block-wise computation.
        Does nothing by default. Subclasses should override this method if they require metric-specific input checks.
        """
        return None

    def calc_dist_mat(self, seqs: Sequence[str], seqs2: Sequence[str] | None = None) -> csr_matrix:
        """Calculates the pairwise distances between two vectors of gene sequences based on the distance metric
        of the derived class and returns a CSR distance matrix. Also creates a histogram based on the minimum value
        per row of the distance matrix if histogram is set to True.
        """
        if seqs2 is None:
            seqs2 = seqs

        self._validate_seqs(seqs, seqs2)

        seqs = np.asarray(seqs)
        seqs2 = np.asarray(seqs2)
        is_symmetric = np.array_equal(seqs, seqs2)

        if self.n_blocks < 2:
            distance_matrix_csr, row_mins = self._calc_dist_mat_block(seqs, seqs2, is_symmetric)
        else:
            if is_symmetric:
                # Computing only the upper triangle of a symmetric result matrix gives earlier row partitions more
                # work, so use shorter partitions at the beginning to balance the number of comparisons across
                # parallel jobs. Increasing n_blocks for better load balancing instead would add block-processing
                # overhead.
                partition_fractions = np.arange(self.n_blocks + 1) / self.n_blocks
                partition_boundaries = np.rint(len(seqs) * (1 - np.sqrt(1 - partition_fractions))).astype(int)
            else:
                partition_boundaries = np.rint(np.linspace(0, len(seqs), self.n_blocks + 1)).astype(int)

            split_seqs = np.split(seqs, partition_boundaries[1:-1])
            arguments = [
                (
                    split_seqs[x],
                    seqs2,
                    is_symmetric,
                    partition_boundaries[x],
                )
                for x in range(self.n_blocks)
            ]

            delayed_jobs = [joblib.delayed(self._calc_dist_mat_block)(*args) for args in arguments]
            results = list(_parallelize_with_joblib(delayed_jobs, total=len(delayed_jobs)))

            block_matrices_csr, block_row_mins = zip(*results, strict=False)
            distance_matrix_csr = scipy.sparse.vstack(block_matrices_csr)
            row_mins = np.concatenate(block_row_mins)

        if is_symmetric:
            upper_triangular_distance_matrix = distance_matrix_csr
            full_distance_matrix = upper_triangular_distance_matrix.maximum(upper_triangular_distance_matrix.T)
        else:
            full_distance_matrix = distance_matrix_csr

        if self.histogram:
            self._make_histogram(row_mins)

        return full_distance_matrix


class HammingDistanceCalculator(_MetricDistanceCalculator):
    """Computes pairwise distances between gene sequences based on the "hamming" distance metric.

    Set `normalize` to True to use the normalized hamming distance metric instead of the standard hamming distance
    metric. Then the distance will be calculated as percentage of different positions relative to the sequence length
    (e.g. AAGG and AAAA -> 50 (%) normalized hamming distance). The cutoff is then also given as normalized hamming
    distance in percent.

    The code of this class is based on `pwseqdist <https://github.com/agartland/pwseqdist/blob/master/pwseqdist>`_.
    Reused under MIT license, Copyright (c) 2020 Andrew Fiore-Gartland.

    Parameters
    ----------
    cutoff:
        Will eleminate distances > cutoff to make efficient
        use of sparse matrices.
    n_jobs:
        Number of numba parallel threads to use for the pairwise distance calculation
    n_blocks:
        Number of joblib delayed objects (blocks to compute) given to joblib.Parallel
    normalize:
        Determines whether the normalized hamming distance metric should be used instead of the standard
        hamming distance
    histogram:
        Determines whether a nearest neighbor histogram should be created
    """

    def __init__(
        self,
        n_jobs: int = -1,
        n_blocks: int = 1,
        cutoff: int = 2,
        *,
        normalize: bool = False,
        histogram: bool = False,
    ):
        super().__init__(n_jobs=n_jobs, n_blocks=n_blocks, histogram=histogram)
        self.cutoff = cutoff
        self.normalize = normalize

    def _make_histogram(self, row_mins: np.ndarray):
        if self.normalize:
            bins = np.arange(0, 101, 2)
        else:
            max_value = np.max(row_mins)
            bin_step = np.ceil(max_value / 100)
            bins = np.arange(0, max_value + 1, bin_step)

        plt.hist(row_mins, bins=bins, histtype="bar", edgecolor="black")
        plt.axvline(x=self.cutoff, color="r", linestyle="-", label="cutoff")
        plt.legend()
        plt.xlabel("Distance to nearest neighbor")
        plt.ylabel("Count")
        plt.title('Histogram of "distance-to-nearest"-distribution')
        plt.show()

    def _hamming_mat(
        self,
        *,
        seqs: Sequence[str],
        seqs2: Sequence[str],
        is_symmetric: bool = False,
        start_column: int = 0,
    ) -> tuple[list[np.ndarray], list[np.ndarray], np.ndarray, np.ndarray]:
        """Computes the pairwise hamming distances for sequences in seqs and seqs2.

        This function is a wrapper and contains an inner JIT compiled numba function without parameters. The reason for this is
        that this way some of the parameters can be treated as constant by numba and this allows for a better optimization
        of the numba compiler in this specific case.

        If this function is used to compute a block of a bigger result matrix, is_symmetric and start_column
        can be used to only compute the part of the block that would be part of the upper triangular matrix of the
        result matrix.

        Parameters
        ----------
        seqs/2:
            A python sequence of strings representing gene sequences
        is_symmetric:
            Determines whether the final result matrix is symmetric, assuming that this function is
            only used to compute a block of a bigger result matrix
        start_column:
            Determines at which column the calculation should be started. This is only used if this function is
            used to compute a block of a bigger result matrix that is symmetric

        Returns
        -------
        data_rows:
            List with arrays containing the non-zero data values of the result matrix per row,
            needed to create the final scipy CSR result matrix later
        indices_rows:
            List with arrays containing the non-zero entry column indeces of the result matrix per row,
            needed to create the final scipy CSR result matrix later
        row_element_counts:
            Array with integers that indicate the amount of non-zero values of the result matrix per row,
            needed to create the final scipy CSR result matrix later
        row_mins:
            Array containing the minimum distance per row, ignoring equal sequences and ignoring the cutoff.
            Used to create a nearest neighbor histogram later. Is empty if the histogram should not be created.
        """
        unique_characters = "".join({char for string in (*seqs, *seqs2) for char in string})
        max_seq_len = max(len(s) for s in (*seqs, *seqs2))

        seqs_mat1, seqs_L1 = _seqs2mat(seqs, alphabet=unique_characters, max_len=max_seq_len)
        seqs_mat2, seqs_L2 = _seqs2mat(seqs2, alphabet=unique_characters, max_len=max_seq_len)

        cutoff = self.cutoff
        normalize = self.normalize
        histogram = self.histogram

        if histogram:
            is_symmetric = False

        start_column *= is_symmetric

        nb.set_num_threads(_get_usable_cpus(n_jobs=self.n_jobs, use_numba=True))

        num_threads = nb.get_num_threads()

        jit_parallel = num_threads > 1

        @nb.jit(nopython=True, parallel=jit_parallel, nogil=True)
        def _nb_hamming_mat():
            assert seqs_mat1.shape[0] == seqs_L1.shape[0]
            assert seqs_mat2.shape[0] == seqs_L2.shape[0]

            num_rows = seqs_mat1.shape[0]
            num_cols = seqs_mat2.shape[0]

            data_rows = nb.typed.List()
            indices_rows = nb.typed.List()
            row_element_counts = np.zeros(num_rows)

            if histogram:
                row_mins = np.zeros(num_rows)
            else:
                row_mins = np.zeros(0)

            empty_row = np.zeros(0)
            for _ in range(0, num_rows):
                data_rows.append([empty_row])
                indices_rows.append([empty_row])

            data_row_matrix = np.empty((num_threads, num_cols))
            indices_row_matrix = np.empty((num_threads, num_cols))

            for row_index in nb.prange(num_rows):
                thread_id = nb.get_thread_id()
                row_end_index = 0
                seq1_len = seqs_L1[row_index]

                if histogram:
                    if normalize:
                        row_min = 100
                    else:
                        row_min = seq1_len

                for col_index in range(start_column + row_index * is_symmetric, num_cols):
                    distance = 1
                    seq2_len = seqs_L2[col_index]
                    if seq1_len == seq2_len:
                        for i in range(0, seq1_len):
                            distance += seqs_mat1[row_index, i] != seqs_mat2[col_index, i]

                        if normalize:
                            distance = int((distance - 1) * 100 / seq1_len + 0.5) + 1

                        if distance <= cutoff + 1:
                            data_row_matrix[thread_id, row_end_index] = distance
                            indices_row_matrix[thread_id, row_end_index] = col_index
                            row_end_index += 1

                        if histogram:
                            if distance > 1:
                                row_min = min(row_min, distance - 1)

                data_rows[row_index][0] = data_row_matrix[thread_id, 0:row_end_index].copy()
                indices_rows[row_index][0] = indices_row_matrix[thread_id, 0:row_end_index].copy()
                row_element_counts[row_index] = row_end_index
                if histogram:
                    row_mins[row_index] = row_min

            data_rows_flat = []
            indices_rows_flat = []

            for i in range(len(data_rows)):
                data_rows_flat.append(data_rows[i][0])
                indices_rows_flat.append(indices_rows[i][0])

            return data_rows_flat, indices_rows_flat, row_element_counts, row_mins

        data_rows, indices_rows, row_element_counts, row_mins = _nb_hamming_mat()

        return data_rows, indices_rows, row_element_counts, row_mins

    _metric_mat = _hamming_mat


class GPUHammingDistanceCalculator(_MetricDistanceCalculator):
    """Computes pairwise distances between gene sequences based on the "hamming" distance metric with GPU support.

    The code of this class is based on `pwseqdist <https://github.com/agartland/pwseqdist/blob/master/pwseqdist>`_.
    Reused under MIT license, Copyright (c) 2020 Andrew Fiore-Gartland.

    For performance reasons, the rows and columns of the final result matrix are grouped into tiles for GPU
    computation. `gpu_tile_rows` and `gpu_tile_cols` control how many matrix rows and columns are grouped into each
    tile. Each tile is computed on the GPU and converted to a sparse CSR matrix before the tiles are combined again.

    `gpu_tile_buffer_cols` controls how many buffer columns are initially reserved for sparse result entries in each
    row of a tile. Because only distances at or below the cutoff are retained, the number of entries that need to be
    stored is usually considerably smaller than the number of columns in the tile. If necessary, the buffer is
    enlarged and the calculation is retried.

    Smaller tiles reduce per-tile memory pressure but add tile-management overhead. Larger values for
    `gpu_tile_buffer_cols` can avoid retries but require more GPU memory.

    Parameters
    ----------
    cutoff:
        Will eleminate distances > cutoff to make efficient
        use of sparse matrices.
    n_blocks:
        Number of outer row partitions submitted through joblib. This can be used with a distributed joblib backend to
        distribute the calculation across multiple GPU workers.
    gpu_tile_rows:
        Number of result matrix rows per GPU tile.
    gpu_tile_cols:
        Number of result matrix columns per GPU tile.
    gpu_tile_buffer_cols:
        Initial number of retained sparse entries reserved per row of each tile. Higher values can avoid retries for
        denser results but require more GPU memory.
    gpu_n_blocks:
        Deprecated since v0.26.0 and ignored. Use `gpu_tile_cols` to set the number of columns per GPU tile.
    gpu_block_width:
        Deprecated since v0.26.0 and ignored. Use `gpu_tile_buffer_cols` to set the initial result buffer width.
    """

    @deprecated_arg(
        "gpu_n_blocks",
        Deprecation(
            "0.26.0", "This argument is ignored. Use `gpu_tile_cols` to set the number of columns per GPU tile."
        ),
    )
    @deprecated_arg(
        "gpu_block_width",
        Deprecation(
            "0.26.0", "This argument is ignored. Use `gpu_tile_buffer_cols` to set the initial result buffer width."
        ),
    )
    def __init__(
        self,
        *,
        cutoff: int = 2,
        n_blocks: int = 1,
        gpu_tile_rows: int = 100_000,
        gpu_tile_cols: int = 100_000,
        gpu_tile_buffer_cols: int = 1000,
        gpu_n_blocks: int | None = None,
        gpu_block_width: int | None = None,
    ):
        super().__init__(n_jobs=1, n_blocks=n_blocks)
        if cutoff > 125:
            raise ValueError(
                "GPUHammingDistanceCalculator only supports cutoff <= 125 because the intermediate "
                "GPU buffer stores distances as signed int8 values and uses distance + 1 encoding."
            )
        if gpu_tile_rows < 1:
            raise ValueError("`gpu_tile_rows` must be >= 1.")
        if gpu_tile_cols < 1:
            raise ValueError("`gpu_tile_cols` must be >= 1.")
        if gpu_tile_buffer_cols < 1:
            raise ValueError("`gpu_tile_buffer_cols` must be >= 1.")
        self.cutoff = cutoff
        self.gpu_tile_rows = gpu_tile_rows
        self.gpu_tile_cols = gpu_tile_cols
        self.gpu_tile_buffer_cols = gpu_tile_buffer_cols

    def _gpu_hamming_mat(
        self,
        *,
        seqs: Sequence[str],
        seqs2: Sequence[str],
        is_symmetric: bool = False,
        start_column: int = 0,
    ) -> tuple[list[np.ndarray], list[np.ndarray], np.ndarray, np.ndarray]:
        """Computes the pairwise hamming distances for sequences in seqs and seqs2 with GPU support.

        Parameters
        ----------
        seqs/2:
            A python sequence of strings representing gene sequences
        is_symmetric:
            Determines whether the final result matrix is symmetric, assuming that this function is
            only used to compute a block of a bigger result matrix
        start_column:
            Global row offset of an outer row block scheduled by joblib. Used to skip column blocks below the diagonal
            when computing a symmetric result matrix.

        Returns
        -------
        data_rows:
            List with array containing the non-zero data values of the result matrix,
            needed to create the final scipy CSR result matrix later
        indices_rows:
            List with array containing the non-zero entry column indeces of the result matrix,
            needed to create the final scipy CSR result matrix later
        row_element_counts:
            Array with integers that indicate the amount of non-zero values of the result matrix per row,
            needed to create the final scipy CSR result matrix later
        row_mins:
            Always returns a numpy array containing None because the computation of the minimum distance per row is
            not implemented for the GPU hamming calculator yet.
        """
        import cupy as cp
        from tqdm import tqdm

        n_col_blocks = (len(seqs2) + self.gpu_tile_cols - 1) // self.gpu_tile_cols
        n_row_blocks = (len(seqs) + self.gpu_tile_rows - 1) // self.gpu_tile_rows

        seqs_blocks = np.array_split(np.asarray(seqs), n_row_blocks)
        seqs_block_starts = np.cumsum([0] + [len(block) for block in seqs_blocks[:-1]])
        seqs_sorted_per_block = []
        seqs_original_indices_blocks = []

        for seqs_block in seqs_blocks:
            seqs_block_lengths = np.vectorize(len)(seqs_block)
            seqs_block_sort_indices = np.argsort(seqs_block_lengths)
            seqs_sorted_per_block.append(seqs_block[seqs_block_sort_indices])
            seqs_original_indices_blocks.append(cp.asarray(seqs_block_sort_indices.astype(np.int32)))

        seqs = np.concatenate(seqs_sorted_per_block)

        seqs2_blocks = np.array_split(np.asarray(seqs2), n_col_blocks)
        seqs2_block_starts = np.cumsum([0] + [len(block) for block in seqs2_blocks[:-1]])
        seqs2_sorted_per_block = []
        seqs2_original_indices_blocks = []
        seqs2_block_start = 0

        for seqs2_block in seqs2_blocks:
            seqs2_block_lengths = np.vectorize(len)(seqs2_block)
            seqs2_block_sort_indices = np.argsort(seqs2_block_lengths)
            seqs2_sorted_per_block.append(seqs2_block[seqs2_block_sort_indices])
            seqs2_original_indices_blocks.append(
                cp.asarray((seqs2_block_sort_indices + seqs2_block_start).astype(np.int32))
            )
            seqs2_block_start += len(seqs2_block)

        seqs2 = np.concatenate(seqs2_sorted_per_block)

        max_seq_len = max(len(s) for s in itertools.chain(seqs, seqs2))

        def _seqs2mat_fast(seqs: Sequence[str], max_len: None | int = None) -> tuple[np.ndarray, np.ndarray]:
            if max_len is None:
                max_len = np.max([len(s) for s in seqs])
            mat = -1 * np.ones((len(seqs), max_len), dtype=np.int8)
            L = np.zeros(len(seqs), dtype=np.int32)
            for i, seq in enumerate(seqs):
                mat[i][0 : len(seq)] = np.frombuffer(seq.encode("ascii"), dtype=np.uint8)
                L[i] = len(seq)
            return mat, L

        try:
            seqs_mat1, seqs_L1 = _seqs2mat_fast(seqs, max_len=max_seq_len)
            seqs_mat2, seqs_L2 = _seqs2mat_fast(seqs2, max_len=max_seq_len)
        except UnicodeError:
            logging.info(
                "UnicodeError error occurred while converting sequences, retrying with implementation for non ascii sequences"
            )
            unique_characters = "".join(sorted({char for string in itertools.chain(seqs, seqs2) for char in string}))
            seqs_mat1, seqs_L1 = _seqs2mat(seqs, alphabet=unique_characters, max_len=max_seq_len)
            seqs_mat2, seqs_L2 = _seqs2mat(seqs2, alphabet=unique_characters, max_len=max_seq_len)

        hamming_kernel = cp.RawKernel(
            r"""
        extern "C" __global__ __launch_bounds__(256)
        void hamming_kernel(
            const char* __restrict__ seqs_mat1,
            const char* __restrict__ seqs_mat2,
            const int* __restrict__ seqs_L1,
            const int* __restrict__ length_starts,
            const int* __restrict__ length_ends,
            const int* __restrict__ seqs_original_indices,
            const int* seqs2_original_indices,
            const int cutoff,
            char* __restrict__ data,
            int* __restrict__ indices,
            int* __restrict__ row_element_counts,
            const int seqs_mat1_rows,
            const int seqs_mat2_rows,
            const int data_cols,
            const int indices_cols
        ) {
            int row = blockDim.x * blockIdx.x + threadIdx.x;
            if (row < seqs_mat1_rows) {
                int seqs_original_index = seqs_original_indices[row];
                int seq1_len = seqs_L1[row];
                int row_end_index = 0;

                int col_start = length_starts[seq1_len];
                int col_end = length_ends[seq1_len];
                for (int col = col_start; col < col_end; col++) {
                    char distance = 1;

                    for (int i = 0; i < seq1_len; i++) {
                        char val1 = seqs_mat1[i*seqs_mat1_rows+row];
                        char val2 = seqs_mat2[i*seqs_mat2_rows+col];

                        if(val1 != val2) {
                            distance++;
                            if (distance > cutoff + 1) {
                                break;
                            }
                        }
                    }
                    if (distance <= cutoff + 1) {
                        if (row_end_index < data_cols) {
                            int seqs2_original_index = seqs2_original_indices[col];
                            data[(long long)seqs_original_index * data_cols + row_end_index] = distance;
                            indices[(long long)seqs_original_index * indices_cols + row_end_index] = seqs2_original_index;
                        }
                        row_end_index++;
                    }
                }
                row_element_counts[seqs_original_index] = row_end_index;
            }
        }
        """,
            "hamming_kernel",
            options=("--maxrregcount=256",),
        )

        create_csr_kernel = cp.RawKernel(
            r"""
        extern "C" __global__
        void create_csr_kernel(
            int* data, int* indices,
            char* data_matrix, int* indices_matrix,
            int* indptr, int data_matrix_rows, int data_matrix_cols, int data_rows, int indices_matrix_cols
        ) {
            int row = blockDim.x * blockIdx.x + threadIdx.x;
            int col = blockDim.y * blockIdx.y + threadIdx.y;

            if (row < data_matrix_rows && col < data_matrix_cols) {
                int row_start = indptr[row];
                int row_end = indptr[row + 1];
                int row_end_index = row_end - row_start;
                int data_index = row_start + col;

                if ((data_index < data_rows) && (col < row_end_index)) {
                    data[data_index] = data_matrix[(long long)row * data_matrix_cols + col];
                    indices[data_index] = indices_matrix[(long long)row * indices_matrix_cols + col];
                }
            }
        }
            """,
            "create_csr_kernel",
        )

        def calc_col_block_gpu(
            seqs_mat1,
            seqs_mat2_block,
            seqs_L1_block,
            length_bounds,
            seqs_original_indices_block,
            seqs2_original_indices_block,
            buffer_width,
        ):
            d_seqs_L1 = cp.asarray(seqs_L1_block.astype(np.int32, copy=False))
            d_length_starts, d_length_ends = length_bounds

            threads_per_block = 256
            blocks_per_grid = (seqs_mat1.shape[0] + (threads_per_block - 1)) // threads_per_block

            seqs_mat1_rows = seqs_mat1.shape[0]
            seqs_mat2_rows = seqs_mat2_block.shape[0]

            d_seqs_mat1_transposed = cp.transpose(cp.asarray(seqs_mat1.astype(np.int8, copy=False))).copy()
            d_seqs_mat2_transposed = cp.transpose(cp.asarray(seqs_mat2_block.astype(np.int8, copy=False))).copy()

            def run_hamming_kernel(buffer_width):
                d_data_matrix = cp.empty((seqs_mat1_rows, buffer_width), dtype=cp.int8)
                d_indices_matrix = cp.empty((seqs_mat1_rows, buffer_width), dtype=np.int32)
                d_row_element_counts = cp.zeros(seqs_mat1_rows, dtype=np.int32)

                hamming_kernel(
                    (blocks_per_grid,),
                    (threads_per_block,),
                    (
                        d_seqs_mat1_transposed,
                        d_seqs_mat2_transposed,
                        d_seqs_L1,
                        d_length_starts,
                        d_length_ends,
                        seqs_original_indices_block,
                        seqs2_original_indices_block,
                        self.cutoff,
                        d_data_matrix,
                        d_indices_matrix,
                        d_row_element_counts,
                        seqs_mat1_rows,
                        seqs_mat2_rows,
                        buffer_width,
                        buffer_width,
                    ),
                )
                row_element_counts = d_row_element_counts.get()
                required_buffer_width = int(np.max(row_element_counts))
                if required_buffer_width > buffer_width:
                    # Release undersized buffers before allocating larger ones for the retry.
                    d_data_matrix = None
                    d_indices_matrix = None
                return d_data_matrix, d_indices_matrix, row_element_counts, required_buffer_width

            d_data_matrix, d_indices_matrix, row_element_counts, required_buffer_width = run_hamming_kernel(
                buffer_width
            )

            if required_buffer_width > buffer_width:
                # The buffer was too small, so retry with the required buffer size.
                logging.info(
                    f"GPU Hamming tile buffer increased from {buffer_width} to {required_buffer_width}; "
                    f"retrying the {seqs_mat1_rows} x {seqs_mat2_rows} tile."
                )
                buffer_width = required_buffer_width
                d_data_matrix, d_indices_matrix, row_element_counts, _ = run_hamming_kernel(buffer_width)

            row_element_sum = np.sum(row_element_counts, dtype=np.int64)

            if row_element_sum > np.iinfo(np.int32).max:
                raise ValueError(
                    "There are too many result values to be held by the resulting CSR matrix of the current block. "
                    f"Current number: {row_element_sum}, maximum number: {np.iinfo(np.int32).max}. "
                    "Consider choosing a smaller cutoff to resolve this issue."
                )

            indptr = np.zeros(seqs_mat1.shape[0] + 1, dtype=np.int32)
            indptr[1:] = np.cumsum(row_element_counts)
            d_indptr = cp.asarray(indptr)

            n_elements = indptr[-1]
            d_data = cp.zeros(n_elements, dtype=cp.int32)
            d_indices = cp.zeros(n_elements, dtype=cp.int32)

            threads_per_block = (1, 256)
            blocks_per_grid_x = (d_data_matrix.shape[0] + threads_per_block[0] - 1) // threads_per_block[0]
            blocks_per_grid_y = (d_data_matrix.shape[1] + threads_per_block[1] - 1) // threads_per_block[1]
            blocks_per_grid = (blocks_per_grid_x, blocks_per_grid_y)

            create_csr_kernel(
                (blocks_per_grid_x, blocks_per_grid_y),
                threads_per_block,
                (
                    d_data,
                    d_indices,
                    d_data_matrix,
                    d_indices_matrix,
                    d_indptr,
                    d_data_matrix.shape[0],
                    d_data_matrix.shape[1],
                    d_data.shape[0],
                    d_indices_matrix.shape[1],
                ),
            )

            data = d_data.get()
            indices = d_indices.get()

            res = csr_matrix((data, indices, indptr), shape=(seqs_mat1.shape[0], seqs_mat2.shape[0]))
            return res, buffer_width

        seqs_mat1_blocks = np.array_split(seqs_mat1, n_row_blocks)
        seqs_L1_blocks = np.array_split(seqs_L1, n_row_blocks)
        seqs_mat2_blocks = np.array_split(seqs_mat2, n_col_blocks)
        seqs_L2_blocks = np.array_split(seqs_L2, n_col_blocks)

        possible_lengths = np.arange(max_seq_len + 1)
        length_bounds_blocks = [
            (
                cp.asarray(np.searchsorted(lengths, possible_lengths, side="left").astype(np.int32)),
                cp.asarray(np.searchsorted(lengths, possible_lengths, side="right").astype(np.int32)),
            )
            for lengths in seqs_L2_blocks
        ]

        logging.info(f"\nStart GPU calculations for {n_row_blocks} row tiles x {n_col_blocks} column tiles:")

        @nb.njit
        def csr_union_numba(block_data, block_indices, block_indptrs, num_rows, num_elements):
            data = np.empty(num_elements, dtype=block_data[0].dtype)
            indices = np.empty(num_elements, dtype=block_indices[0].dtype)
            indptr = np.zeros(num_rows + 1, dtype=np.int32)

            ptr = 0
            for row in range(num_rows):
                for b in range(len(block_indptrs)):
                    start = block_indptrs[b][row]
                    end = block_indptrs[b][row + 1]
                    count = end - start

                    for j in range(count):
                        data[ptr + j] = block_data[b][start + j]
                        indices[ptr + j] = block_indices[b][start + j]

                    ptr += count
                indptr[row + 1] = ptr

            return data, indices, indptr

        def csr_union(blocks):
            num_rows = blocks[0].shape[0]
            num_elements = sum(b.nnz for b in blocks)

            block_data = [b.data for b in blocks]
            block_indices = [b.indices for b in blocks]
            block_indptrs = [b.indptr for b in blocks]

            data, indices, indptr = csr_union_numba(block_data, block_indices, block_indptrs, num_rows, num_elements)

            shape = blocks[0].shape
            result = csr_matrix((data, indices, indptr), shape=shape)
            return result

        def skip_col_block(row_block_idx, col_block_idx):
            row_start = start_column + seqs_block_starts[row_block_idx]
            col_end = seqs2_block_starts[col_block_idx] + seqs_mat2_blocks[col_block_idx].shape[0]
            return is_symmetric and col_end <= row_start

        def count_blocks_to_compute():
            n_blocks_to_compute = 0
            for row_block_idx in range(n_row_blocks):
                for col_block_idx in range(n_col_blocks):
                    if not skip_col_block(row_block_idx, col_block_idx):
                        n_blocks_to_compute += 1
            return n_blocks_to_compute

        def calc_row_block_gpu(
            row_block_idx,
            seqs_mat1_block,
            seqs_L1_block,
            seqs_original_indices_block,
            buffer_width,
        ):
            result_blocks = []
            n_calculated_blocks = 0

            for i in range(0, n_col_blocks):
                # Skip calculation of blocks below the diagonal if the result matrix is symmetric.
                if skip_col_block(row_block_idx, i):
                    continue

                result_block, buffer_width = calc_col_block_gpu(
                    seqs_mat1_block,
                    seqs_mat2_blocks[i],
                    seqs_L1_block,
                    length_bounds_blocks[i],
                    seqs_original_indices_block,
                    seqs2_original_indices_blocks[i],
                    buffer_width,
                )
                result_blocks.append(result_block)
                n_calculated_blocks += 1

            if not result_blocks:
                return (
                    csr_matrix((seqs_mat1_block.shape[0], seqs_mat2.shape[0]), dtype=np.int32),
                    n_calculated_blocks,
                    buffer_width,
                )

            num_elements = sum(int(block.indptr[-1]) for block in result_blocks)

            if num_elements > np.iinfo(np.int32).max:
                raise ValueError(
                    "The overall number of result values is too high to construct the final CSR matrix by combining "
                    "the already calculated blocks. "
                    f"Current number: {num_elements}, maximum number: {np.iinfo(np.int32).max}. "
                    "Consider choosing a smaller cutoff to resolve this issue."
                )

            result_sparse = csr_union(result_blocks)
            result_sparse.sort_indices()
            return result_sparse, n_calculated_blocks, buffer_width

        row_blocks = [None] * n_row_blocks
        buffer_width = self.gpu_tile_buffer_cols
        with tqdm(total=count_blocks_to_compute(), desc="Processing", unit="block") as progress_bar:
            for row_block_idx in range(n_row_blocks):
                row_blocks[row_block_idx], n_calculated_blocks, buffer_width = calc_row_block_gpu(
                    row_block_idx,
                    seqs_mat1_blocks[row_block_idx],
                    seqs_L1_blocks[row_block_idx],
                    seqs_original_indices_blocks[row_block_idx],
                    buffer_width,
                )
                progress_bar.update(n_calculated_blocks)

        result_sparse = scipy.sparse.vstack(row_blocks, format="csr")

        row_element_counts_gpu = np.diff(result_sparse.indptr)
        result_sparse.sort_indices()

        # Returns the results in a way that fits the current interface, could be improved later
        return [result_sparse.data], [result_sparse.indices], row_element_counts_gpu, np.array([None])

    _metric_mat = _gpu_hamming_mat


class TCRdistDistanceCalculator(_MetricDistanceCalculator):
    """Computes pairwise distances between TCR CDR3 sequences based on the "tcrdist" distance metric.

    The code of this class is heavily based on `pwseqdist <https://github.com/agartland/pwseqdist/blob/master/pwseqdist>`_.
    Reused under MIT license, Copyright (c) 2020 Andrew Fiore-Gartland.

    Using default weight, gap penalty, ntrim and ctrim is equivalent to the
    original distance published in :cite:`TCRdist`.

    Parameters
    ----------
    dist_weight:
        Weight applied to the mismatch distances before summing with the gap penalties
    gap_penalty:
        Distance penalty for the difference in the length of the two sequences
    ntrim/ctrim:
        Positions trimmed off the N-terminus (0) and C-terminus (L-1) ends of the peptide sequence. These symbols will be ignored
        in the distance calculation.
    fixed_gappos:
        If True, insert gaps at a fixed position after the cysteine residue statring the CDR3 (typically position 6).
        If False, find the "optimal" position for inserting the gaps to make up the difference in length
    cutoff:
        Will eliminate distances > cutoff to make efficient
        use of sparse matrices.
    n_jobs:
        Number of numba parallel threads to use for the pairwise distance calculation
    n_blocks:
        Number of joblib delayed objects (blocks to compute) given to joblib.Parallel
    histogram:
        Determines whether a nearest neighbor histogram should be created. Not implemented for this metric
    base_matrix:
        Amino acid substitution matrix used by TCRdist. `"blosum62"` uses the original
        BLOSUM62 substitution matrix, while `"tcrblosum"` uses TCRBLOSUM substitution
        matrices (:cite:`TCRBLOSUM`). Depending on `chain_type`, either the TCRBLOSUM
        alpha- or beta-chain matrix is used.
    distance_cap:
        Maximum distance assigned to a mismatch after converting substitution scores to distances.
        The default value, `"default"`, keeps the original behavior: BLOSUM62 uses a cap of `4`,
        while TCRBLOSUM distances are uncapped. Set to an integer to choose a cap explicitly, or
        `None` for uncapped distances.
    chain_type:
        Required when `base_matrix="tcrblosum"`. `"VJ"` selects the alpha-chain matrix
        and `"VDJ"` selects the beta-chain matrix. When called via `ir_dist`, this value
        is set automatically and should not be provided.
    """

    def __init__(
        self,
        cutoff: int = 20,
        *,
        dist_weight: int = 3,
        gap_penalty: int = 4,
        ntrim: int = 3,
        ctrim: int = 2,
        fixed_gappos: bool = True,
        n_jobs: int = -1,
        n_blocks: int = 1,
        histogram: bool = False,
        base_matrix: Literal["blosum62", "tcrblosum"] = "blosum62",
        distance_cap: int | None | Literal["default"] = "default",
        chain_type: Literal["VJ", "VDJ"] | None = None,
    ):
        self.dist_weight = dist_weight
        self.gap_penalty = gap_penalty
        self.ntrim = ntrim
        self.ctrim = ctrim
        self.fixed_gappos = fixed_gappos
        self.cutoff = cutoff
        self.histogram = histogram
        if distance_cap != "default" and distance_cap is not None and not isinstance(distance_cap, int):
            raise ValueError("`distance_cap` must be non-negative, `None`, or 'default'.")
        if isinstance(distance_cap, int) and distance_cap < 0:
            raise ValueError("`distance_cap` must be non-negative, `None`, or 'default'.")

        if base_matrix == "blosum62":
            substitution_matrix = BLOSUM62
            matrix_distance_cap = 4 if distance_cap == "default" else distance_cap
            distance_offset = 4

        elif base_matrix == "tcrblosum":
            if chain_type == "VJ":
                substitution_matrix = TCRBLOSUM_ALPHA
            elif chain_type == "VDJ":
                substitution_matrix = TCRBLOSUM_BETA
            else:
                raise ValueError("`chain_type` must be 'VJ' or 'VDJ' when `base_matrix='tcrblosum'`.")

            # Use one `distance_offset` across alpha and beta matrices so equal substitution scores
            # map to equal distances for both chain types. This keeps VJ and VDJ distances on a
            # shared scale for clonotype clustering.
            off_diagonal = ~np.eye(len(substitution_matrix.alphabet), dtype=bool)
            max_score = int(
                max(
                    np.max(TCRBLOSUM_ALPHA.matrix[off_diagonal]),
                    np.max(TCRBLOSUM_BETA.matrix[off_diagonal]),
                )
            )

            matrix_distance_cap = None if distance_cap == "default" else distance_cap
            distance_offset = max_score + 1

        else:
            raise ValueError(f"Unknown `base_matrix`: {base_matrix!r}")

        self.tcr_nb_distance_matrix = _substitution_to_distance_matrix(
            substitution_matrix.matrix,
            AA_ALPHABET_WITH_UNKNOWN,
            substitution_matrix.alphabet,
            distance_cap=matrix_distance_cap,
            distance_offset=distance_offset,
        )

        super().__init__(n_jobs=n_jobs, n_blocks=n_blocks, histogram=histogram)

    def _tcrdist_mat(
        self,
        *,
        seqs: Sequence[str],
        seqs2: Sequence[str],
        is_symmetric: bool = False,
        start_column: int = 0,
    ) -> tuple[list[np.ndarray], list[np.ndarray], np.ndarray]:
        """Computes the pairwise TCRdist distances for sequences in seqs and seqs2.

        This function is a wrapper and contains an inner JIT compiled numba function without parameters. The reason for this is
        that this way some of the parameters can be treated as constant by numba and this allows for a better optimization
        of the numba compiler in this specific case.

        If this function is used to compute a block of a bigger result matrix, is_symmetric and start_column
        can be used to only compute the part of the block that would be part of the upper triangular matrix of the
        result matrix.

        Note: to use with non-CDR3 sequences set ntrim and ctrim to 0.

        Parameters
        ----------
        seqs/2:
            A python sequence of strings representing gene sequences
        is_symmetric:
            Determines whether the final result matrix is symmetric, assuming that this function is
            only used to compute a block of a bigger result matrix
        start_column:
            Determines at which column the calculation should be started. This is only used if this function is
            used to compute a block of a bigger result matrix that is symmetric

        Returns
        -------
        data_rows:
            List with arrays containing the non-zero data values of the result matrix per row,
            needed to create the final scipy CSR result matrix later
        indices_rows:
            List with arrays containing the non-zero entry column indeces of the result matrix per row,
            needed to create the final scipy CSR result matrix later
        row_element_counts:
            Array with integers that indicate the amount of non-zero values of the result matrix per row,
            needed to create the final scipy CSR result matrix later
        row_mins:
            Always returns a numpy array containing None because the computation of the minimum distance per row is
            not implemented for the tcrdist calculator yet.
        """
        max_seq_len = max(len(s) for s in (*seqs, *seqs2))

        seqs_mat1, seqs_L1 = _seqs2mat(seqs, max_len=max_seq_len)
        seqs_mat2, seqs_L2 = _seqs2mat(seqs2, max_len=max_seq_len)

        cutoff = self.cutoff
        dist_weight = self.dist_weight
        gap_penalty = self.gap_penalty
        ntrim = self.ntrim
        ctrim = self.ctrim
        fixed_gappos = self.fixed_gappos

        dist_mat_weighted = self.tcr_nb_distance_matrix * dist_weight
        start_column *= is_symmetric

        nb.set_num_threads(_get_usable_cpus(n_jobs=self.n_jobs, use_numba=True))

        num_threads = nb.get_num_threads()

        jit_parallel = num_threads > 1

        @nb.jit(nopython=True, parallel=jit_parallel, nogil=True)
        def _nb_tcrdist_mat():
            assert seqs_mat1.shape[0] == seqs_L1.shape[0]
            assert seqs_mat2.shape[0] == seqs_L2.shape[0]

            num_rows = seqs_mat1.shape[0]
            num_cols = seqs_mat2.shape[0]

            data_rows = nb.typed.List()
            indices_rows = nb.typed.List()
            row_element_counts = np.zeros(num_rows)

            empty_row = np.zeros(0)
            for _ in range(0, num_rows):
                data_rows.append([empty_row])
                indices_rows.append([empty_row])

            data_row_matrix = np.empty((num_threads, num_cols))
            indices_row_matrix = np.empty((num_threads, num_cols))

            for row_index in nb.prange(num_rows):
                thread_id = nb.get_thread_id()
                row_end_index = 0
                seq1_len = seqs_L1[row_index]

                for col_index in range(start_column + row_index * is_symmetric, num_cols):
                    distance = 1
                    seq2_len = seqs_L2[col_index]

                    if seq1_len == seq2_len:
                        for i in range(ntrim, seq1_len - ctrim):
                            distance += dist_mat_weighted[seqs_mat1[row_index, i], seqs_mat2[col_index, i]]

                    else:
                        short_len = min(seq1_len, seq2_len)
                        len_diff = abs(seq1_len - seq2_len)
                        if fixed_gappos:
                            min_gappos = min(6, 3 + (short_len - 5) // 2)
                            max_gappos = min_gappos
                        else:
                            min_gappos = 5
                            max_gappos = short_len - 1 - 4
                            while min_gappos > max_gappos:
                                min_gappos -= 1
                                max_gappos += 1
                        min_dist = -1

                        for gappos in range(min_gappos, max_gappos + 1):
                            tmp_dist = 0

                            remainder = short_len - gappos
                            for n_i in range(ntrim, gappos):
                                tmp_dist += dist_mat_weighted[seqs_mat1[row_index, n_i], seqs_mat2[col_index, n_i]]

                            for c_i in range(ctrim, remainder):
                                tmp_dist += dist_mat_weighted[
                                    seqs_mat1[row_index, seq1_len - 1 - c_i], seqs_mat2[col_index, seq2_len - 1 - c_i]
                                ]

                            if tmp_dist < min_dist or min_dist == -1:
                                min_dist = tmp_dist

                            if min_dist == 0:
                                break

                        distance = min_dist + len_diff * gap_penalty + 1

                    if distance <= cutoff + 1:
                        data_row_matrix[thread_id, row_end_index] = distance
                        indices_row_matrix[thread_id, row_end_index] = col_index
                        row_end_index += 1

                data_rows[row_index][0] = data_row_matrix[thread_id, 0:row_end_index].copy()
                indices_rows[row_index][0] = indices_row_matrix[thread_id, 0:row_end_index].copy()
                row_element_counts[row_index] = row_end_index

            data_rows_flat = []
            indices_rows_flat = []

            for i in range(len(data_rows)):
                data_rows_flat.append(data_rows[i][0])
                indices_rows_flat.append(indices_rows[i][0])

            return data_rows_flat, indices_rows_flat, row_element_counts

        data_rows, indices_rows, row_element_counts = _nb_tcrdist_mat()
        return data_rows, indices_rows, row_element_counts, np.array([None])

    _metric_mat = _tcrdist_mat


class NeedlemanWunschDistanceCalculator(_MetricDistanceCalculator):
    """Computes pairwise global-alignment distances with linear-gap Needleman-Wunsch.

    For each sequence pair, a global alignment score is computed using the
    Needleman-Wunsch dynamic programming algorithm with one linear gap penalty
    for every gap position. The alignment score is converted into a distance by
    subtracting it from the best possible self-alignment score of the two
    sequences:
    ``min(self_score(seq1), self_score(seq2)) - alignment_score(seq1, seq2)``.
    Distances are therefore small for sequence pairs that can be globally
    aligned with few or conservative substitutions and short gaps, and larger
    for sequence pairs requiring strongly penalized substitutions or many gap
    positions.

    Parameters
    ----------
    gap_penalty:
        Linear penalty for each gap position
    cutoff:
        Will eliminate distances > cutoff to make efficient use of sparse matrices
    n_jobs:
        Number of numba parallel threads to use for the pairwise distance calculation
    n_blocks:
        Number of joblib delayed objects (blocks to compute) given to joblib.Parallel
    histogram:
        Determines whether a nearest neighbor histogram should be created. Not implemented for this metric
    """

    def __init__(
        self,
        cutoff: int = 10,
        *,
        gap_penalty: int = 4,
        n_jobs: int = -1,
        n_blocks: int = 1,
        histogram: bool = False,
    ):
        if cutoff < 0:
            raise ValueError("`cutoff` must be non-negative.")
        if gap_penalty < 0:
            raise ValueError("`gap_penalty` must be non-negative.")

        self.cutoff = cutoff
        self.gap_penalty = gap_penalty
        self.histogram = histogram

        self.nw_substitution_matrix = _map_matrix_to_alphabet(
            BLOSUM62.matrix,
            BLOSUM62.alphabet,
            AA_ALPHABET_WITH_UNKNOWN,
        )
        super().__init__(n_jobs=n_jobs, n_blocks=n_blocks, histogram=histogram)

    def _validate_seqs(self, seqs: Sequence[str], seqs2: Sequence[str]) -> None:
        """Warn once if input contains non-canonical amino acids."""
        canonical_amino_acids = frozenset(CANONICAL_AA_ALPHABET)
        sequences = seqs if seqs2 is seqs else itertools.chain(seqs, seqs2)
        if any(not canonical_amino_acids.issuperset(seq) for seq in sequences):
            logging.warning(
                f"Non-canonical amino acid symbols detected. Canonical symbols are: {CANONICAL_AA_ALPHABET}. "
                "Needleman-Wunsch assigns a substitution score of 0 "
                "to these symbols, which may affect the resulting distances."
            )

    def _needleman_wunsch_mat(
        self,
        *,
        seqs: Sequence[str],
        seqs2: Sequence[str],
        is_symmetric: bool = False,
        start_column: int = 0,
    ) -> tuple[list[np.ndarray], list[np.ndarray], np.ndarray, np.ndarray]:
        """Computes pairwise linear-gap Needleman-Wunsch distances."""
        max_seq_len = max(len(s) for s in (*seqs, *seqs2))

        seqs_mat1, seqs_L1 = _seqs2mat(seqs, max_len=max_seq_len)
        seqs_mat2, seqs_L2 = _seqs2mat(seqs2, max_len=max_seq_len)

        cutoff = self.cutoff
        gap_penalty = self.gap_penalty
        substitution_matrix = self.nw_substitution_matrix
        start_column *= is_symmetric

        nb.set_num_threads(_get_usable_cpus(n_jobs=self.n_jobs, use_numba=True))
        num_threads = nb.get_num_threads()
        jit_parallel = num_threads > 1

        @nb.njit
        def _self_scores(seqs_mat, seqs_L):
            scores = np.zeros(seqs_mat.shape[0], dtype=np.int32)
            for row in range(seqs_mat.shape[0]):
                score = 0
                for i in range(seqs_L[row]):
                    aa = seqs_mat[row, i]
                    score += substitution_matrix[aa, aa]
                scores[row] = score
            return scores

        self_scores1 = _self_scores(seqs_mat1, seqs_L1)
        self_scores2 = (
            self_scores1
            if is_symmetric and seqs_mat1.shape[0] == seqs_mat2.shape[0]
            else _self_scores(seqs_mat2, seqs_L2)
        )

        @nb.jit(nopython=True, parallel=jit_parallel, nogil=True)
        def _nb_needleman_wunsch_mat():
            assert seqs_mat1.shape[0] == seqs_L1.shape[0]
            assert seqs_mat2.shape[0] == seqs_L2.shape[0]

            num_rows = seqs_mat1.shape[0]
            num_cols = seqs_mat2.shape[0]
            max_len = seqs_mat1.shape[1]

            data_rows = nb.typed.List()
            indices_rows = nb.typed.List()
            row_element_counts = np.zeros(num_rows, dtype=np.int32)

            empty_row = np.zeros(0, dtype=np.int32)
            for _ in range(0, num_rows):
                data_rows.append([empty_row])
                indices_rows.append([empty_row])

            data_row_matrix = np.empty((num_threads, num_cols), dtype=np.int32)
            indices_row_matrix = np.empty((num_threads, num_cols), dtype=np.int32)
            previous_rows = np.empty((num_threads, max_len + 1), dtype=np.int32)
            current_rows = np.empty((num_threads, max_len + 1), dtype=np.int32)

            # Only alignment paths within a band around the diagonal can stay within the cutoff,
            # because each step away from the diagonal requires one gap penalty.
            band_width = max_len if gap_penalty == 0 else cutoff // gap_penalty

            for row_index in nb.prange(num_rows):
                thread_id = nb.get_thread_id()
                row_end_index = 0
                seq1_len = seqs_L1[row_index]

                col_start = start_column + row_index * is_symmetric
                if is_symmetric:
                    data_row_matrix[thread_id, row_end_index] = 1
                    indices_row_matrix[thread_id, row_end_index] = col_start
                    row_end_index += 1
                    col_start += 1

                for col_index in range(col_start, num_cols):
                    seq2_len = seqs_L2[col_index]
                    len_diff = abs(seq1_len - seq2_len)

                    # Skip pairs whose length difference alone cannot stay within the cutoff.
                    if len_diff * gap_penalty > cutoff:
                        continue

                    min_self_score = min(self_scores1[row_index], self_scores2[col_index])

                    band_start = 1 - band_width
                    band_end = 1 + band_width

                    j_end = min(band_width, seq2_len)

                    for j in range(j_end + 1):
                        previous_rows[thread_id, j] = -j * gap_penalty

                    for i in range(1, seq1_len + 1):
                        aa1 = seqs_mat1[row_index, i - 1]

                        j_start = max(1, band_start)
                        j_end = min(seq2_len, band_end)

                        if i <= band_width:
                            current_rows[thread_id, 0] = -i * gap_penalty

                        for j in range(j_start, j_end + 1):
                            aa2 = seqs_mat2[col_index, j - 1]
                            match_score = previous_rows[thread_id, j - 1] + substitution_matrix[aa1, aa2]
                            best_score = match_score

                            if band_width == 0:
                                best_score = match_score
                            elif j == band_start:
                                delete_score = previous_rows[thread_id, j] - gap_penalty
                                best_score = max(match_score, delete_score)
                            elif j == band_end:
                                insert_score = current_rows[thread_id, j - 1] - gap_penalty
                                best_score = max(match_score, insert_score)
                            else:
                                delete_score = previous_rows[thread_id, j] - gap_penalty
                                insert_score = current_rows[thread_id, j - 1] - gap_penalty
                                best_score = max(match_score, delete_score, insert_score)

                            current_rows[thread_id, j] = best_score

                        copy_start = j_start * (i > band_width)

                        for j in range(copy_start, j_end + 1):
                            previous_rows[thread_id, j] = current_rows[thread_id, j]

                        band_start += 1
                        band_end += 1

                    distance = max(0, min_self_score - previous_rows[thread_id, seq2_len]) + 1

                    if distance <= cutoff + 1:
                        data_row_matrix[thread_id, row_end_index] = distance
                        indices_row_matrix[thread_id, row_end_index] = col_index
                        row_end_index += 1

                data_rows[row_index][0] = data_row_matrix[thread_id, 0:row_end_index].copy()
                indices_rows[row_index][0] = indices_row_matrix[thread_id, 0:row_end_index].copy()
                row_element_counts[row_index] = row_end_index

            data_rows_flat = []
            indices_rows_flat = []

            for i in range(len(data_rows)):
                data_rows_flat.append(data_rows[i][0])
                indices_rows_flat.append(indices_rows[i][0])

            return data_rows_flat, indices_rows_flat, row_element_counts

        data_rows, indices_rows, row_element_counts = _nb_needleman_wunsch_mat()
        return data_rows, indices_rows, row_element_counts, np.array([None])

    _metric_mat = _needleman_wunsch_mat


@deprecated(
    Deprecation(
        "0.15.0",
        "If `gap_open == gap_extend` (the default), use NeedlemanWunschDistanceCalculator instead, which is much "
        "faster and provides identical results for canonical amino-acid sequences. If you actually have a use-case "
        "for affine gap penalties, please let us know by opening an issue on GitHub.",
    )
)
@_doc_params(params=_doc_params_parallel_distance_calculator)
class AlignmentDistanceCalculator(ParallelDistanceCalculator):
    """\
    Calculates distance between sequences based on pairwise sequence alignment.

    The distance between two sequences is defined as :math:`S_{{1,2}}^{{max}} - S_{{1,2}}`,
    where :math:`S_{{1,2}}` is the alignment score of sequences 1 and 2 and
    :math:`S_{{1,2}}^{{max}}` is the max. achievable alignment score of sequences 1 and 2.
    :math:`S_{{1,2}}^{{max}}` is defined as :math:`\\min(S_{{1,1}}, S_{{2,2}})`.

    The use of alignment-based distances is heavily inspired by :cite:`TCRdist`.

    High-performance sequence alignments are calculated leveraging
    the `parasail library <https://github.com/jeffdaily/parasail-python>`_ (:cite:`Daily2016`).

    Choosing a cutoff:
        Alignment distances need to be viewed in the light of the substitution matrix.
        The alignment distance is the difference between the actual alignment
        score and the max. achievable alignment score. For instance, a mutation
        from *Leucine* (`L`) to *Isoleucine* (`I`) results in a BLOSUM62 score of `2`.
        An `L` aligned with `L` achieves a score of `4`. The distance is, therefore, `2`.

        On the other hand, a single *Tryptophane* (`W`) mutating into, e.g.
        *Proline* (`P`) already results in a distance of `15`.

        We are still lacking empirical data up to which distance a CDR3 sequence still
        is likely to recognize the same antigen, but reasonable cutoffs are `<15`.

    Parameters
    ----------
    cutoff
        Will eleminate distances > cutoff to make efficient
        use of sparse matrices. The default cutoff is `10`.
    {params}
    subst_mat
        Name of parasail substitution matrix
    gap_open
        Gap open penalty
    gap_extend
        Gap extend penatly
    """

    @deprecated_arg("block_size", _deprecation_block_size)
    def __init__(
        self,
        cutoff: int = 10,
        *,
        n_jobs: int = -1,
        block_size: int | None = None,
        subst_mat: str = "blosum62",
        gap_open: int = 11,
        gap_extend: int = 11,
    ):
        super().__init__(cutoff, n_jobs=n_jobs)
        self.subst_mat = subst_mat
        self.gap_open = gap_open
        self.gap_extend = gap_extend

    def _compute_block(self, seqs1, seqs2, origin):
        try:
            import parasail
        except ImportError:
            raise ImportError(
                "Using the alignment distance requires the installation of `parasail`. "
                "You can install it with `pip install parasail`."
            ) from None

        subst_mat = parasail.Matrix(self.subst_mat)
        origin_row, origin_col = origin

        square_matrix = seqs2 is None
        if square_matrix:
            seqs2 = seqs1

        self_alignment_scores1 = self._self_alignment_scores(seqs1)
        if square_matrix:
            self_alignment_scores2 = self_alignment_scores1
        else:
            self_alignment_scores2 = self._self_alignment_scores(seqs2)

        result = []
        for row, s1 in enumerate(seqs1):
            col_start = row if square_matrix else 0
            for col, s2 in enumerate(seqs2[col_start:], start=col_start):
                profile = parasail.profile_create_16(s1, subst_mat)
                r = parasail.nw_scan_profile_16(profile, s2, self.gap_open, self.gap_extend)
                max_score = np.min([self_alignment_scores1[row], self_alignment_scores2[col]])
                d = max_score - r.score
                if d <= self.cutoff:
                    result.append((d + 1, origin_row + row, origin_col + col))

        return result

    def _self_alignment_scores(self, seqs: Sequence) -> dict:
        """Calculate self-alignments. We need them as reference values
        to turn scores into dists
        """
        try:
            import parasail
        except ImportError:
            raise ImportError(
                "Using the alignment distance requires the installation of `parasail`. "
                "You can install it with `pip install parasail`."
            ) from None

        return np.fromiter(
            (
                parasail.nw_scan_16(
                    s,
                    s,
                    self.gap_open,
                    self.gap_extend,
                    parasail.Matrix(self.subst_mat),
                ).score
                for s in seqs
            ),
            dtype=int,
            count=len(seqs),
        )


@deprecated(
    Deprecation(
        "0.26.0",
        "If `gap_open == gap_extend` (the default), use NeedlemanWunschDistanceCalculator instead, which is much "
        "faster and provides identical results for canonical amino-acid sequences. If you actually have a use-case "
        "for affine gap penalties, please let us know by opening an issue on GitHub.",
    )
)
@_doc_params(params=_doc_params_parallel_distance_calculator)
class FastAlignmentDistanceCalculator(ParallelDistanceCalculator):
    """\
    Calculates distance between sequences based on pairwise sequence alignment.

    The distance between two sequences is defined as :math:`S_{{1,2}}^{{max}} - S_{{1,2}}`,
    where :math:`S_{{1,2}}` is the alignment score of sequences 1 and 2 and
    :math:`S_{{1,2}}^{{max}}` is the max. achievable alignment score of sequences 1 and 2.
    :math:`S_{{1,2}}^{{max}}` is defined as :math:`\\min(S_{{1,1}}, S_{{2,2}})`.

    The use of alignment-based distances is heavily inspired by :cite:`TCRdist`.

    High-performance sequence alignments are calculated leveraging
    the `parasail library <https://github.com/jeffdaily/parasail-python>`_ (:cite:`Daily2016`).

    To speed up the computation, we pre-filter sequence pairs based on
        a) differences in sequence length
        b) the number of different characters, based on an estimate of the mismatch penalty (`estimated_penalty`).

    The filtering based on `estimated_penalty` is a *heuristic* and *may lead to false negatives*, i.e. sequence
    pairs that are actually below the distance cutoff, but are removed during pre-filtering. Sensible values for
    `estimated_penalty` are depending on the substitution matrix, but higher values lead to a higher false negative rate.

    We provide default values for BLOSUM and PAM matrices. The provided default values were obtained by testing different
    alues on the Wu dataset (:cite:`Wu2020`) and selecting those that provided a reasonable balance between
    speedup and loss. Loss stayed well under 10% in all our test cases with the default values, and speedup
    increases with the number of cells.

    While the length-based filter is always active, the filter based on different characters can be disabled by
    setting the estimated penalty to zero. Using length-based filtering only, there won't be any false negatives
    *unless with a substitution matrix in which a substitution results in a higher score than the corresponding match.*
    Using the length-based filter only results in a substancially reduced speedup compared to combining it with
    the `estimated_penalty` heuristic.

    Choosing a cutoff:
        Alignment distances need to be viewed in the light of the substitution matrix.
        The alignment distance is the difference between the actual alignment
        score and the max. achievable alignment score. For instance, a mutation
        from *Leucine* (`L`) to *Isoleucine* (`I`) results in a BLOSUM62 score of `2`.
        An `L` aligned with `L` achieves a score of `4`. The distance is, therefore, `2`.

        On the other hand, a single *Tryptophane* (`W`) mutating into, e.g.
        *Proline* (`P`) already results in a distance of `15`.

        We are still lacking empirical data up to which distance a CDR3 sequence still
        is likely to recognize the same antigen, but reasonable cutoffs are `<15`.

    Choosing an expected penalty:
        The choice of an expected penalty is likely influenced by similar considerations as the
        other parameters. Essentially, this can be thought of as a superficial (dis)similarity
        measure. A higher value more strongly penalizes mismatching characters and is more in line
        with looking for closely related sequence pairs, while a lower value is more forgiving
        and better suited when looking for more distantly related sequence pairs.

    Parameters
    ----------
    cutoff
        Will eleminate distances > cutoff to make efficient
        use of sparse matrices. The default cutoff is `10`.
    {params}
    subst_mat
        Name of parasail substitution matrix
    gap_open
        Gap open penalty
    gap_extend
        Gap extend penatly
    estimated_penalty
        Estimate of the average mismatch penalty
    """

    @deprecated_arg("block_size", _deprecation_block_size)
    def __init__(
        self,
        cutoff: int = 10,
        *,
        n_jobs: int = -1,
        block_size: int | None = None,
        subst_mat: str = "blosum62",
        gap_open: int = 11,
        gap_extend: int = 11,
        estimated_penalty: float = None,
    ):
        super().__init__(cutoff, n_jobs=n_jobs)
        self.subst_mat = subst_mat
        self.gap_open = gap_open
        self.gap_extend = gap_extend

        penalty_dict = {
            "blosum30": 4.0,
            "blosum35": 4.0,
            "blosum40": 4.0,
            "blosum45": 4.0,
            "blosum50": 4.0,
            "blosum55": 4.0,
            "blosum60": 4.0,
            "blosum62": 4.0,
            "blosum65": 4.0,
            "blosum70": 4.0,
            "blosum75": 4.0,
            "blosum80": 4.0,
            "blosum85": 4.0,
            "blosum90": 4.0,
            "pam10": 8.0,
            "pam20": 8.0,
            "pam30": 8.0,
            "pam40": 8.0,
            "pam50": 8.0,
            "pam60": 4.0,
            "pam70": 4.0,
            "pam80": 4.0,
            "pam90": 4.0,
            "pam100": 4.0,
            "pam110": 2.0,
            "pam120": 2.0,
            "pam130": 2.0,
            "pam140": 2.0,
            "pam150": 2.0,
            "pam160": 2.0,
            "pam170": 2.0,
            "pam180": 2.0,
            "pam190": 2.0,
            "pam200": 2.0,
        }

        if subst_mat not in penalty_dict.keys():
            raise Exception("Invalid substitution matrix.")

        self.estimated_penalty = estimated_penalty if estimated_penalty is not None else penalty_dict[subst_mat]

    def _compute_block(self, seqs1, seqs2, origin):
        try:
            import parasail
        except ImportError:
            raise ImportError(
                "Using the alignment distance requires the installation of `parasail`. "
                "You can install it with `pip install parasail`."
            ) from None

        subst_mat = parasail.Matrix(self.subst_mat)
        origin_row, origin_col = origin

        square_matrix = seqs2 is None
        if square_matrix:
            seqs2 = seqs1

        self_alignment_scores1 = self._self_alignment_scores(seqs1)
        if square_matrix:
            self_alignment_scores2 = self_alignment_scores1
        else:
            self_alignment_scores2 = self._self_alignment_scores(seqs2)

        max_len_diff = ((self.cutoff - self.gap_open) / self.gap_extend) + 1

        result = []
        for row, s1 in enumerate(seqs1):
            col_start = row if square_matrix else 0
            profile = parasail.profile_create_16(s1, subst_mat)
            len1 = len(s1)

            for col, s2 in enumerate(seqs2[col_start:], start=col_start):
                len_diff = abs(len1 - len(s2))
                # No need to calculate diagonal values
                if s1 == s2:
                    result.append((1, origin_row + row, origin_col + col))
                # Dismiss sequences based on length
                elif len_diff <= max_len_diff:
                    # Dismiss sequences that are too different
                    if (
                        self._num_different_characters(s1, s2, len_diff) * self.estimated_penalty
                        + len_diff * self.gap_extend
                        <= self.cutoff
                    ):
                        r = parasail.nw_scan_profile_16(profile, s2, self.gap_open, self.gap_extend)
                        max_score = np.min([self_alignment_scores1[row], self_alignment_scores2[col]])
                        d = max_score - r.score

                        if d <= self.cutoff:
                            result.append((d + 1, origin_row + row, origin_col + col))

        return result

    def _self_alignment_scores(self, seqs: Sequence) -> dict:
        """Calculate self-alignments. We need them as reference values
        to turn scores into dists
        """
        try:
            import parasail
        except ImportError:
            raise ImportError(
                "Using the alignment distance requires the installation of `parasail`. "
                "You can install it with `pip install parasail`."
            ) from None

        return np.fromiter(
            (
                parasail.nw_scan_16(
                    s,
                    s,
                    self.gap_open,
                    self.gap_extend,
                    parasail.Matrix(self.subst_mat),
                ).score
                for s in seqs
            ),
            dtype=int,
            count=len(seqs),
        )

    def _num_different_characters(self, s1, s2, len_diff):
        longer, shorter = (s1, s2) if len(s1) >= len(s2) else (s2, s1)

        for c in shorter:
            if c in longer:
                longer = longer.replace(c, "", 1)
        return len(longer) - len_diff
