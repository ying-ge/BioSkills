from polars.datatype_expr.datatype_expr import DataTypeExpr

__all__ = [
    "DataTypeExpr",
]
