from polars.io.spreadsheet.functions import read_excel, read_ods

__all__ = [
    "read_excel",
    "read_ods",
]
