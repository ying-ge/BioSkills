from polars.io.iceberg.functions import scan_iceberg

__all__ = ["scan_iceberg"]
