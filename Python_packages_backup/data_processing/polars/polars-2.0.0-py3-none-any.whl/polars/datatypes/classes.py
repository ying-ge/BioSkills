from __future__ import annotations

import contextlib
import enum
from collections import OrderedDict
from collections.abc import Mapping
from datetime import tzinfo
from inspect import isclass
from typing import TYPE_CHECKING, Any, Generic, TypeVar, overload

import polars._reexport as pl
import polars.datatypes
from polars._utils.expired import (
    RemovedParameter,
    getattr_fallback,
    raise_for_removed_attributes,
    removed_parameters,
)

with contextlib.suppress(ImportError):  # Module not available when building docs
    import polars._plr as plr
    from polars._plr import PyCategories
    from polars._plr import dtype_str_repr as _dtype_str_repr


import polars.datatypes.classes as pldt

if TYPE_CHECKING:
    import sys
    from collections.abc import Callable, Iterable, Iterator, Sequence

    if sys.version_info >= (3, 11):
        from typing import Self
    else:
        from typing_extensions import Self

    from polars import Series
    from polars._typing import (
        PolarsDataType,
        PythonDataType,
        SchemaDict,
        TimeUnit,
    )


R_co = TypeVar("R_co", covariant=True)


class classinstmethod(Generic[R_co]):
    """Decorator that allows a method to be called from the class OR instance."""

    func: Callable[..., R_co]

    def __init__(self, func: Callable[..., R_co]) -> None:
        self.func = func

    def __get__(self, instance: Any, type_: Any) -> Callable[..., R_co]:
        if instance is not None:
            return self.func.__get__(instance, type_)
        return self.func.__get__(type_, type_)


class DataTypeClass(type):
    """Metaclass for nicely printing DataType classes."""

    def __repr__(cls) -> str:
        return cls.__name__

    def _string_repr(cls) -> str:
        return _dtype_str_repr(cls)

    # Methods below defined here in signature only to satisfy mypy

    @classmethod
    def base_type(cls) -> DataTypeClass:  # noqa: D102
        ...

    @classmethod
    def is_(cls, other: PolarsDataType) -> bool:  # noqa: D102
        ...

    @classmethod
    def is_numeric(cls) -> bool:  # noqa: D102
        ...

    @classmethod
    def is_decimal(cls) -> bool:  # noqa: D102
        ...

    @classmethod
    def is_integer(cls) -> bool:  # noqa: D102
        ...

    @classmethod
    def is_object(cls) -> bool:  # noqa: D102
        ...

    @classmethod
    def is_signed_integer(cls) -> bool:  # noqa: D102
        ...

    @classmethod
    def is_unsigned_integer(cls) -> bool:  # noqa: D102
        ...

    @classmethod
    def is_float(cls) -> bool:  # noqa: D102
        ...

    @classmethod
    def is_temporal(cls) -> bool:  # noqa: D102
        ...

    @classmethod
    def is_nested(cls) -> bool:  # noqa: D102
        ...

    @classmethod
    def is_extension(cls) -> bool:  # noqa: D102
        ...

    @classmethod
    def from_python(cls, py_type: PythonDataType) -> PolarsDataType:  # noqa: D102
        ...

    @classmethod
    def to_python(cls) -> PythonDataType:  # noqa: D102
        ...

    @classmethod
    def to_dtype_expr(cls) -> pl.DataTypeExpr:  # noqa: D102
        ...


class DataType(metaclass=DataTypeClass):
    """Base class for all Polars data types."""

    def _string_repr(self) -> str:
        return _dtype_str_repr(self)

    @overload  # type: ignore[override]
    def __eq__(  # pyrefly: ignore[bad-override]
        self, other: pl.DataTypeExpr
    ) -> pl.Expr: ...

    @overload
    def __eq__(self, other: PolarsDataType) -> bool: ...

    def __eq__(self, other: pl.DataTypeExpr | PolarsDataType) -> pl.Expr | bool:
        if isinstance(other, pl.DataTypeExpr):
            return self.to_dtype_expr() == other
        elif type(other) is DataTypeClass:
            return issubclass(other, type(self))
        else:
            return isinstance(other, type(self))

    def __hash__(self) -> int:
        return hash(self.__class__)

    def __repr__(self) -> str:
        return self.__class__.__name__

    @classmethod
    def base_type(cls) -> type[Self]:
        """
        Return this DataType's fundamental/root type class.

        Examples
        --------
        >>> pl.Datetime("ns").base_type()
        Datetime
        >>> pl.List(pl.Int32).base_type()
        List
        >>> pl.Struct([pl.Field("a", pl.Int64), pl.Field("b", pl.Boolean)]).base_type()
        Struct
        """
        return cls

    @classinstmethod
    def is_(self, other: PolarsDataType) -> bool:
        """
        Check if this DataType is the same as another DataType.

        This is a stricter check than `self == other`, as it enforces an exact
        match of all dtype attributes for nested and/or uninitialised dtypes.

        Parameters
        ----------
        other
            the other Polars dtype to compare with.

        Examples
        --------
        >>> pl.List == pl.List(pl.Int32)
        True
        >>> pl.List.is_(pl.List(pl.Int32))
        False
        """
        return self == other and hash(self) == hash(other)

    @classmethod
    def is_numeric(cls) -> bool:
        """Check whether the data type is a numeric type."""
        return issubclass(cls, NumericType)

    @classmethod
    def is_decimal(cls) -> bool:
        """Check whether the data type is a decimal type."""
        return issubclass(cls, Decimal)

    @classmethod
    def is_integer(cls) -> bool:
        """Check whether the data type is an integer type."""
        return issubclass(cls, IntegerType)

    @classmethod
    def is_object(cls) -> bool:
        """Check whether the data type is an object type."""
        return issubclass(cls, ObjectType)

    @classmethod
    def is_signed_integer(cls) -> bool:
        """Check whether the data type is a signed integer type."""
        return issubclass(cls, SignedIntegerType)

    @classmethod
    def is_unsigned_integer(cls) -> bool:
        """Check whether the data type is an unsigned integer type."""
        return issubclass(cls, UnsignedIntegerType)

    @classmethod
    def is_float(cls) -> bool:
        """Check whether the data type is a floating point type."""
        return issubclass(cls, FloatType)

    @classmethod
    def is_temporal(cls) -> bool:
        """Check whether the data type is a temporal type."""
        return issubclass(cls, TemporalType)

    @classmethod
    def is_nested(cls) -> bool:
        """Check whether the data type is a nested type."""
        return issubclass(cls, NestedType)

    @classmethod
    def is_extension(cls) -> bool:
        """Check whether the data type is an extension type."""
        return issubclass(cls, BaseExtension)

    @classmethod
    def from_python(cls, py_type: PythonDataType) -> PolarsDataType:
        """
        Return the Polars data type corresponding to a given Python type.

        Notes
        -----
        Not every Python type has a corresponding Polars data type; in general
        you should declare Polars data types explicitly to exactly specify
        the desired type and its properties (such as scale/unit).

        Examples
        --------
        >>> pl.DataType.from_python(int)
        Int64
        >>> pl.DataType.from_python(float)
        Float64
        >>> from datetime import tzinfo
        >>> pl.DataType.from_python(tzinfo)  # doctest: +SKIP
        TypeError: cannot parse input <class 'datetime.tzinfo'> into Polars data type
        """
        from polars.datatypes._parse import parse_into_dtype

        return parse_into_dtype(py_type)

    @classinstmethod
    def to_python(self) -> PythonDataType:
        """
        Return the Python type corresponding to this Polars data type.

        Examples
        --------
        >>> pl.Int16().to_python()
        <class 'int'>
        >>> pl.Float32().to_python()
        <class 'float'>
        >>> pl.Array(pl.Date(), 10).to_python()
        <class 'list'>
        """
        from polars.datatypes import dtype_to_py_type

        return dtype_to_py_type(self)

    @classinstmethod
    def to_dtype_expr(self) -> pl.DataTypeExpr:
        """
        Return a :class:`DataTypeExpr` with a static :class:`DataType`.

        Examples
        --------
        >>> pl.Int16().to_dtype_expr().collect_dtype({})
        Int16
        """
        from polars._plr import PyDataTypeExpr

        return pl.DataTypeExpr._from_pydatatype_expr(PyDataTypeExpr.from_dtype(self))


class NumericType(DataType):
    """Base class for numeric data types."""

    @classmethod
    def max(cls) -> pl.Expr:
        """
        Return a literal expression representing the maximum value of this data type.

        Examples
        --------
        >>> pl.select(pl.Int8.max() == 127)
        shape: (1, 1)
        ┌─────────┐
        │ literal │
        │ ---     │
        │ bool    │
        ╞═════════╡
        │ true    │
        └─────────┘
        """
        return pl.Expr._from_pyexpr(plr._get_dtype_max(cls))

    @classmethod
    def min(cls) -> pl.Expr:
        """
        Return a literal expression representing the minimum value of this data type.

        Examples
        --------
        >>> pl.select(pl.Int8.min() == -128)
        shape: (1, 1)
        ┌─────────┐
        │ literal │
        │ ---     │
        │ bool    │
        ╞═════════╡
        │ true    │
        └─────────┘
        """
        return pl.Expr._from_pyexpr(plr._get_dtype_min(cls))


class IntegerType(NumericType):
    """Base class for integer data types."""


class SignedIntegerType(IntegerType):
    """Base class for signed integer data types."""


class UnsignedIntegerType(IntegerType):
    """Base class for unsigned integer data types."""


class FloatType(NumericType):
    """Base class for float data types."""


class TemporalType(DataType):
    """Base class for temporal data types."""


class NestedType(DataType):
    """Base class for nested data types."""


class ObjectType(DataType):
    """Base class for object data types."""


class Int8(SignedIntegerType):
    """8-bit signed integer type."""


class Int16(SignedIntegerType):
    """16-bit signed integer type."""


class Int32(SignedIntegerType):
    """32-bit signed integer type."""


class Int64(SignedIntegerType):
    """64-bit signed integer type."""


class Int128(SignedIntegerType):
    """
    128-bit signed integer type.

    .. warning::
        This functionality is considered **unstable**.
        It is a work-in-progress feature and may not always work as expected.
        It may be changed at any point without it being considered a breaking change.
    """


class UInt8(UnsignedIntegerType):
    """8-bit unsigned integer type."""


class UInt16(UnsignedIntegerType):
    """16-bit unsigned integer type."""


class UInt32(UnsignedIntegerType):
    """32-bit unsigned integer type."""


class UInt64(UnsignedIntegerType):
    """64-bit unsigned integer type."""


class UInt128(UnsignedIntegerType):
    """128-bit unsigned integer type.

    .. warning::
        This functionality is considered **unstable**.
        It is a work-in-progress feature and may not always work as expected.
        It may be changed at any point without it being considered a breaking change.
    """


class Float16(FloatType):
    """16-bit floating point type.

    .. warning::
        Regular computing platforms do not natively support `Float16` operations,
        and compute operations on `Float16` will be significantly slower as a result
        than operation on :class:`Float32` or :class:`Float64`.
        As such, it is recommended to cast to `Float32` before doing any compute
        operations, and cast back to `Float16` afterward if needed.
    """


class Float32(FloatType):
    """32-bit floating point type."""


class Float64(FloatType):
    """64-bit floating point type."""


class Decimal(NumericType):
    """
    Decimal 128-bit type with an optional precision and non-negative scale.

    Parameters
    ----------
    precision
        Maximum number of digits in each number.
        If set to `None` (default), the precision is set to 38 (the maximum
        supported by Polars).
    scale
        Number of digits to the right of the decimal point in each number.
    """

    precision: int
    scale: int

    def __init__(
        self,
        precision: int | None = None,
        scale: int = 0,
    ) -> None:
        if precision is None:
            precision = 38

        self.precision = precision
        self.scale = scale

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(precision={self.precision}, scale={self.scale})"
        )

    def __eq__(self, other: PolarsDataType) -> bool:  # type: ignore[override]
        # allow comparing object instances to class
        if type(other) is DataTypeClass and issubclass(other, Decimal):
            return True
        elif isinstance(other, Decimal):
            return self.precision == other.precision and self.scale == other.scale
        else:
            return False

    def __hash__(self) -> int:
        return hash((self.__class__, self.precision, self.scale))


class Boolean(DataType):
    """Boolean type."""


class String(DataType):
    """UTF-8 encoded string type."""


# Allow Utf8 as an alias for String
Utf8 = String


class Binary(DataType):
    """Binary type."""


class Date(TemporalType):
    """
    Data type representing a calendar date.

    Notes
    -----
    The underlying representation of this type is a 32-bit signed integer.
    The integer indicates the number of days since the Unix epoch (1970-01-01).
    The number can be negative to indicate dates before the epoch.
    """


class Time(TemporalType):
    """
    Data type representing the time of day.

    Notes
    -----
    The underlying representation of this type is a 64-bit signed integer.
    The integer indicates the number of nanoseconds since midnight.
    """

    @classmethod
    def max(cls) -> pl.Expr:
        """
        Return a literal expression representing the maximum value of this data type.

        Examples
        --------
        >>> pl.select(pl.Time.max() == 86_399_999_999_999)
        shape: (1, 1)
        ┌─────────┐
        │ literal │
        │ ---     │
        │ bool    │
        ╞═════════╡
        │ true    │
        └─────────┘
        """
        return pl.Expr._from_pyexpr(plr._get_dtype_max(cls))

    @classmethod
    def min(cls) -> pl.Expr:
        """
        Return a literal expression representing the minimum value of this data type.

        Examples
        --------
        >>> pl.select(pl.Time.min() == 0)
        shape: (1, 1)
        ┌─────────┐
        │ literal │
        │ ---     │
        │ bool    │
        ╞═════════╡
        │ true    │
        └─────────┘
        """
        return pl.Expr._from_pyexpr(plr._get_dtype_min(cls))


class Datetime(TemporalType):
    """
    Data type representing a calendar date and time of day.

    Parameters
    ----------
    time_unit : {'us', 'ns', 'ms'}
        Unit of time. Defaults to `'us'` (microseconds).
    time_zone
        Time zone string, as defined in zoneinfo (to see valid strings run
        `import zoneinfo; zoneinfo.available_timezones()` for a full list).
        When used to match dtypes, can set this to "*" to check for Datetime
        columns that have any (non-null) timezone.

    Notes
    -----
    The underlying representation of this type is a 64-bit signed integer.
    The integer indicates the number of time units since the Unix epoch
    (1970-01-01 00:00:00). The number can be negative to indicate datetimes before the
    epoch.
    """

    time_unit: TimeUnit
    time_zone: str | None

    def __init__(
        self, time_unit: TimeUnit = "us", time_zone: str | tzinfo | None = None
    ) -> None:
        if time_unit not in ("ms", "us", "ns"):
            msg = (
                "invalid `time_unit`"
                f"\n\nExpected one of {{'ns','us','ms'}}, got {time_unit!r}."
            )
            raise ValueError(msg)

        if isinstance(time_zone, tzinfo):
            time_zone = str(time_zone)

        self.time_unit = time_unit
        self.time_zone = time_zone

    def __eq__(self, other: PolarsDataType) -> bool:  # type: ignore[override]
        # allow comparing object instances to class
        if type(other) is DataTypeClass and issubclass(other, Datetime):
            return True
        elif isinstance(other, Datetime):
            return (
                self.time_unit == other.time_unit and self.time_zone == other.time_zone
            )
        else:
            return False

    def __hash__(self) -> int:
        return hash((self.__class__, self.time_unit, self.time_zone))

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        return (
            f"{class_name}(time_unit={self.time_unit!r}, time_zone={self.time_zone!r})"
        )


class Duration(TemporalType):
    """
    Data type representing a time duration.

    Parameters
    ----------
    time_unit : {'us', 'ns', 'ms'}
        Unit of time. Defaults to `'us'` (microseconds).

    Notes
    -----
    The underlying representation of this type is a 64-bit signed integer.
    The integer indicates an amount of time units and can be negative to indicate
    negative time offsets.
    """

    time_unit: TimeUnit

    def __init__(self, time_unit: TimeUnit = "us") -> None:
        if time_unit not in ("ms", "us", "ns"):
            msg = (
                "invalid `time_unit`"
                f"\n\nExpected one of {{'ns','us','ms'}}, got {time_unit!r}."
            )
            raise ValueError(msg)

        self.time_unit = time_unit

    def __eq__(self, other: PolarsDataType) -> bool:  # type: ignore[override]
        # allow comparing object instances to class
        if type(other) is DataTypeClass and issubclass(other, Duration):
            return True
        elif isinstance(other, Duration):
            return self.time_unit == other.time_unit
        else:
            return False

    def __hash__(self) -> int:
        return hash((self.__class__, self.time_unit))

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        return f"{class_name}(time_unit={self.time_unit!r})"


class Categories:
    """
    A named collection of categories for :py:class:`Categorical`.

    Two categories are considered equal (and will use the same physical mapping of
    categories to strings) if they have the same name, namespace and physical backing
    type, even if they are created in separate calls to `Categories`.

    .. warning::
        This functionality is currently considered **unstable**. It may be
        changed at any point without it being considered a breaking change.

    Parameters
    ----------
    name
        The name of this `Categories`. If set to `None` or an empty string, this
        refers to the global categories.

    namespace
        An optional namespace for this `Categories`. Defaults to the empty string.
        If the name is empty or `None` indicating the global categories, the
        namespace must also be empty.

    physical : {UInt8, UInt16, UInt32}
        The physical type used to represent the categories. Defaults to
        :py:class:`UInt32`.

    See Also
    --------
    Categorical

    Examples
    --------
    A `Categories` instance can be indexed using either string or integer keys:

        >>> fruit = pl.Categories("fruit")
        >>> s = pl.Series(["apple", "banana", "orange"], dtype=pl.Categorical(fruit))
        >>> fruit[0]
        'apple'
        >>> fruit["apple"]
        0

    All `Categories` objects with the same name, namespace and physical type
    share the same mapping, even if they're created separately:

        >>> fruit2 = pl.Categories("fruit")
        >>> fruit2["banana"]
        1

    To get a list of all categories, you can iterate over the `Categories` instance:

        >>> list(fruit)
        ['apple', 'banana', 'orange']

    .. note::
        Because the categories are backed by a concurrent data structure, physical
        category values may be reserved before they are assigned a string lexical
        value if concurrent queries are running. As a result, the resulting `Series`
        may contain `None` values.

    The `Categories` instance is only a weak reference to the actual
    mapping stored in Polars. If no actual data exists using this mapping (like
    a `Series` or `DataFrame`), the mapping is cleaned up by Polars:

        >>> del s
        >>> "apple" in fruit
        False

    If you wish to keep a persistent mapping, simply keep alive some object which
    uses the mapping, e.g. `keepalive = pl.Series([], dtype=pl.Categorical(fruit))`.
    """

    _categories: PyCategories

    def __init__(
        self,
        name: str | None = None,
        namespace: str = "",
        physical: PolarsDataType = pldt.UInt32,
    ) -> None:
        if name is None or name == "":
            assert namespace == "", "global categories may not specify a namespace"
            assert physical == pldt.UInt32, (
                "global categories may not specify a physical type"
            )
            self._categories = PyCategories.global_categories()
            return

        if physical == pldt.UInt32:
            internal_phys = "u32"
        elif physical == pldt.UInt16:
            internal_phys = "u16"
        elif physical == pldt.UInt8:
            internal_phys = "u8"
        else:
            msg = "Categorical physical must be one of pl.UInt(8|16|32)"
            raise TypeError(msg)

        self._categories = PyCategories(name, namespace, internal_phys)

    @staticmethod
    def _from_py_categories(py_categories: PyCategories) -> Categories:
        self = Categories.__new__(Categories)
        self._categories = py_categories
        return self

    @staticmethod
    def random(
        namespace: str = "", physical: PolarsDataType = pldt.UInt32
    ) -> Categories:
        """
        Creates a new `Categories` with a random name.

        Parameters
        ----------
        namespace
            An optional namespace for this `Categories`. Defaults to the empty string.

        physical : {UInt8, UInt16, UInt32}
            The physical type used to represent the categories. Defaults
            to :py:class:`UInt32`.
        """
        if physical == pldt.UInt32:
            internal_phys = "u32"
        elif physical == pldt.UInt16:
            internal_phys = "u16"
        elif physical == pldt.UInt8:
            internal_phys = "u8"
        else:
            msg = "Categorical physical must be one of pl.UInt(8|16|32)"
            raise TypeError(msg)

        return Categories._from_py_categories(
            PyCategories.random(namespace, internal_phys)
        )

    def name(self) -> str:
        """The name of this `Categories`."""
        return self._categories.name()

    def namespace(self) -> str:
        """The namespace of this `Categories`."""
        return self._categories.namespace()

    def physical(self) -> PolarsDataType:
        """The physical type used to represent the categories."""
        phys = self._categories.physical()
        if phys == "u8":
            return pldt.UInt8
        elif phys == "u16":
            return pldt.UInt16
        elif phys == "u32":
            return pldt.UInt32
        else:
            msg = "unknown physical dtype"
            raise RuntimeError(msg)

    def is_global(self) -> bool:
        """Returns whether this refers to the global categories."""
        return self._categories.is_global()

    def __getitem__(self, key: str | int) -> str | int:
        if isinstance(key, str):
            if (cat := self._categories.get_cat(key)) is None:
                raise KeyError(key)
            return cat
        elif isinstance(key, int):
            if (s := self._categories.cat_to_str(key)) is None:
                msg = f"category index out of range: {key}"
                raise IndexError(msg)
            return s
        else:
            msg = f"invalid key type {type(key)}; expected str or int"
            raise TypeError(msg)

    def __contains__(self, item: str | int) -> bool:
        if isinstance(item, str):
            return self._categories.get_cat(item) is not None
        elif isinstance(item, int):
            return self._categories.cat_to_str(item) is not None
        else:
            return False

    def __iter__(self) -> Iterator[str | None]:
        for i in range(self._categories.num_cats_upper_bound()):
            yield self._categories.cat_to_str(i)

    def to_series(self) -> Series:
        """
        Return a :class:`Series` containing all categories in this `Categories`.

        The categories are ordered by their physical category value.

        .. note::
            Because the categories are backed by a concurrent data structure, physical
            category values may be reserved before they are assigned a string lexical
            value if concurrent queries are running. As a result, the resulting `Series`
            may contain `None` values.

        Examples
        --------
        >>> fruit = pl.Categories("fruit")
        >>> s = pl.Series(["apple", "banana", "orange"], dtype=pl.Categorical(fruit))
        >>> fruit.to_series()
        shape: (3,)
        Series: 'fruit' [str]
        [
            "apple"
            "banana"
            "orange"
        ]
        """
        return pl.Series(self.name(), list(self), dtype=String)

    def to_dict(self) -> dict[str, int]:
        """
        Return a dictionary mapping category strings to their physical category values.

        Examples
        --------
        >>> fruit = pl.Categories("fruit")
        >>> s = pl.Series(["apple", "banana", "orange"], dtype=pl.Categorical(fruit))
        >>> fruit.to_dict()
        {'apple': 0, 'banana': 1, 'orange': 2}
        """
        return {cat: i for i, cat in enumerate(self) if cat is not None}

    def __repr__(self) -> str:
        name = self.name()
        namespace = self.namespace()
        phys = self.physical()
        if self._categories.is_global():
            return "Categories()"
        elif namespace == "" and phys == pldt.UInt32:
            return f'Categories("{name}")'
        else:
            return f'Categories(name="{name}", namespace="{namespace}", physical=pl.{phys})'

    def __hash__(self) -> int:
        return hash(self._categories)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Categories) and self._categories == other._categories

    def __getstate__(self) -> tuple[str, str, PolarsDataType]:
        return self.name(), self.namespace(), self.physical()

    def __setstate__(self, state: tuple[str, str, PolarsDataType]) -> None:
        self.__dict__ = Categories(*state).__dict__


class Categorical(DataType):
    """
    A categorical encoding of a set of strings.

    Parameters
    ----------
    categories
        The categories used for this type; must be a :py:class:`Categories`
        instance, or a string which is interpreted as the name of a
        :py:class:`Categories`. If not provided, the global categories
        (`pl.Categories()`) are used.

    See Also
    --------
    Categories
    """

    categories: Categories

    def __init__(
        self,
        categories: Categories | str | None = None,
    ) -> None:
        if isinstance(categories, str):
            self.categories = Categories(name=categories)
        elif categories is None:
            self.categories = Categories()
        else:
            self.categories = categories

    def __repr__(self) -> str:
        if self.categories.is_global():
            return f"{self.__class__.__name__}"
        else:
            return f"{self.__class__.__name__}({self.categories!r})"

    def __eq__(self, other: PolarsDataType) -> bool:  # type: ignore[override]
        # allow comparing object instances to class
        if type(other) is DataTypeClass and issubclass(other, Categorical):
            return self.categories.is_global()
        elif isinstance(other, Categorical):
            return self.categories == other.categories
        else:
            return False

    def __hash__(self) -> int:
        return hash((self.__class__, self.categories))


class Enum(DataType):
    """
    A fixed categorical encoding of a unique set of strings.

    Parameters
    ----------
    categories
        The categories in the dataset; must be a unique set of strings, or an
        existing Python string-valued enum.

    Examples
    --------
    Explicitly define enumeration categories:

    >>> pl.Enum(["north", "south", "east", "west"])
    Enum(categories=['north', 'south', 'east', 'west'])

    Initialise from an existing Python enumeration:

    >>> from http import HTTPMethod
    >>> pl.Enum(HTTPMethod)
    Enum(categories=['CONNECT', 'DELETE', 'GET', 'HEAD', 'OPTIONS', 'PATCH', 'POST', 'PUT', 'TRACE'])
    """  # noqa: W505

    categories: Series

    def __init__(self, categories: Series | Iterable[str] | type[enum.Enum]) -> None:
        if isclass(categories) and issubclass(categories, enum.Enum):
            for enum_subclass in (enum.Flag, enum.IntEnum):
                if issubclass(categories, enum_subclass):
                    enum_type_name = categories.__name__
                    msg = f"Enum categories must be strings; `{enum_type_name}` values are integers"
                    raise TypeError(msg)

            enum_values = [
                getattr(v, "value", v) for v in categories.__members__.values()
            ]
            categories = pl.Series(values=enum_values)
        elif not isinstance(categories, pl.Series):
            categories = pl.Series(values=categories)

        if categories.is_empty():
            self.categories = pl.Series(name="category", dtype=String)
            return

        if categories.has_nulls():
            msg = "Enum categories must not contain null values"
            raise TypeError(msg)

        if (dtype := categories.dtype) != String:
            msg = f"Enum categories must be strings; found data of type {dtype}"
            raise TypeError(msg)

        if categories.n_unique() != categories.len():
            duplicate = categories.filter(categories.is_duplicated())[0]
            msg = f"Enum categories must be unique; found duplicate {duplicate!r}"
            raise ValueError(msg)

        self.categories = categories.rechunk().alias("category")

    def __eq__(self, other: PolarsDataType) -> bool:  # type: ignore[override]
        # allow comparing object instances to class
        if type(other) is DataTypeClass and issubclass(other, Enum):
            return True
        elif isinstance(other, Enum):
            return self.categories.equals(other.categories)
        else:
            return False

    def __hash__(self) -> int:
        return hash((self.__class__, tuple(self.categories)))

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        return f"{class_name}(categories={self.categories.to_list()!r})"

    if not TYPE_CHECKING:

        def __getattr__(self, name: str) -> Any:
            raise_for_removed_attributes(
                self,
                name,
                {
                    "union": "construct the combined `Enum` explicitly, e.g."
                    " `pl.Enum([*lhs.categories, *rhs.categories])`.",
                },
                version="2.0",
            )
            return getattr_fallback(self, super(), name)


class Object(ObjectType):
    """Data type for wrapping arbitrary Python objects."""


class Null(DataType):
    """Data type representing null values."""


class Unknown(DataType):
    """Type representing DataType values that could not be determined statically."""


class List(NestedType):
    """
    Variable length list type.

    Parameters
    ----------
    inner
        The `DataType` of the values within each list.

    Examples
    --------
    >>> df = pl.DataFrame(
    ...     {
    ...         "integer_lists": [[1, 2], [3, 4]],
    ...         "float_lists": [[1.0, 2.0], [3.0, 4.0]],
    ...     }
    ... )
    >>> df
    shape: (2, 2)
    ┌───────────────┬─────────────┐
    │ integer_lists ┆ float_lists │
    │ ---           ┆ ---         │
    │ list[i64]     ┆ list[f64]   │
    ╞═══════════════╪═════════════╡
    │ [1, 2]        ┆ [1.0, 2.0]  │
    │ [3, 4]        ┆ [3.0, 4.0]  │
    └───────────────┴─────────────┘
    """

    inner: PolarsDataType

    def __init__(self, inner: PolarsDataType | PythonDataType) -> None:
        self.inner = polars.datatypes.parse_into_dtype(inner)

    def __eq__(self, other: PolarsDataType) -> bool:  # type: ignore[override]
        # This equality check allows comparison of type classes and type instances.
        # If a parent type is not specific about its inner type, we infer it as equal:
        # > list[i64] == list[i64] -> True
        # > list[i64] == list[f32] -> False
        # > list[i64] == list      -> True

        # allow comparing object instances to class
        if type(other) is DataTypeClass and issubclass(other, List):
            return True
        elif isinstance(other, List):
            return self.inner == other.inner
        else:
            return False

    def __hash__(self) -> int:
        return hash((self.__class__, self.inner))

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        return f"{class_name}({self.inner!r})"


class Map(NestedType):
    """
    Key-value mapping type.

    Keys are unique within a row and never null. Entry order is preserved and
    participates in equality and hashing.

    Duplicate keys are resolved when a map is built, keeping the first position and the
    last value.

    Parameters
    ----------
    key
        The `DataType` of the keys. Must be row-encodable, so `Object` is not allowed.

        A nested key dtype is accepted by Polars but has no Python representation.
    value
        The `DataType` of the values.

    Examples
    --------
    >>> s = pl.Series("a", [{"x": 1, "y": 2}], dtype=pl.Map(pl.String, pl.Int64))
    >>> s
    shape: (1,)
    Series: 'a' [map[str, i64]]
    [
            {"x": 1, "y": 2}
    ]
    """

    key: PolarsDataType
    value: PolarsDataType

    def __init__(
        self,
        key: PolarsDataType | PythonDataType,
        value: PolarsDataType | PythonDataType,
    ) -> None:
        self.key = polars.datatypes.parse_into_dtype(key)
        self.value = polars.datatypes.parse_into_dtype(value)

    def __eq__(self, other: PolarsDataType) -> bool:  # type: ignore[override]
        # Bare dtype classes act as wildcards throughout the dtype API.
        if type(other) is DataTypeClass and issubclass(other, Map):
            return True
        elif isinstance(other, Map):
            return self.key == other.key and self.value == other.value
        else:
            return False

    def __hash__(self) -> int:
        return hash((self.__class__, self.key, self.value))

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        return f"{class_name}({self.key!r}, {self.value!r})"


class Array(NestedType):
    """
    Fixed length list type.

    Parameters
    ----------
    inner
        The `DataType` of the values within each array.
    shape
        The shape of the arrays.
    width
        The length of the arrays.

        .. versionchanged:: 0.20.31
            The `width` parameter for `Array` has been removed. Use `shape` instead.

    Examples
    --------
    >>> s = pl.Series("a", [[1, 2], [4, 3]], dtype=pl.Array(pl.Int64, 2))
    >>> s
    shape: (2,)
    Series: 'a' [array[i64, 2]]
    [
            [1, 2]
            [4, 3]
    ]
    """

    inner: PolarsDataType
    size: int
    shape: tuple[int, ...]

    @removed_parameters(
        RemovedParameter(
            name="width",
            deprecated_in="0.20.31",
            removed_in="2.0",
            hint="use `shape` instead.",
        )
    )
    def __init__(
        self,
        inner: PolarsDataType | PythonDataType,
        shape: int | tuple[int, ...] | None = None,
    ) -> None:
        if shape is None:
            msg = "Array constructor is missing the required argument `shape`"
            raise TypeError(msg)

        inner_parsed = polars.datatypes.parse_into_dtype(inner)
        inner_shape = inner_parsed.shape if isinstance(inner_parsed, Array) else ()

        if isinstance(shape, int):
            self.inner = inner_parsed
            self.size = shape
            self.shape = (shape,) + inner_shape

        elif isinstance(shape, tuple) and isinstance(shape[0], int):  # type: ignore[redundant-expr]
            if len(shape) > 1:
                inner_parsed = Array(inner_parsed, shape[1:])

            self.inner = inner_parsed
            self.size = shape[0]
            self.shape = shape + inner_shape

        else:
            msg = f"invalid input for shape: {shape!r}"
            raise TypeError(msg)

    def __eq__(self, other: PolarsDataType) -> bool:  # type: ignore[override]
        # This equality check allows comparison of type classes and type instances.
        # If a parent type is not specific about its inner type, we infer it as equal:
        # > array[i64] == array[i64] -> True
        # > array[i64] == array[f32] -> False
        # > array[i64] == array      -> True

        # allow comparing object instances to class
        if type(other) is DataTypeClass and issubclass(other, Array):
            return True
        elif isinstance(other, Array):
            if self.shape != other.shape:
                return False
            else:
                return self.inner == other.inner
        else:
            return False

    def __hash__(self) -> int:
        return hash((self.__class__, self.inner, self.size))

    def __repr__(self) -> str:
        # Get leaf type
        dtype = self.inner
        while isinstance(dtype, Array):
            dtype = dtype.inner

        class_name = self.__class__.__name__
        return f"{class_name}({dtype!r}, shape={self.shape})"

    if not TYPE_CHECKING:

        def __getattr__(self, name: str) -> Any:
            raise_for_removed_attributes(
                self, name, {"width": "use `size` instead."}, version="2.0"
            )
            return getattr_fallback(self, super(), name)


class Field:
    """
    Definition of a single field within a `Struct` DataType.

    Parameters
    ----------
    name
        The name of the field within its parent `Struct`.
    dtype
        The `DataType` of the field's values.
    """

    name: str
    dtype: PolarsDataType

    def __init__(self, name: str, dtype: PolarsDataType) -> None:
        self.name = name
        self.dtype = polars.datatypes.parse_into_dtype(dtype)

    def __eq__(self, other: Field) -> bool:  # type: ignore[override]
        return (self.name == other.name) & (self.dtype == other.dtype)

    def __hash__(self) -> int:
        return hash((self.name, self.dtype))

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        return f"{class_name}({self.name!r}, {self.dtype})"


class Struct(NestedType):
    """
    Struct composite type.

    Parameters
    ----------
    fields
        The fields that make up the struct. Can be either a sequence of Field
        objects or a mapping of column names to data types.

    Examples
    --------
    Initialize using a dictionary:

    >>> dtype = pl.Struct({"a": pl.Int8, "b": pl.List(pl.String)})
    >>> dtype
    Struct({'a': Int8, 'b': List(String)})

    Initialize using a list of Field objects:

    >>> dtype = pl.Struct([pl.Field("a", pl.Int8), pl.Field("b", pl.List(pl.String))])
    >>> dtype
    Struct({'a': Int8, 'b': List(String)})

    When initializing a Series, Polars can infer a struct data type from the data.

    >>> s = pl.Series([{"a": 1, "b": ["x", "y"]}, {"a": 2, "b": ["z"]}])
    >>> s
    shape: (2,)
    Series: '' [struct[2]]
    [
            {1,["x", "y"]}
            {2,["z"]}
    ]
    >>> s.dtype
    Struct({'a': Int64, 'b': List(String)})
    """

    fields: list[Field]

    def __init__(self, fields: Sequence[Field] | SchemaDict) -> None:
        if isinstance(fields, Mapping):
            self.fields = [Field(name, dtype) for name, dtype in fields.items()]
        else:
            self.fields = list(fields)

    def __eq__(self, other: PolarsDataType) -> bool:  # type: ignore[override]
        # The comparison allows comparing objects to classes, and specific
        # inner types to those without (eg: inner=None). if one of the
        # arguments is not specific about its inner type we infer it
        # as being equal. (See the List type for more info).
        if isclass(other) and issubclass(other, Struct):
            return True
        elif isinstance(other, Struct):
            return self.fields == other.fields
        else:
            return False

    def __hash__(self) -> int:
        return hash((self.__class__, tuple(self.fields)))

    def __iter__(self) -> Iterator[tuple[str, PolarsDataType]]:
        for fld in self.fields:
            yield fld.name, fld.dtype

    def __reversed__(self) -> Iterator[tuple[str, PolarsDataType]]:
        for fld in reversed(self.fields):
            yield fld.name, fld.dtype

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        return f"{class_name}({dict(self)})"

    def to_schema(self) -> OrderedDict[str, PolarsDataType]:
        """Return Struct dtype as a schema dict."""
        return OrderedDict(self)


class BaseExtension(DataType):
    """
    Base class for extension data types.

    .. warning::
        This functionality is considered **unstable**. It may be changed at any
        point without it being considered a breaking change.

    See Also
    --------
    Extension
    polars.register_extension_type
    """

    def __init__(
        self, name: str, storage: PolarsDataType, metadata: str | None = None
    ) -> None:
        self._name = name
        self._storage = storage
        self._metadata = metadata

    @classmethod
    def ext_from_params(
        cls, name: str, storage: PolarsDataType, metadata: str | None
    ) -> Any:
        """Creates an Extension type instance from its parameters."""
        slf = cls.__new__(cls)
        slf._name = name
        slf._storage = storage
        slf._metadata = metadata
        return slf

    def ext_name(self) -> str:
        """Returns the name of this extension type."""
        return self._name

    def ext_storage(self) -> PolarsDataType:
        """Returns the storage type for this extension type."""
        return self._storage

    def ext_metadata(self) -> str | None:
        """Returns the metadata for this extension type."""
        return self._metadata

    def _string_repr(self) -> str:
        """
        Return a short string representation of the extension type.

        This should be lowercase and if feasible show parameters in brackets,
        for example i64, str, datetime[ns], etc. This is used when displaying
        dataframes in a human-readable format, so brevity is important.

        This function starts with an underscore for historical reasons; it is
        intended to be overridden by subclasses.
        """
        s = self.ext_name().lower()
        if len(s) <= 12:
            return s
        else:
            return s[:10] + ".."

    def __repr__(self) -> str:
        md = self.ext_metadata()
        if md is not None:
            return f"{self.__class__.__name__}({self.ext_name()!r}, {self.ext_storage()!r}, {md!r})"
        else:
            return f"{self.__class__.__name__}({self.ext_name()!r}, {self.ext_storage()!r})"

    # It's not recommended to override the below methods.
    def __hash__(self) -> int:
        return hash((self.ext_name(), self.ext_storage(), self.ext_metadata()))

    @overload  # type: ignore[override]
    def __eq__(self, other: pl.DataTypeExpr) -> pl.Expr: ...

    @overload
    def __eq__(self, other: PolarsDataType) -> bool: ...

    def __eq__(self, other: pl.DataTypeExpr | PolarsDataType) -> pl.Expr | bool:
        if isinstance(other, pl.DataTypeExpr):
            return self.to_dtype_expr() == other
        else:
            return (
                isinstance(other, BaseExtension)
                and self.ext_name() == other.ext_name()
                and self.ext_storage() == other.ext_storage()
                and self.ext_metadata() == other.ext_metadata()
            )

    def __getstate__(self) -> tuple[str, PolarsDataType, str | None]:
        return self.ext_name(), self.ext_storage(), self.ext_metadata()

    def __setstate__(self, state: tuple[str, PolarsDataType, str | None]) -> None:
        self.__dict__ = type(self).ext_from_params(*state).__dict__


class Extension(BaseExtension):
    """
    Generic extension data type.

    When `UNKNOWN_EXTENSION_TYPE_BEHAVIOR` is set to `"load_as_extension"`, any
    non-registered extension type will be loaded as this type.

    .. warning::
        This functionality is considered **unstable**. It may be changed at any
        point without it being considered a breaking change.

    See Also
    --------
    BaseExtension
    polars.register_extension_type
    """
