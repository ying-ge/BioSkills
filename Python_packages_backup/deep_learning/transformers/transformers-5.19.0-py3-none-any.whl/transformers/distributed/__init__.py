# Copyright 2025 The HuggingFace Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import TYPE_CHECKING

from ..utils import _LazyModule


_import_structure = {
    "configuration_utils": ["DistributedConfig"],
    "fsdp": ["is_fsdp_enabled", "is_fsdp_managed_module", "verify_fsdp_plan"],
    "mixin": ["DistributedMixin"],
    "utils": [
        "gather_full_state_dict",
        "initialize_distributed_mesh",
        "initialize_fully_sharded_data_parallelism",
        "load_optimizer_distributed",
        "save_model_checkpoint_distributed",
        "save_optimizer_distributed",
    ],
}


if TYPE_CHECKING:
    from .configuration_utils import (
        DistributedConfig,
    )
    from .fsdp import is_fsdp_enabled, is_fsdp_managed_module, verify_fsdp_plan
    from .mixin import DistributedMixin
    from .utils import (
        gather_full_state_dict,
        initialize_distributed_mesh,
        initialize_fully_sharded_data_parallelism,
        load_optimizer_distributed,
        save_model_checkpoint_distributed,
        save_optimizer_distributed,
    )

else:
    import sys

    sys.modules[__name__] = _LazyModule(__name__, globals()["__file__"], _import_structure, module_spec=__spec__)
