%module graphviz

%begin %{
#define SWIG_PYTHON_STRICT_BYTE_CHAR
%}

%{
#include "graphviz/cgraph.h"
#include "graphviz/gvc.h"
#include <stdlib.h>
#include <string.h>
%}

#define GRAPHVIZ_MAJOR_VERSION GRAPHVIZ_VERSION_MAJOR
#define GRAPHVIZ_MINOR_VERSION GRAPHVIZ_VERSION_MINOR
#define GRAPHVIZ_PATCH_VERSION GRAPHVIZ_VERSION_PATCH

%typemap(in) FILE* input_file (int fd, PyObject *mode_obj, PyObject *mode_byte_obj, char *mode) {
    if ($input == Py_None) { $1 = NULL; }
    else {
        // work around to get hold of FILE*
        fd = PyObject_AsFileDescriptor($input);

        mode_obj = PyObject_GetAttrString($input, "mode");
        mode_byte_obj = PyUnicode_AsUTF8String(mode_obj);

        mode = PyBytes_AsString(mode_byte_obj);
        $1 = fdopen(dup(fd), mode);
        Py_XDECREF(mode_obj);
        Py_XDECREF(mode_byte_obj);
    }
}

%typemap(in) FILE* output_file (int fd, PyObject *mode_obj, PyObject *mode_byte_obj, char *mode) {
    if ($input == Py_None) { $1 = NULL; }
    else {
        // work around to get hold of FILE*
        fd = PyObject_AsFileDescriptor($input);

        mode_obj = PyObject_GetAttrString($input, "mode");
        mode_byte_obj = PyUnicode_AsUTF8String(mode_obj);

        mode = PyBytes_AsString(mode_byte_obj);
        $1 = fdopen(dup(fd), mode);
        Py_XDECREF(mode_obj);
        Py_XDECREF(mode_byte_obj);
    }
}

%typemap(freearg) FILE* input_file {
    fclose($1);
}

%typemap(freearg) FILE* output_file {
    if ($1) fclose($1);
}


%exception agnode {
  $action
  if (!result) {
     PyErr_SetString(PyExc_KeyError,"agnode: no key");
     return NULL;
  }
}

%exception agedge {
  $action
  if (!result) {
     PyErr_SetString(PyExc_KeyError,"agedge: no key");
     return NULL;
  }
}

/* agset returns -1 on error */
%exception agset {
  $action
  if (result==-1) {
     PyErr_SetString(PyExc_KeyError,"agset: no key");
     return NULL;
  }
}

/* agsetsafeset_label returns -1 on error */
%exception agsafeset_label {
  $action
  if (result==-1) {
     PyErr_SetString(PyExc_KeyError,"agsafeset_label: Error");
     return NULL;
  }
}


/* agdelnode returns -1 on error */
%exception agdelnode {
  $action
  if (result==-1) {
     PyErr_SetString(PyExc_KeyError,"agdelnode: no key");
     return NULL;
  }
}

%exception agnxtattr {
  $action
  if (!result) {
     PyErr_SetString(PyExc_StopIteration,"agnxtattr");
     return NULL;
  }
}

%exception agattr {
  $action
  if (!result) {
     PyErr_SetString(PyExc_KeyError,"agattr: no key");
     return NULL;
  }
}


%exception agattr_label {
  $action
  if (!result) {
     PyErr_SetString(PyExc_KeyError,"agattr_label: no key");
     return NULL;
  }
}

%exception agread {
  $action
  if (!result) {
     PyErr_SetString(PyExc_ValueError,"agread: bad input data");
     return NULL;
  }
}


/* graphs */
Agraph_t *agopen(char *name, Agdesc_t kind, Agdisc_t *disc);

/* some helpers to avoid using cvar in python modules */
%pythoncode %{
def agraphnew(name,strict=False,directed=False):
    if strict:
       if directed:
            return _graphviz.agopen(name,cvar.Agstrictdirected,None)
       else:
            return _graphviz.agopen(name,cvar.Agstrictundirected,None)
    else:
        if directed:
            return _graphviz.agopen(name,cvar.Agdirected,None)
        else:
            return _graphviz.agopen(name,cvar.Agundirected,None)
%}

int       agclose(Agraph_t *g);
Agraph_t *agread(FILE *input_file, Agdisc_t *);
int       agwrite(Agraph_t *g, FILE *output_file);
int	  agisundirected(Agraph_t * g);
int       agisdirected(Agraph_t * g);
int       agisstrict(Agraph_t * g);
/* void      agclean(Agraph_t *g, int kind, int *rec)   */
/* Agraph_t        *agconcat(Agraph_t *g, FILE *file, Agdisc_t *disc); */


/* nodes */
Agnode_t *agnode(Agraph_t *g, char *name, int createflag);
Agnode_t *agidnode(Agraph_t * g, IDTYPE id, int createflag);
Agnode_t *agsubnode(Agraph_t *g, Agnode_t *n, int createflag);
Agnode_t *agfstnode(Agraph_t *g);
Agnode_t *agnxtnode(Agraph_t *g, Agnode_t *n);
Agnode_t *aglstnode(Agraph_t * g);
Agnode_t *agprvnode(Agraph_t * g, Agnode_t * n);
/* Agsubnode_t *agsubrep(Agraph_t * g, Agnode_t * n); */

/* edges */

Agedge_t *agedge(Agraph_t * g, Agnode_t * t, Agnode_t * h,
 		char *name, int createflag);
Agedge_t *agidedge(Agraph_t * g, Agnode_t * t, Agnode_t * h,
 		  IDTYPE id, int createflag);
Agedge_t *agsubedge(Agraph_t * g, Agedge_t * e, int createflag);
Agedge_t *agfstin(Agraph_t * g, Agnode_t * n);
Agedge_t *agnxtin(Agraph_t * g, Agedge_t * e);
Agedge_t *agfstout(Agraph_t * g, Agnode_t * n);
Agedge_t *agnxtout(Agraph_t * g, Agedge_t * e);
Agedge_t *agfstedge(Agraph_t * g, Agnode_t * n);
Agedge_t *agnxtedge(Agraph_t * g, Agedge_t * e, Agnode_t * n);


Agnode_t *aghead(Agedge_t *e);
Agnode_t *agtail(Agedge_t *e);

/* attributes */
Agsym_t *agattr(Agraph_t *g, int kind, char *name, char *value);
Agsym_t *agattrsym(void *obj, char *name);
Agsym_t *agnxtattr(Agraph_t *g, int kind, Agsym_t *attr);
char    *agget(void *obj, char *name);
char    *agxget(void *obj, Agsym_t *sym);
int      agset(void *obj, char *name, char *value);
int      agxset(void *obj, Agsym_t *sym, char *value);
int      agsafeset(void *obj, char *name, char *value, char *def);

%inline %{
  char *agattrname(Agsym_t *atsym) {
    return atsym->name;
  }
  %}

%inline %{
  char *agattrdefval(Agsym_t *atsym) {
    return atsym->defval;
  }
  %}

%{
  /** create a string as an internally cached HTML-like string, if necessary
   *
   * @param g Graph with which to associated new strings
   * @param name Name of an attribute being created
   * @param val Value of the attribute being created
   * @return The equivalent of `val`, as a plain string or HTML-like string, as relevant
   */
  static char *htmlize(Agraph_t *g, const char *name, char *val) {
    size_t len;
    char *hs;

    if (val[0] == '<' && (strcmp(name, "label") == 0 || strcmp(name, "xlabel") == 0)) {
      len = strlen(val);
      if (val[len - 1] == '>') {
        hs = malloc(len - 1);
        memcpy(hs, val + 1, len - 2);
        *(hs+len-2) = '\0';
        val = agstrdup_html(g,hs);
        free(hs);
      }
    }

    return val;
  }
%}

/* styled from gv.cpp in Graphviz to handle <> html data in label */
%inline %{
  int agsafeset_label(Agraph_t *g, void *obj, char *name, char *val, char *def)
{
    val = htmlize(g, name, val);
    return agsafeset(obj, name, val,def);
}
  %}




/* styled from gv.cpp in Graphviz to handle <> html data in label */
%inline %{
  Agsym_t *agattr_label(Agraph_t *g, int kind, char *name, char *val)
{
    val = htmlize(g, name, val);
    return agattr(g, kind, name, val);
}
  %}




/* subgraphs */
Agraph_t *agsubg(Agraph_t *g, char *name, int createflag);
Agraph_t *agfstsubg(Agraph_t *g);
Agraph_t *agnxtsubg(Agraph_t *subg);
Agraph_t *agparent(Agraph_t *g);
Agraph_t *agroot(Agraph_t *g);
/* Agedge_t *agsubedge(Agraph_t *g, Agedge_t *e, int createflag); */
long      agdelsubg(Agraph_t *g, Agraph_t *sub);


/* cardinality */
int agnnodes(Agraph_t * g);
int agnedges(Agraph_t * g);
int agdegree(Agraph_t * g, Agnode_t * n, int in, int out);

/* generic */
Agraph_t  *agraphof(void*);
char      *agnameof(void*);

int agdelnode(Agraph_t * g, Agnode_t * arg_n);
int agdeledge(Agraph_t * g, Agedge_t * arg_e);

/* This pretty code finds anonymous items (start with %) or
   items with no label and returns None.
   Useful for anonymous edges .
*/
%pythoncode %{
def agnameof(handle):
  name=_graphviz.agnameof(handle)
  if name is None:
     return None
  if name==b'' or name.startswith(b'%'):
    return None
  else:
    return name
%}




/* Agdesc_t Agdirected, Agstrictdirected, Agundirected, Agstrictundirected;  */
/* constants are safer */
/* directed, strict, noloops, maingraph */
const Agdesc_t Agdirected = { 1, 0, 0, 1 };
const Agdesc_t Agstrictdirected = { 1, 1, 0, 1 };
const Agdesc_t Agundirected = { 0, 0, 0, 1 };
const Agdesc_t Agstrictundirected = { 0, 1, 0, 1 };


#define AGRAPH      0               /* can't exceed 2 bits. see Agtag_t. */
#define AGNODE      1
#define AGOUTEDGE   2
#define AGINEDGE    3               /* (1 << 1) indicates an edge tag.   */
#define AGEDGE      AGOUTEDGE       /* synonym in object kind args */



/**************** GVC ******************/
/* Could do the whole gvc.h file here. */
/* But gvParseArgs code is "a mess" (their comment in source code) */
/* It uses global variables to set default attributes */
/* It doesn't update current nodes with these defaults yet it sets */
/* any future nodes to these defaults even if in a different graph */
/* and a different gvContext. */
/* The result is that you can set a default for one graph and it doesnt */
/* do anything to that graph, but then all future graphs have that default */
//
/* This code only uses a small portion of the libgvc functions. */
/* The focus is on layout and render operations. */

/*  set up a graphviz context - and init graph - retaining old API */
GVC_t *gvContext(void);
int gvFreeContext(GVC_t *gvc);

/* Compute a layout using a specified engine */
int gvLayout(GVC_t *gvc, Agraph_t *g, char* prog);
int gvFreeLayout(GVC_t *gvc, Agraph_t *g);

/* Render layout in a specified format to an open FILE */
int gvRender(GVC_t *gvc, Agraph_t* g, char *format, FILE *output_file=NULL);
int gvRenderFilename(GVC_t *gvc, Agraph_t* g, char *format, char *filename);

/* Render layout in a specified format to an external context */
/*-------------------------------------------------------------*/
/* Writing a dot file to a string involves some pointer crazy stuff */
/* (the input strings are changed by the function... this magic makes */
/* python return the strings instead of changing the input. The next */
/* three lines are straight from the SWIG manual.  */
%include <cstring.i>
%include <typemaps.i>
#if GRAPHVIZ_VERSION_MAJOR >= 14
%cstring_output_allocate_size(char **result, size_t* size, free(*$1));
int gvRenderData(GVC_t *gvc, Agraph_t* g, char *format, char **result, size_t *size);
#else
%cstring_output_allocate_size(char **result, unsigned int* size, free(*$1));
int gvRenderData(GVC_t *gvc, Agraph_t* g, char *format, char **result, unsigned int *size);
#endif
/* Free memory allocated and pointed to by *result in gvRenderData */
extern void gvFreeRenderData (char* data);

/* --- Wheel-compatible context with builtin plugins ---                */
/* Wheels build graphviz with demand-loading (ltdl/config6) disabled,    */
/* so plugins must be registered as builtins -- see                      */
/* gvContextWithBuiltins() below.                                        */
%{
#include "graphviz/gvplugin.h"

/* Layout engines + core text-format output: builtin on every platform. */
#ifdef _WIN32
extern __declspec(dllimport) gvplugin_library_t gvplugin_dot_layout_LTX_library;
extern __declspec(dllimport) gvplugin_library_t gvplugin_neato_layout_LTX_library;
extern __declspec(dllimport) gvplugin_library_t gvplugin_core_LTX_library;
#else
extern gvplugin_library_t gvplugin_dot_layout_LTX_library;
extern gvplugin_library_t gvplugin_neato_layout_LTX_library;
extern gvplugin_library_t gvplugin_core_LTX_library;
#endif

/* Raster output plugin, per platform:                                       */
/*   macOS         -> Quartz (native CoreText/CoreGraphics); supersedes gd,    */
/*                    which isn't built there (--with-libgd=no).               */
/*   Windows/Linux -> pango/cairo (graphviz's default png renderer; centers    */
/*                    text correctly) PLUS gd for the gif/jpg that cairo/pango  */
/*                    can't emit. pango finds system fonts via fontconfig.      */
#ifdef __APPLE__
extern gvplugin_library_t gvplugin_quartz_LTX_library;
#elif defined(_WIN32)
extern __declspec(dllimport) gvplugin_library_t gvplugin_gd_LTX_library;
extern __declspec(dllimport) gvplugin_library_t gvplugin_pango_LTX_library;
#else
extern gvplugin_library_t gvplugin_gd_LTX_library;
extern gvplugin_library_t gvplugin_pango_LTX_library;
#endif
%}

%inline %{
/* Build the context from a fixed builtin-plugin list, like graphviz's own `dot`
   for ENABLE_LTDL=off builds (dot_builtins.cpp). gvContextPlugins() registers
   the plugins AND binds the default engine per API; gvContext()+gvAddLibrary()
   skip the latter, leaving pango's textlayout unbound so text vanishes with
   "PANGO_IS_LAYOUT" warnings. It is the only exported API for this -- the
   gvconfig() it calls internally is not exported from the Windows gvc.dll. */
GVC_t *gvContextWithBuiltins(void) {
    /* static: gvContextPlugins keeps this pointer (no copy), so it must outlive
       the context. Addresses are set at runtime because MSVC rejects the address
       of a __declspec(dllimport) symbol in a static initializer (C2099) -- same
       approach as graphviz's gvpack. */
    static lt_symlist_t builtins[] = {
        { "gvplugin_core_LTX_library", 0 },
        { "gvplugin_dot_layout_LTX_library", 0 },
        { "gvplugin_neato_layout_LTX_library", 0 },
#if defined(__APPLE__)
        { "gvplugin_quartz_LTX_library", 0 },
#else
        /* Windows + Linux: gd (gif/jpg/legacy) + pango/cairo (centered text). */
        { "gvplugin_gd_LTX_library", 0 },
        { "gvplugin_pango_LTX_library", 0 },
#endif
        { 0, 0 }
    };
    builtins[0].address = &gvplugin_core_LTX_library;
    builtins[1].address = &gvplugin_dot_layout_LTX_library;
    builtins[2].address = &gvplugin_neato_layout_LTX_library;
#if defined(__APPLE__)
    builtins[3].address = &gvplugin_quartz_LTX_library;
#else
    builtins[3].address = &gvplugin_gd_LTX_library;
    builtins[4].address = &gvplugin_pango_LTX_library;
#endif
    return gvContextPlugins(builtins, 0);
}
%}
