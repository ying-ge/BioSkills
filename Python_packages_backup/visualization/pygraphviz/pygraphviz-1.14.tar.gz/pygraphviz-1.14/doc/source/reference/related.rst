Related Packages
----------------

   - Python bindings distributed with Graphviz (graphviz-python):  http://www.graphviz.org/

   - pydot: http://code.google.com/p/pydot/

   - mfGraph: http://www.geocities.com/foetsch/mfgraph/index.htm

   - Yapgvb: http://yapgvb.sourceforge.net/
