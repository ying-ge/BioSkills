import type { Rect, TypedArrayConstructor } from "../types";
import { Indices } from "../types";
export declare class SpatialIndex {
    private readonly factor_bbox;
    private readonly shift_factor_bbox;
    private n_items;
    private node_size;
    private array_type_coordinates;
    private array_type_indices;
    private _tree_level_bounds;
    private _n_total_nodes;
    private _coordinate_index_position;
    private minX;
    private minY;
    private maxX;
    private maxY;
    private _data_byte_buffer;
    private _bboxes;
    private _indices;
    constructor(n_items: number, node_size?: number, array_type_coordinates?: TypedArrayConstructor);
    _init_tree_structure(): void;
    _configure_data_buffer(): void;
    add_rect(x0: number, y0: number, x1: number, y1: number): void;
    add_point(x: number, y: number): void;
    add_empty(): void;
    build_index(): void;
    finish(): void;
    get bbox(): Rect;
    indices(rect: Rect): Indices;
    bounds(rect: Rect): Rect;
    private _search;
    private _search_recursive;
    protected _normalize(rect: Rect): Rect;
    private _addAllLeavesOfNode;
    private static _upperBound;
    private _optimize_item_order;
    /** Computes the Hilbert key of every item and writes the sorted item order into _indices. */
    private _sort_by_hilbert_values;
    private _apply_item_order;
    private _generate_internal_tree_nodes;
}
//# sourceMappingURL=spatial.d.ts.map