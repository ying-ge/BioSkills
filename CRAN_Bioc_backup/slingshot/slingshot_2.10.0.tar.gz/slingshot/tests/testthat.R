library(testthat)
library(slingshot)

test_check("slingshot")
