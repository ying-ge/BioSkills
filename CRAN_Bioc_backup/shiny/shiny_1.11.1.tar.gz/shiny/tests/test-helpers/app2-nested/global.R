stop("global.R should never be sourced alongside app.R")
