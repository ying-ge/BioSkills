[![R build status](https://github.com/bhklab/PharmacoGx/workflows/R-CMD-check-bioc-devel/badge.svg)](https://github.com/bhklab/PharmacoGx/actions)

**Bioc-Release**: ![Bioconductor RELEASE](http://bioconductor.org/shields/build/release/bioc/PharmacoGx.svg) 
**Bioc-Devel**: ![Bioconductor DEVEL](http://bioconductor.org/shields/build/devel/bioc/PharmacoGx.svg)

PharmacoGx
==========

R package to analyze large-scale pharmacogenomic datasets.


Dependencies:

All dependencies are available from CRAN or Bioconductor.
