# ==== PharmacoSet Class

## TODO:: Can we implement intersect method for PSets?

# ==== LongTable Class

## TODO:: Implement intersection of LongTable objects