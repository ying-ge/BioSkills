library(testthat)
library(TCGAbiolinks)

test_check("TCGAbiolinks")
