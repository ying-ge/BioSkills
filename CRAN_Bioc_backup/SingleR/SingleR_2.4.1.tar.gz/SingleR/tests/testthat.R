library(testthat)
library(SingleR)
test_check("SingleR")
