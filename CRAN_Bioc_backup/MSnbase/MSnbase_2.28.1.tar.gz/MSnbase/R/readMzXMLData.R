readMzXMLData <- function(files,
                          pdata = NULL,
                          msLevel = 2,
                          verbose = isMSnbaseVerbose(),
                          centroided = FALSE,
                          smoothed = FALSE,
                          removePeaks = 0,
                          clean = FALSE,
                          cache = 1) {

  .Defunct(new = "readMSData")
}
