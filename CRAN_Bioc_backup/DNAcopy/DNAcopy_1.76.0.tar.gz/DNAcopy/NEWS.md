# DNAcopy 1.75.5 (10/08/2023)

* Fixed the bug in passing weights for weighted segmentation

# DNAcopy 1.75.4 (07/05/2023)

* Updated the reference and source for Coriell data

# DNAcopy 1.75.3 (06/29/2023)

* Added init.c to register native (Fortran) routines and to disable symbol search
* Gzipped cytoBand.tab and converted default.DNAcopy.bdry to rda file in data directory

# DNAcopy 1.75.2 (06/27/2023)

* Added a `NEWS.md` file to track changes to the package.
* changed all dfloat in fortran to dble (Ripley email for CRAN/clinfun)
