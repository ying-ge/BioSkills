# #' Deprecated data/functions
# #'
# #' These data/functions are Deprecated in this release of ggpattern,
# #' they will be marked as Defunct and removed in a future version.
# #'
# #' @name ggpattern-deprecated
# NULL
