library(testthat)
library(nucleoSim)

## Run all unit tests
test_check("nucleoSim")
