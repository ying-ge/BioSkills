library(testthat)
library(clusterProfiler)

test_check("clusterProfiler")
