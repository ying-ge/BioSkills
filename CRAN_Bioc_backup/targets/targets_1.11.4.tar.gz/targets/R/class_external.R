#' @export
store_row_path.tar_external <- function(store, file) {
  file$path
}

#' @export
store_path_from_name.tar_external <- function(
  store,
  format,
  name,
  path,
  path_store
) {
  path
}

#' @export
store_cache_path.tar_external <- function(store, path) {}
