library(targets)
list(tar_target(x, stop("intentional error")))
