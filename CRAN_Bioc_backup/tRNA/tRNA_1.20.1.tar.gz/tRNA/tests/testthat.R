library(testthat)
library(tRNA)

test_check("tRNA")
