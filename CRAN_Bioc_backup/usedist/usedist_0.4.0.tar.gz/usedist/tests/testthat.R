library(testthat)
library(usedist)

test_check("usedist")
