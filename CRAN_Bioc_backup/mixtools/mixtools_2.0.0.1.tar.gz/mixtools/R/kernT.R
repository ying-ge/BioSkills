kern.T <- function (x, xi, h)
{
    (1-abs((xi-x)/h))/h
}
