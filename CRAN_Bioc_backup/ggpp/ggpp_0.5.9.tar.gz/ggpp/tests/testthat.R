library(testthat)
library(ggpp)

# keep error messages as ASCII
options(cli.condition_unicode_bullets = FALSE)

test_check("ggpp")
