library(testthat)
library(flowWorkspace)

test_check("flowWorkspace")

# test_file("/home/wjiang2/rglab/workspace/flowWorkspace/tests/testthat/test-main.R")
#Sys.setenv(test_gs_compatibility="yes")
#Sys.getenv("test_gs_compatibility")
#test_file("/home/rstudio/opensource/workspace/flowWorkspace/tests/testthat/gs-archive.R")
# test_file("/home/wjiang2/rglab/workspace/flowWorkspace/tests/testthat/GatingHierarchy-testSuite.R")


