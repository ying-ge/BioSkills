#### functions ####
#### methods #####
## coxVariableName.R
## coxBaseEstimator.R
## coxCenter.R
## coxFormula
## coxLP
## coxN
## coxSpecialStrata
## coxStrataLevel
## coxStrata
## coxVarCov
## SurvResponseVar
## splitStrataVar
## * model.matrix
## terms.phreg


