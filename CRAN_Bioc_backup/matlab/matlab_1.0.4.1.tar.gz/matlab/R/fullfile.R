###
### $Id: fullfile.R 29 2022-05-30 23:02:22Z proebuck $
###
### Build full filename from parts.
###


##-----------------------------------------------------------------------------
fullfile <- function(...) {
    file.path(...)
}

