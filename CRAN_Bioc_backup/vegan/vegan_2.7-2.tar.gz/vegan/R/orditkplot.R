###
### Editable Tcl/Tk plot for ordination
###
`orditkplot` <-
    function(...)
{
    .Defunct(package = "vegan",
            msg = "orditkplot was moved to CRAN package vegan3d --
install vegan3d from CRAN and use vegan3d::orditkplot")
}
