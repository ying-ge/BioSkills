/* definitions for backtrack in nestedness.c */
#ifndef BACKSTEP
#define BACKSTEP (4)
#endif /* BACKSTEP depth */
#ifndef RESET
#define RESET 1
#endif /* RESET */
#ifndef LOUD
#define LOUD 0
#endif /* LOUD */
