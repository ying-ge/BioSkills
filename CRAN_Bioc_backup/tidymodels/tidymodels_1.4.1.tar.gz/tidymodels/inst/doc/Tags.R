## -----------------------------------------------------------------------------
knitr::opts_chunk$set(
  message = FALSE,
  digits = 3,
  collapse = TRUE,
  comment = "#>"
  )
options(digits = 3)
library(tidymodels)

## -----------------------------------------------------------------------------
library(tidymodels)
tag_show()

