library(testthat)
library(EpiDISH)

test_check("EpiDISH")
