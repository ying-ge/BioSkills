#pragma once
#include <glmnetpp_bits/util/types.hpp>

namespace glmnetpp {

template <util::glm_type glm>
struct ElnetDriver;

} // namespace glmnetpp
