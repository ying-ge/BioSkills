# contrasts = list(list("a", "b"),
#                  list("a", "c"),
#                  list("a", c("b", "c")))
# conditions = c("a", "b", "c")
# labels = c("a vs b", "a vs c", "a vs b,c")
# 
# MSstatsContrastMatrix(contrasts, conditions, labels)
# MSstatsContrastMatrix(contrasts, conditions, NULL)
