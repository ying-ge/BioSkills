print.gml <-
function (x, ...) 
{
    x = x["net"]
    NextMethod()
}
