print.reduced <-
function (x, ...) 
{
    x = x["reduc"]
    NextMethod()
}
