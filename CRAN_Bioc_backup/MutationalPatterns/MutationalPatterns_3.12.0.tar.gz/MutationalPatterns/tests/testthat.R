library(testthat)
library(MutationalPatterns)

test_check("MutationalPatterns")
