#ifndef THREESTEP_SUMMARY_METHODS_PARAM_H
#define THREESTEP_SUMMARY_METHODS_PARAM_H 



typedef struct{
  int psi_method;
  double psi_k;
} summary_plist;

#endif
