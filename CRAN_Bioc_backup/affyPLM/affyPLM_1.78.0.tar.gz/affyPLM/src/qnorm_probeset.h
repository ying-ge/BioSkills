#ifndef QNORM_PROBESET_H
#define  QNORM_PROBESET_H

void qnorm_probeset_c(double *data, int rows, int cols,int n_probesets, const char **ProbeNames, int usemedian,int uselog);

#endif
