#ifndef DO_PLMRLM_H
#define DO_PLMRLM_H 1

#include "common_types.h"


void do_PLMrlm(Datagroup *data,PLMmodelparam *model, PLMoutput *output, outputsettings *store);
void do_PLM_rlm(PLM_Datagroup *data,  PLM_model_parameters *model, PLM_output *output, PLM_outputsettings *store);

#endif
