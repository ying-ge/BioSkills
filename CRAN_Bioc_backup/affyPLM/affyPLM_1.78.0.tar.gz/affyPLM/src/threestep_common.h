#ifndef THREESTEP_COMMON_H
#define THREESTEP_COMMON_H 1

double median(double *x, int length);
double median_low(double *x, int length);

#endif
