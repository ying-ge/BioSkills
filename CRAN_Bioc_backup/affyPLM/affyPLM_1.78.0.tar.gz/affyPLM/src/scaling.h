#ifndef SCALING_H
#define SCALING_H 1

void scaling_norm(double *data, int rows, int cols,double trim, int baseline, int logscale);


#endif
