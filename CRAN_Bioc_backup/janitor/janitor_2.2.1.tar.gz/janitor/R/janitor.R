#' janitor
#'
#' janitor has simple little tools for examining and cleaning dirty data.
#'
#' @section Main functions:
#' The main janitor functions can: perfectly format ugly \code{data.frame} column names; isolate
#' duplicate records for further study; and provide quick one- and two-variable tabulations
#' (i.e., frequency tables and crosstabs) that improve on the base R function \code{table()}.
#'
#'
#' Other functions in the package can format for reporting the results of these tabulations.
#' These tabulate-and-report functions approximate popular features of SPSS and Microsoft Excel.
#'
#' @section Package context:
#' This package follows the principles of the "tidyverse" and in particular works well with
#' the \code{\%>\%} pipe function.
#'
#'
#' janitor was built with beginning-to-intermediate R users in mind
#' and is optimized for user-friendliness.  Advanced users can already do everything
#' covered here, but they can do it faster with janitor and save their thinking for
#' more fun tasks.
#'
#' @docType package
#' @name janitor
#' @keywords internal
NULL
## quiets concerns of R CMD check re: the .'s that appear in pipelines
## and the "n" that is produced by dplyr::count() in a pipeline
if (getRversion() >= "2.15.1") utils::globalVariables(c(".", "n"))
