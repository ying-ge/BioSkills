library(testthat)
library(microbiomeMarker)

test_check("microbiomeMarker")
