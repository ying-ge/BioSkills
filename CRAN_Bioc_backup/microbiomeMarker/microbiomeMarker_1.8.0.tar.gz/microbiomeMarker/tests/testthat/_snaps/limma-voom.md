# limma voom

    Code
      print(marker_table(mm_lv), digits = 5)
    Output
                                        feature enrich_group ef_logFC     pvalue
      marker1    p__Bacteroidetes|g__Prevotella Enterotype.2   5.8537 1.0514e-12
      marker2 p__Verrucomicrobia|g__Akkermansia Enterotype.3  -8.6516 3.1047e-04
      marker3                p__Verrucomicrobia Enterotype.3  -8.3000 5.4262e-04
                    padj
      marker1 2.5023e-10
      marker2 3.6946e-02
      marker3 4.3048e-02

