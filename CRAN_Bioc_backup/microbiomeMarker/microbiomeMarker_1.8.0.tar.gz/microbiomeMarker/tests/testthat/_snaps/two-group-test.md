# test two group result

    Code
      mm_welch
    Output
      microbiomeMarker-class inherited from phyloseq-class
      normalization method:              [ TSS ]
      microbiome marker identity method: [ welch.test ]
      marker_table() Marker Table:       [ 3 microbiome markers with 5 variables ]
      otu_table()    OTU Table:          [ 244 taxa and  39 samples ]
      sample_data()  Sample Data:        [ 39 samples by  9 sample variables ]
      tax_table()    Taxonomy Table:     [ 244 taxa by 1 taxonomic ranks ]

---

    Code
      mm_t
    Output
      microbiomeMarker-class inherited from phyloseq-class
      normalization method:              [ TSS ]
      microbiome marker identity method: [ t.test ]
      marker_table() Marker Table:       [ 2 microbiome markers with 5 variables ]
      otu_table()    OTU Table:          [ 244 taxa and  39 samples ]
      sample_data()  Sample Data:        [ 39 samples by  9 sample variables ]
      tax_table()    Taxonomy Table:     [ 244 taxa by 1 taxonomic ranks ]

