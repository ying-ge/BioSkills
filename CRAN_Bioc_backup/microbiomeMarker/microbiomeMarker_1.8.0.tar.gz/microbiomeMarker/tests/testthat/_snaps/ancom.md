# ancom result

    Code
      print(head(curr_marker), digits = 5)
    Output
                            feature enrich_group ef_CLR_diff_mean  W
      marker1                    __     Cesarean         0.076290  1
      marker2     c__Actinobacteria     Cesarean         0.310201 10
      marker3     c__Coriobacteriia      Vaginal         0.110342  4
      marker4        c__Bacteroidia      Vaginal         0.120525  6
      marker5      c__Fusobacteriia     Cesarean         0.083236  1
      marker6 c__Betaproteobacteria     Cesarean         0.188186  3

