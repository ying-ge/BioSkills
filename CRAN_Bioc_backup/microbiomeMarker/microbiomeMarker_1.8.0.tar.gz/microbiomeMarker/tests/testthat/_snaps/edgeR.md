# result of edger

    Code
      print(marker_table(mm_edger), digits = 5)
    Output
                                                                                                                                                        feature
      marker1                                                                                              k__Bacteria|p__Proteobacteria|c__Gammaproteobacteria
      marker2                                                                         k__Bacteria|p__Proteobacteria|c__Gammaproteobacteria|o__Enterobacteriales
      marker3                                                   k__Bacteria|p__Proteobacteria|c__Gammaproteobacteria|o__Enterobacteriales|f__Enterobacteriaceae
      marker4                                     k__Bacteria|p__Proteobacteria|c__Gammaproteobacteria|o__Enterobacteriales|f__Enterobacteriaceae|g__Klebsiella
      marker5                   k__Bacteria|p__Proteobacteria|c__Gammaproteobacteria|o__Enterobacteriales|f__Enterobacteriaceae|g__Klebsiella|g__Klebsiella_s__
      marker6                                    k__Bacteria|p__Proteobacteria|c__Gammaproteobacteria|o__Enterobacteriales|f__Enterobacteriaceae|g__Escherichia
      marker7                            k__Bacteria|p__Proteobacteria|c__Gammaproteobacteria|o__Enterobacteriales|f__Enterobacteriaceae|g__Escherichia|s__coli
      marker8                     k__Bacteria|p__Actinobacteria|c__Actinobacteria|o__Bifidobacteriales|f__Bifidobacteriaceae|g__Bifidobacterium|s__adolescentis
      marker9                                            k__Bacteria|p__Bacteroidetes|c__Bacteroidia|o__Bacteroidales|f__[Paraprevotellaceae]|g__Paraprevotella
      marker10                     k__Bacteria|p__Bacteroidetes|c__Bacteroidia|o__Bacteroidales|f__[Paraprevotellaceae]|g__Paraprevotella|g__Paraprevotella_s__
      marker11                                                                                                                    k__Bacteria|p__Proteobacteria
      marker12                                                         k__Bacteria|p__Firmicutes|c__Clostridia|o__Clostridiales|f__Lachnospiraceae|g__Roseburia
      marker13                                        k__Bacteria|p__Firmicutes|c__Clostridia|o__Clostridiales|f__Lachnospiraceae|g__Roseburia|g__Roseburia_s__
      marker14 k__Bacteria|p__Firmicutes|c__Clostridia|o__Clostridiales|f__Clostridiaceae|f__Clostridiaceae_g__Clostridium|f__Clostridiaceae_g__Clostridium_s__
      marker15                                                                                                           k__Bacteria|p__Cyanobacteria|c__4C0d-2
      marker16                                                                                                    k__Bacteria|p__Cyanobacteria|c__4C0d-2|o__YS2
      marker17                                                                                         k__Bacteria|p__Cyanobacteria|c__4C0d-2|o__YS2|o__YS2_f__
      marker18                                                                          k__Bacteria|p__Cyanobacteria|c__4C0d-2|o__YS2|o__YS2_f__|o__YS2_f___g__
      marker19                                                       k__Bacteria|p__Cyanobacteria|c__4C0d-2|o__YS2|o__YS2_f__|o__YS2_f___g__|o__YS2_f___g___s__
      marker20                                                            k__Bacteria|p__Proteobacteria|c__Alphaproteobacteria|o__Rickettsiales|f__mitochondria
      marker21                                        k__Bacteria|p__Proteobacteria|c__Alphaproteobacteria|o__Rickettsiales|f__mitochondria|f__mitochondria_g__
      marker22                k__Bacteria|p__Proteobacteria|c__Alphaproteobacteria|o__Rickettsiales|f__mitochondria|f__mitochondria_g__|f__mitochondria_g___s__
      marker23                                                                            k__Bacteria|p__Proteobacteria|c__Alphaproteobacteria|o__Rickettsiales
      marker24                                   k__Bacteria|p__Bacteroidetes|c__Bacteroidia|o__Bacteroidales|f__Prevotellaceae|g__Prevotella|g__Prevotella_s__
      marker25                                                                                             k__Bacteria|p__Proteobacteria|c__Alphaproteobacteria
      marker26                                                                             k__Bacteria|p__Actinobacteria|c__Actinobacteria|o__Bifidobacteriales
      marker27                                                       k__Bacteria|p__Actinobacteria|c__Actinobacteria|o__Bifidobacteriales|f__Bifidobacteriaceae
      marker28                                                                               k__Bacteria|p__Actinobacteria|c__Actinobacteria|o__Actinomycetales
      marker29                                    k__Bacteria|p__Actinobacteria|c__Actinobacteria|o__Bifidobacteriales|f__Bifidobacteriaceae|g__Bifidobacterium
      marker30                                                            k__Bacteria|p__Actinobacteria|c__Actinobacteria|o__Actinomycetales|f__Nocardioidaceae
      marker31                                                             k__Bacteria|p__Bacteroidetes|c__Bacteroidia|o__Bacteroidales|f__[Paraprevotellaceae]
      marker32                                                                       k__Bacteria|p__Firmicutes|c__Clostridia|o__Clostridiales|f__Eubacteriaceae
      marker33                                       k__Bacteria|p__Firmicutes|c__Erysipelotrichi|o__Erysipelotrichales|f__Erysipelotrichaceae|g__Coprobacillus
      marker34                  k__Bacteria|p__Firmicutes|c__Erysipelotrichi|o__Erysipelotrichales|f__Erysipelotrichaceae|g__Coprobacillus|g__Coprobacillus_s__
               enrich_group ef_logFC     pvalue       padj
      marker1            CD  -4.7938 1.7225e-06 0.00080748
      marker2            CD  -5.2183 3.0820e-06 0.00080748
      marker3            CD  -5.2183 3.0820e-06 0.00080748
      marker4            CD  -9.5469 5.7230e-06 0.00089966
      marker5            CD  -9.5469 5.7230e-06 0.00089966
      marker6            CD  -5.2156 9.1574e-06 0.00102824
      marker7            CD  -5.2156 9.1574e-06 0.00102824
      marker8       Control   8.0864 2.0042e-05 0.00196912
      marker9       Control   9.0024 2.9510e-05 0.00226870
      marker10      Control   9.0024 2.9510e-05 0.00226870
      marker11           CD  -3.4448 3.1750e-05 0.00226870
      marker12      Control   3.2158 1.3357e-04 0.00874873
      marker13      Control   3.1378 2.0167e-04 0.01219313
      marker14      Control   5.0967 2.6625e-04 0.01457664
      marker15      Control   8.3773 3.7962e-04 0.01457664
      marker16      Control   8.3773 3.7962e-04 0.01457664
      marker17      Control   8.3773 3.7962e-04 0.01457664
      marker18      Control   8.3773 3.7962e-04 0.01457664
      marker19      Control   8.3773 3.7962e-04 0.01457664
      marker20           CD  -3.7258 4.0771e-04 0.01457664
      marker21           CD  -3.7256 4.0800e-04 0.01457664
      marker22           CD  -3.7256 4.0800e-04 0.01457664
      marker23           CD  -3.6959 4.4733e-04 0.01528713
      marker24           CD  -6.5872 5.8173e-04 0.01879493
      marker25           CD  -3.4967 5.9780e-04 0.01879493
      marker26      Control   3.0131 9.5040e-04 0.02766728
      marker27      Control   3.0131 9.5040e-04 0.02766728
      marker28           CD  -3.7715 1.1025e-03 0.03042827
      marker29      Control   3.0180 1.1227e-03 0.03042827
      marker30           CD  -8.2442 2.1199e-03 0.05554251
      marker31      Control   6.5572 2.8503e-03 0.07226790
      marker32      Control   5.4734 3.7850e-03 0.08918605
      marker33      Control   5.4044 3.8579e-03 0.08918605
      marker34      Control   5.4044 3.8579e-03 0.08918605

