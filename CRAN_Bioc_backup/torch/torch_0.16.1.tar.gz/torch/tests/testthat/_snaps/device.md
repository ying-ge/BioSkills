# printer works

    torch_device(type='cpu') 

