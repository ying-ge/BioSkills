# print slice

    Code
      print(slc(1, 3, 5))
    Output
      <slice>

