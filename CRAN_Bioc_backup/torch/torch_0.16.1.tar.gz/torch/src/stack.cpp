#include <torch.h>

// [[Rcpp::export]]
XPtrTorchStack test_stack(XPtrTorchStack x) { return x; }
