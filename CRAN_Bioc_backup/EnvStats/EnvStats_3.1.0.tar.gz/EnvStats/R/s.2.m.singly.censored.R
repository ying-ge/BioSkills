s.2.m.singly.censored <-
function (r, alf, bet) 
{
    (-r * (alf + 0.5))/(bet + r^2/2)
}
