n.unique <-
function (x, ...) 
{
    length(unique(x, ...))
}
