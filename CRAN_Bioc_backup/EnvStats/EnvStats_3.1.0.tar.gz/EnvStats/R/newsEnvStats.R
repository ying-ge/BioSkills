newsEnvStats <-
function () 
{
    utils::news(package = "EnvStats")
}
