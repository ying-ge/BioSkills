s.1.m.singly.censored <-
function (r, alf, bet) 
{
    (-r * g1.m.singly.censored(r, 1.5, alf, bet))/g2.m.singly.censored(r, 
        0, alf, bet)
}
