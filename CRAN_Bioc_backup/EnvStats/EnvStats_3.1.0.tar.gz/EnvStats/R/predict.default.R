predict.default <-
function (object, ...) 
stats::predict(object, ...)
