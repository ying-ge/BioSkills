distChoose <-
function (y, ...) 
UseMethod("distChoose")
