library(testthat)
library(multiMiR)

test_check("multiMiR")
