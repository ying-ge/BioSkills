library(testthat)
library(DNAshapeR)
test_check("DNAshapeR")

