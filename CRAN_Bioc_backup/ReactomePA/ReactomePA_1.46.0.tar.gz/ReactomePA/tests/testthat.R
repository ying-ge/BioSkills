library(testthat)
library(ReactomePA)

test_check("ReactomePA")

