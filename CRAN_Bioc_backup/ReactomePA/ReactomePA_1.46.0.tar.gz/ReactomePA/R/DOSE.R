
##' @importFrom DOSE geneID
##' @export
DOSE::geneID

##' @importFrom DOSE geneInCategory
##' @export
DOSE::geneInCategory
