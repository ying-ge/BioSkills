utils::globalVariables(c("sig.gene70", "sig.ggi", "sig.gene76",
    "sigOvcAngiogenic","modelOvcAngiogenic", "sig.genius","scmod1.robust",
    "sigOvcCrijns", "sigOvcCrijn", "sigOvcTCGA", "sigOvcYoshihara",
    "sig.pik3cags", "pam50", "sig.tamr13", "sig.oncotypedx"))