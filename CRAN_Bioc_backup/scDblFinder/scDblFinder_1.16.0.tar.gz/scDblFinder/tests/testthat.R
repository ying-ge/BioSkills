library(testthat)
library(scDblFinder)
test_check("scDblFinder")
