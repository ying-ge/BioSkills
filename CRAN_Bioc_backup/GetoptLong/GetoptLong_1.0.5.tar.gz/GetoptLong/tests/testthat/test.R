print(commandArgs(trailingOnly = FALSE))
print(commandArgs(trailingOnly = TRUE))