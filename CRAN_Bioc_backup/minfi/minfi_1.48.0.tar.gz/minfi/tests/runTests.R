require("minfi") || stop("unable to load minfi")
BiocGenerics:::testPackage("minfi")
