library("testthat")
library("wakefield")

test_check("wakefield")