context("Checking death")

test_that("death ...",{


})

