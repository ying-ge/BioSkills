context("Checking smokes")

test_that("smokes ...",{


})

