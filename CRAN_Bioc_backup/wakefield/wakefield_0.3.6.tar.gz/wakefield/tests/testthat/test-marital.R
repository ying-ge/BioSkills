context("Checking marital")

test_that("marital ...",{


})

