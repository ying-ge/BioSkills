context("Checking dice")

test_that("dice ...",{


})

