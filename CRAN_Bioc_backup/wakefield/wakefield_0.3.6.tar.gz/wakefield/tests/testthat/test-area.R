context("Checking area")

test_that("area ...",{


})

