context("Checking lorem_ipsum")

test_that("lorem_ipsum ...",{


})

