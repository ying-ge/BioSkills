context("Checking sentence")

test_that("sentence ...",{


})

