context("Checking race")

test_that("race ...",{


})

