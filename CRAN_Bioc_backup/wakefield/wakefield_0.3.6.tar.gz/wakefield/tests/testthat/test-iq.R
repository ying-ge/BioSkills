context("Checking iq")

test_that("iq ...",{


})

