context("Checking string")

test_that("string ...",{


})

