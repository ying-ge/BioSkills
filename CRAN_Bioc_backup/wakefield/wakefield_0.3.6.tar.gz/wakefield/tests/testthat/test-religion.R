context("Checking religion")

test_that("religion ...",{


})

