context("Checking state")

test_that("state ...",{


})

