context("Checking animal")

test_that("animal ...",{


})

