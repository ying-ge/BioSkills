context("Checking r_dummy")

test_that("r_dummy ...",{


})

