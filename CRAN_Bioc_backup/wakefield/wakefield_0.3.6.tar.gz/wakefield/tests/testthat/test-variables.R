context("Checking variables")

test_that("variables ...",{


})

