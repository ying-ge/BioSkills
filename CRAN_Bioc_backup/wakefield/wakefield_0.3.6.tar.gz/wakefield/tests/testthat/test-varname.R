context("Checking varname")

test_that("varname ...",{


})

