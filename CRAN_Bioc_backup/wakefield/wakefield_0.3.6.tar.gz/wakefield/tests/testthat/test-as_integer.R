context("Checking as_integer")

test_that("as_integer ...",{


})

