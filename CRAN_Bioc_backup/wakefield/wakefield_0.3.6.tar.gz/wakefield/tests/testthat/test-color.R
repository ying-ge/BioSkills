context("Checking color")

test_that("color ...",{


})

