context("Checking sat")

test_that("sat ...",{


})

