context("Checking r_sample_ordered")

test_that("r_sample_ordered ...",{


})

