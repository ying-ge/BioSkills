context("Checking r_sample_replace")

test_that("r_sample_replace ...",{


})

