context("Checking coin")

test_that("coin ...",{


})

