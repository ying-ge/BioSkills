context("Checking military")

test_that("military ...",{


})

