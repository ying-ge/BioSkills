context("Checking political")

test_that("political ...",{


})

