context("Checking r_series")

test_that("r_series ...",{


})

