context("Checking peek")

test_that("peek ...",{


})

