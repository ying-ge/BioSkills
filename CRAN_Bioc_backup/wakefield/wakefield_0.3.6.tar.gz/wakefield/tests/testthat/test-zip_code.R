context("Checking zip_code")

test_that("zip_code ...",{


})

