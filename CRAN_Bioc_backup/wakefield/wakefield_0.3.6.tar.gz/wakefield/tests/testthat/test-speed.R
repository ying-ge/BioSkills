context("Checking speed")

test_that("speed ...",{


})

