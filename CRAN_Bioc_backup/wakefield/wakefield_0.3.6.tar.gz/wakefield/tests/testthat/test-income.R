context("Checking income")

test_that("income ...",{


})

