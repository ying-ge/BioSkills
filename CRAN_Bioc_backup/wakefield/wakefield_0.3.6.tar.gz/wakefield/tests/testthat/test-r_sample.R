context("Checking r_sample")

test_that("r_sample ...",{


})

