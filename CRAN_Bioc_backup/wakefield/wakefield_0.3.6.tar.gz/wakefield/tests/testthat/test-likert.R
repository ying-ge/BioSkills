context("Checking likert")

test_that("likert ...",{


})

