context("Checking relate")

test_that("relate ...",{


})

