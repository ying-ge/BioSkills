context("Checking name")

test_that("name ...",{


})

