context("Checking probs")

test_that("probs ...",{


})

