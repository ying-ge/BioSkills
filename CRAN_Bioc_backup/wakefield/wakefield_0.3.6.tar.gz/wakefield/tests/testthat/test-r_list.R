context("Checking r_list")

test_that("r_list ...",{


})

