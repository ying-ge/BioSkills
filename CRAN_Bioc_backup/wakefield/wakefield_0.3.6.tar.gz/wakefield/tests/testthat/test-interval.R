context("Checking interval")

test_that("interval ...",{


})

