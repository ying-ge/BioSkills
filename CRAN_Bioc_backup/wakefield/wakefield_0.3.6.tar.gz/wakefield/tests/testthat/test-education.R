context("Checking education")

test_that("education ...",{


})

