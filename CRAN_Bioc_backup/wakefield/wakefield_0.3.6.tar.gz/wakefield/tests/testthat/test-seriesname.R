context("Checking seriesname")

test_that("seriesname ...",{


})

