context("Checking dna")

test_that("dna ...",{


})

