context("Checking r_na")

test_that("r_na ...",{


})

