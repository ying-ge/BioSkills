context("Checking hair")

test_that("hair ...",{


})

