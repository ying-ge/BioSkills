context("Checking r_insert")

test_that("r_insert ...",{


})

