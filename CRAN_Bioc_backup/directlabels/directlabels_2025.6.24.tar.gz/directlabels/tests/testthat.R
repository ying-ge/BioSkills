if(require(testthat))test_check("directlabels")
