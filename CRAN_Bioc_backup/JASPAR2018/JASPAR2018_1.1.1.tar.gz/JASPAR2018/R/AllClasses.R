
setClass("JASPAR2018", slots=c(db="character")
         )
