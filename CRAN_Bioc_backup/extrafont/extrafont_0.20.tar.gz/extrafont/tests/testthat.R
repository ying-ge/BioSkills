library(testthat)
library(extrafont)

test_check("extrafont")
