#' @keywords internal
#' @aliases extrafont extrafont-package NULL
#' @import extrafontdb
#' @author This package has been written by Winston Chang (github.com/wch/extrafont)
#'
#' Maintainer: Frederic Bertrand <frederic.bertrand@@lecnam.net>
#'
"_PACKAGE"
