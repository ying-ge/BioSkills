##' @importFrom ggplot2 ggsave
##' @export
ggplot2::ggsave

##' @importFrom magrittr %>%
##' @export
magrittr::`%>%`

##' @importFrom ggfun ggrange
##' @export
ggfun::ggrange


##' @importFrom ggfun xrange
##' @export
ggfun::xrange

##' @importFrom ggfun yrange
##' @export
ggfun::yrange

