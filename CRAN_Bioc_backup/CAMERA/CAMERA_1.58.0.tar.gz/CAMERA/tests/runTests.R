require("CAMERA") || stop("unable to load CAMERA")
BiocGenerics:::testPackage("CAMERA")