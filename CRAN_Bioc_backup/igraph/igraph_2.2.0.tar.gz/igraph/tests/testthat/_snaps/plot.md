# layout as graph attribute error works

    Code
      plot(g)
    Condition
      Error in `plot()`:
      ! The layout has 5 rows, but the graph has 10 vertices.
      i It is recommended to store the layout as x and y vertex attributes and not as a matrix graph attribute.

