# mst error works

    Code
      mst(g, algorithm = "undefined")
    Condition
      Error in `mst()`:
      ! Invalid `algorithm`.

