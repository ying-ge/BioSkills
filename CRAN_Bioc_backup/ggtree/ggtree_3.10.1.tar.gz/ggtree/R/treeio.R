#has.slot <- treeio:::has.slot
#getNodeNum <- treeio:::getNodeNum
getRoot <- tidytree::rootnode
get.tree <- treeio::get.tree
getNodeNum <- getFromNamespace('getNodeNum', 'treeio')
has.slot <- getFromNamespace('has.slot', 'treeio')
is.tree <- getFromNamespace('is.tree', 'treeio')
set_branch_length <- getFromNamespace("set_branch_length", "treeio")
