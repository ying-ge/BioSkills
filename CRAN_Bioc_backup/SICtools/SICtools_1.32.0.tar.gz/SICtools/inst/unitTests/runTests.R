## runTests

BiocGenerics:::testPackage("SICtools")



