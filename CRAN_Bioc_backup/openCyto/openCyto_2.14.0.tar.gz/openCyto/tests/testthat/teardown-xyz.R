if(get_default_backend()=="tile")
{
  message("clean up ", gs_dir)
  unlink(gs_dir)
}
  