library(testthat)
library(openCyto)

test_check("openCyto")


#taking quite some time , thus only for internal testing
#test_file("~/rglab/workspace/openCyto/tests/testthat/gating-testSuite.R")
