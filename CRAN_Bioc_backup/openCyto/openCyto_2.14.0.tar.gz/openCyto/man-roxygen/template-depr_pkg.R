#' @name openCyto-deprecated
#' @description 
#' \code{<%= old %>} --> \code{\link{<%= new %>}}

