context("Export Reports Functionality")

test_that(
  "Argument Functionality", 
  {
    skip("Tests to be developed for 3.0.0 release")
    skip_if(!RUN_REPORTS_TEST, 
            "EXPORT_REPORTS_ID is not provided. Testing Skipped")
  }
)