context("Create File Repository Folder Argument Functionality")

# No tests performed: There is no way to undo folder creation
# so we do not perform tests to avoid making a cluttered 
# file repository structure in the project.