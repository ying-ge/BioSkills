context("Export Records Basic Functionality")

test_that(
  "Functionality", 
  {
    skip("Tests to be developed for 3.0.0 release")
  }
)