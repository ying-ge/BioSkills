context("Switch DAG Functionality")

# Testing the switchDag functionality requires designating DAGs to which 
# the current user may switch, which cannont be controlled via the API.
# We have tested that this functionality behaves as desired, but cannot
# provide automated tests without requiring manual configuration within the
# project. Thus, no testing is performed here.