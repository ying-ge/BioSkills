context("Export Reports Argument Validation")

test_that(
  "Argument Validation", 
  {
    skip("Tests to be developed for 3.0.0 release")
    skip_if(length(EXPORT_REPORTS_ID) == 0, 
            "EXPORT_REPORTS_ID is not provided. Testing Skipped")
  }
)