# pamr
Prediction Analysis of Microarrays
