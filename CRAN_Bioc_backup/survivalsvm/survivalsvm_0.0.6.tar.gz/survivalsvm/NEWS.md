##### Version 0.0.2
* Initial version on Github
##### Version 0.0.3
* Fix regression approach for more explicit error message when incosistent solutions are found for the optimization problem.
##### Version 0.0.4
* Call the function quadprog from the package quadprog, since the new version of the pracma package does not include quadprog anymore
##### Version 0.0.6
* We fix notes reported by CRAN. No changes in functionalities.