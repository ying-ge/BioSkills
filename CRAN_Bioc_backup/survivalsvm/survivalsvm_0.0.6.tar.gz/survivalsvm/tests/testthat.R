library(testthat)
library(survivalsvm)

test_check("survivalsvm")