library(testthat)
library(givitiR)

test_check("givitiR")
