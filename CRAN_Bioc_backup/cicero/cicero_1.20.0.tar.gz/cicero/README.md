[![Travis build status](https://travis-ci.org/cole-trapnell-lab/cicero-release.svg?branch=master)](https://travis-ci.org/cole-trapnell-lab/cicero-release)
[![Coverage status](https://codecov.io/gh/cole-trapnell-lab/cicero-release/branch/master/graph/badge.svg)](https://codecov.io/github/cole-trapnell-lab/cicero-release?branch=master)
# Cicero
### Predicting the cis-regulatory landscape

Please see our [website](http://cole-trapnell-lab.github.io/cicero-release/) for information on installing and using Cicero
