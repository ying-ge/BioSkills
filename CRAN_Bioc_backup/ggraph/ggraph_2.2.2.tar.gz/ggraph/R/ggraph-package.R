#' @keywords internal
'_PACKAGE'

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @import ggplot2 tidygraph rlang vctrs
#' @importFrom memoise memoise
#' @importFrom lifecycle deprecated
#' @useDynLib ggraph, .registration = TRUE
## usethis namespace: end
NULL
