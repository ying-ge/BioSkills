if (getRversion() >= "2.15.1") {
  utils::globalVariables('ranks_ref')
}
