# plotrix

`plotrix` is an `R` package that provides many plotting, labeling, and axis &
color scaling functions.  

Its original author and maintainer, Jim Lemon, passed away in
September 2023. 

Currently it is being maintained by Duncan Murdoch.  Please submit
bug reports to https://github.com/dmurdoch/plotrix/issues.  


## Authors

Jim Lemon, Ben Bolker, Sander Oom, Eduardo Klein, Barry Rowlingson, Hadley
Wickham, Anupam Tyagi, Olivier Eterradossi, Gabor Grothendieck, Michael Toews,
John Kane, Rolf Turner, Carl Witthoft, Julian Stander, Thomas Petzoldt, Remko
Duursma, Elisa Biancotto, Ofir Levy, Christophe Dutang, Peter Solymos, Robby
Engelmann, Michael Hecker, Felix Steinbeck, Hans Borchers, Henrik Singmann, Ted
Toal, Derek Ogle, Darshan Baral, Ulrike Groemping, Bill Venables
