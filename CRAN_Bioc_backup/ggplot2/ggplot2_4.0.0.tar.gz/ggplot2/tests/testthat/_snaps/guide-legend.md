# unresolved, modified expressions throw a warning (#6264)

    Unable to apply staged modifications.
    Caused by error:
    ! object 'prop' not found

