# GeomXxx$parameters() does not contain partial matches

    Code
      problems
    Output
       [1] "GeomBoxplot  : `notch` with `notchwidth`"
       [2] "GeomContour  : `arrow` with `arrow.fill`"
       [3] "GeomCurve    : `arrow` with `arrow.fill`"
       [4] "GeomDensity2d: `arrow` with `arrow.fill`"
       [5] "GeomFunction : `arrow` with `arrow.fill`"
       [6] "GeomLine     : `arrow` with `arrow.fill`"
       [7] "GeomPath     : `arrow` with `arrow.fill`"
       [8] "GeomQuantile : `arrow` with `arrow.fill`"
       [9] "GeomSegment  : `arrow` with `arrow.fill`"
      [10] "GeomSf       : `arrow` with `arrow.fill`"
      [11] "GeomSpoke    : `arrow` with `arrow.fill`"
      [12] "GeomStep     : `arrow` with `arrow.fill`"

# StatXxx$parameters() does not contain partial matches

    Code
      problems
    Output
      [1] "StatDensity        : `n` with `na.rm`"                             
      [2] "StatDensity2d      : `na.rm` with `n`"                             
      [3] "StatDensity2dFilled: `na.rm` with `n`"                             
      [4] "StatQuantile       : `method` with `method.args`"                  
      [5] "StatSmooth         : `method` with `method.args`, `n` with `na.rm`"
      [6] "StatSummary2d      : `fun` with `fun.args`"                        
      [7] "StatSummaryHex     : `fun` with `fun.args`"                        

