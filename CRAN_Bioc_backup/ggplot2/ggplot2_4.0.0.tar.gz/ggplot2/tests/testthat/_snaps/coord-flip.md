# flip coords throws error when limits are badly specified

    `xlim` must be a vector, not a <ScaleContinuousPosition> object.

---

    `ylim` must be a vector of length 2, not length 3.

