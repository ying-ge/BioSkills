# binned scales only support continuous data

    Binned scales only support continuous data.

---

    Binned scales only support continuous data.

