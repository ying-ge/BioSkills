# geom_col removes columns with parts outside the plot limits

    Removed 3 rows containing missing values or values outside the scale range (`geom_col()`).

---

    Removed 1 row containing missing values or values outside the scale range (`geom_col()`).

