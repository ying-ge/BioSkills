# modifying theme element properties with + operator works

    Code
      theme_grey() + "asdf"
    Condition
      Error:
      ! Can't add `"asdf"` to a theme object.

