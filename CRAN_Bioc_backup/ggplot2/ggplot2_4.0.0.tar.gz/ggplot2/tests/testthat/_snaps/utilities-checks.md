# check_device checks R versions correctly

    R 4.0.0 does not support gradients.

---

    R 4.1.0 does not support gradients.

---

    R 4.2.0 does not support glyphs.

# check_device finds device capabilities

    The pdf device does not support clipping paths.

---

    Unable to check the capabilities of the foobar device.

