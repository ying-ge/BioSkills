setGeneric("pwm", function(pwm) standardGeneric("pwm"))

setGeneric("ic", function(pwm) standardGeneric("ic"))

setGeneric("consensus", function(pwm) standardGeneric("consensus"))

# setGeneric("alphabet", function(pwm) standardGeneric("alphabet"))

# setGeneric("seqLogo", signature(pwm="pwm"),
#            function(x, ic.scale=TRUE, xaxis=TRUE, yaxis=TRUE,
#                     xfontsize=15, yfontsize=15,
#                     fill=c(A="#61D04F", C="#2297E6", G="#F5C710", T="#DF536B"))
#              standardGeneric("seqLogo")
# )
