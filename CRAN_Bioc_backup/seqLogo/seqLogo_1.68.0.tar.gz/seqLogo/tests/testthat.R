library(testthat)
library(seqLogo)

test_check("seqLogo")
