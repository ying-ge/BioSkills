require("XVector") || stop("unable to load XVector package")
XVector:::.test()
