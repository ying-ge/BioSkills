library(testthat)
library(EpiEstim)

test_check("EpiEstim")
