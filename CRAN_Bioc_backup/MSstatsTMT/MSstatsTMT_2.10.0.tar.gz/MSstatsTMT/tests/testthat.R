library(testthat)
library(MSstatsTMT)

test_check("MSstatsTMT")
