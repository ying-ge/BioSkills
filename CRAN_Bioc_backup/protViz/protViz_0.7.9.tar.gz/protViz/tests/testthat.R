#R
library(testthat)   
suppressPackageStartupMessages(library(protViz))  
test_check("protViz")  
