library(testthat)
library(parsnip)

test_check("parsnip")

