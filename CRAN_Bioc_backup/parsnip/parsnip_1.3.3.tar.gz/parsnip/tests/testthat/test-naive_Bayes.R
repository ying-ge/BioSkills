test_that("testing", {
  # Testing is done in {discrim}
  # https://github.com/tidymodels/discrim

  expect_true(TRUE)
})