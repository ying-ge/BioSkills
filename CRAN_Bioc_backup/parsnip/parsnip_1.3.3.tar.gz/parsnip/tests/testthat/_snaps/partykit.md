# fit ctree models

    `weights` should be an integer vector with size the same as the number of rows of `data`.

# fit cforest models

    `weights` should be a numeric vector with size the same as the number of rows of `data`.

