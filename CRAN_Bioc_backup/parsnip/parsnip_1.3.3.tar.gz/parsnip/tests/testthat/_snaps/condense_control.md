# condense_control works

    Code
      condense_control(control_parsnip(), ctrl)
    Condition
      Error:
      ! a <control_parsnip> object cannot be coerced to a <control_parsnip> object.
      i The arguments `allow_par` and `anotherone` are missing.

---

    Code
      control_test(ctrl)
    Condition
      Error in `control_test()`:
      ! a <control_parsnip> object cannot be coerced to a <control_parsnip> object.
      i The arguments `allow_par` and `anotherone` are missing.

