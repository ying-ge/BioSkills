# NULL engines

    Code
      set_engine(nearest_neighbor(), NULL)
    Condition
      Error in `set_engine()`:
      ! Missing engine. Possible mode/engine combinations are: classification {kknn} and regression {kknn}.

