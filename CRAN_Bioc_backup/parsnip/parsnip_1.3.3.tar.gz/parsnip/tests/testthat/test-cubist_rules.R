test_that("testing", {
  # Testing is done in {rules}
  # https://github.com/tidymodels/rules

  expect_true(TRUE)
})