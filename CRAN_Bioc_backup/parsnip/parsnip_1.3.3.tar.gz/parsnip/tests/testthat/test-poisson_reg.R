test_that("testing", {
  # Testing is done in {poissonreg}
  # https://github.com/tidymodels/poissonreg

  expect_true(TRUE)
})