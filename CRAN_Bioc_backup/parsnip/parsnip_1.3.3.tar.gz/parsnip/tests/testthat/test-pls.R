test_that("testing", {
  # Testing is done in {plsmod}
  # https://github.com/tidymodels/plsmod

  expect_true(TRUE)
})