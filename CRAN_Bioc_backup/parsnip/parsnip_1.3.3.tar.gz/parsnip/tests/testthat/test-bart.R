test_that("check_args() works", {
  # Here for completeness, no checking is done
  expect_true(TRUE)
})
