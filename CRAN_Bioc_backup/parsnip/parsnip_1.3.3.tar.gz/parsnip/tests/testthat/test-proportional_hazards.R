test_that("testing", {
  # Testing is done in {censored}
  # https://github.com/tidymodels/censored

  expect_true(TRUE)
})