test_that("testing", {
  # Testing is done in {baguette}
  # https://github.com/tidymodels/baguette

  expect_true(TRUE)
})