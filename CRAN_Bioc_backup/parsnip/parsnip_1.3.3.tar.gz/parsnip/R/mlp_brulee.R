#' Multilayer perceptron via brulee
#'
#' [brulee::brulee_mlp()] fits a neural network.
#'
#' @includeRmd man/rmd/mlp_brulee.md details
#'
#' @name details_mlp_brulee
#' @keywords internal
NULL

# See inst/README-DOCS.md for a description of how these files are processed
