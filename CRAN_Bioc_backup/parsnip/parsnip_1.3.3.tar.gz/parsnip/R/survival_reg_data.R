
set_new_model("survival_reg")
set_model_mode("survival_reg", "censored regression")

# ------------------------------------------------------------------------------

# parsnip just contains the model specification, the engines are the censored package.
