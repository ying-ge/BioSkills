library(testthat)
library(KEGGgraph)

test_check("KEGGgraph")
