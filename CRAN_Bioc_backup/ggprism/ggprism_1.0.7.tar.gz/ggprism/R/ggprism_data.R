#' Palettes and theme data for ggprism
#'
#' This list object contains the strings and values used in
#' ggprism themes and palettes.
"ggprism_data"
