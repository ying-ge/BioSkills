
#' @useDynLib glmGamPoi, .registration = TRUE
NULL


#' @import stats
#' @import Rcpp
#' @importFrom methods as is canCoerce
#' @importFrom utils head
#' @importFrom SummarizedExperiment assay
#' @importFrom BiocGenerics end width
NULL
