library(testthat)
library(glmGamPoi)

test_check("glmGamPoi")
