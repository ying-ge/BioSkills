.onLoad <- function(libname, pkgname)
{
  library.dynam("survcomp", pkgname, libname)
}