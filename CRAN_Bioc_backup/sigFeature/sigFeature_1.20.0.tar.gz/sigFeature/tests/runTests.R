



BiocGenerics:::testPackage("sigFeature")
