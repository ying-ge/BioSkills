library(testthat)
library(pROC)
data(aSAH)

test_check("pROC")
