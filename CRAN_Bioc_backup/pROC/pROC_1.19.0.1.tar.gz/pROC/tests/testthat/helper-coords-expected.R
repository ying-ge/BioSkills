# expected.coords <- coords(r.s100b, "all", ret="all")
# dump("expected.coords", "", control = c("all", "hexNumeric"))

expected.coords <-
  structure(list(
    threshold = c(
      -Inf, 0x1.1eb851eb851ecp-5, 0x1.70a3d70a3d70ap-5,
      0x1.c28f5c28f5c29p-5, 0x1.0a3d70a3d70a4p-4, 0x1.3333333333334p-4,
      0x1.5c28f5c28f5c2p-4, 0x1.851eb851eb852p-4, 0x1.ae147ae147ae2p-4,
      0x1.d70a3d70a3d7p-4, 0x1p-3, 0x1.147ae147ae148p-3, 0x1.28f5c28f5c29p-3,
      0x1.3d70a3d70a3d7p-3, 0x1.51eb851eb851fp-3, 0x1.6666666666666p-3,
      0x1.7ae147ae147aep-3, 0x1.a3d70a3d70a3ep-3, 0x1.ccccccccccccdp-3,
      0x1.e147ae147ae14p-3, 0x1.f5c28f5c28f5cp-3, 0x1.051eb851eb852p-2,
      0x1.0f5c28f5c28f6p-2, 0x1.199999999999ap-2, 0x1.28f5c28f5c29p-2,
      0x1.3d70a3d70a3d7p-2, 0x1.4cccccccccccdp-2, 0x1.570a3d70a3d71p-2,
      0x1.6147ae147ae14p-2, 0x1.75c28f5c28f5cp-2, 0x1.947ae147ae148p-2,
      0x1.ae147ae147ae1p-2, 0x1.bd70a3d70a3d7p-2, 0x1.c7ae147ae147bp-2,
      0x1.d1eb851eb851fp-2, 0x1.dc28f5c28f5c2p-2, 0x1.e666666666666p-2,
      0x1.f0a3d70a3d70ap-2, 0x1.fae147ae147aep-2, 0x1.051eb851eb852p-1,
      0x1.147ae147ae148p-1, 0x1.23d70a3d70a3ep-1, 0x1.47ae147ae147ap-1,
      0x1.68f5c28f5c28fp-1, 0x1.7333333333333p-1, 0x1.828f5c28f5c29p-1,
      0x1.970a3d70a3d7p-1, 0x1.ae147ae147ae1p-1, 0x1.d1eb851eb851ep-1,
      0x1.83d70a3d70a3dp+0, Inf
    ), specificity = c(
      0x0p+0, 0x0p+0, 0x1.1c71c71c71c72p-4,
      0x1.c71c71c71c71cp-4, 0x1.1c71c71c71c72p-3, 0x1.c71c71c71c71cp-3,
      0x1.38e38e38e38e4p-2, 0x1.8e38e38e38e39p-2, 0x1.f1c71c71c71c7p-2,
      0x1.1555555555555p-1, 0x1.1555555555555p-1, 0x1.2aaaaaaaaaaabp-1,
      0x1.471c71c71c71cp-1, 0x1.638e38e38e38ep-1, 0x1.78e38e38e38e4p-1,
      0x1.871c71c71c71cp-1, 0x1.8e38e38e38e39p-1, 0x1.9c71c71c71c72p-1,
      0x1.9c71c71c71c72p-1, 0x1.9c71c71c71c72p-1, 0x1.a38e38e38e38ep-1,
      0x1.a38e38e38e38ep-1, 0x1.a38e38e38e38ep-1, 0x1.a38e38e38e38ep-1,
      0x1.aaaaaaaaaaaabp-1, 0x1.aaaaaaaaaaaabp-1, 0x1.b1c71c71c71c7p-1,
      0x1.b8e38e38e38e4p-1, 0x1.cp-1, 0x1.cp-1, 0x1.c71c71c71c71cp-1,
      0x1.c71c71c71c71cp-1, 0x1.ce38e38e38e39p-1, 0x1.ce38e38e38e39p-1,
      0x1.d555555555555p-1, 0x1.dc71c71c71c72p-1, 0x1.eaaaaaaaaaaabp-1,
      0x1.f1c71c71c71c7p-1, 0x1.f1c71c71c71c7p-1, 0x1p+0, 0x1p+0, 0x1p+0,
      0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0,
      0x1p+0
    ), sensitivity = c(
      0x1p+0, 0x1.f3831f3831f38p-1, 0x1.f3831f3831f38p-1,
      0x1.f3831f3831f38p-1, 0x1.f3831f3831f38p-1, 0x1.ce0c7ce0c7ce1p-1,
      0x1.c18f9c18f9c19p-1, 0x1.a895da895da89p-1, 0x1.8f9c18f9c18fap-1,
      0x1.831f3831f3832p-1, 0x1.76a2576a2576ap-1, 0x1.5da895da895dbp-1,
      0x1.512bb512bb513p-1, 0x1.512bb512bb513p-1, 0x1.44aed44aed44bp-1,
      0x1.44aed44aed44bp-1, 0x1.44aed44aed44bp-1, 0x1.44aed44aed44bp-1,
      0x1.3831f3831f383p-1, 0x1.2bb512bb512bbp-1, 0x1.2bb512bb512bbp-1,
      0x1.1f3831f3831f4p-1, 0x1.12bb512bb512cp-1, 0x1.063e7063e7064p-1,
      0x1.063e7063e7064p-1, 0x1.f3831f3831f38p-2, 0x1.da895da895da9p-2,
      0x1.c18f9c18f9c19p-2, 0x1.c18f9c18f9c19p-2, 0x1.a895da895da89p-2,
      0x1.a895da895da89p-2, 0x1.8f9c18f9c18fap-2, 0x1.8f9c18f9c18fap-2,
      0x1.5da895da895dbp-2, 0x1.5da895da895dbp-2, 0x1.5da895da895dbp-2,
      0x1.5da895da895dbp-2, 0x1.44aed44aed44bp-2, 0x1.2bb512bb512bbp-2,
      0x1.2bb512bb512bbp-2, 0x1.12bb512bb512cp-2, 0x1.f3831f3831f38p-3,
      0x1.c18f9c18f9c19p-3, 0x1.8f9c18f9c18fap-3, 0x1.2bb512bb512bbp-3,
      0x1.f3831f3831f38p-4, 0x1.8f9c18f9c18fap-4, 0x1.2bb512bb512bbp-4,
      0x1.8f9c18f9c18fap-5, 0x1.8f9c18f9c18fap-6, 0x0p+0
    ), accuracy = c(
      0x1.738a31d738a32p-2,
      0x1.6a7a5616a7a56p-2, 0x1.97c9a0d97c9a1p-2, 0x1.b2f9341b2f934p-2,
      0x1.c518eb9c518ecp-2, 0x1.e0487ede0487fp-2, 0x1.06cbe4d06cbe5p-1,
      0x1.18eb9c518eb9cp-1, 0x1.2f9341b2f9342p-1, 0x1.3d2b0b53d2b0bp-1,
      0x1.38a31d738a31dp-1, 0x1.3d2b0b53d2b0bp-1, 0x1.4ac2d4f4ac2d5p-1,
      0x1.5ce28c75ce28cp-1, 0x1.65f268365f268p-1, 0x1.6f0243f6f0244p-1,
      0x1.738a31d738a32p-1, 0x1.7c9a0d97c9a0ep-1, 0x1.78121fb78122p-1,
      0x1.738a31d738a32p-1, 0x1.78121fb78122p-1, 0x1.738a31d738a32p-1,
      0x1.6f0243f6f0244p-1, 0x1.6a7a5616a7a56p-1, 0x1.6f0243f6f0244p-1,
      0x1.6a7a5616a7a56p-1, 0x1.6a7a5616a7a56p-1, 0x1.6a7a5616a7a56p-1,
      0x1.6f0243f6f0244p-1, 0x1.6a7a5616a7a56p-1, 0x1.6f0243f6f0244p-1,
      0x1.6a7a5616a7a56p-1, 0x1.6f0243f6f0244p-1, 0x1.65f268365f268p-1,
      0x1.6a7a5616a7a56p-1, 0x1.6f0243f6f0244p-1, 0x1.78121fb78122p-1,
      0x1.78121fb78122p-1, 0x1.738a31d738a32p-1, 0x1.7c9a0d97c9a0ep-1,
      0x1.78121fb78122p-1, 0x1.738a31d738a32p-1, 0x1.6f0243f6f0244p-1,
      0x1.6a7a5616a7a56p-1, 0x1.616a7a5616a7ap-1, 0x1.5ce28c75ce28cp-1,
      0x1.585a9e9585a9fp-1, 0x1.53d2b0b53d2b1p-1, 0x1.4f4ac2d4f4ac3p-1,
      0x1.4ac2d4f4ac2d5p-1, 0x1.463ae71463ae7p-1
    ), tn = c(
      0x0p+0, 0x0p+0,
      0x1.4p+2, 0x1p+3, 0x1.4p+3, 0x1p+4, 0x1.6p+4, 0x1.cp+4, 0x1.18p+5,
      0x1.38p+5, 0x1.38p+5, 0x1.5p+5, 0x1.7p+5, 0x1.9p+5, 0x1.a8p+5,
      0x1.b8p+5, 0x1.cp+5, 0x1.dp+5, 0x1.dp+5, 0x1.dp+5, 0x1.d8p+5,
      0x1.d8p+5, 0x1.d8p+5, 0x1.d8p+5, 0x1.ep+5, 0x1.ep+5, 0x1.e8p+5,
      0x1.fp+5, 0x1.f8p+5, 0x1.f8p+5, 0x1p+6, 0x1p+6, 0x1.04p+6, 0x1.04p+6,
      0x1.08p+6, 0x1.0cp+6, 0x1.14p+6, 0x1.18p+6, 0x1.18p+6, 0x1.2p+6,
      0x1.2p+6, 0x1.2p+6, 0x1.2p+6, 0x1.2p+6, 0x1.2p+6, 0x1.2p+6, 0x1.2p+6,
      0x1.2p+6, 0x1.2p+6, 0x1.2p+6, 0x1.2p+6
    ), tp = c(
      0x1.48p+5, 0x1.4p+5,
      0x1.4p+5, 0x1.4p+5, 0x1.4p+5, 0x1.28p+5, 0x1.2p+5, 0x1.1p+5,
      0x1p+5, 0x1.fp+4, 0x1.ep+4, 0x1.c000000000001p+4, 0x1.bp+4, 0x1.bp+4,
      0x1.ap+4, 0x1.ap+4, 0x1.ap+4, 0x1.ap+4, 0x1.9p+4, 0x1.8p+4, 0x1.8p+4,
      0x1.7000000000001p+4, 0x1.6p+4, 0x1.5p+4, 0x1.5p+4, 0x1.4p+4,
      0x1.3p+4, 0x1.2p+4, 0x1.2p+4, 0x1.1p+4, 0x1.1p+4, 0x1p+4, 0x1p+4,
      0x1.c000000000001p+3, 0x1.c000000000001p+3, 0x1.c000000000001p+3,
      0x1.c000000000001p+3, 0x1.ap+3, 0x1.8p+3, 0x1.8p+3, 0x1.6p+3,
      0x1.4p+3, 0x1.2p+3, 0x1p+3, 0x1.8p+2, 0x1.4p+2, 0x1p+2, 0x1.8p+1,
      0x1p+1, 0x1p+0, 0x0p+0
    ), fn = c(
      0x0p+0, 0x1p+0, 0x1p+0, 0x1p+0,
      0x1p+0, 0x1p+2, 0x1.4p+2, 0x1.cp+2, 0x1.2p+3, 0x1.4p+3, 0x1.6p+3,
      0x1.9fffffffffffep+3, 0x1.cp+3, 0x1.cp+3, 0x1.ep+3, 0x1.ep+3,
      0x1.ep+3, 0x1.ep+3, 0x1p+4, 0x1.1p+4, 0x1.1p+4, 0x1.1ffffffffffffp+4,
      0x1.3p+4, 0x1.4p+4, 0x1.4p+4, 0x1.5p+4, 0x1.6p+4, 0x1.7p+4, 0x1.7p+4,
      0x1.8p+4, 0x1.8p+4, 0x1.9p+4, 0x1.9p+4, 0x1.bp+4, 0x1.bp+4, 0x1.bp+4,
      0x1.bp+4, 0x1.cp+4, 0x1.dp+4, 0x1.dp+4, 0x1.ep+4, 0x1.fp+4, 0x1p+5,
      0x1.08p+5, 0x1.18p+5, 0x1.2p+5, 0x1.28p+5, 0x1.3p+5, 0x1.38p+5,
      0x1.4p+5, 0x1.48p+5
    ), fp = c(
      0x1.2p+6, 0x1.2p+6, 0x1.0cp+6, 0x1p+6,
      0x1.fp+5, 0x1.cp+5, 0x1.9p+5, 0x1.6p+5, 0x1.28p+5, 0x1.08p+5,
      0x1.08p+5, 0x1.ep+4, 0x1.ap+4, 0x1.6p+4, 0x1.3p+4, 0x1.1p+4,
      0x1p+4, 0x1.cp+3, 0x1.cp+3, 0x1.cp+3, 0x1.ap+3, 0x1.ap+3, 0x1.ap+3,
      0x1.ap+3, 0x1.8p+3, 0x1.8p+3, 0x1.6p+3, 0x1.4p+3, 0x1.2p+3, 0x1.2p+3,
      0x1p+3, 0x1p+3, 0x1.cp+2, 0x1.cp+2, 0x1.8p+2, 0x1.4p+2, 0x1.8p+1,
      0x1p+1, 0x1p+1, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0,
      0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0
    ), npv = c(
      NaN,
      0x0p+0, 0x1.aaaaaaaaaaaabp-1, 0x1.c71c71c71c71cp-1, 0x1.d1745d1745d17p-1,
      0x1.999999999999ap-1, 0x1.a12f684bda12fp-1, 0x1.999999999999ap-1,
      0x1.9745d1745d174p-1, 0x1.97829cbc14e5ep-1, 0x1.8f5c28f5c28f6p-1,
      0x1.86fb586fb587p-1, 0x1.8888888888889p-1, 0x1.9p-1, 0x1.8f0f0f0f0f0f1p-1,
      0x1.9249249249249p-1, 0x1.93d4bb7e327a9p-1, 0x1.96cb65b2d96cbp-1,
      0x1.914c1bacf914cp-1, 0x1.8bf258bf258bfp-1, 0x1.8d79435e50d79p-1,
      0x1.884fcace213f3p-1, 0x1.8348348348348p-1, 0x1.7e613716aefccp-1,
      0x1.8p-1, 0x1.7b425ed097b42p-1, 0x1.784a062b2e43ep-1, 0x1.7575757575757p-1,
      0x1.7711dc47711dcp-1, 0x1.72c234f72c235p-1, 0x1.745d1745d1746p-1,
      0x1.702e05c0b817p-1, 0x1.71c71c71c71c7p-1, 0x1.69bd37a6f4deap-1,
      0x1.6b5ad6b5ad6b6p-1, 0x1.6cefa8d9df51bp-1, 0x1.7p-1, 0x1.6db6db6db6db7p-1,
      0x1.6a052bf5a814bp-1, 0x1.6cfd7720f353ap-1, 0x1.6969696969697p-1,
      0x1.65e7254813e23p-1, 0x1.6276276276276p-1, 0x1.5f15f15f15f16p-1,
      0x1.5885fb37072d7p-1, 0x1.5555555555555p-1, 0x1.5233ab7315234p-1,
      0x1.4f2094f2094f2p-1, 0x1.4c1bacf914c1cp-1, 0x1.4924924924925p-1,
      0x1.463ae71463ae7p-1
    ), ppv = c(
      0x1.738a31d738a32p-2, 0x1.6db6db6db6db7p-2,
      0x1.7ecdc1cb5d4efp-2, 0x1.89d89d89d89d9p-2, 0x1.9191919191919p-2,
      0x1.9765d9765d976p-2, 0x1.aca6b29aca6b3p-2, 0x1.be5be5be5be5cp-2,
      0x1.dae6076b981dbp-2, 0x1.fp-2, 0x1.e79e79e79e79ep-2, 0x1.ee58469ee5848p-2,
      0x1.04d4873ecade3p-1, 0x1.1a1f58d0fac68p-1, 0x1.27d27d27d27d2p-1,
      0x1.3594d653594d6p-1, 0x1.3cf3cf3cf3cf4p-1, 0x1.4cccccccccccdp-1,
      0x1.4834834834835p-1, 0x1.435e50d79435ep-1, 0x1.4c1bacf914c1cp-1,
      0x1.471c71c71c71dp-1, 0x1.41d41d41d41d4p-1, 0x1.3c3c3c3c3c3c4p-1,
      0x1.45d1745d1745dp-1, 0x1.4p-1, 0x1.4444444444444p-1, 0x1.4924924924925p-1,
      0x1.5555555555555p-1, 0x1.4ec4ec4ec4ec5p-1, 0x1.5c28f5c28f5c3p-1,
      0x1.5555555555555p-1, 0x1.642c8590b2164p-1, 0x1.5555555555556p-1,
      0x1.6666666666667p-1, 0x1.79435e50d7944p-1, 0x1.a5a5a5a5a5a5bp-1,
      0x1.bbbbbbbbbbbbcp-1, 0x1.b6db6db6db6dbp-1, 0x1p+0, 0x1p+0, 0x1p+0,
      0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0,
      NaN
    ), fdr = c(
      0x1.463ae71463ae7p-1, 0x1.4924924924925p-1, 0x1.40991f1a51588p-1,
      0x1.3b13b13b13b14p-1, 0x1.3737373737373p-1, 0x1.344d1344d1345p-1,
      0x1.29aca6b29aca7p-1, 0x1.20d20d20d20d2p-1, 0x1.128cfc4a33f13p-1,
      0x1.08p-1, 0x1.0c30c30c30c31p-1, 0x1.08d3dcb08d3ddp-1, 0x1.f656f1826a43ap-2,
      0x1.cbc14e5e0a72fp-2, 0x1.b05b05b05b05bp-2, 0x1.94d653594d653p-2,
      0x1.8618618618618p-2, 0x1.6666666666666p-2, 0x1.6f96f96f96f97p-2,
      0x1.79435e50d7943p-2, 0x1.67c8a60dd67c9p-2, 0x1.71c71c71c71c7p-2,
      0x1.7c57c57c57c58p-2, 0x1.8787878787878p-2, 0x1.745d1745d1746p-2,
      0x1.8p-2, 0x1.7777777777777p-2, 0x1.6db6db6db6db7p-2, 0x1.5555555555555p-2,
      0x1.6276276276276p-2, 0x1.47ae147ae147bp-2, 0x1.5555555555555p-2,
      0x1.37a6f4de9bd38p-2, 0x1.5555555555555p-2, 0x1.3333333333333p-2,
      0x1.0d79435e50d79p-2, 0x1.6969696969697p-3, 0x1.1111111111111p-3,
      0x1.2492492492492p-3, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0,
      0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, NaN
    ), fpr = c(
      0x1p+0,
      0x1p+0, 0x1.dc71c71c71c72p-1, 0x1.c71c71c71c71cp-1, 0x1.b8e38e38e38e4p-1,
      0x1.8e38e38e38e39p-1, 0x1.638e38e38e38ep-1, 0x1.38e38e38e38e4p-1,
      0x1.071c71c71c71cp-1, 0x1.d555555555556p-2, 0x1.d555555555556p-2,
      0x1.aaaaaaaaaaaaap-2, 0x1.71c71c71c71c8p-2, 0x1.38e38e38e38e4p-2,
      0x1.0e38e38e38e38p-2, 0x1.e38e38e38e39p-3, 0x1.c71c71c71c71cp-3,
      0x1.8e38e38e38e38p-3, 0x1.8e38e38e38e38p-3, 0x1.8e38e38e38e38p-3,
      0x1.71c71c71c71c8p-3, 0x1.71c71c71c71c8p-3, 0x1.71c71c71c71c8p-3,
      0x1.71c71c71c71c8p-3, 0x1.5555555555554p-3, 0x1.5555555555554p-3,
      0x1.38e38e38e38e4p-3, 0x1.1c71c71c71c7p-3, 0x1p-3, 0x1p-3, 0x1.c71c71c71c72p-4,
      0x1.c71c71c71c72p-4, 0x1.8e38e38e38e38p-4, 0x1.8e38e38e38e38p-4,
      0x1.5555555555558p-4, 0x1.1c71c71c71c7p-4, 0x1.555555555555p-5,
      0x1.c71c71c71c72p-6, 0x1.c71c71c71c72p-6, 0x0p+0, 0x0p+0, 0x0p+0,
      0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0,
      0x0p+0
    ), tpr = c(
      0x1p+0, 0x1.f3831f3831f38p-1, 0x1.f3831f3831f38p-1,
      0x1.f3831f3831f38p-1, 0x1.f3831f3831f38p-1, 0x1.ce0c7ce0c7ce1p-1,
      0x1.c18f9c18f9c19p-1, 0x1.a895da895da89p-1, 0x1.8f9c18f9c18fap-1,
      0x1.831f3831f3832p-1, 0x1.76a2576a2576ap-1, 0x1.5da895da895dbp-1,
      0x1.512bb512bb513p-1, 0x1.512bb512bb513p-1, 0x1.44aed44aed44bp-1,
      0x1.44aed44aed44bp-1, 0x1.44aed44aed44bp-1, 0x1.44aed44aed44bp-1,
      0x1.3831f3831f383p-1, 0x1.2bb512bb512bbp-1, 0x1.2bb512bb512bbp-1,
      0x1.1f3831f3831f4p-1, 0x1.12bb512bb512cp-1, 0x1.063e7063e7064p-1,
      0x1.063e7063e7064p-1, 0x1.f3831f3831f38p-2, 0x1.da895da895da9p-2,
      0x1.c18f9c18f9c19p-2, 0x1.c18f9c18f9c19p-2, 0x1.a895da895da89p-2,
      0x1.a895da895da89p-2, 0x1.8f9c18f9c18fap-2, 0x1.8f9c18f9c18fap-2,
      0x1.5da895da895dbp-2, 0x1.5da895da895dbp-2, 0x1.5da895da895dbp-2,
      0x1.5da895da895dbp-2, 0x1.44aed44aed44bp-2, 0x1.2bb512bb512bbp-2,
      0x1.2bb512bb512bbp-2, 0x1.12bb512bb512cp-2, 0x1.f3831f3831f38p-3,
      0x1.c18f9c18f9c19p-3, 0x1.8f9c18f9c18fap-3, 0x1.2bb512bb512bbp-3,
      0x1.f3831f3831f38p-4, 0x1.8f9c18f9c18fap-4, 0x1.2bb512bb512bbp-4,
      0x1.8f9c18f9c18fap-5, 0x1.8f9c18f9c18fap-6, 0x0p+0
    ), tnr = c(
      0x0p+0,
      0x0p+0, 0x1.1c71c71c71c72p-4, 0x1.c71c71c71c71cp-4, 0x1.1c71c71c71c72p-3,
      0x1.c71c71c71c71cp-3, 0x1.38e38e38e38e4p-2, 0x1.8e38e38e38e39p-2,
      0x1.f1c71c71c71c7p-2, 0x1.1555555555555p-1, 0x1.1555555555555p-1,
      0x1.2aaaaaaaaaaabp-1, 0x1.471c71c71c71cp-1, 0x1.638e38e38e38ep-1,
      0x1.78e38e38e38e4p-1, 0x1.871c71c71c71cp-1, 0x1.8e38e38e38e39p-1,
      0x1.9c71c71c71c72p-1, 0x1.9c71c71c71c72p-1, 0x1.9c71c71c71c72p-1,
      0x1.a38e38e38e38ep-1, 0x1.a38e38e38e38ep-1, 0x1.a38e38e38e38ep-1,
      0x1.a38e38e38e38ep-1, 0x1.aaaaaaaaaaaabp-1, 0x1.aaaaaaaaaaaabp-1,
      0x1.b1c71c71c71c7p-1, 0x1.b8e38e38e38e4p-1, 0x1.cp-1, 0x1.cp-1,
      0x1.c71c71c71c71cp-1, 0x1.c71c71c71c71cp-1, 0x1.ce38e38e38e39p-1,
      0x1.ce38e38e38e39p-1, 0x1.d555555555555p-1, 0x1.dc71c71c71c72p-1,
      0x1.eaaaaaaaaaaabp-1, 0x1.f1c71c71c71c7p-1, 0x1.f1c71c71c71c7p-1,
      0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0,
      0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0
    ), fnr = c(
      0x0p+0, 0x1.8f9c18f9c18fap-6,
      0x1.8f9c18f9c18fap-6, 0x1.8f9c18f9c18fap-6, 0x1.8f9c18f9c18fap-6,
      0x1.8f9c18f9c18fap-4, 0x1.f3831f3831f38p-4, 0x1.5da895da895dbp-3,
      0x1.c18f9c18f9c19p-3, 0x1.f3831f3831f38p-3, 0x1.12bb512bb512cp-2,
      0x1.44aed44aed449p-2, 0x1.5da895da895dbp-2, 0x1.5da895da895dbp-2,
      0x1.76a2576a2576ap-2, 0x1.76a2576a2576ap-2, 0x1.76a2576a2576ap-2,
      0x1.76a2576a2576ap-2, 0x1.8f9c18f9c18fap-2, 0x1.a895da895da89p-2,
      0x1.a895da895da89p-2, 0x1.c18f9c18f9c17p-2, 0x1.da895da895da9p-2,
      0x1.f3831f3831f38p-2, 0x1.f3831f3831f38p-2, 0x1.063e7063e7064p-1,
      0x1.12bb512bb512cp-1, 0x1.1f3831f3831f4p-1, 0x1.1f3831f3831f4p-1,
      0x1.2bb512bb512bbp-1, 0x1.2bb512bb512bbp-1, 0x1.3831f3831f383p-1,
      0x1.3831f3831f383p-1, 0x1.512bb512bb513p-1, 0x1.512bb512bb513p-1,
      0x1.512bb512bb513p-1, 0x1.512bb512bb513p-1, 0x1.5da895da895dbp-1,
      0x1.6a2576a2576a2p-1, 0x1.6a2576a2576a2p-1, 0x1.76a2576a2576ap-1,
      0x1.831f3831f3832p-1, 0x1.8f9c18f9c18fap-1, 0x1.9c18f9c18f9c2p-1,
      0x1.b512bb512bb51p-1, 0x1.c18f9c18f9c19p-1, 0x1.ce0c7ce0c7ce1p-1,
      0x1.da895da895da9p-1, 0x1.e7063e7063e7p-1, 0x1.f3831f3831f38p-1,
      0x1p+0
    ), `1-specificity` = c(
      0x1p+0, 0x1p+0, 0x1.dc71c71c71c72p-1,
      0x1.c71c71c71c71cp-1, 0x1.b8e38e38e38e4p-1, 0x1.8e38e38e38e39p-1,
      0x1.638e38e38e38ep-1, 0x1.38e38e38e38e4p-1, 0x1.071c71c71c71cp-1,
      0x1.d555555555556p-2, 0x1.d555555555556p-2, 0x1.aaaaaaaaaaaaap-2,
      0x1.71c71c71c71c8p-2, 0x1.38e38e38e38e4p-2, 0x1.0e38e38e38e38p-2,
      0x1.e38e38e38e39p-3, 0x1.c71c71c71c71cp-3, 0x1.8e38e38e38e38p-3,
      0x1.8e38e38e38e38p-3, 0x1.8e38e38e38e38p-3, 0x1.71c71c71c71c8p-3,
      0x1.71c71c71c71c8p-3, 0x1.71c71c71c71c8p-3, 0x1.71c71c71c71c8p-3,
      0x1.5555555555554p-3, 0x1.5555555555554p-3, 0x1.38e38e38e38e4p-3,
      0x1.1c71c71c71c7p-3, 0x1p-3, 0x1p-3, 0x1.c71c71c71c72p-4, 0x1.c71c71c71c72p-4,
      0x1.8e38e38e38e38p-4, 0x1.8e38e38e38e38p-4, 0x1.5555555555558p-4,
      0x1.1c71c71c71c7p-4, 0x1.555555555555p-5, 0x1.c71c71c71c72p-6,
      0x1.c71c71c71c72p-6, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0,
      0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0
    ), `1-sensitivity` = c(
      0x0p+0,
      0x1.8f9c18f9c19p-6, 0x1.8f9c18f9c19p-6, 0x1.8f9c18f9c19p-6, 0x1.8f9c18f9c19p-6,
      0x1.8f9c18f9c18f8p-4, 0x1.f3831f3831f38p-4, 0x1.5da895da895dcp-3,
      0x1.c18f9c18f9c18p-3, 0x1.f3831f3831f38p-3, 0x1.12bb512bb512cp-2,
      0x1.44aed44aed44ap-2, 0x1.5da895da895dap-2, 0x1.5da895da895dap-2,
      0x1.76a2576a2576ap-2, 0x1.76a2576a2576ap-2, 0x1.76a2576a2576ap-2,
      0x1.76a2576a2576ap-2, 0x1.8f9c18f9c18fap-2, 0x1.a895da895da8ap-2,
      0x1.a895da895da8ap-2, 0x1.c18f9c18f9c18p-2, 0x1.da895da895da8p-2,
      0x1.f3831f3831f38p-2, 0x1.f3831f3831f38p-2, 0x1.063e7063e7064p-1,
      0x1.12bb512bb512cp-1, 0x1.1f3831f3831f4p-1, 0x1.1f3831f3831f4p-1,
      0x1.2bb512bb512bcp-1, 0x1.2bb512bb512bcp-1, 0x1.3831f3831f383p-1,
      0x1.3831f3831f383p-1, 0x1.512bb512bb512p-1, 0x1.512bb512bb512p-1,
      0x1.512bb512bb512p-1, 0x1.512bb512bb512p-1, 0x1.5da895da895dap-1,
      0x1.6a2576a2576a2p-1, 0x1.6a2576a2576a2p-1, 0x1.76a2576a2576ap-1,
      0x1.831f3831f3832p-1, 0x1.8f9c18f9c18fap-1, 0x1.9c18f9c18f9c2p-1,
      0x1.b512bb512bb51p-1, 0x1.c18f9c18f9c19p-1, 0x1.ce0c7ce0c7ce1p-1,
      0x1.da895da895da9p-1, 0x1.e7063e7063e7p-1, 0x1.f3831f3831f38p-1,
      0x1p+0
    ), `1-accuracy` = c(
      0x1.463ae71463ae7p-1, 0x1.4ac2d4f4ac2d5p-1,
      0x1.341b2f9341b3p-1, 0x1.268365f268366p-1, 0x1.1d738a31d738ap-1,
      0x1.0fdbc090fdbcp-1, 0x1.f268365f26836p-2, 0x1.ce28c75ce28c8p-2,
      0x1.a0d97c9a0d97cp-2, 0x1.85a9e9585a9eap-2, 0x1.8eb9c518eb9c6p-2,
      0x1.85a9e9585a9eap-2, 0x1.6a7a5616a7a56p-2, 0x1.463ae71463ae8p-2,
      0x1.341b2f9341b3p-2, 0x1.21fb78121fb78p-2, 0x1.18eb9c518eb9cp-2,
      0x1.06cbe4d06cbe4p-2, 0x1.0fdbc090fdbcp-2, 0x1.18eb9c518eb9cp-2,
      0x1.0fdbc090fdbcp-2, 0x1.18eb9c518eb9cp-2, 0x1.21fb78121fb78p-2,
      0x1.2b0b53d2b0b54p-2, 0x1.21fb78121fb78p-2, 0x1.2b0b53d2b0b54p-2,
      0x1.2b0b53d2b0b54p-2, 0x1.2b0b53d2b0b54p-2, 0x1.21fb78121fb78p-2,
      0x1.2b0b53d2b0b54p-2, 0x1.21fb78121fb78p-2, 0x1.2b0b53d2b0b54p-2,
      0x1.21fb78121fb78p-2, 0x1.341b2f9341b3p-2, 0x1.2b0b53d2b0b54p-2,
      0x1.21fb78121fb78p-2, 0x1.0fdbc090fdbcp-2, 0x1.0fdbc090fdbcp-2,
      0x1.18eb9c518eb9cp-2, 0x1.06cbe4d06cbe4p-2, 0x1.0fdbc090fdbcp-2,
      0x1.18eb9c518eb9cp-2, 0x1.21fb78121fb78p-2, 0x1.2b0b53d2b0b54p-2,
      0x1.3d2b0b53d2b0cp-2, 0x1.463ae71463ae8p-2, 0x1.4f4ac2d4f4ac2p-2,
      0x1.585a9e9585a9ep-2, 0x1.616a7a5616a7ap-2, 0x1.6a7a5616a7a56p-2,
      0x1.738a31d738a32p-2
    ), `1-npv` = c(
      NaN, 0x1p+0, 0x1.5555555555554p-3,
      0x1.c71c71c71c72p-4, 0x1.745d1745d1748p-4, 0x1.9999999999998p-3,
      0x1.7b425ed097b44p-3, 0x1.9999999999998p-3, 0x1.a2e8ba2e8ba3p-3,
      0x1.a1f58d0fac688p-3, 0x1.c28f5c28f5c28p-3, 0x1.e4129e4129e4p-3,
      0x1.ddddddddddddcp-3, 0x1.cp-3, 0x1.c3c3c3c3c3c3cp-3, 0x1.b6db6db6db6dcp-3,
      0x1.b0ad12073615cp-3, 0x1.a4d269349a4d4p-3, 0x1.bacf914c1badp-3,
      0x1.d0369d0369d04p-3, 0x1.ca1af286bca1cp-3, 0x1.dec0d4c77b034p-3,
      0x1.f2df2df2df2ep-3, 0x1.033d91d2a2068p-2, 0x1p-2, 0x1.097b425ed097cp-2,
      0x1.0f6bf3a9a3784p-2, 0x1.1515151515152p-2, 0x1.11dc47711dc48p-2,
      0x1.1a7b9611a7b96p-2, 0x1.1745d1745d174p-2, 0x1.1fa3f47e8fd2p-2,
      0x1.1c71c71c71c72p-2, 0x1.2c8590b21642cp-2, 0x1.294a5294a5294p-2,
      0x1.2620ae4c415cap-2, 0x1.2p-2, 0x1.2492492492492p-2, 0x1.2bf5a814afd6ap-2,
      0x1.260511be1958cp-2, 0x1.2d2d2d2d2d2d2p-2, 0x1.3431b56fd83bap-2,
      0x1.3b13b13b13b14p-2, 0x1.41d41d41d41d4p-2, 0x1.4ef40991f1a52p-2,
      0x1.5555555555556p-2, 0x1.5b98a919d5b98p-2, 0x1.61bed61bed61cp-2,
      0x1.67c8a60dd67c8p-2, 0x1.6db6db6db6db6p-2, 0x1.738a31d738a32p-2
    ), `1-ppv` = c(
      0x1.463ae71463ae7p-1, 0x1.4924924924924p-1, 0x1.40991f1a51588p-1,
      0x1.3b13b13b13b14p-1, 0x1.3737373737374p-1, 0x1.344d1344d1345p-1,
      0x1.29aca6b29aca6p-1, 0x1.20d20d20d20d2p-1, 0x1.128cfc4a33f12p-1,
      0x1.08p-1, 0x1.0c30c30c30c31p-1, 0x1.08d3dcb08d3dcp-1, 0x1.f656f1826a43ap-2,
      0x1.cbc14e5e0a73p-2, 0x1.b05b05b05b05cp-2, 0x1.94d653594d654p-2,
      0x1.8618618618618p-2, 0x1.6666666666666p-2, 0x1.6f96f96f96f96p-2,
      0x1.79435e50d7944p-2, 0x1.67c8a60dd67c8p-2, 0x1.71c71c71c71c6p-2,
      0x1.7c57c57c57c58p-2, 0x1.8787878787878p-2, 0x1.745d1745d1746p-2,
      0x1.8p-2, 0x1.7777777777778p-2, 0x1.6db6db6db6db6p-2, 0x1.5555555555556p-2,
      0x1.6276276276276p-2, 0x1.47ae147ae147ap-2, 0x1.5555555555556p-2,
      0x1.37a6f4de9bd38p-2, 0x1.5555555555554p-2, 0x1.3333333333332p-2,
      0x1.0d79435e50d78p-2, 0x1.6969696969694p-3, 0x1.111111111111p-3,
      0x1.2492492492494p-3, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0,
      0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, 0x0p+0, NaN
    ), precision = c(
      0x1.738a31d738a32p-2,
      0x1.6db6db6db6db7p-2, 0x1.7ecdc1cb5d4efp-2, 0x1.89d89d89d89d9p-2,
      0x1.9191919191919p-2, 0x1.9765d9765d976p-2, 0x1.aca6b29aca6b3p-2,
      0x1.be5be5be5be5cp-2, 0x1.dae6076b981dbp-2, 0x1.fp-2, 0x1.e79e79e79e79ep-2,
      0x1.ee58469ee5848p-2, 0x1.04d4873ecade3p-1, 0x1.1a1f58d0fac68p-1,
      0x1.27d27d27d27d2p-1, 0x1.3594d653594d6p-1, 0x1.3cf3cf3cf3cf4p-1,
      0x1.4cccccccccccdp-1, 0x1.4834834834835p-1, 0x1.435e50d79435ep-1,
      0x1.4c1bacf914c1cp-1, 0x1.471c71c71c71dp-1, 0x1.41d41d41d41d4p-1,
      0x1.3c3c3c3c3c3c4p-1, 0x1.45d1745d1745dp-1, 0x1.4p-1, 0x1.4444444444444p-1,
      0x1.4924924924925p-1, 0x1.5555555555555p-1, 0x1.4ec4ec4ec4ec5p-1,
      0x1.5c28f5c28f5c3p-1, 0x1.5555555555555p-1, 0x1.642c8590b2164p-1,
      0x1.5555555555556p-1, 0x1.6666666666667p-1, 0x1.79435e50d7944p-1,
      0x1.a5a5a5a5a5a5bp-1, 0x1.bbbbbbbbbbbbcp-1, 0x1.b6db6db6db6dbp-1,
      0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0, 0x1p+0,
      0x1p+0, 0x1p+0, 0x1p+0, NaN
    ), recall = c(
      0x1p+0, 0x1.f3831f3831f38p-1,
      0x1.f3831f3831f38p-1, 0x1.f3831f3831f38p-1, 0x1.f3831f3831f38p-1,
      0x1.ce0c7ce0c7ce1p-1, 0x1.c18f9c18f9c19p-1, 0x1.a895da895da89p-1,
      0x1.8f9c18f9c18fap-1, 0x1.831f3831f3832p-1, 0x1.76a2576a2576ap-1,
      0x1.5da895da895dbp-1, 0x1.512bb512bb513p-1, 0x1.512bb512bb513p-1,
      0x1.44aed44aed44bp-1, 0x1.44aed44aed44bp-1, 0x1.44aed44aed44bp-1,
      0x1.44aed44aed44bp-1, 0x1.3831f3831f383p-1, 0x1.2bb512bb512bbp-1,
      0x1.2bb512bb512bbp-1, 0x1.1f3831f3831f4p-1, 0x1.12bb512bb512cp-1,
      0x1.063e7063e7064p-1, 0x1.063e7063e7064p-1, 0x1.f3831f3831f38p-2,
      0x1.da895da895da9p-2, 0x1.c18f9c18f9c19p-2, 0x1.c18f9c18f9c19p-2,
      0x1.a895da895da89p-2, 0x1.a895da895da89p-2, 0x1.8f9c18f9c18fap-2,
      0x1.8f9c18f9c18fap-2, 0x1.5da895da895dbp-2, 0x1.5da895da895dbp-2,
      0x1.5da895da895dbp-2, 0x1.5da895da895dbp-2, 0x1.44aed44aed44bp-2,
      0x1.2bb512bb512bbp-2, 0x1.2bb512bb512bbp-2, 0x1.12bb512bb512cp-2,
      0x1.f3831f3831f38p-3, 0x1.c18f9c18f9c19p-3, 0x1.8f9c18f9c18fap-3,
      0x1.2bb512bb512bbp-3, 0x1.f3831f3831f38p-4, 0x1.8f9c18f9c18fap-4,
      0x1.2bb512bb512bbp-4, 0x1.8f9c18f9c18fap-5, 0x1.8f9c18f9c18fap-6,
      0x0p+0
    ), lr_pos = c(
      0x1p+0, 0x1.f3831f3831f38p-1, 0x1.0c65054fddb48p+0,
      0x1.18f9c18f9c19p+0, 0x1.220a1220a122p+0, 0x1.29080722c996cp+0,
      0x1.43af143af143bp+0, 0x1.5b6355b6355b5p+0, 0x1.84cf3ae52b085p+0,
      0x1.a6509a6509a64p+0, 0x1.98b1198b1198ap+0, 0x1.a3971a3971a3bp+0,
      0x1.d2da0e68b497cp+0, 0x1.13ddf13ddf13ep+1, 0x1.3398276f67848p+1,
      0x1.57c82c131957bp+1, 0x1.6d44aed44aed5p+1, 0x1.a17310f29ec61p+1,
      0x1.9164cb5f71485p+1, 0x1.815685cc43ca8p+1, 0x1.9efab77984151p+1,
      0x1.8db04529c93eep+1, 0x1.7c65d2da0e68bp+1, 0x1.6b1b608a53927p+1,
      0x1.895da895da898p+1, 0x1.76a2576a2576bp+1, 0x1.8441d8441d844p+1,
      0x1.949ad949ad94cp+1, 0x1.c18f9c18f9c19p+1, 0x1.a895da895da89p+1,
      0x1.dda895da895d6p+1, 0x1.c18f9c18f9c16p+1, 0x1.00e45932d7dc6p+2,
      0x1.c18f9c18f9c1bp+1, 0x1.063e7063e7062p+2, 0x1.3ab153ab153adp+2,
      0x1.063e7063e7068p+3, 0x1.6d44aed44aed2p+3, 0x1.512bb512bb51p+3,
      Inf, Inf, Inf, Inf, Inf, Inf, Inf, Inf, Inf, Inf, Inf, NaN
    ),
    lr_neg = c(
      NaN, Inf, 0x1.67a6167a6168p-2, 0x1.c18f9c18f9c2p-3,
      0x1.67a6167a6168p-3, 0x1.c18f9c18f9c17p-2, 0x1.98b1198b1198ap-2,
      0x1.c18f9c18f9c1bp-2, 0x1.ce67d3c1eaf2fp-2, 0x1.cd1692f8cba5cp-2,
      0x1.fb326e7813366p-2, 0x1.164cb5f71483fp-1, 0x1.11a553e2ae495p-1,
      0x1.f7821f7821f78p-2, 0x1.fcefdc2f9853dp-2, 0x1.ea6e1ea6e1ea7p-2,
      0x1.e1ac273f54bd1p-2, 0x1.d11025e4df0edp-2, 0x1.f011397ca9a97p-2,
      0x1.0789268a3a221p-1, 0x1.0311ac652c218p-1, 0x1.124ef2c57a054p-1,
      0x1.218c3925c7e92p-1, 0x1.30c97f8615cdp-1, 0x1.2bb512bb512bbp-1,
      0x1.3ab153ab153abp-1, 0x1.4446037aeee8p-1, 0x1.4d8b94d8b94d9p-1,
      0x1.484039164cb6p-1, 0x1.5685cc43ca7b2p-1, 0x1.512bb512bb514p-1,
      0x1.5f3831f3831f4p-1, 0x1.59d0ee3a98bc4p-1, 0x1.757b3eba2a12fp-1,
      0x1.6fd296fd296fdp-1, 0x1.6a552d92381a1p-1, 0x1.5fd4906c96f07p-1,
      0x1.67a6167a6167ap-1, 0x1.747e4e2352991p-1, 0x1.6a2576a2576a2p-1,
      0x1.76a2576a2576ap-1, 0x1.831f3831f3832p-1, 0x1.8f9c18f9c18fap-1,
      0x1.9c18f9c18f9c2p-1, 0x1.b512bb512bb51p-1, 0x1.c18f9c18f9c19p-1,
      0x1.ce0c7ce0c7ce1p-1, 0x1.da895da895da9p-1, 0x1.e7063e7063e7p-1,
      0x1.f3831f3831f38p-1, 0x1p+0
    ), youden = c(
      0x1p+0, 0x1.f3831f3831f38p-1,
      0x1.0b88ac0de0163p+0, 0x1.163356b88ac0ep+0, 0x1.1d4fc87fa732ap+0,
      0x1.1fe9cca947754p+0, 0x1.2f00b19ab5c46p+0, 0x1.37d926283d0d3p+0,
      0x1.443fd399528efp+0, 0x1.4c3a46c3a46c4p+0, 0x1.45fbd65fbd66p+0,
      0x1.4429a0429a043p+0, 0x1.4c24136cebe18p+0, 0x1.5a5cf6fb24c5p+0,
      0x1.5ec93141e8698p+0, 0x1.65e5a30904db4p+0, 0x1.6973dbec93142p+0,
      0x1.70904db3af85ep+0, 0x1.6a51dd4fc87fap+0, 0x1.64136cebe1796p+0,
      0x1.67a1a5cf6fb24p+0, 0x1.6163356b88ac1p+0, 0x1.5b24c507a1a5dp+0,
      0x1.54e654a3ba9f9p+0, 0x1.58748d8748d88p+0, 0x1.52361d2361d24p+0,
      0x1.4f85e5a30904ep+0, 0x1.4cd5ae22b0378p+0, 0x1.5063e7063e706p+0,
      0x1.4a2576a2576a2p+0, 0x1.4db3af85e5a3p+0, 0x1.47753f21fe9ccp+0,
      0x1.4b0378058cd5bp+0, 0x1.3e86973dbec93p+0, 0x1.4214d0214d021p+0,
      0x1.45a30904db3bp+0, 0x1.4cbf7acbf7accp+0, 0x1.4a0f434b9edf6p+0,
      0x1.43d0d2e7b7d92p+0, 0x1.4aed44aed44afp+0, 0x1.44aed44aed44bp+0,
      0x1.3e7063e7063e7p+0, 0x1.3831f3831f383p+0, 0x1.31f3831f3831fp+0,
      0x1.2576a2576a257p+0, 0x1.1f3831f3831f4p+0, 0x1.18f9c18f9c19p+0,
      0x1.12bb512bb512cp+0, 0x1.0c7ce0c7ce0c8p+0, 0x1.063e7063e7064p+0,
      0x1p+0
    ), closest.topleft = c(
      0x1p+0, 0x1.0026fc7f508fcp+0,
      0x1.bba9a08035aa9p-1, 0x1.94d908cc0fbd8p-1, 0x1.7bf57a932c2f6p-1,
      0x1.3a9a08035aa96p-1, 0x1.fd0e6285bdb01p-2, 0x1.9c44c669e0a2dp-2,
      0x1.3fc3061228843p-2, 0x1.1406f8b4fd12ap-2, 0x1.20d1d27b6c3eap-2,
      0x1.18b9dca282bb8p-2, 0x1.f9da593c0e914p-3, 0x1.ae00464589d39p-3,
      0x1.a0bd65809f12ep-3, 0x1.844b9e642d4bep-3, 0x1.77422321ce7b3p-3,
      0x1.5f8dfd34c4ffep-3, 0x1.8552988ad044ep-3, 0x1.ad86fbd5e4862p-3,
      0x1.a2dc512b39db8p-3, 0x1.cd807c6b5718cp-3, 0x1.fa946fa07d526p-3,
      0x1.150c156556441p-2, 0x1.101be2d3f44a6p-2, 0x1.2915a46390636p-2,
      0x1.3ebc3a20425c7p-2, 0x1.55ffd69b6c2f4p-2, 0x1.523f0c55e4489p-2,
      0x1.6ee079d50ddbep-2, 0x1.6b84d2537950dp-2, 0x1.895e23cd27621p-2,
      0x1.86679f0f8632ap-2, 0x1.c5c1edf26fcf8p-2, 0x1.c3308bf8c1fbdp-2,
      0x1.c1044cc30783bp-2, 0x1.bddb36a36ca67p-2, 0x1.de5f5d22c7cdp-2,
      0x1.008c1f4343eb6p-1, 0x1.0026fc7f508fcp-1, 0x1.121f5f2e72d3bp-1,
      0x1.24b3b3dad756bp-1, 0x1.37e3fa847e18bp-1, 0x1.4bb0332b6719cp-1,
      0x1.751c7a70ffd9p-1, 0x1.8abc890faf974p-1, 0x1.a0f889aba1948p-1,
      0x1.b7d07c44d5d0dp-1, 0x1.cf4460db4c4c2p-1, 0x1.e754376f05068p-1,
      0x1p+0
    )
  ), class = "data.frame", row.names = c(NA, -51L))
r.s100b.reversed <- roc(aSAH$outcome, aSAH$s100b, direction = ">", quiet = TRUE)

# expected.coords.reverse <- coords(r.s100b.reversed, c(0.05, 0.055, 0.205, 0.52), ret="all")
# dump("expected.coords.reverse", "", control = c("all", "hexNumeric"))

expected.coords.reverse <-
  structure(list(threshold = c(
    0x1.999999999999ap-5, 0x1.c28f5c28f5c29p-5,
    0x1.a3d70a3d70a3dp-3, 0x1.0a3d70a3d70a4p-1
  ), specificity = c(
    0x1.c71c71c71c71cp-1,
    0x1.c71c71c71c71cp-1, 0x1.8e38e38e38e39p-3, 0x0p+0
  ), sensitivity = c(
    0x1.8f9c18f9c18fap-6,
    0x1.8f9c18f9c18fap-6, 0x1.76a2576a2576ap-2, 0x1.76a2576a2576ap-1
  ), accuracy = c(
    0x1.268365f268366p-1, 0x1.268365f268366p-1, 0x1.06cbe4d06cbe5p-2,
    0x1.0fdbc090fdbc1p-2
  ), tn = c(0x1p+6, 0x1p+6, 0x1.cp+3, 0x0p+0), tp = c(0x1p+0, 0x1p+0, 0x1.ep+3, 0x1.ep+4), fn = c(
    0x1.4p+5,
    0x1.4p+5, 0x1.ap+4, 0x1.6p+3
  ), fp = c(
    0x1p+3, 0x1p+3, 0x1.dp+5,
    0x1.2p+6
  ), npv = c(
    0x1.3b13b13b13b14p-1, 0x1.3b13b13b13b14p-1,
    0x1.6666666666666p-2, 0x0p+0
  ), ppv = c(
    0x1.c71c71c71c71cp-4,
    0x1.c71c71c71c71cp-4, 0x1.a4d269349a4d2p-3, 0x1.2d2d2d2d2d2d3p-2
  ), fdr = c(
    0x1.c71c71c71c71cp-1, 0x1.c71c71c71c71cp-1, 0x1.96cb65b2d96cbp-1,
    0x1.6969696969697p-1
  ), fpr = c(
    0x1.c71c71c71c72p-4, 0x1.c71c71c71c72p-4,
    0x1.9c71c71c71c72p-1, 0x1p+0
  ), tpr = c(
    0x1.8f9c18f9c18fap-6,
    0x1.8f9c18f9c18fap-6, 0x1.76a2576a2576ap-2, 0x1.76a2576a2576ap-1
  ), tnr = c(
    0x1.c71c71c71c71cp-1, 0x1.c71c71c71c71cp-1, 0x1.8e38e38e38e39p-3,
    0x0p+0
  ), fnr = c(
    0x1.f3831f3831f38p-1, 0x1.f3831f3831f38p-1,
    0x1.44aed44aed44bp-1, 0x1.12bb512bb512cp-2
  ), `1-specificity` = c(
    0x1.c71c71c71c72p-4,
    0x1.c71c71c71c72p-4, 0x1.9c71c71c71c72p-1, 0x1p+0
  ), `1-sensitivity` = c(
    0x1.f3831f3831f38p-1,
    0x1.f3831f3831f38p-1, 0x1.44aed44aed44bp-1, 0x1.12bb512bb512cp-2
  ), `1-accuracy` = c(
    0x1.b2f9341b2f934p-2, 0x1.b2f9341b2f934p-2,
    0x1.7c9a0d97c9a0ep-1, 0x1.78121fb78122p-1
  ), `1-npv` = c(
    0x1.89d89d89d89d8p-2,
    0x1.89d89d89d89d8p-2, 0x1.4cccccccccccdp-1, 0x1p+0
  ), `1-ppv` = c(
    0x1.c71c71c71c71cp-1,
    0x1.c71c71c71c71cp-1, 0x1.96cb65b2d96ccp-1, 0x1.6969696969696p-1
  ), precision = c(
    0x1.c71c71c71c71cp-4, 0x1.c71c71c71c71cp-4,
    0x1.a4d269349a4d2p-3, 0x1.2d2d2d2d2d2d3p-2
  ), recall = c(
    0x1.8f9c18f9c18fap-6,
    0x1.8f9c18f9c18fap-6, 0x1.76a2576a2576ap-2, 0x1.76a2576a2576ap-1
  ), lr_pos = c(
    0x1.c18f9c18f9c16p-3, 0x1.c18f9c18f9c16p-3, 0x1.d11025e4df0edp-2,
    0x1.76a2576a2576ap-1
  ), lr_neg = c(
    0x1.18f9c18f9c19p+0, 0x1.18f9c18f9c19p+0,
    0x1.a17310f29ec6p+1, Inf
  ), youden = c(
    0x1.d399528eea7e4p-1, 0x1.d399528eea7e4p-1,
    0x1.1edf6498a0f43p-1, 0x1.76a2576a2576ap-1
  ), closest.topleft = c(
    0x1.eda663ae3ac1p-1,
    0x1.eda663ae3ac1p-1, 0x1.0d125b0df7abdp+0, 0x1.126d582d13f33p+0
  )), class = "data.frame", row.names = c(NA, -4L))
