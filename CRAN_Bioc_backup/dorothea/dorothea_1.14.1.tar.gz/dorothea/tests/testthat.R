library(testthat)
library(dorothea)

test_check("dorothea")
