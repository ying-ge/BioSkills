#' @keywords internal
#' @description{
#' \if{html}{\figure{tool_logo.png}{options: align='right' alt='logo' width='120'}}
#' This package contains human and mouse TF regulons.
#'
#' }
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
## usethis namespace: end
NULL
