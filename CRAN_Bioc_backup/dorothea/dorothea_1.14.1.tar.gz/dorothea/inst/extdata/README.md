### Extdata

DoRothEA is constructed based on the networks in the directory `networks`.  

The data to construct those networks is available at Zenodo:

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.3713238.svg)](https://doi.org/10.5281/zenodo.3713238)

Please place the folder `tf_target_sources` at this directory level and use the scripts `01_*-04_*.R` in the [scripts](https://github.com/saezlab/dorothea/tree/master/inst/scripts) directory to reproduce the network generation workflow.
