### Scripts
The scripts `01_*-04_*.R` build the individual TF-target networks for each evidence/dataset combination. You can find the final networks [here](https://github.com/saezlab/dorothea/tree/master/inst/extdata/networks).

The script `05_consensus.R` integrates all those networks to the final DoRothEA resource.
