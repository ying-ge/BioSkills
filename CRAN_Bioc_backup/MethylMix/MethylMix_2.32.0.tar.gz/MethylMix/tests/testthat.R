library(testthat)
library(MethylMix)

test_check("MethylMix")
