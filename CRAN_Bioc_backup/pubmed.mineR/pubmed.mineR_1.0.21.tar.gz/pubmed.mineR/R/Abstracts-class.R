setClass("Abstracts", representation(Journal = "character", Abstract = "character",PMID = "numeric"));



