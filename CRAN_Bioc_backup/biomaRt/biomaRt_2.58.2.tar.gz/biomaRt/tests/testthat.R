library(testthat)
library(mockery)
library(biomaRt)

test_check("biomaRt", encoding = "UTF-8")