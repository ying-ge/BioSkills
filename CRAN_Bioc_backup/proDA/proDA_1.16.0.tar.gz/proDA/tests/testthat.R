library(testthat)
library(proDA)

test_check("proDA")
