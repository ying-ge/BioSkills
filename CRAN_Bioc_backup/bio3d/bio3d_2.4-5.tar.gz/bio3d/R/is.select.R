is.select <- function(x)
  inherits(x, "select")