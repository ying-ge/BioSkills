is.pdb <- function(x)
  inherits(x, "pdb")

is.pdbs <- function(x)
  inherits(x, "pdbs")

