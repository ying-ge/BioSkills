"nma" <- function(...) {
  UseMethod("nma")
}

