#' @rdname aanma.pdb
"aanma" <- function(...) {
  UseMethod("aanma")
}
