"atom.select" <- function(...)
  UseMethod("atom.select")
