library(testthat)
library(GEOquery)

test_check("GEOquery")
