# GEOquery 2.63.2

* Added a `NEWS.md` file to track changes to the package.
