
[![Build
Status](https://travis-ci.org/sneumann/Rdisop.svg?branch=master)](https://travis-ci.org/sneumann/Rdisop)
