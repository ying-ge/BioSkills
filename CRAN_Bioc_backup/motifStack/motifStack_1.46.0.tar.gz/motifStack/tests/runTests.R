require("motifStack") || stop("unable to load Package:motifStack")
require("TFBSTools") || stop("unable to load Package:TFBSTools")
#require("MotifDb") || stop("unalble to load Package::motifDb")
BiocGenerics:::testPackage("motifStack")