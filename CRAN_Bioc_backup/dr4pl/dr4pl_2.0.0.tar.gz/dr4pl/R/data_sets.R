#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_1
#' @name sample_data_1
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_1)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_2
#' @name sample_data_2
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_2)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_3
#' @name sample_data_3
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_3)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_4
#' @name sample_data_4
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_4)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_5
#' @name sample_data_5
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_5)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_6
#' @name sample_data_6
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_6)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_7
#' @name sample_data_7
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_7)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_8
#' @name sample_data_8
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_8)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_9
#' @name sample_data_9
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_9)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_10
#' @name sample_data_10
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_10)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_11
#' @name sample_data_11
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_11)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_12
#' @name sample_data_12
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_12)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These may or may not have numerical errors in other dose-response curve-packages, but definitly not using these methods.
#' @title sample_data_13
#' @name sample_data_13
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = sample_data_13)
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These all have numerical errors in other dose-response curve-packages, but not using these methods.
#' This data set exemplifies the case of a single extreme outlier of one dose measurement. 
#' @title Single High Outlier
#' @name drc_error_1
#' @docType data
#' @keywords sample_data
#' @examples 
#'   a <- dr4pl(Response~Dose, data = drc_error_1, method.init = "logistic", method.robust = "Tukey")
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These all have numerical errors in other dose-response curve-packages, but not using these methods.
#' This data set exemplifies the case of multiple outliers as well as a small number of observations per dose measurement.
#' @title Multiple High Outliers at Different measurements 
#' @name drc_error_2
#' @docType data
#' @keywords sample_data
#' @examples 
#'   a <- dr4pl(Response~Dose, data = drc_error_2, trend = "decreasing", method.optim = "CG")
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These all have numerical errors in other dose-response curve-packages, but not using these methods.
#' This data set exemplifies the case of multiple outliers at a single dose measurement as well as the support problem.
#' @title Support Problem and Outliers at a Single Dose Level
#' @name drc_error_3
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = drc_error_3, method.init = "Mead", method.robust = "Huber")
#'   plot(a)
NULL
#' These are a handful of experimentally derived datasets from the wet-laboratory.
#' These all have numerical errors in other dose-response curve-packages, but not using these methods.
#' This data set exemplifies the support problem.
#' @title Support Problem
#' @name drc_error_4
#' @docType data
#' @keywords sample_data
#' @examples
#'   a <- dr4pl(Response~Dose, data = drc_error_4, method.init = "logistic")
#'   plot(a)
NULL