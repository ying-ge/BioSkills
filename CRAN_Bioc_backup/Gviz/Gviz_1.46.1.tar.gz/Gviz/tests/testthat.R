library(testthat)
library(Gviz)

test_check("Gviz")
