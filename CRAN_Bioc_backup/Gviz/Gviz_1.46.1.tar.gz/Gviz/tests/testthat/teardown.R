## teardown
unlink("../Rplots.pdf") # in `Gviz` main directory
