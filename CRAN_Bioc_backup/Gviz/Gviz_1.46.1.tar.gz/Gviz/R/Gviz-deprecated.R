#' Deprecated functions in package `Gviz`
#'
#' @name Gviz-deprecated
#'
#' @description These functions are provided for compatibility with older
#' versions of `Gviz` only, and will be defunct at the next release.
#' ## The following functions are deprecated and will be made defunct (use the replacement indicated below):
#'
#' (none)
NULL
