#' Defunct functions in package `Gviz`
#'
#' @name Gviz-defunct
#'
#' @description These functions are defunct and no longer available.
#' ## Defunct functions are:
#'
#' (none)
NULL
