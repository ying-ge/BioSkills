library(testthat)
library(survminer)

test_check("survminer")
