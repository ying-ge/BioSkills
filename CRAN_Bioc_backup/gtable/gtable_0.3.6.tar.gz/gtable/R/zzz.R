release_extra_revdeps <- function() {
  c(
    "ggplot2"
  )
}
