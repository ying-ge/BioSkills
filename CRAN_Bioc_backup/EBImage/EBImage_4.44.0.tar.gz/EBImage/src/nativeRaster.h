#ifndef EBIMAGE_NATIVERASTER_H
#define EBIMAGE_NATIVERASTER_H

#include <R.h>
#include <Rdefines.h>

#ifdef __cplusplus
extern "C" {
#endif

SEXP nativeRaster (SEXP);

#ifdef __cplusplus
};
#endif

#endif
