#ifndef EBIMAGE_DRAWCIRCLE_H
#define EBIMAGE_DRAWCIRCLE_H

#include <R.h>
#include <Rdefines.h>

#ifdef __cplusplus
extern "C" {
#endif
  
  SEXP drawCircle (SEXP, SEXP, SEXP, SEXP);
  
#ifdef __cplusplus
};
#endif

#endif

