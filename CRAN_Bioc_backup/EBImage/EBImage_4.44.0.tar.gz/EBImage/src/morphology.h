#ifndef EBIMAGE_MORPH_H
#define EBIMAGE_MORPH_H

#include <R.h>
#include <Rdefines.h>

#ifdef __cplusplus
extern "C" {
#endif
  
SEXP morphology (SEXP, SEXP, SEXP);
  
#ifdef __cplusplus
};
#endif

#endif
