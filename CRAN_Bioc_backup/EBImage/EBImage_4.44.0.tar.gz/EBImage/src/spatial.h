#ifndef EBIMAGE_SPATIAL_H
#define EBIMAGE_SPATIAL_H

#include <R.h>
#include <Rdefines.h>

#ifdef __cplusplus
extern "C" {
#endif

SEXP affine (SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);

#ifdef __cplusplus
};
#endif

#endif
