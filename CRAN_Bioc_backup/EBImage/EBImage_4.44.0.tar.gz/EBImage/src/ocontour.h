#ifndef EBIMAGE_OCONTOUR_H
#define EBIMAGE_OCONTOUR_H

#include <R.h>
#include <Rdefines.h>

#ifdef __cplusplus
extern "C" {
#endif

SEXP ocontour (SEXP);

#ifdef __cplusplus
};
#endif

#endif
