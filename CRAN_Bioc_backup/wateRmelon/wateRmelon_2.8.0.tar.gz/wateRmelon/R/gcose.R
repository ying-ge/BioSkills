gcose <-
function(x){ # gets a matrix of ss
   gcoms(x)/sqrt(ncol(x))
}
