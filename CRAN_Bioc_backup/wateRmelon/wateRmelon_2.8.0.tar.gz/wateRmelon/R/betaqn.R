betaqn <-
function(bn){

       normalizeQuantiles(bn)
}
