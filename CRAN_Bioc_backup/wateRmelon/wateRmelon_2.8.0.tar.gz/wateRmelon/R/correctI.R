correctI <-
function (BetaValues, SI, SII) {
    return(BetaValues)
}
