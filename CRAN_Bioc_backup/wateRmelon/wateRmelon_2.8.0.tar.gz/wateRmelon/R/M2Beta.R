M2Beta <-
function (M) 
{
    return((2^M)/(2^M + 1))
}
