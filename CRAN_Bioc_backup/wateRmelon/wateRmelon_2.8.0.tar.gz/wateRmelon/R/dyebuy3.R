danes <-
function(mn, un, onetwo, fudge=100, ret2=FALSE, ...){ 

  mnc <- dfsfit(mn, onetwo, ...)
  unc <- dfsfit(un, onetwo, ...)
  nanes (mnc, unc, onetwo, fudge, ret2, ...)   
}
