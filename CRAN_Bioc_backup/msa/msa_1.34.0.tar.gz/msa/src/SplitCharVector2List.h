//
// File SplitCharVector2List.h defining prototypes for SplitCharVector2List.cpp
//

#ifndef _SplitCharVector2List_H_

#define _SplitCharVector2List_H_

RcppExport SEXP SplitCharVector2List(SEXP xR);

#endif
