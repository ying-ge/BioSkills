setGeneric("version", function(object) standardGeneric("version"))

setGeneric("msaConsensusSequence",
           function(x, ...) standardGeneric("msaConsensusSequence"))

setGeneric("msaConservationScore",
           function(x, ...) standardGeneric("msaConservationScore"))
