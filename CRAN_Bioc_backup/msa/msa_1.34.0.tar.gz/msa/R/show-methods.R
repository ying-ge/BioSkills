setMethod("show", signature("MsaDNAMultipleAlignment"),
          function(object) print(object))
setMethod("show", signature("MsaRNAMultipleAlignment"),
          function(object) print(object))
setMethod("show", signature("MsaAAMultipleAlignment"),
          function(object) print(object))
