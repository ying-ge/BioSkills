#!/bin/bash
nohup R CMD BATCH tests-separate.R &
