#' @method summary metainf
#' @export

summary.metainf <- function(object, ...)
  object
