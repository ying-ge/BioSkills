#' @method summary metacum
#' @export

summary.metacum <- function(object, ...)
  object
