change.contr <- function(design, contrasts="contr.treatment"){
   qua.design(design, quantitative="none", contrasts=contrasts)
}

