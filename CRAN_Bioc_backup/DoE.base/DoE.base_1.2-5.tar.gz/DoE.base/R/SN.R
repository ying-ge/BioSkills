SN <- function(x){
    20*log10(mean(x)/sd(x))
}