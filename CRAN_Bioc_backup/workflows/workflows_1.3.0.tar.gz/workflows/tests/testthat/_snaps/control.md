# parsnip control is validated

    Code
      control_workflow(control_parsnip = 1)
    Condition
      Error in `control_workflow()`:
      ! `control_parsnip` must be a <control_parsnip> object.

