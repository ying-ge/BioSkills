#' geom_signif exported from ggsignif package
#'
#' See \code{ggsignif::\link[ggsignif:stat_signif]{geom_signif}} for details.
#'
#' @name geom_signif
#' @rdname geom_signif
#' @keywords internal
#' @export
#' @importFrom ggsignif geom_signif
NULL
