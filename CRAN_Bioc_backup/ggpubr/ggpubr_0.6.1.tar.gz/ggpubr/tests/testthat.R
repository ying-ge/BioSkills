library(testthat)
library(ggpubr)

test_check("ggpubr")
