library(testthat)
library(ggplot2)
library(ggtext)

test_check("ggtext")
