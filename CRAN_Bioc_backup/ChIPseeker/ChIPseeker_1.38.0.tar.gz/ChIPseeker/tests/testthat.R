library(testthat)
library(ChIPseeker)

test_check("ChIPseeker")
