library(testthat)
library(circRNAprofiler)

test_check("circRNAprofiler")
