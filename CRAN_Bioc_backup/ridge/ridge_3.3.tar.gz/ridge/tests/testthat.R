library(testthat)
library(ridge)

test_check("ridge")
