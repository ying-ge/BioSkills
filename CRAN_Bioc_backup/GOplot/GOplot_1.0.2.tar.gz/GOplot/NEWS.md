GOplot 1.0.2 (2016-03-29) 
----------------------------------------

* Add function 'reduce_overlap' to reduce the number of redundant terms and improve readability of plots

* Add parameter 'bg.col' to GOBubble() to enable panel background colour of facet plot 

* Add new plot function GOHeat()

* Fix various bugs of draw_table()


GOplot 1.0.1 (2015-07-15) 
----------------------------------------

* Fix various bugs of GOVenn()

* Fix bug of 'process.lable' argument in GOChord

* Adjust draw_table() to new release of gridExtra

* Add parameter 'limit' to chord_dat() to restrict the dimension of the binary martix