== Updating PWIZ

- Check out a copy of https://github.com/ProteoWizard/pwiz somewhere
- The pwiz version is in ./pwiz/Version.cpp, e.g. 3_0_20294

- Move old stuff away: 
  cp -avx pwiz pwiz-old
  git rm -rf pwiz

- 
