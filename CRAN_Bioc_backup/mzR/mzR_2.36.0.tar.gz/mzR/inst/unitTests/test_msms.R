test_ramp <- function() {

  filename <- system.file('iontrap/extracted.mzData', package = "msdata")

  ##   checkTrue(length(x1@env$msnMz) == length(x2@env$mz) + length(x3@env$mz))
  ##   checkTrue(all(x1@msnLevel[1:6]==2))
  ##   checkTrue(all(x1@msnScanindex[1:6] == x2@scanindex[1:6]))
  
}

