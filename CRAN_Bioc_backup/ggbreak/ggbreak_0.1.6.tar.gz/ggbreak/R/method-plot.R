##' @method plot ggbreak
##' @export
plot.ggbreak <- function(x, y, ...) {
    NextMethod()
}

##' @method plot ggwrap
plot.ggwrap <- function(x, y, ...){
    NextMethod()
}

##' @method plot ggcut
plot.ggcut <- function(x, y, ...){
    NextMethod()
}
