library(testthat)
library(incidence)

test_check("incidence")
