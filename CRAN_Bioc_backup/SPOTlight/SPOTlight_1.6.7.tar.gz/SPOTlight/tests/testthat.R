set.seed(321)
library(testthat)
library(SPOTlight)
# plotImage() ----
test_check("SPOTlight")
