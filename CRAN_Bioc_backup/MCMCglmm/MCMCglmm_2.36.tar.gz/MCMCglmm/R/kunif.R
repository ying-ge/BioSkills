kunif<-function(min, max, k){
    (((min-max)^k)+((max-min)^k))/((2^(k+1))*(k+1))
}
