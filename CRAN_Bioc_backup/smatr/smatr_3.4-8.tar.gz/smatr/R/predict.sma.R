predict.sma <- function(object,...){
  
  message("MA and SMA were not designed for prediction of Y nor X. Use fitted() if you must...")  
}