#' CNOlistToy
#'
#' Small in-silico case study used for demonstration. Use with PKN_ToyPB data.
#' 
#' @usage data(CNOlistToy)
"CNOlistToy"
