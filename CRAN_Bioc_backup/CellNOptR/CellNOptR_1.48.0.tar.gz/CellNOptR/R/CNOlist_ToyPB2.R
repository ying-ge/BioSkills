#' CNOlistToy2
#'
#' Small in-silico case study used for demonstration. Use with PKN_ToyPB2 data.
#' 
#' @usage data(CNOlistToy2)
"CNOlistToy2"
