#' pknmodel
#'
#' Small in-silico case study used for demonstration. Use with CNOlist_ToyPB data.
#' 
#' @usage data(PKN_ToyPB)
"pknmodel"
