library(testthat)
library(lolR)

test_check("lolR")
