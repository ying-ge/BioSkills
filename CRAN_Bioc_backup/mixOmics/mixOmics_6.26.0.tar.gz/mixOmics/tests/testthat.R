library(testthat)
library(mixOmics)

test_check("mixOmics")
