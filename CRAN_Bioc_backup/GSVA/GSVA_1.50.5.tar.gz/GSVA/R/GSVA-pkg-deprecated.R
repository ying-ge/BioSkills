## GSVA-pkg-deprecated.R
#' @title Deprecated functions in package `GSVA`.
#' @description The functions listed below are deprecated and will be defunct in
#'   the near future. When possible, alternative functions with similar
#'   functionality are also mentioned. Help pages for deprecated functions are
#'   available at [`gsva-deprecated`].
#' @name GSVA-pkg-deprecated
#' @keywords internal
NULL
