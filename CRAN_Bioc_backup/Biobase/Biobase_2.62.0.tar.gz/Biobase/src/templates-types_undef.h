#undef CONCAT
#undef CONCAT_MACROS

#undef METHOD_NAME

#undef X_C_TYPE
#undef X_IN_C
#undef X_ISNAN

#undef ANS_SXP
#undef ANS_NA
#undef ANS_C_TYPE
#undef ANS_IN_C

#undef X_TYPE
#undef ANS_TYPE

#undef MARGIN
