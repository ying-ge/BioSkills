pseudo.kFoldCrossValidation <- function(x,...){
  stop("the function pseudo.kFoldCrossValidation has to be written")
}
