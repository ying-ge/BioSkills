library("testthat")
library("SpatialExperiment")
test_check("SpatialExperiment")
