#ifndef WIN_R_BUILD
#if __cplusplus < 201402L
#error Error: ranger requires C++14. Possible fixes: 1) Update R, 2) Set "CXX = g++ -std=gnu++14" or similar in local Makevars, 3) update C++ compiler. See https://github.com/imbs-hl/ranger/wiki/FAQ. 
#endif
#endif

