

NEWS
=====
`spillover_match` has been added to provide simplified matching functionality between 
single stained controls and channels using a csv file that maps filenames to channels.

This is utilized by `spillover_ng`, which has been moved to `flowStats`.



flowCore
========

Core flow infrastructure

Install the devtools package and then do
`devtools::install_github("RGLab/flowCore")`

You may need to install other dependencies as well.
