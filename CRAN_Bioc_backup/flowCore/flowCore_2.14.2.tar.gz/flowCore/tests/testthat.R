library(testthat)
library(flowCore)
library(flowStats)


test_check("flowCore")

#devtools::test("~/rglab/workspace/flowCore")
