#' @importFrom pkgload parse_deps
#' @export
pkgload::parse_deps

#' @importFrom pkgload check_dep_version
#' @export
pkgload::check_dep_version
