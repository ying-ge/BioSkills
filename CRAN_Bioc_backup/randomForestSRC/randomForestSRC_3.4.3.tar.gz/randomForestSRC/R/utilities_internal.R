# internal-utils.R -- Dummy file for documentation linkage
# This file does not define actual functions. It exists to tie together 
# the manual documentation (man/internal-utils.Rd) with the exported names,
# preventing \"Undocumented object\" warnings during R CMD check.
NULL
