#ifndef  RF_ENTRY_GENERIC_H
#define  RF_ENTRY_GENERIC_H
void processDefaultGrow(void);
void processDefaultPredict(void);
#endif
