#ifndef RF_ERROR_H
#define RF_ERROR_H
void exit2R(void);
void printR(char *format, ...);
#endif
