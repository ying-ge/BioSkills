#ifndef RF_RFSRC_H
#define RF_RFSRC_H
void rfsrc(char mode, int seedValue);
#endif
