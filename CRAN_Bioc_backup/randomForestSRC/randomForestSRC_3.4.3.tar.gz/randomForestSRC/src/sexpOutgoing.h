#ifndef  RF_SEXP_OUTGOING_H
#define  RF_SEXP_OUTGOING_H
extern char  *RF_sexpString[];
#endif
