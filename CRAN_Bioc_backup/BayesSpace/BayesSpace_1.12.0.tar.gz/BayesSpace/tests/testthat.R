library(testthat)
library(BayesSpace)

test_check("BayesSpace")
