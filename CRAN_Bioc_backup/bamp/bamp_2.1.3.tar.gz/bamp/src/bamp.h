void bamp(int* cases, int* population, int* blocks, int* dims, double* vdb, int* mcnumbers, int* settings, double* ab);
