# linear regression grid reduction - glmnet

    Code
      min_grid(mod, data.frame(mixture = 1:3))
    Condition
      Error in `no_penalty()`:
      ! At least one penalty value is required for glmnet.

# logistic regression grid reduction - glmnet

    Code
      min_grid(mod, data.frame(mixture = 1:3))
    Condition
      Error in `no_penalty()`:
      ! At least one penalty value is required for glmnet.

# multinomial regression grid reduction - glmnet

    Code
      min_grid(mod, data.frame(mixture = 1:3))
    Condition
      Error in `no_penalty()`:
      ! At least one penalty value is required for glmnet.

