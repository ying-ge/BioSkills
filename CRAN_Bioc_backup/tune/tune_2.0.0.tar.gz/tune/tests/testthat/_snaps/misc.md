# empty ellipses

    Code
      tune:::empty_ellipses(a = 1)
    Condition
      Warning:
      The `...` are not used in this function but 1 object was passed: "a"

