library(testthat)
library(MultiAssayExperiment)

example("MultiAssayExperiment")

test_check("MultiAssayExperiment")
