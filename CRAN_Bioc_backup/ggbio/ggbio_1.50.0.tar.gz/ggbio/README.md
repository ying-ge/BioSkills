# INSTALL
[![R-CMD-check](https://github.com/lawremi/ggbio/workflows/R-CMD-check-and-coverage/badge.svg)](https://github.com/lawremi/ggbio/actions)
[![Codecov test
coverage](https://codecov.io/gh/lawremi/ggbio/branch/master/graph/badge.svg)](https://codecov.io/gh/lawremi/ggbio?branch=master)

    if (!requireNamespace("BiocManager", quietly=TRUE))
        install.packages("BiocManager")
    BiocManager::install("ggbio")
