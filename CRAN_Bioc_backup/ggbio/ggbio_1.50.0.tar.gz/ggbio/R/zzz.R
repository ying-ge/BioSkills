.onAttach <- function(...){
  tip <- "Need specific help about ggbio? try mailing \n the maintainer or visit https://lawremi.github.io/ggbio/"
  packageStartupMessage(tip)
}
