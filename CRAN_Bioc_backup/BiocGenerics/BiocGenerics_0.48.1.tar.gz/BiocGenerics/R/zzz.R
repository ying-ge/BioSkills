.test <- function() testPackage("BiocGenerics")

