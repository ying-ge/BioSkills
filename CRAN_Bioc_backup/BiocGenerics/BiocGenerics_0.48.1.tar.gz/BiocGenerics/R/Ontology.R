### =========================================================================
### The Ontology() generic
### -------------------------------------------------------------------------

setGeneric("Ontology", function(object) standardGeneric("Ontology"))

