### =========================================================================
### The dbconn() and dbfile() generics
### -------------------------------------------------------------------------
###

setGeneric("dbconn", function(x) standardGeneric("dbconn"))

setGeneric("dbfile", function(x) standardGeneric("dbfile"))
