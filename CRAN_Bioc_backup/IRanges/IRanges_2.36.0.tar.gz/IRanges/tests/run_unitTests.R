require("IRanges") || stop("unable to load IRanges package")
IRanges:::.test()
