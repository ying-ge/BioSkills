library(testthat)
library(miRBaseVersions.db)

test_check("miRBaseVersions.db")
