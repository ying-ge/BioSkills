library(testthat)
library(scran)
test_check("scran")
