#' @import methods
#' @import SingleCellExperiment
#' @importFrom Matrix t which colSums rowMeans
#' @importFrom Rcpp sourceCpp
#' @useDynLib scran
NULL
