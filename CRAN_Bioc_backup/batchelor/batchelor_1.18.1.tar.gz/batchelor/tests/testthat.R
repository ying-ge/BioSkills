library(testthat)
library(batchelor)
test_check("batchelor")
