#' @importFrom Rcpp sourceCpp
#' @useDynLib batchelor
NULL
