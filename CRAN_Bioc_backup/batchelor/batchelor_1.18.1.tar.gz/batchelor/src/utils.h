#ifndef UTILS_H
#define UTILS_H

#include "Rcpp.h"

// Check subset vector.

void check_subset_vector(Rcpp::IntegerVector, int);

#endif
