# This test corresponds to a single observation.
set.seed(1234)
ndraws_vec <- c(1, 5)
ncat_vec <- c(2, 3)
