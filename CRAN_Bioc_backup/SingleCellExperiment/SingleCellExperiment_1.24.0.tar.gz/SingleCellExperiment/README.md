# SingleCellExperiment Bioconductor Package

This is a clone of the Bioconductor repository for the SingleCellExperiment package.

## Package Status

|                |               |
| -------------- | ------------- |
| Project Status | [![Project Status: Active – The project has reached a stable, usable state and is being actively developed.](http://www.repostatus.org/badges/latest/active.svg)](http://www.repostatus.org/#active) |
| Travis CI      | [![Build Status](https://travis-ci.org/drisso/SingleCellExperiment.svg?branch=master)](https://travis-ci.org/drisso/SingleCellExperiment) |
| Test coverage  | [![Coverage](https://codecov.io/gh/drisso/SingleCellExperiment/branch/master/graph/badge.svg)](https://codecov.io/gh/drisso/SingleCellExperiment) |


## Installation and Usage

Please, see the [SingleCellExperiment](https://bioconductor.org/packages/SingleCellExperiment) Bioconductor page for details on how to install and use the package.
