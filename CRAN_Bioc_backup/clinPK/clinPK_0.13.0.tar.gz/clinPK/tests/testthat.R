library(testthat)
library(clinPK)

test_check("clinPK")
