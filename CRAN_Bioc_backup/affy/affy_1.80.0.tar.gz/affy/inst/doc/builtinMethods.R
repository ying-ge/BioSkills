### R code from vignette source 'builtinMethods.Rnw'

###################################################
### code chunk number 1: builtinMethods.Rnw:39-40
###################################################
library(affy)


###################################################
### code chunk number 2: builtinMethods.Rnw:48-49
###################################################
bgcorrect.methods()


###################################################
### code chunk number 3: builtinMethods.Rnw:99-100
###################################################
normalize.AffyBatch.methods()


###################################################
### code chunk number 4: builtinMethods.Rnw:175-176
###################################################
pmcorrect.methods()


###################################################
### code chunk number 5: builtinMethods.Rnw:199-200
###################################################
express.summary.stat.methods()


