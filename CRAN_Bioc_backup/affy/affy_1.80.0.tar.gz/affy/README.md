[<img src="https://www.bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="200" align="right"/>](https://bioconductor.org/)

**affy** is an R/Bioconductor package conaining methods for Affymetrix oligonucleotide arrays.

See https://bioconductor.org/packages/affy for more information including how to install the release version of the package (please refrain from installing directly from GitHub).
