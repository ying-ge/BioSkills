require("trackViewer") || stop("unable to load Package:trackViewer")
require("RUnit") || stop("unable to load Package:RUnit")
BiocGenerics:::testPackage("trackViewer")