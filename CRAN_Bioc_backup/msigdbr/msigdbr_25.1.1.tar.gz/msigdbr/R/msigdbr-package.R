#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import tibble
#' @import tidyselect
#' @importFrom assertthat assert_that
#' @importFrom lifecycle deprecated is_present
#' @importFrom methods is
#' @importFrom rlang .data check_installed inform is_installed
## usethis namespace: end
NULL
