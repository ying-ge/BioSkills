## ----echo=FALSE, results="hide"-----------------------------------------------
knitr::opts_chunk$set(error=FALSE, message=FALSE, warning=FALSE)

## -----------------------------------------------------------------------------
library(csaw)
if (interactive()) csawUsersGuide()

## -----------------------------------------------------------------------------
sessionInfo()

