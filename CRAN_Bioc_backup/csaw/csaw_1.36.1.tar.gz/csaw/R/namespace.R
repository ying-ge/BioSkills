#' @importFrom Rcpp sourceCpp
#' @import SummarizedExperiment
#' @import GenomicRanges
#' @import methods
#' @useDynLib csaw, .registration=TRUE, .fixes="cxx_"
NULL
