### R code from vignette source 'isobar-usecases.Rnw'

###################################################
### code chunk number 1: init
###################################################
  require(distr)
  require(ggplot2)


