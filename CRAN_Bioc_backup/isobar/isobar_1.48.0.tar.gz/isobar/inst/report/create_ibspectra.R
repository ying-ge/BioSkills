library(isobar)
properties.env <- load.properties()
isobar:::.create.or.load.ibspectra(properties.env)
