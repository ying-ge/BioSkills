library(testthat)
library(miRNAtap)

test_check("miRNAtap")
